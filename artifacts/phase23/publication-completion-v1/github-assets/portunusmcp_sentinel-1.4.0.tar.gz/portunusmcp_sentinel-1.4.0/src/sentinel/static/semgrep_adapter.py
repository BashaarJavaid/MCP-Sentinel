"""Pinned Semgrep CLI adapter for generic static pattern rules."""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
from importlib.metadata import PackageNotFoundError, version
from pathlib import Path
from typing import Any

import certifi

from sentinel.errors import InfrastructureError, TargetError
from sentinel.finding import SourceRange
from sentinel.static.model import StaticFileSet, StaticMatch

SEMGREP_VERSION = "1.176.0"
# Reserve space for the fixed flags/configs; Windows has a smaller command limit.
SEMGREP_BATCH_BYTES = 20_000 if os.name == "nt" else 100_000
SEMGREP_TIMEOUT_SECONDS = 10
TYPESCRIPT_CATALOG_RULE_ID = "typescript-tool-catalog"
_TYPESCRIPT_HYBRID_RULE_IDS = {
    "SENT-001",
    "SENT-003",
    "SENT-004",
    "SENT-006",
    "SENT-007",
}


def run_semgrep(
    files: StaticFileSet,
    selected_rule_ids: tuple[str, ...],
    scan_root: Path,
    *,
    deadline: float,
) -> dict[str, list[StaticMatch]]:
    """Run selected bundled Semgrep rules over deterministic file batches."""

    is_typescript = bool(files.typescript_files)
    supported = (
        {"SENT-002", "SENT-005", *_TYPESCRIPT_HYBRID_RULE_IDS}
        if is_typescript
        else {"SENT-002", "SENT-005"}
    )
    rule_ids = tuple(rule_id for rule_id in selected_rule_ids if rule_id in supported)
    catalog = is_typescript and TYPESCRIPT_CATALOG_RULE_ID in selected_rule_ids
    result_ids = (*rule_ids, *((TYPESCRIPT_CATALOG_RULE_ID,) if catalog else ()))
    results: dict[str, list[StaticMatch]] = {rule_id: [] for rule_id in result_ids}
    if not rule_ids and not is_typescript:
        return results
    _verify_semgrep_version()
    executable = shutil.which("semgrep")
    sibling = Path(sys.executable).with_name(
        "semgrep.exe" if Path(sys.executable).suffix.lower() == ".exe" else "semgrep"
    )
    if executable is None and sibling.is_file():
        executable = str(sibling)
    if executable is None:
        raise InfrastructureError("Semgrep executable is not available")

    paths = sorted(
        (
            *(item.path for item in files.python_files),
            *(item.path for item in files.typescript_files),
            *files.config_files,
        ),
        key=lambda path: path.as_posix(),
    )
    if not paths:
        return results
    config_root = Path(__file__).parent / "semgrep"
    configs = []
    if is_typescript and not catalog:
        configs.append(config_root / "typescript_parse_gate.yaml")
    for rule_id in rule_ids:
        name = rule_id.lower().replace("-", "")
        if rule_id == "SENT-005" or (
            rule_id == "SENT-002" and (files.python_files or not is_typescript)
        ):
            configs.append(config_root / f"{name}.yaml")
        if is_typescript and rule_id != "SENT-005":
            configs.append(config_root / f"{name}_typescript.yaml")
    if catalog:
        configs.append(config_root / "typescript_tool_catalog.yaml")
    environment = os.environ.copy()
    environment.update(
        {
            "SEMGREP_SEND_METRICS": "off",
            "SEMGREP_ENABLE_VERSION_CHECK": "0",
            "SSL_CERT_FILE": certifi.where(),
        }
    )
    batches: list[list[Path]] = [[]]
    size = 0
    for path in paths:
        cost = len(str(path).encode("utf-8")) + 3
        if batches[-1] and size + cost > SEMGREP_BATCH_BYTES:
            batches.append([])
            size = 0
        batches[-1].append(path)
        size += cost
    for batch in batches:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            raise InfrastructureError("static analysis timeout: deadline exceeded")
        with tempfile.TemporaryDirectory(prefix="sentinel-semgrep-") as directory:
            temporary_root = Path(directory)
            output = temporary_root / "results.json"
            environment.update(
                {
                    "SEMGREP_LOG_FILE": str(temporary_root / "semgrep.log"),
                    "SEMGREP_SETTINGS_FILE": str(temporary_root / "settings.yml"),
                }
            )
            command = [
                executable,
                "scan",
                "--json",
                "--output",
                str(output),
                "--jobs",
                "1",
                "--timeout",
                str(SEMGREP_TIMEOUT_SECONDS),
                "--metrics",
                "off",
                "--disable-version-check",
                "--disable-nosem",
            ]
            for config in configs:
                command.extend(("--config", str(config)))
            command.extend(str(path) for path in batch)
            try:
                completed = subprocess.run(
                    command,
                    check=False,
                    capture_output=True,
                    text=True,
                    encoding="utf-8",
                    timeout=remaining,
                    env=environment,
                    cwd=scan_root,
                )
            except (OSError, subprocess.TimeoutExpired) as error:
                raise InfrastructureError(
                    f"Semgrep execution failed: {error}"
                ) from error
            if completed.returncode not in {0, 1}:
                detail = completed.stderr.strip() or "unknown Semgrep failure"
                raise InfrastructureError(f"Semgrep execution failed: {detail}")
            if not output.is_file():
                detail = completed.stderr.strip() or "Semgrep wrote no JSON report"
                raise InfrastructureError(f"Semgrep execution failed: {detail}")
            payload = _parse_payload(
                output.read_text(encoding="utf-8"), typescript=is_typescript
            )
        _collect_results(payload, results, files, scan_root)
    return results


def _verify_semgrep_version() -> None:
    try:
        installed = version("semgrep")
    except PackageNotFoundError as error:
        raise InfrastructureError(
            f"Semgrep {SEMGREP_VERSION} is not installed"
        ) from error
    if installed != SEMGREP_VERSION:
        raise InfrastructureError(
            f"Semgrep version mismatch: expected {SEMGREP_VERSION}, found {installed}"
        )


def _parse_payload(raw: str, *, typescript: bool = False) -> dict[str, Any]:
    try:
        payload = json.loads(raw)
    except json.JSONDecodeError as error:
        raise InfrastructureError("Semgrep returned invalid JSON") from error
    if not isinstance(payload, dict) or not isinstance(payload.get("results"), list):
        raise InfrastructureError("Semgrep returned an unexpected JSON shape")
    if (
        payload.get("errors")
        and typescript
        and any(
            token in json.dumps(payload["errors"]).lower()
            for token in ("parse error", "syntax error")
        )
    ):
        raise TargetError("cannot parse TypeScript source")
    if payload.get("errors"):
        raise InfrastructureError(f"Semgrep reported scan errors: {payload['errors']}")
    return payload


def _collect_results(
    payload: dict[str, Any],
    results: dict[str, list[StaticMatch]],
    files: StaticFileSet,
    scan_root: Path,
) -> None:
    for item in payload["results"]:
        if not isinstance(item, dict):
            raise InfrastructureError("Semgrep result entry is not an object")
        extra = item.get("extra", {})
        metadata = extra.get("metadata", {}) if isinstance(extra, dict) else {}
        rule_id = metadata.get("sentinel_rule_id")
        if rule_id not in results:
            continue
        reported_path = Path(str(item.get("path", "")))
        raw_path = (scan_root / reported_path).resolve()
        relative = _relative_path(raw_path, files, scan_root)
        start = item.get("start", {})
        end = item.get("end", {})
        try:
            source_range = SourceRange(
                start_line=int(start["line"]),
                start_column=int(start["col"]),
                end_line=int(end["line"]),
                end_column=max(int(end["col"]), int(start["col"]) + 1),
            )
        except (KeyError, TypeError, ValueError) as error:
            raise InfrastructureError(
                "Semgrep returned an invalid source range"
            ) from error
        snippet = str(extra.get("lines", ""))
        results[rule_id].append(
            StaticMatch(
                rule_id=rule_id,
                path=relative,
                range=source_range,
                snippet=snippet,
                match_kinds=(str(item.get("check_id", "semgrep")),),
                captures=_captures(extra),
            )
        )


def _relative_path(
    path: Path,
    files: StaticFileSet,
    scan_root: Path,
) -> str:
    for python_file in files.python_files:
        if python_file.path == path:
            return python_file.relative_path
    for typescript_file in files.typescript_files:
        if typescript_file.path == path:
            return typescript_file.relative_path
    for config_file in files.config_files:
        if config_file == path:
            return path.relative_to(scan_root).as_posix()
    raise InfrastructureError(f"Semgrep returned an out-of-scope path: {path}")


def _captures(extra: dict[str, Any]) -> dict[str, str]:
    raw = extra.get("metavars", {})
    if not isinstance(raw, dict):
        return {}
    captures: dict[str, str] = {}
    for name, value in raw.items():
        if isinstance(value, dict) and isinstance(value.get("abstract_content"), str):
            captures[str(name)] = value["abstract_content"]
    return dict(sorted(captures.items()))
