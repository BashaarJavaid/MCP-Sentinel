"""Run MCP Sentinel as a Python module."""

from sentinel.cli import app

if __name__ == "__main__":
    app()
