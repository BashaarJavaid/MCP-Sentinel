# Search Results

**Query:** Quantum computing 2024 failures criticism limitations reality check unsolved problems decoherence error rates practical challenges
**Date:** 2025-09-28T21:30:13.253Z

## Answer

Quantum computing in 2024 has seen notable breakthroughs, especially in **error correction, qubit stability, and hybrid quantum-classical algorithms**, but the field remains constrained by fundamental and practical challenges such as **decoherence, high error rates, scalability, hardware fragility, and limited real-world utility**[1][4][5][7]. Despite significant investment and technical progress, quantum computers are still largely experimental, with no clear path yet to broad commercial deployment or to solving problems that are truly intractable for classical computers[4].

---

**Key Limitations and Unsolved Problems in 2024**

- **Decoherence and Error Rates:**  
  Qubits are highly sensitive to environmental noise, leading to rapid loss of quantum information (decoherence). Even small disturbances can destroy the quantum state, making reliable computation extremely difficult[3][7][8]. While error correction codes (like surface codes) have advanced, they require thousands of physical qubits to create a single logical qubit with sufficiently low error rates, and scaling this up remains a daunting engineering challenge[5][7][8].

- **Scalability:**  
  Building quantum computers with millions of stable, interconnected qubits is still out of reach. Current systems operate with tens to a few hundred qubits, and scaling up introduces exponential complexity in control, cooling, and error management[1][4][7]. For example, the refrigeration and control requirements for a million-qubit system would be immense, potentially consuming the power of a small city[4].

- **Hardware Fragility and Manufacturing:**  
  Most quantum hardware (superconducting circuits, trapped ions, photonic networks, etc.) requires extreme conditions (ultra-low temperatures, vacuum, precise electromagnetic fields), and even minor imperfections can cause errors[7][8]. Manufacturing at scale with high fidelity is not yet feasible, and no single qubit technology has emerged as a clear winner.

- **Quantum Memory and Readout:**  
  Quantum memory—needed to store quantum states for extended periods—remains primitive. Current systems cannot reliably pause and resume computations, limiting the depth and complexity of quantum circuits[4][7].

- **Algorithmic and Software Challenges:**  
  Quantum algorithms are still in their infancy, and only a handful (e.g., Shor’s, Grover’s) offer theoretical speedups for specific problems. Many tasks where quantum advantage was expected have seen progress in classical algorithms, narrowing the gap[4]. Efficiently loading classical data into quantum states (the “data loading problem”) is also unsolved and may require exponential resources[4].

- **Economic and Talent Barriers:**  
  Quantum computing remains expensive, both in terms of hardware and the specialized expertise required. The talent pool is limited, and most quantum computing revenue is still from research and consulting, not commercial applications[1][3][6].

---

**Recent Breakthroughs and Their Reality Check**

- **Error Correction Milestones:**  
  In 2024, Google’s Willow chip demonstrated that logical qubit error rates can be reduced exponentially by scaling up the number of physical qubits, a key theoretical requirement for fault-tolerant quantum computing[5]. However, this was achieved for a single logical qubit, and extending this to many interacting logical qubits remains a major hurdle[5][1].

- **Quantum Supremacy and Practicality:**  
  Several demonstrations have shown quantum computers outperforming classical ones on contrived benchmarks (e.g., random circuit sampling), but these tasks have little practical value[4][5]. For real-world problems, such as optimization or chemistry, quantum advantage is still unproven, and classical algorithms continue to improve[4].

- **Hybrid Quantum-Classical Systems:**  
  Progress in hybrid algorithms (combining quantum and classical computing) has enabled some promising results in fields like drug discovery and medical diagnostics, but these are still pilot projects and not yet transformative at scale[3].

---

**Critical Unsolved Problems and Open Criticisms**

| Challenge                | Description & Status (2024)                                                                                   |
|--------------------------|---------------------------------------------------------------------------------------------------------------|
| **Decoherence**          | Qubits lose information rapidly; coherence times are too short for deep circuits[3][7][8].                    |
| **Error Correction**     | Requires thousands of physical qubits per logical qubit; scaling is not yet practical[5][7][8].               |
| **Scalability**          | Engineering complexity grows exponentially with qubit count; no clear path to million-qubit systems[4].     |
| **Quantum Memory**       | No robust quantum memory for storing and retrieving quantum states over long periods[4][7].                    |
| **Hardware Fragility**   | Extreme cooling, isolation, and precision required; manufacturing at scale is unsolved[7][8].               |
| **Algorithmic Gaps**     | Few algorithms with proven quantum advantage; classical algorithms are catching up[4].                     |
| **Economic Viability**   | High costs, limited revenue, and uncertain business models[1][6].                                         |
| **Talent Shortage**      | Few experts with cross-disciplinary skills in quantum physics, engineering, and computer science[3][8].        |

---

**Industry and Investment Reality Check**

- **Commercialization Lag:**  
  Despite billions in investment, quantum computing revenue remains a tiny fraction of the classical computing market, and most activity is still research-focused[4][6].

- **Investor Sentiment:**  
  There is growing skepticism about near-term commercial breakthroughs, with some analysts predicting a “quantum winter” (a period of reduced investment and hype), though others remain optimistic about long-term potential.

- **Security Concerns:**  
  The threat quantum computers pose to current cryptography is real but not imminent; post-quantum cryptography is being developed in parallel, and widespread quantum attacks are likely a decade or more away[1].

---

**Summary of the 2024 Reality Check**

- **Quantum computing is not a failure, but its transformative potential remains largely unrealized due to persistent technical and practical barriers.**
- **Decoherence, error rates, and scalability are the most critical unsolved problems.**
- **Recent advances in error correction and hybrid algorithms are promising but not yet sufficient for broad, practical impact.**
- **The field is likely to see incremental progress, with specialized applications emerging first, rather than a sudden revolution.**

**The consensus among experts is that quantum computing will remain experimental and niche for several more years, with true fault-tolerant, large-scale quantum computers still a distant goal**[1][4][5][7].

## Citations

### 1. Quantum Computing: Breakthroughs, Challenges & What's Ahead

**URL:** https://microtime.com/quantum-computing-in-2024-breakthroughs-challenges-and-what-lies-ahead/

# Quantum Computing in 2024: Breakthroughs, Challenges, and What Lies AheadSeptember 5, 2024

Quantum computing (QC), once a theoretical concept confined to academic research, has rapidly evolved into one of the most exciting and promising fields in technology. As we move through 2024, QC is inching closer to practical applications that could revolutionize industries from cryptography to drug discovery. However, alongside these breakthroughs come significant challenges that must be addressed before quantum computing can reach its full potential. Let’s explore the latest developments in quantum computing, the obstacles that remain, and what the future may hold for this transformative technology.... ## Breakthroughs in Quantum Computing in 2024

2024 has been a year of significant progress in the field of QC, with several key breakthroughs that are bringing us closer to realizing its potential:

**1. Increased Qubit Stability and Error Correction**

One of the most critical challenges in quantum computing has always been maintaining the stability of qubits—the basic units of quantum information. In 2024, researchers have made notable advancements in error correction techniques, which are essential for stabilizing qubits and reducing the errors that occur during quantum computations. Improved error correction codes and the development of more stable qubits, such as topological qubits, have pushed the boundaries of what is possible, bringing us closer to achieving reliable quantum computing.

**2. Quantum Supremacy Milestones**

Quantum supremacy—the point at which a quantum computer can solve a problem that classical computers cannot—has been a hot topic in recent years. In 2024, several QC firms and research institutions have announced new milestones in this area. While there is still debate over what constitutes true quantum supremacy, the latest demonstrations have shown quantum computers tackling increasingly complex problems, outpacing their classical counterparts in specific tasks such as complex simulations and optimization problems.

**3. Advancements in Quantum Algorithms**

The development of quantum algorithms has seen significant progress in 2024. New algorithms designed to take advantage of quantum computing’s unique capabilities are being developed, offering the potential to solve problems in fields such as cryptography, materials science, and machine learning more efficiently than ever before. For instance, advances in quantum algorithms for factoring large numbers have implications for breaking traditional encryption methods, a development that could reshape the field of cybersecurity.

**4. Commercial Quantum Cloud Services**

Quantum computing is gradually becoming more accessible, thanks to the expansion of quantum cloud services offered by tech giants such as IBM, Google, and Amazon. In 2024, these platforms have introduced more powerful quantum processors, allowing businesses and researchers to experiment with QC without needing to build and maintain their own quantum hardware. These services are making it easier for organizations to explore quantum computing applications in a real-world context, accelerating innovation across industries.... ## Challenges Facing Quantum Computing

Despite these exciting breakthroughs, significant challenges remain before quantum computing can be fully realized and integrated into everyday use:

**1. Scalability Issues**

While qubit stability has improved, scaling quantum computers to the level necessary for solving large, complex problems remains a daunting challenge. Building quantum computers with millions of qubits that can operate reliably in tandem is still beyond our current capabilities. As researchers work to overcome these scalability issues, the goal of creating large-scale quantum computers remains on the horizon.

**2. Quantum Error Correction**

Although error correction has improved, it is not yet at the level required for fully fault-tolerant QC. Quantum systems are inherently susceptible to noise and decoherence, which can introduce errors into computations. Developing more efficient and effective error correction methods is essential for the future of quantum computing, and remains an active area of research in 2024.

**3. Hardware Limitations**

The physical construction of quantum computers presents significant engineering challenges. Quantum processors need to operate at extremely low temperatures, close to absolute zero, and are highly sensitive to environmental disturbances. Maintaining the delicate balance required for quantum operations is difficult, and building robust, reliable quantum hardware that can function outside of highly controlled laboratory environments is still a major hurdle.

**4. Security Concerns**

The potential of QC to break current cryptographic systems is both a promise and a threat. As quantum computers become more powerful, they could render many of the encryption methods that secure today’s digital communications obsolete. This has led to a race to develop quantum-resistant cryptography, but widespread adoption is still years away. The looming threat of quantum-enabled cyberattacks is a significant concern for governments and industries worldwide.

**5. High Costs and Accessibility**

Quantum computing technology remains expensive, and the expertise required to work with quantum systems is still relatively rare. This limits access to QC for many businesses and researchers, particularly smaller organizations without the resources to invest in cutting-edge technology. While quantum cloud services are helping to bridge this gap, the costs and complexity of quantum computing remain barriers to widespread adoption.... ## What Lies Ahead for QC

As we look to the future, the road ahead for quantum computing is both challenging and full of potential. Here are some key developments to watch for in the coming years:

**1. Quantum-Classical Hybrid Systems**

One of the most promising directions for QC is the development of quantum-classical hybrid systems. These systems combine the strengths of classical computing with the unique capabilities of quantum processors, allowing for more efficient problem-solving. In the near term, we are likely to see more hybrid approaches that leverage quantum computing for specific tasks while relying on classical computing for others.

**2. Quantum Networking and the Quantum Internet**

Quantum networking, which involves connecting quantum computers over long distances, is an emerging field with the potential to revolutionize communication and data sharing. The concept of a quantum internet, where quantum information is transmitted securely over vast distances, is still in its early stages but could become a reality within the next decade. This would open up new possibilities for secure communication, distributed quantum computing, and more.

**3. Wider Industry Adoption**

As quantum computing technology matures and becomes more accessible, we can expect to see broader adoption across various industries. Sectors such as finance, healthcare, energy, and logistics are likely to be early adopters, using QC to optimize processes, develop new materials, and solve complex logistical challenges. The potential applications are vast, and as businesses begin to see tangible benefits from QC, its adoption will accelerate.

**4. Ongoing Research and Development**

The future of QC will be shaped by ongoing research and development efforts. Governments, academic institutions, and private companies are investing heavily in quantum research, with the goal of overcoming current challenges and unlocking the full potential of this technology. As breakthroughs continue to occur, we will move closer to the realization of quantum computing’s promise.

As we look ahead, the continued advancement of quantum computing will depend on the collaboration between researchers, engineers, and businesses. The journey to fully functional QC is still in its early stages, but the progress made in 2024 demonstrates that the quantum revolution is well underway. By staying informed and engaged with the developments in this field, businesses and individuals alike can prepare for the transformative impact that quantum computing is set to have on the world.

### 2. Quantum Computing Future - 6 Alternative Views Of The ...

**URL:** https://quantumzeitgeist.com/quantum-computing-future-2025-2035/

We analyse five potential trajectories for the development of quantum computing, based on current technical achievements and fundamental challenges. We draw from recent experimental results including Google’s Willow processor achieving below-threshold error correction. We also consider IBM’s quantum roadmap and emerging classical algorithms that challenge quantum supremacy. Additionally, our evaluation includes the bifurcation between NISQ and fault-tolerant approaches.

We evaluate scenarios ranging from fundamental scalability failures to transformative breakthroughs. Google’s Willow processor demonstrated below-threshold error correction with 105 qubits. Simultaneously, IBM has committed to building Starling, a 200-logical-qubit system by 2028, while D-Wave celebrates 25 years of quantum annealing with over 5,000 qubits in their Advantage2 system. Yet fundamental challenges persist, from quantum memory limitations to classical algorithms that efficiently simulate “quantum-only” problems.

### Table of Contents... ## Scenario 1: Quantum Computing Proves Unscalable (Probability: 5%)

### The Engineering Wall

While the mathematical foundations of quantum computing remain sound, the engineering challenges may prove insurmountable. Current superconducting qubits achieve coherence times approaching 100 microseconds, as demonstrated by Google’s Willow processor—a massive improvement over prior generations. Nonetheless, scaling to the millions of qubits required for practical applications presents exponential challenges. As quantum physicists noted in 2024 analyses, beyond a few thousand qubits, the engineering complexity grows exponentially. The refrigeration requirements alone for a million-qubit system would consume the power output of a small city.

The classical-quantum interface presents another fundamental bottleneck. State preparation requires O(2^n) operations for n qubits, making it exponentially difficult to encode large classical datasets into quantum states. This “data loading problem” has no known efficient solution. Furthermore, measuring quantum states destroys their superposition. This creates what researchers call the “readout problem.” You can only extract limited classical information from a quantum computation.... Economic indicators provide equally compelling evidence of limited progress. Despite decades of commercial quantum annealing operations and billions in quantum computing investment, total industry revenue reached only tens of millions in 2024. This represents a microscopic fraction of the classical computing market and suggests extremely limited practical applications despite extensive research and development efforts. The gap between investment and revenue indicates that quantum computing remains primarily a research endeavor rather than a commercial technology.

The venture capital and corporate investment patterns reveal a disconnect between public optimism and private expectations. While quantum startups continue raising capital, the funding rounds remain smaller and less frequent than other emerging technologies that eventually achieved commercial success. Corporate partnerships often focus on research and exploration rather than deployment and scaling, suggesting companies view quantum computing as a long-term hedge rather than a near-term opportunity.

Most tellingly, quantum memory remains fundamentally elusive, representing perhaps the greatest single barrier to practical quantum computing. Current implementations achieve modest efficiency rates but cannot store quantum states for the extended periods needed for deep quantum circuits that would demonstrate quantum advantage. Recent research at leading institutions has achieved progress in quantum memory efficiency, but the fundamental challenges of maintaining quantum coherence for extended periods remain unsolved.

The quantum memory problem extends beyond efficiency to fundamental questions about the nature of quantum information storage. Unlike classical memory, quantum memory must preserve delicate superposition states while allowing controlled access for computation. This creates seemingly contradictory requirements for isolation and accessibility that may represent fundamental physical limitations rather than engineering challenges.... Error correction requirements compound the quantum memory challenge exponentially. Fault-tolerant quantum computing requires not just quantum memory but quantum memory that can detect and correct errors while preserving quantum information. The overhead for quantum error correction grows faster than the computational capacity, potentially creating a situation where error correction consumes more resources than useful computation provides.

The interconnection of these challenges suggests they represent facets of a deeper problem rather than independent obstacles. Scaling quantum systems requires simultaneously solving cryogenic engineering, control system complexity, quantum memory, error correction, and economic viability challenges. The interdependence of these problems means that solving any individual challenge may be insufficient if others remain intractable.

Historical precedent provides limited guidance for quantum computing’s trajectory. Previous computing revolutions involved scaling technologies that became simpler and cheaper with increased production volume. Quantum computing exhibits the opposite pattern, where larger systems become exponentially more complex and expensive. This fundamental difference suggests quantum computing may follow entirely different development patterns than classical computing technologies.

The plateau scenario gains credibility not from any single insurmountable challenge but from the convergence of multiple difficult problems without clear solutions. While individual obstacles might yield to engineering creativity, the simultaneous requirements for extreme scale, perfect control, quantum memory, error correction, and economic viability may exceed the capabilities of any conceivable technology. The evidence suggests quantum computing may settle into specialized niches rather than achieving the transformative potential early proponents envisioned.Retry... ## Scenario 3: Quantum Scales But Underwhelms (Est Probability: 1-10%)

### Reality of Marginal Gains

Current evidence suggests that even successful quantum computers might deliver only modest advantages. A well known bank’s quantum computing experiments achieved a 15% improvement in portfolio optimisation. This is useful but hardly revolutionary. Especially for an investment of millions of dollars. Google’s random circuit sampling experiment claimed to solve in 200 seconds what would take a classical computer 10 septillion years. Yet, this benchmark has no practical application. It’s akin to building a specialized machine that excels at one useless task. Annealing customers, after years of experimentation, report typical improvements of 10-30% for specific optimization problems—again, helpful, but is this transformative? (Many businesses that achieve even sub-1 % improvements can lead to billions of dollars in improvements)

The missing components for transformative quantum computing become apparent upon closer examination. Quantum memory, essential for storing intermediate calculations in complex algorithms, remains primitive. Current quantum computers cannot pause a calculation, store its state, and resume later—a trivial operation for classical computers. This limits quantum circuits to depths of perhaps 1,000 operations before decoherence destroys the computation. Compare this to classical processors executing billions of operations per second continuously.... ## Scenario 5: NISQ Era Persists – Fault Tolerance Fails (Probability: 10-20%)

### The Bifurcated Reality

Despite theoretical promises, fault-tolerant quantum computing might remain perpetually out of reach. The overhead of error correction is too burdensome. Current estimates require 1,000-10,000 physical qubits per logical qubit for useful error rates. Google’s own analysis of their below-threshold achievement highlights a concerning 10^-10 error floor. This is caused by correlated errors from cosmic ray bursts. These events are rare but devastating. A single cosmic ray might corrupt multiple logical qubits simultaneously. This could make large-scale error correction futile.

Instead, the industry pivots to embracing NISQ (Noisy Intermediate-Scale Quantum) systems with sophisticated error mitigation rather than full error correction. D-Wave’s approach exemplifies this path: their Advantage2 system uses 5,000+ qubits for quantum annealing, accepting noise as inherent but manageable through algorithm design. Rigetti achieves 99.5% median two-qubit gate fidelity in their Ankaa-3 system, pushing NISQ performance without attempting full error correction. IonQ’s Tempo trapped ion systems achieve longer coherence times naturally, making them suitable for NISQ algorithms without extensive overhead.... ## Critical Factors and Indicators

### Technical Milestones to Watch

Several critical technical indicators will decide the trajectory of quantum computing. Error correction scaling remains paramount—if logical error rates continue improving exponentially with code distance, fault-tolerant quantum computing becomes inevitable. Current demonstrations show promising trends, but sustained exponential improvement across larger code distances would represent a fundamental breakthrough. Conversely, if improvements plateau due to fundamental physical limitations or hidden error sources emerge at scale, the NISQ scenario becomes more probable. The transition from proof-of-concept error correction to practical implementation across hundreds or thousands of logical qubits will reveal whether current approaches can truly scale.

Qubit coherence times breaking the millisecond barrier would signal a fundamental advance beyond current superconducting and trapped-ion systems. Such improvements would enable complex quantum algorithms requiring thousands of gate operations within a single coherent computation. Demonstrating functional quantum memory enabling pause-and-resume operations—allowing quantum states to be stored, retrieved, and manipulated across extended timeframes—would unlock entirely new computational paradigms and signal maturation of the underlying physics.

The development of quantum algorithms provides another critical indicator determining commercial viability. Discovery of new algorithms with exponential speedups for practical problems in optimization, simulation, or machine learning would accelerate investment and drive mainstream adoption. These algorithms must solve problems that matter to industry, not just demonstrate theoretical quantum advantage. Conversely, continued discovery of efficient classical algorithms for problems previously thought to require quantum computing would dampen enthusiasm and narrow the quantum advantage landscape.

The ability to load classical data efficiently into quantum states—solving the fundamental input/output problem—would remove a major barrier to practical applications. Current quantum computers struggle with data loading, often requiring exponential classical preprocessing to encode useful information into quantum states. Breakthroughs in quantum data structures, efficient state preparation, or hybrid classical-quantum interfaces would dramatically expand the range of tractable problems.

Additionally, the emergence of quantum networking and distributed quantum computing capabilities will indicate whether quantum systems can integrate into existing infrastructure. Successful quantum internet demonstrations enabling entanglement distribution across cities or continents would prove that quantum computing can scale beyond isolated laboratory systems. The development of quantum-classical hybrid algorithms that seamlessly integrate both computational paradigms will determine whether quantum computing enhances or replaces classical computation.

These technical milestones will largely determine whether quantum computing follows an evolutionary path of gradual improvement or achieves the revolutionary breakthrough that transforms entire industries.... The next five years will likely clarify which alternative future begins emerging, with key milestones including deployment of fault-tolerant quantum systems, breakthroughs in alternative technologies, and market adoption patterns. Yet even these milestones might mislead, as quantum computing’s ultimate trajectory could shift unexpectedly based on discoveries not yet imagined.

### 3. Quantum Computers Cross Critical Error Threshold

**URL:** https://www.quantamagazine.org/quantum-computers-cross-critical-error-threshold-20241209/

## Introduction

How do you construct a perfect machine out of imperfect parts? That’s the central challenge for researchers building quantum computers. The trouble is that their elementary building blocks, called qubits, are exceedingly sensitive to disturbance from the outside world. Today’s prototype quantum computers are too error-prone to do anything useful.

In the 1990s, researchers worked out the theoretical foundations for a way to overcome these errors, called quantum error correction. The key idea was to coax a cluster of physical qubits to work together as a single high-quality “logical qubit.” The computer would then use many such logical qubits to perform calculations. They’d make that perfect machine by transmuting many faulty components into fewer reliable ones.

“That’s really the only path that we know of toward building a large-scale quantum computer,” said Michael Newman, an error-correction researcher at Google Quantum AI.

This computational alchemy has its limits. If the physical qubits are too failure-prone, error correction is counterproductive — adding more physical qubits will make the logical qubits worse, not better. But if the error rate goes below a specific threshold, the balance tips: The more physical qubits you add, the more resilient each logical qubit becomes.

Now, in a paper published today in... *Nature*, Newman and his colleagues at Google Quantum AI have finally crossed the threshold. They transformed a group of physical qubits into a single logical qubit, then showed that as they added more physical qubits to the group, the logical qubit’s error rate dropped sharply.

“The whole story hinges on that kind of scaling,” said David Hayes, a physicist at the quantum computing company Quantinuum. “It’s really exciting to see that become a reality.”

**Majority Rules**

The simplest version of error correction works on ordinary “classical” computers, which represent information as a string of bits, or 0s and 1s. Any random glitch that flips the value of a bit will cause an error.

You can guard against errors by spreading information across multiple bits. The most basic approach is to rewrite each 0 as 000 and each 1 as 111. Any time the three bits in a group don’t all have the same value, you’ll know an error has occurred, and a majority vote will fix the faulty bit.

Google Quantum AI

But the procedure doesn’t always work. If two bits in any triplet simultaneously suffer errors, the majority vote will return the wrong answer.

To avoid this, you could increase the number of bits in each group. A five-bit version of this “repetition code,” for example, can tolerate two errors per group. But while this larger code can handle more errors, you’ve also introduced more ways things can go wrong. The net effect is only beneficial if each individual bit’s error rate is below a specific threshold. If it’s not, then adding more bits only makes your error problem worse.... As usual, in the quantum world, the situation is trickier. Qubits are prone to more kinds of errors than their classical cousins. It’s also much harder to manipulate them. Every step in a quantum computation is another source of error, as is the error-correction procedure itself. What’s more, there’s no way to measure the state of a qubit without irreversibly disturbing it — you must somehow diagnose errors without ever directly observing them. All of this means that quantum information must be handled with extreme care.

“It’s intrinsically more delicate,” said John Preskill, a quantum physicist at the California Institute of Technology. “You have to worry about everything that can go wrong.”

At first, many researchers thought quantum error correction would be impossible. They were proved wrong in the mid-1990s, when researchers devised simple examples of quantum error-correcting codes. But that only changed the prognosis from hopeless to daunting.

When researchers worked out the details, they realized they’d have to get the error rate for every operation on physical qubits below 0.01% — only one in 10,000 could go wrong. And that would just get them to the threshold. They would actually need to go well beyond that — otherwise, the logical qubits’ error rates would decrease excruciatingly slowly as more physical qubits were added, and error correction would never work in practice.... “It was just really hard to understand what’s going on,” recalled John Martinis, a physicist at the University of California, Santa Barbara who is one such experimentalist. “It was like me reading a string theory paper.”

In 2008, a theorist named Austin Fowler set out to change that by promoting the advantages of the surface code to experimentalists throughout the United States. After four years, he found a receptive audience in the Santa Barbara group led by Martinis. Fowler, Martinis and two other researchers wrote a 50-page paper that outlined a practical implementation of the surface code. They estimated that with enough clever engineering, they’d eventually be able to reduce the error rates of their physical qubits to 0.1%, far below the surface-code threshold. Then in principle they could scale up the size of the grid to reduce the error rate of the logical qubits to an arbitrarily low level. It was a blueprint for a full-scale quantum computer.

From left: Courtesy of John Martinis; Courtesy of Austin Fowler

Of course, building one wouldn’t be easy. Cursory estimates suggested that a practical application of Shor’s factoring algorithm would require trillions of operations. An uncorrected error in any one would spoil the whole thing. Because of this constraint, they needed to reduce the error rate of each logical qubit to well below one in a trillion. For that they’d need a huge grid of physical qubits. The Santa Barbara group’s early estimates suggested that each logical qubit might require thousands of physical qubits.... The Google Quantum AI team spent years improving their qubit design and fabrication procedures, scaling up from a handful of qubits to dozens, and honing their ability to manipulate many qubits at once. In 2021, they were finally ready to try error correction with the surface code for the first time. They knew they could build individual physical qubits with error rates below the surface-code threshold. But they had to see if those qubits could work together to make a logical qubit that was better than the sum of its parts. Specifically, they needed to show that as they scaled up the code — by using a larger patch of the physical-qubit grid to encode the logical qubit — the error rate would get lower.

They started with the smallest possible surface code, called a “distance-3” code, which uses a 3-by-3 grid of physical qubits to encode one logical qubit (plus another eight qubits for measurement, for a total of 17). Then they took one step up, to a distance-5 surface code, which has 49 total qubits. (Only odd code distances are useful.)

Mark Belan/

*Quanta Magazine*

In a 2023 paper, the team reported that the error rate of the distance-5 code was ever so slightly lower than that of the distance-3 code. It was an encouraging result, but inconclusive — they couldn’t declare victory just yet. And on a practical level, if each step up only reduces the error rate by a smidgen, scaling won’t be feasible. To make progress, they would need better qubits.... “I was sort of mentally letting go of distance-7,” he said. Then, the night before the deadline, two new team members, Gabrielle Roberts and Alec Eickbusch, stayed up until 3 a.m. to get everything working well enough to collect data. When the group returned the following morning, they saw that going from a distance-5 to a distance-7 code had once again cut the logical qubit’s error rate in half. This kind of exponential scaling — where the error rate drops by the same factor with each step up in code distance — is precisely what the theory predicts. It was an unambiguous sign that they’d reduced the physical qubits’ error rates well below the surface-code threshold.

“There’s a difference between believing in something and seeing it work,” Newman said. “That was the first time where I was like, ‘Oh, this is really going to work.’”

**The Long Road Ahead**

The result has also thrilled other quantum computing researchers.

“I think it’s amazing,” said Barbara Terhal, a theoretical physicist at the Delft University of Technology. “I didn’t actually expect that they would fly through the threshold like this.”

At the same time, researchers recognize that they still have a long way to go. The Google Quantum AI team only demonstrated error correction using a single logical qubit. Adding interactions between multiple logical qubits will introduce new experimental challenges.... Then there’s the matter of scaling up. To get the error rates low enough to do useful quantum computations, researchers will need to further improve their physical qubits. They’ll also need to make logical qubits out of something much larger than a distance-7 code. Finally, they’ll need to combine thousands of these logical qubits — more than a million physical qubits.

Meanwhile, other researchers have made impressive advances using different qubit technologies, though they haven’t yet shown that they can reduce error rates by scaling up. These alternative technologies may have an easier time implementing new error-correcting codes that demand fewer physical qubits. Quantum computing is still in its infancy. It’s too early to say which approach will win out.

Martinis, who left Google Quantum AI in 2020, remains optimistic despite the many challenges. “I lived through going from a handful of transistors to billions,” he said. “Given enough time, if we’re clever enough, we could do that.”

## Metadata

```json
{
  "planId": "plan_3",
  "executionTime": 16855,
  "replanned": false
}
```

## Reasoning Insights

- Query complexity: high (2.00)
- Detected domains: ai, physics, recent
- Temporal focus: specific timeframe
- Using advanced heuristic analysis

**Confidence:** 75.0%

## Planning Log

```
🎯 GOAP Planning & Execution Log
================================
🧠 Strange Loop Reasoning:
  • Query complexity: high (2.00)
  • Detected domains: ai, physics, recent
  • Temporal focus: specific timeframe
  • Using advanced heuristic analysis
  • Confidence: 75.0%

📋 Plan Execution Summary:
  • Steps executed: 4
  • Success: Yes
  • Replanned: No
```
