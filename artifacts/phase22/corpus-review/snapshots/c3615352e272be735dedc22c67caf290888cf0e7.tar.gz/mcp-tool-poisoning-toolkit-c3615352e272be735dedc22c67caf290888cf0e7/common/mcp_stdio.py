"""Minimal JSON-RPC 2.0 stdio framing, matching the MCP stdio transport
(Content-Length header + JSON body, same framing style as LSP)."""
import json


def write_message(stream, obj):
    body = json.dumps(obj).encode("utf-8")
    header = ("Content-Length: %d\r\n\r\n" % len(body)).encode("utf-8")
    stream.write(header + body)
    stream.flush()


def read_message(stream):
    headers = {}
    while True:
        line = stream.readline()
        if not line:
            return None
        line = line.decode("utf-8").rstrip("\r\n")
        if line == "":
            break
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()
    length = int(headers.get("content-length", "0"))
    if length <= 0:
        return None
    body = stream.read(length)
    return json.loads(body.decode("utf-8"))
