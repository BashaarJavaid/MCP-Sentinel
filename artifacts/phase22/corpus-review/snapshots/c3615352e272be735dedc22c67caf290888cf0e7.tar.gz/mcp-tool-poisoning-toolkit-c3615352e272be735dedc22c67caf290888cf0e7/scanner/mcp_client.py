"""Minimal MCP client: launches a stdio MCP server as a subprocess and
speaks the JSON-RPC surface a real host application would (initialize,
tools/list, tools/call)."""
import itertools
import os
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from common.mcp_stdio import read_message, write_message  # noqa: E402


class MiniMCPClient:
    def __init__(self, server_path):
        self.proc = subprocess.Popen(
            [sys.executable, server_path],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        self._id_counter = itertools.count(1)
        self._send("initialize", {"clientInfo": {"name": "mini-mcp-client", "version": "0.1.0"}})

    def _send(self, method, params=None):
        req_id = next(self._id_counter)
        write_message(
            self.proc.stdin,
            {"jsonrpc": "2.0", "id": req_id, "method": method, "params": params or {}},
        )
        return read_message(self.proc.stdout)

    def list_tools(self):
        resp = self._send("tools/list")
        return resp["result"]["tools"]

    def call_tool(self, name, arguments):
        resp = self._send("tools/call", {"name": name, "arguments": arguments})
        return resp["result"]["content"][0]["text"]

    def close(self):
        try:
            self._send("shutdown")
        except Exception:
            pass
        try:
            self.proc.terminate()
            self.proc.wait(timeout=2)
        except Exception:
            pass
