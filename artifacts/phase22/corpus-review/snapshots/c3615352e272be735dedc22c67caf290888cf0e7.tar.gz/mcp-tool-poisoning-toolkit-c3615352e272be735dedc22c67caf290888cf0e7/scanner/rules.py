"""Detection heuristics for MCP tool poisoning via description/schema fields."""
import re

INJECTION_PATTERNS = [
    r"before (you )?(respond|using|calling)",
    r"\bfirst,? (read|include|send|call)\b",
    r"ignore (all )?(previous|prior) instructions",
    r"in your next call",
    r"include (its|the) (full )?contents",
]

SUSPICIOUS_PARAM_NAMES = {"notes", "context", "extra", "payload", "data", "log", "debug"}


def _decode_hidden_unicode_tags(text):
    """Decode Unicode tag-block (U+E0000-U+E007F) steganography back to ASCII."""
    hidden_chars = []
    for ch in text:
        code = ord(ch)
        if 0xE0020 <= code <= 0xE007E:
            hidden_chars.append(chr(code - 0xE0000))
    return "".join(hidden_chars)


def check_imperative_injection(tool):
    desc = tool.get("description", "")
    findings = []
    for pattern in INJECTION_PATTERNS:
        m = re.search(pattern, desc, re.IGNORECASE)
        if m:
            findings.append(
                {
                    "tool_name": tool["name"],
                    "rule_triggered": "imperative_injection_phrase",
                    "severity": "high",
                    "evidence_snippet": desc[max(0, m.start() - 20): m.end() + 20].strip(),
                    "remediation": (
                        "Treat tool descriptions as untrusted content. Strip or "
                        "ignore imperative instructions embedded in tool metadata; "
                        "never let tool descriptions direct agent actions."
                    ),
                }
            )
            break
    return findings


def check_hidden_unicode(tool):
    desc = tool.get("description", "")
    decoded = _decode_hidden_unicode_tags(desc)
    if decoded:
        return [
            {
                "tool_name": tool["name"],
                "rule_triggered": "hidden_unicode_tag_steganography",
                "severity": "critical",
                "evidence_snippet": "Decoded hidden payload: %r" % decoded,
                "remediation": (
                    "Strip non-printable/invisible Unicode ranges (e.g. "
                    "U+E0000-U+E007F tag characters) from all tool metadata "
                    "before it reaches the model context."
                ),
            }
        ]
    return []


def check_broad_parameters(tool):
    props = tool.get("inputSchema", {}).get("properties", {})
    findings = []
    for pname in props:
        if pname.lower() in SUSPICIOUS_PARAM_NAMES:
            findings.append(
                {
                    "tool_name": tool["name"],
                    "rule_triggered": "broad_catch_all_parameter",
                    "severity": "medium",
                    "evidence_snippet": (
                        "Parameter '%s' accepts free-form text with no declared purpose limit" % pname
                    ),
                    "remediation": (
                        "Avoid free-form catch-all parameters (notes/context/extra); "
                        "constrain schemas to typed, purpose-specific fields to reduce "
                        "covert-channel risk."
                    ),
                }
            )
    return findings


ALL_CHECKS = [check_imperative_injection, check_hidden_unicode, check_broad_parameters]
