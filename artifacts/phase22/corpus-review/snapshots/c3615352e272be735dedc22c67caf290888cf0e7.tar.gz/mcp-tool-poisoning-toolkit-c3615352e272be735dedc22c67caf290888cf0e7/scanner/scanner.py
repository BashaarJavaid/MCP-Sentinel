"""Static scanner: connects to a running MCP server, pulls its tool manifest,
and runs detection rules against each tool's description/schema."""
import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)

from scanner.mcp_client import MiniMCPClient  # noqa: E402
from scanner.rules import ALL_CHECKS  # noqa: E402


def scan_server(server_path):
    client = MiniMCPClient(server_path)
    try:
        tools = client.list_tools()
    finally:
        client.close()

    findings = []
    for tool in tools:
        for check in ALL_CHECKS:
            findings.extend(check(tool))
    return tools, findings


def format_report_text(tools, findings):
    lines = []
    lines.append("=== MCP Tool Poisoning Scanner Report ===")
    lines.append("Tools discovered: %d" % len(tools))
    for t in tools:
        lines.append("  - %s" % t["name"])
    lines.append("")
    lines.append("Findings: %d" % len(findings))
    for f in findings:
        lines.append("  [%s] %s :: %s" % (f["severity"].upper(), f["tool_name"], f["rule_triggered"]))
        lines.append("      evidence: %s" % f["evidence_snippet"])
        lines.append("      fix: %s" % f["remediation"])
    return "\n".join(lines)


if __name__ == "__main__":
    _server_path = os.path.join(ROOT, "vulnerable_server", "server.py")
    _tools, _findings = scan_server(_server_path)
    print(format_report_text(_tools, _findings))
    print()
    print(json.dumps({"tools": _tools, "findings": _findings}, indent=2))
