import collections,datetime,hashlib,json,xml.etree.ElementTree as ET
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration'
read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read('v19-source-verification.json');seal=read('evidence-v48.json');prior=read('v18-closeout-audit/packet.json');head=v['source']
counts={}
for case in ET.parse(b/'v19-final-full-suite-junit.xml').iter('testcase'):
 name=case.attrib['classname'];path=name.replace('.','/')+'.py'
 if not (root/path).is_file():continue
 state='failed' if case.find('failure') is not None or case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
 row=counts.setdefault(path,{});row[state]=row.get(state,0)+1
assert sum(r.get('passed',0) for r in counts.values())==2194
assert sum(r.get('skipped',0) for r in counts.values())==36
assert not any(r.get('failed',0) for r in counts.values())
rows=[]
for old in prior['requirements']:
 row={'id':old['id'],'requirement':old['requirement'],'disposition':old['disposition'],'source_and_test_files':old['source_and_test_files'],'current_tests':{n:counts[n] for n in old['current_tests'] if n in counts},'prior_requirement_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),'historical_assessment':{'audit':'v18-closeout-audit/packet.json','text':old['assessment']},'evidence':list(dict.fromkeys(old['evidence']+['artifacts/phase22/integration/v19-source-verification.json','artifacts/phase22/integration/v19-hosted-audit/packet.json'])),'assessment':'Fresh local/hosted engineering checks bind this requirement to1f3f72f. Five static deadline files changed; detector algorithms, rule meaning, schemas, inputs and model/dynamic budgets did not. Existing source assessments and named corpus observations retain their original sources; no new corpus measurement is inferred.','interpretation':'Passing engineering checks do not establish detection accuracy or satisfy timing, fresh evaluation or human acceptance. Final owning-document hashes are separately bound after this audit.'}
 i=row['id']
 if i in [f'R{n}' for n in range(18,28)]+['R35','R64','R65']:
  row['assessment']='Required whole current-source corpus execution/condition gate remains unresolved. Original source assessments, Meta raw-label erratum,15/25 Linux development completion, ten Meta timeouts and skipped historical pair remain preserved. The300-second policy is approved but no new corpus observation is made.'
 if i=='R63':
  row['original_requirement']=row['requirement'];row['requirement']='Historical45-input deterministic repeat pair:300-second maximum,120-second performance target'
  row['assessment']='User explicitly approved prospective timing revision. Both entire historical45-input batches still must complete correctly under300seconds native and whole-input time, with120-second counts separately reported. No full sequence is approved or executed on the new candidate; original120-second failures unchanged.'
  row['evidence']+=['artifacts/phase22/integration/v19-timeout-policy-authorization.json','artifacts/phase22/integration/v19-linux-timeout-diagnostic-proposal.json']
 if i in ['R66','R88']:row['assessment']='No post-stabilization fresh freeze/evaluation approved or executed. Exposed families and prior frozen misses remain disclosed. No generalization threshold or acceptance is invented.'
 if i=='R84':row['assessment']='No final technical acceptance requested or received. Phase 22 remains incomplete; Phase21 pilots deferred and Phase24/15 unchanged.'
 if i in ['R87','R89']:row['assessment']='Prior five-input native repeats remain passed detection regressions at measured2ac39aa, with2/2 correlated vulnerable hits and zero matching fixed/control alerts per batch. Deadline-only compatibility is explained in v19-source-verification.json; exact scanner-byte equality is false. These are not new300-second-policy native observations or fresh generalization evidence.'
 if i in ['R44','R70']:row['assessment']='Current production request regeneration and six checked replays pass with zero paid calls. Runtime components and approved Git image are identical; the13 historical Git campaigns remain incomplete1040planned/312tested/728remaining, with exit3 and cleanup. Fresh owned demo replay has its own narrower scope.'
 if i in ['R77','R78']:row['assessment']='Explicit user deferral of the full paid benchmark remains in force. No paid request is made.'
 if i=='R79':row['evidence']+=['artifacts/phase22/integration/evidence-v48.json']
 if i=='R82':row['evidence']+=['artifacts/phase22/integration/v19-delivery-verification.json']
 rows.append(row)
additional=[{**r,'scope':'Historical executed scope retained from v18 audit; no unused authorization reopens.'} for r in prior['additional_scope_requirements']]
for suffix,title,evidence in [('POLICY','Record explicit prospective timing-policy revision',['v19-timeout-policy-authorization.json']),('DEADLINE','Implement uniform300-second shared deadline and durable boundary controls',['v19-candidate.json','v19-final-full-suite-junit.xml']),('VERIFY','Complete current-source local/hosted engineering and compatible replay/runtime verification',['v19-source-verification.json','v19-hosted-audit/packet.json']),('PROPOSAL','Prepare exact bounded Linux diagnostic without executing it',['v19-linux-timeout-diagnostic-proposal.json']),('DELIVERY','Seal and deliver completed scope while retaining unmet Phase22 gates',['evidence-v48.json','v19-delivery-verification.json'])]:additional.append({'id':'V19-'+suffix,'requirement':title,'disposition':'passed','evidence':evidence})
dispositions=dict(collections.Counter(r['disposition'] for r in rows));assert len(rows)==89 and dispositions=={'passed':70,'unresolved':17,'explicitly user-deferred':2}
p={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':head,'scanner_identity':v['scanner'],'requirements':rows,'dispositions':dispositions,'additional_scope_requirements':additional,'additional_scope_dispositions':dict(collections.Counter(r['disposition'] for r in additional)),'prior_audit':{'path':'v18-closeout-audit/packet.json','sha256':sha(b/'v18-closeout-audit/packet.json')},'current_tests_by_file':counts,'current_source_and_test_files':v['source_and_test_files_sha256'],'references_sha256':{n:sha(b/n) for n in ['v19-source-verification.json','v19-hosted-audit/packet.json','v19-final-local-checks.json','v19-timeout-policy-authorization.json','v19-linux-timeout-diagnostic-proposal.json','evidence-v48.json']},'original_failed_gate':v['original_failed_gate'],'policy_approved':True,'native_and_whole_input_hard_limit_seconds':300,'performance_target_seconds':120,'current_source_corpus_runs':0,'diagnostic_approved':False,'full_sequence_approved':False,'fresh_evaluation_approved':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'new_paid_calls':0,'phase22_complete':False,'status':'Approved timeout policy implemented and engineering-verified. The four-observation Linux diagnostic is prepared, not approved or run. Timing/fresh evaluation/human acceptance remain unmet.','owning_document_binding':'v19-final-documentation-binding.json supersedes audit-stage owning-document hashes only.'}
out=b/'v19-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
coverage=read('v19-final-full-suite-coverage.json')['totals']['percent_covered']
summary=f'''The approved **120-second performance target / 300-second static maximum** is
implemented and verified at `1f3f72f`. The same deadline applies to every input;
fast scans return immediately. The TypeScript parser and source-flow workers use
the remaining shared budget, shorter caller deadlines are honored, and coverage/
report assembly checks expiry. No detector rules or model/dynamic budgets change.

Local full verification passes **2,194 tests / 36 skipped**, with **{coverage:.2f}%**
branch coverage. Fresh CI **34545976337** passes all **29 normal jobs**; each of
12 suites passes **2,194 / 36**. Docs **34545976336** and the final local docs build
pass. Six production requests regenerate/replay with **zero paid calls**; Git
runtime components/image remain compatible with the retained incomplete campaigns.
Initial failing deadline regressions, lint/type-check corrections and all earlier
failures are preserved. The scanner bytes now differ from `592a9cd` and `2ac39aa`;
prior exposed detections remain source-bound regressions with deadline-only
compatibility explained in `v19-source-verification.json`.

**No new corpus timing run has occurred.** The original Linux result remains
15/25 development complete, ten Meta timeouts at 120 seconds and both historical
batches skipped. The user approved revising the prospective hard timing criterion
to 300 seconds; completion within the original 120-second target must still be
reported separately. This is no speedup or completed timing-gate claim.

`v19-linux-timeout-diagnostic-proposal.json` is prepared and **unapproved**:
two named slow Meta inputs twice each, four native observations, 300 seconds each,
one 30-minute standard Linux job, no profiles/retries/paid calls. Stop at the first
incomplete or mismatching result. Full 25+45+45 verification, fresh evaluation and
human acceptance remain separate checkpoints. **Phase 22 remains incomplete.**
Paid benchmark/pilots remain deferred; Phase 21 incomplete and Phase 24/15 unchanged.
'''
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']:
 f=root/name;s=f.read_text();start=s.index('The user approved a uniform **120-second performance target / 300-second static');end=s.index('Historical v18 throughput probe',start);end=s.rfind('\n',start,end)
 # Replace the current section prose, preserving the historical heading and all its contents.
 link='[Timing policy](phase22-timeout-policy.md)\n\n' if name.startswith('docs/') else ''
 s=s[:start]+summary+'\n'+link+s[end+1:];f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text();start=s.index('The user approved the 120-second target / 300-second maximum.');end=s.index('## Historical v18 source-bound audit',start);s=s[:start]+'''All 89 original requirements are mapped in `v19-closeout-audit/packet.json`:
**70 passed, 2 explicitly user-deferred, 17 unresolved**. R63 keeps its ID and
records its original wording plus the user-approved prospective 300-second
maximum/120-second target. Original failed measurements remain unchanged.
All 33 added rows retain **32 passed, 1 unresolved** (historical v14 retention).
Five v19 rows cover policy, deadline controls, verification, proposal and delivery.
The diagnostic itself is not approved or run. No current-source timing or fresh
evaluation pass, paid call or human acceptance is inferred.

'''+s[end:];f.write_text(s)
index=f'''Batch 48 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 47 prior archives are verified. Restore
after batches 1–47 in separate staging using `evidence-v48.json`, requiring existing
destinations to match identical bytes or their recorded previous hash. Stop on
unexpected conflicts. This batch retains the policy approval, candidate, all
local/hosted checks and artifacts, original regression failures and corrections,
production replay/runtime compatibility, prepared diagnostic and helper sources.
Final audit/documentation/delivery bindings are tracked directly after sealing.
'''
f=b/'README.md';s=f.read_text().replace('batches 1–47 and closeout audit','batches 1–48 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text(f.read_text().rstrip()+'\n\n### Evidence batch 48\n\n'+index)
f=root/'docs/phase22-timeout-policy.md';f.write_text(f.read_text().rstrip()+f'\n\n## Candidate verification\n\nCandidate `1f3f72f` passes the local full suite (2,194 passed, 36 skipped), all 29\nnormal hosted CI jobs and docs. The four-observation diagnostic proposal remains\nunapproved and unexecuted. See the [integration evidence index](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n')
body='The static scanner now allows a 300-second maximum while retaining 120 seconds as its performance target. Phase 22 remains incomplete.\n\n'+summary+'\n[Policy](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/docs/phase22-timeout-policy.md), [current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v19-closeout-audit/packet.json), [unapproved diagnostic](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v19-linux-timeout-diagnostic-proposal.json), and [evidence batches 1–48](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nFinal docs/evidence delivery uses authorized CI skip only after proving product/test/workflow/package inputs equal tested `1f3f72f`. This later delivery is not another hosted code pass.\n'
f=b/'v19-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(dispositions,p['additional_scope_dispositions'])
