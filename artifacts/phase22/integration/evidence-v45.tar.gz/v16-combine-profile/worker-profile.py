"""Count uncached generic combination; retain original logic and LRU behavior."""
import ast,collections,hashlib,inspect,json,sys,textwrap,threading,time
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root/'src'),str(root)]
from sentinel.static import workers,path_flow
out=Path(__file__).resolve().parent;rule=sys.argv[-1];counts=collections.Counter();arities=collections.Counter();distinct=collections.Counter();timings=collections.Counter();active=[];stop=threading.Event()
def _count(key):counts[key]+=1
def _begin_generic(values):
 n=len(values);d=len({id(value) for value in values});eligible=n>2 and d==2
 counts['generic_calls']+=1;counts['eligible_calls']+=eligible;counts['generic_operands']+=n;arities[n]+=1;distinct[d]+=1
 frame={'eligible':eligible,'nested_cpu':0.,'nested_wall':0.};active.append(frame)
 frame['wall']=time.perf_counter();frame['cpu']=time.process_time()
def _end_generic():
 cpu=time.process_time();wall=time.perf_counter();frame=active.pop();cpu-=frame['cpu'];wall-=frame['wall']
 for kind in ('generic','eligible') if frame['eligible'] else ('generic',):
  timings[kind+'.inclusive.cpu']+=cpu;timings[kind+'.exclusive.cpu']+=cpu-frame['nested_cpu'];timings[kind+'.inclusive.wall']+=wall;timings[kind+'.exclusive.wall']+=wall-frame['nested_wall']
 if active:active[-1]['nested_cpu']+=cpu;active[-1]['nested_wall']+=wall
original=path_flow._combine;assert original.cache_info().currsize==0
raw=textwrap.dedent(inspect.getsource(original.__wrapped__));before=ast.parse(raw);tree=ast.parse(raw);function=tree.body[0];assert isinstance(function,ast.FunctionDef)
index=next(i for i,n in enumerate(function.body) if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='tainted')
tail=function.body[index:];function.body=function.body[:index]+[ast.parse('_begin_generic(values)').body[0],ast.Try(body=tail,handlers=[],orelse=[],finalbody=[ast.parse('_end_generic()').body[0]])]
function.body.insert(0,ast.parse('_count("cache_miss_calls")').body[0]);ast.fix_missing_locations(tree)
class Strip(ast.NodeTransformer):
 def visit_Expr(self,node):
  if isinstance(node.value,ast.Call) and isinstance(node.value.func,ast.Name) and node.value.func.id in {'_count','_begin_generic','_end_generic'}:return None
  return self.generic_visit(node)
 def visit_Try(self,node):
  assert not node.handlers and not node.orelse and len(node.finalbody)==1
  assert isinstance(node.finalbody[0].value,ast.Call) and node.finalbody[0].value.func.id=='_end_generic'
  return [self.visit(n) for n in node.body]
assert ast.dump(Strip().visit(ast.parse(ast.unparse(tree))))==ast.dump(before)
source='from __future__ import annotations\n'+ast.unparse(tree)+'\n';file=out/(rule+'-instrumented-combine.py');file.write_text(source)
namespace=dict(path_flow.__dict__,_count=_count,_begin_generic=_begin_generic,_end_generic=_end_generic);exec(compile(source,str(file),'exec'),namespace);instrumented=namespace['_combine'];assert instrumented.cache_parameters()==original.cache_parameters();path_flow._combine=instrumented
identity={'original_sha256':hashlib.sha256(raw.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(source.encode()).hexdigest(),'original_ast_and_decorator_preserved':True,'lru_parameters':original.cache_parameters(),'source_values_recorded':False}
def snapshot(final=False):
 data={'rule':rule,**identity,'counts':dict(counts),'generic_operand_cardinality':dict(arities),'generic_distinct_identity_cardinality':dict(distinct),'timings_seconds':dict(timings),'worker_cpu_seconds':time.process_time(),'cache_info':instrumented.cache_info()._asdict(),'active_generic_intervals':len(active),'final_worker_snapshot':final,'timing_definition':'Generic body is the existing tainted/operators/keys/Value return block after identical-value, missing/None and two-value branches. Body timers exclude preceding classification/counter work; include field reductions, called helpers and constructor cost. Exclusive subtracts nested generic-body intervals, not library calls. Worker CPU includes imports, instrumentation and snapshot thread. Attribution is instrumented and not wholly removable cost; parent inclusive intervals must not be summed.'}
 p=out/(rule+'-combine-profile.json');tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(p)
def snapshots():
 while not stop.wait(15):snapshot()
if __name__=='__main__':
 thread=threading.Thread(target=snapshots,daemon=True);thread.start()
 try:workers._worker()
 finally:stop.set();thread.join();snapshot(True)
