from __future__ import annotations
@lru_cache(maxsize=4096)
def _combine(values: tuple[Value, ...], key: str) -> Value:
    _count('cache_miss_calls')
    if values:
        first = values[0]
        if all((value is first or value == first for value in values[1:])):
            if not first.sources and (first.contained or first.checked_path_parent or first.option_safe or first.url_checks):
                return replace(first, key=key or first.key, contained=False, checked_path_parent=False, option_safe=False, url_checks=frozenset())
            return replace(first, key=key) if key and key != first.key else first
    present = [value for value in values if value.key not in {'None', '#missing'}]
    if present and len(present) != len(values):
        return replace(combine(present, key), maybe_none=any((value.maybe_none or value.key == 'None' for value in values)), maybe_missing=any((value.maybe_missing for value in values)))
    if len(values) == 2:
        left, right = values
        has_sources = bool(left.sources or right.sources)
        return Value(left.sources | right.sources, key or (left.key if left.key == right.key else _key('merge', *sorted((left.key, right.key)))), left.resolved and right.resolved, has_sources and (not left.sources or left.contained) and (not right.sources or right.contained), left.locations | right.locations, left.path_object and right.path_object, left.repository_object and right.repository_object, left.instance if left.instance == right.instance else None, has_sources and (not left.sources or left.option_safe) and (not right.sources or right.option_safe), left.url_checks & right.url_checks if left.sources and right.sources else left.url_checks if left.sources else right.url_checks if right.sources else frozenset(), left.operator_credential or right.operator_credential, left.credential_fallback or right.credential_fallback, left.credential_present and right.credential_present, left.maybe_missing or right.maybe_missing, left.maybe_none or right.maybe_none, left.operator_opt_in & right.operator_opt_in if left.operator_credential and right.operator_credential else left.operator_opt_in if left.operator_credential else right.operator_opt_in if right.operator_credential else frozenset(), has_sources and (not left.sources or left.checked_path_parent) and (not right.sources or right.checked_path_parent))
    _begin_generic(values)
    try:
        tainted = [v for v in values if v.sources]
        operators = [v for v in values if v.operator_credential]
        keys = sorted({v.key for v in values})
        return Value(union((v.sources for v in values)), key or (keys[0] if len(keys) == 1 else _key('merge', *keys)), bool(values) and all((v.resolved for v in values)), bool(tainted) and all((v.contained for v in tainted)), frozenset().union(*(v.locations for v in values)), bool(values) and all((v.path_object for v in values)), bool(values) and all((v.repository_object for v in values)), values[0].instance if values and all((v.instance == values[0].instance for v in values)) else None, bool(tainted) and all((v.option_safe for v in tainted)), frozenset.intersection(*(v.url_checks for v in tainted)) if tainted else frozenset(), bool(operators), any((v.credential_fallback for v in values)), bool(values) and all((v.credential_present for v in values)), any((v.maybe_missing for v in values)), any((v.maybe_none for v in values)), frozenset.intersection(*(v.operator_opt_in for v in operators)) if operators else frozenset(), bool(tainted) and all((v.checked_path_parent for v in tainted)))
    finally:
        _end_generic()
