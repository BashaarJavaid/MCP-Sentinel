"""Exercise one-use accounting and failure closure with synthetic reports only."""
import importlib.util,json
from contextlib import ExitStack
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('diagnostic',OUT/'diagnostic.py');d=importlib.util.module_from_spec(spec);spec.loader.exec_module(d)
try:d.m.approved()
except FileNotFoundError:pass
else:raise AssertionError('Unapproved diagnostic accepted')
assert not(OUT/'execution-consumed.json').exists()
results=[]
for failure in [None,'report','trace','cleanup']:
 with TemporaryDirectory(prefix='sentinel-trace-runner-control-') as tmp:
  root=Path(tmp);assets=root/'assets';assets.mkdir();out=root/'raw';ref=root/'reference.json';report={'findings':[],'warnings':[],'static_analysis':{'duration_ms':1}};ref.write_text(json.dumps(report))
  proposal={'scanner':{'revision':'synthetic'},'order':[{'group':'ddg','batch':'trace','input_id':'ddg-cgnat-fixed'}],'bounds':{'native_observations':1},'groups':{'ddg':{'inputs':{'ddg-cgnat-fixed':{'reference_report':str(ref)}}}}}
  proposal_path=assets/'proposal.json';proposal_path.write_text(json.dumps(proposal));approval=assets/'approval.json';approval.write_text('{"approved":true,"synthetic":true}')
  def supervise(command,log,seconds):
   assert seconds==300;destination=Path(command[-1]);folder=destination/'ddg-cgnat-fixed';folder.mkdir(parents=True);data=dict(report)
   if failure=='report':data['warnings']=['synthetic mismatch']
   (folder/'report.json').write_text(json.dumps(data));trace=out/(destination.name+'-trace');trace.mkdir();events=[{'event':e} for e in ['url_sink-enter','guard-exit','network_rejection-exit','dedup-before','dedup-after']];events.append({'event':'final','stats':{'restored':True,'dropped':int(failure=='trace'),'events':5,'bytes':100}});(trace/'guard-1.jsonl').write_text(''.join(json.dumps(e)+'\n' for e in events))
   return {'elapsed_seconds':.01,'elapsed_including_cleanup_seconds':.012,'returncode':0,'timed_out':False,'remaining_group_killed':False,'cleanup_verified':failure!='cleanup'}
  with ExitStack() as stack:
   for obj,name,new in [(d,'OUT',assets),(d.m,'PROPOSAL',proposal_path),(d.m,'APPROVAL',approval),(d.m,'approved',lambda:proposal),(d.m,'identity',lambda _:None),(d.m,'selfcheck',lambda:None),(d.m.supervisor,'selfcheck',lambda _:None),(d.m.supervisor,'supervise',supervise)]:stack.enter_context(patch.object(obj,name,new))
   try:d.run(out)
   except AssertionError:assert failure is not None
   else:assert failure is None
   packet=json.loads((out/'packet.json').read_text());assert packet['budget_closed'] and packet['remaining']==0 and len(packet['attempts'])==1 and packet['passed']==(failure is None)
   try:d.run(out)
   except AssertionError:pass
   else:raise AssertionError('Consumed diagnostic allowed to repeat')
  results.append({'synthetic_failure':failure,'budget_closed':True,'second_execution_rejected':True,'passed':failure is None})
with (OUT/'runner-selfcheck.json').open('x') as f:json.dump({'checks':results,'unapproved_diagnostic_rejected':True,'corpus_observations':0,'paid_calls':0,'target_execution':False,'qualification':'All measurement responses mocked; real trace transparency checked separately.'},f,indent=2);f.write('\n')
print('Synthetic success/report/trace/cleanup gates close one-use budget; unapproved execution rejected.')
