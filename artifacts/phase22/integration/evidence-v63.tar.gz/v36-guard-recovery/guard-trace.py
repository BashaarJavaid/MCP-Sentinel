"""Bounded observational guard tracing; never evaluate an extra target expression."""
import hashlib,json,os
from contextlib import ExitStack,contextmanager
from pathlib import Path
from unittest.mock import patch
from sentinel.static import engine
from sentinel.static.path_flow import Value
from sentinel.static.rules.sent015 import URLFlow

MAX_EVENTS=20000
MAX_BYTES=8*1024*1024
FILES={'security.py','fetch.py','server.py','helpers.py','policy.py'}
NAMES={'url','current','current_url','parsed','hostname','request','safe_ip','address'}
def digest(value):return hashlib.sha256(value.encode()).hexdigest()
def value(flow,v):
 if not isinstance(v,Value):return None
 origin,part=flow.parts.get(v.key,('',''))
 return {'key_sha256':digest(v.key),'source_count':len(v.sources),'checks':sorted(v.url_checks),'part':part,'origin_sha256':digest(origin),'maybe_missing':v.maybe_missing,'maybe_none':v.maybe_none}
def state(flow,env):
 selected={k:value(flow,v) for k,v in env.items() if k in NAMES}
 selected['network_state']=[{'key_sha256':digest(k),'unknown':('#member:unknown:'+k in env),'mutated':any(marker in env for marker in flow.members.get(k,{}).values())} for k in sorted(flow.networks)]
 selected['fact_count']=sum(k in flow.fact_keys and v.contained for k,v in env.items())
 return selected

@contextmanager
def install(folder):
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True)
 path=folder/f'guard-{os.getpid()}.jsonl';stats={'events':0,'bytes':0,'dropped':0,'restored':False}
 originals={name:getattr(URLFlow,name) for name in ['function','call','guard','network_rejection','url_sink']};dedup=engine._deduplicate
 with path.open('x') as log:
  def emit(row):
   data=json.dumps(row,sort_keys=True,separators=(',',':'))+'\n';size=len(data.encode())
   if stats['events']>=MAX_EVENTS or stats['bytes']+size>MAX_BYTES:stats['dropped']+=1;return
   log.write(data);stats['events']+=1;stats['bytes']+=size
  def wrapper(name,original):
   def observed(flow,symbol,*args,**kwargs):
    selected=Path(symbol.file.relative_path).name in FILES
    if not selected:return original(flow,symbol,*args,**kwargs)
    node=symbol.node if name=='function' else args[0]
    env=args[0] if name=='function' else args[1] if len(args)>1 and isinstance(args[1],dict) else {}
    before=state(flow,env)
    emit({'event':name+'-enter','path':symbol.file.relative_path,'function':symbol.name,'line':getattr(node,'lineno',0),'calls':list(flow.call_sites),'state':before,'sink_value':value(flow,args[1]) if name=='url_sink' else None})
    result=original(flow,symbol,*args,**kwargs)
    predicate=flow.predicates.get(result.key) if isinstance(result,Value) else None
    emit({'event':name+'-exit','path':symbol.file.relative_path,'function':symbol.name,'line':getattr(node,'lineno',0),'state':state(flow,env),'result':value(flow,result),'predicate':[[[digest(origin),check] for origin,check in sorted(facts)] for facts in predicate] if predicate is not None else None})
    return result
   return observed
  def merge(matches):
   def rows(values):return [{'path':m.path,'line':m.range.start_line,'scope':m.captures.get('url_guard_scope'),'flow_locations':json.loads(m.captures.get('flow_locations','[]'))} for m in values if m.rule_id=='SENT-015']
   emit({'event':'dedup-before','matches':rows(matches)});result=dedup(matches);emit({'event':'dedup-after','matches':rows(result)});return result
  try:
   with ExitStack() as stack:
    for name,original in originals.items():stack.enter_context(patch.object(URLFlow,name,wrapper(name,original)))
    stack.enter_context(patch.object(engine,'_deduplicate',merge))
    yield stats
  finally:
   stats['restored']=all(getattr(URLFlow,n) is original for n,original in originals.items()) and engine._deduplicate is dedup
   log.write(json.dumps({'event':'final','stats':stats},sort_keys=True)+'\n')
  assert stats['restored'] and not stats['dropped'],'Trace restoration or capture bound failed'
