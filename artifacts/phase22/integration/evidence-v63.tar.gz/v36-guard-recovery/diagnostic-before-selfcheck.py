"""One separately approved trace, reusing the exact retained measurement child."""
import importlib.util,json,os,subprocess,sys,time
from pathlib import Path
from unittest.mock import patch
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3]
sys.path[:0]=[str(Path.cwd()/'src'),str(Path.cwd())]
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
m=load('retained_evaluator',OUT.parent/'v34-import-binding/evaluate.py')
m.ASSETS=OUT;m.PROPOSAL=OUT/'diagnostic-proposal.json';m.APPROVAL=OUT/'diagnostic-authorization.json'
sha,write=m.sha,m.write

def child(destination):
 from sentinel.static import workers
 trace=load('guard_trace',OUT/'guard-trace.py')
 p=m.approved();assert len(p['order'])==1 and p['bounds']['native_observations']==1
 row=p['order'][0];folder=destination.parent/(destination.name+'-trace')
 with patch.dict(os.environ,{'PHASE22_GUARD_TRACE_DIR':str(folder)}),patch.object(workers,'WORKER',OUT/'trace-worker.py'),trace.install(folder):
  m.child(row['group'],row['input_id'],destination)


def run(destination):
 p=m.approved();assert not destination.exists() and not(OUT/'execution-consumed.json').exists();assert p['bounds']['native_observations']==1 and len(p['order'])==1
 started=time.monotonic();stop=started+600;packet={'scanner':p['scanner'],'proposal_sha256':sha(m.PROPOSAL),'approval_sha256':sha(m.APPROVAL),'attempts':[],'unstarted':p['order'],'passed':False,'paid_calls':0,'target_execution':False,'budget_closed':False,'runner_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()}
 write(destination/'packet.json',packet)
 try:
  with (OUT/'execution-consumed.json').open('x') as f:json.dump({'proposal_sha256':sha(m.PROPOSAL),'approval_sha256':sha(m.APPROVAL),'output':str(destination),'budget_consumed':True},f)
  m.supervisor.selfcheck(destination);m.selfcheck();m.identity('ddg');assert time.monotonic()+315<stop
  row={**p['order'][0],'directory':'01-trace-ddg-cgnat-fixed','state':'attempted'};packet['attempts']=[row];packet['unstarted']=[];write(destination/'packet.json',packet)
  command=[sys.executable,'-I',str(Path(__file__).resolve()),'child',str(destination/row['directory'])];row['command']=command
  row['timing']=m.supervisor.supervise(command,destination/'observation.log',300);row['state']='incomplete';write(destination/'packet.json',packet);m.prior.completed(row['timing'])
  folder=destination/row['directory'];report_path=folder/row['input_id']/'report.json';report=json.loads(report_path.read_text());reference=ROOT/p['groups']['ddg']['inputs'][row['input_id']]['reference_report']
  row['entire_ordered_reference_equal']=m.supervisor.clean(report,m.prior.EXCLUDED)==m.supervisor.clean(json.loads(reference.read_text()),m.prior.EXCLUDED)
  assert row['entire_ordered_reference_equal'],'Instrumentation changed the entire ordered report'
  traces=[];events=[]
  for path in sorted((destination/(row['directory']+'-trace')).glob('guard-*.jsonl')):
   data=[json.loads(line) for line in path.read_text().splitlines()];final=data[-1];assert final['event']=='final' and final['stats']['restored'] and final['stats']['dropped']==0
   assert final['stats']['events']<=20000 and final['stats']['bytes']<=8*1024*1024
   traces.append({'path':str(path.relative_to(destination)),'sha256':sha(path),'stats':final['stats']});events.extend(r['event'] for r in data)
  assert 1<=len(traces)<=2 and all(event in events for event in ['url_sink-enter','guard-exit','network_rejection-exit','dedup-before','dedup-after'])
  row.update(state='completed',native_seconds=report['static_analysis']['duration_ms']/1000,report_sha256=sha(report_path),reference_sha256=sha(reference),traces=traces)
  assert row['native_seconds']<=300 and time.monotonic()<stop;packet['passed']=True
 except BaseException as error:packet['stop_reason']=f'{type(error).__name__}: {error}';raise
 finally:
  packet.update(budget_closed=True,remaining=0,elapsed_seconds=time.monotonic()-started,source_assessment_pending=True,technical_acceptance=False)
  packet['files_sha256']={p.relative_to(destination).as_posix():sha(p) for p in sorted(destination.rglob('*')) if p.is_file() and p!=destination/'packet.json'};write(destination/'packet.json',packet)

if __name__=='__main__':
 mode,directory=sys.argv[1:];assert mode in {'run','child'};globals()[mode](Path(directory))
