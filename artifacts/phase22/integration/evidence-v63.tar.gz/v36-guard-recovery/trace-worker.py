"""Use the original source worker, with observational SENT-015 tracing only."""
import importlib.util,os,sys
from pathlib import Path
FROZEN=Path('/private/tmp/mcp-phase22-frozen-a50e9b7');sys.path[:0]=[str(FROZEN/'src'),str(FROZEN)]
from sentinel.static import workers
if sys.argv[-1]=='SENT-015':
 spec=importlib.util.spec_from_file_location('guard_trace',Path(__file__).with_name('guard-trace.py'));trace=importlib.util.module_from_spec(spec);spec.loader.exec_module(trace)
 with trace.install(os.environ['PHASE22_GUARD_TRACE_DIR']):workers._worker()
else:workers._worker()
