"""Retain all89+97 requirements and account for the approved recovery fallback."""
import copy,hashlib,json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=read(BASE/'v35-ddg-regression/audit.json');p=copy.deepcopy(old);a=read(OUT/'assessment.json');assert a['corpus_observations']==0 and not a['product_test_workflow_changes']
refs=['authorization.json','assessment.json','synthetic-source-retention.json','diagnostic-proposal.json','scoring-rubric.json','trace-selfcheck.json','runner-selfcheck.json','worktree-restoration.json','evidence-restoration.json']
common='The approved source-only recovery reaches its explicit fallback: DDG loss is not reproduced by the scanner-owned controls, so no guessed correction is retained. Meta narrow-scope control reproduces its existing gap. Exact one-input observational trace is prepared and unapproved. Current source/tests/workflows remain verifieda50e9b7/8a3db58; measuredv35 failure and all earlier outcomes remain unchanged. Zero new corpus observations or paid calls.'
for r in p['requirements']:
 r['historical_v35_assessment']={'assessment':r['assessment'],'disposition':r['disposition']};r['interpretation']=common;r['evidence']+=['artifacts/phase22/integration/v36-guard-recovery/'+n for n in refs]
 if r['id'] in {'R33','R65','R84'}:r['assessment']+=' Source-onlyv36 retains these failures, reaches the approved diagnostic fallback and does not infer technical acceptance. The exact one-observation trace needs its own approval.'
 elif r['id'] in {'R62','R83'}:r['assessment']='Owning docs distinguish source-only investigation, unchanged measuredv35 failure, retained engineering and fresh-source history, and the exact unapproved one-input diagnostic. Original failures, incompleteGit and paid/pilot deferrals remain visible; no correction or Phase22 completion is claimed.'
for id,requirement,status in [('V36-AUTH','Perform the approved source-only recovery with zero corpus observations or paid calls','passed'),('V36-INVESTIGATION','Investigate actual guard paths using scanner-owned controls and obey the fallback when loss is not established','passed'),('V36-TRACE-PREPARATION','Prepare exact bounded observational diagnostic with transparent inline/worker and one-use failure checks','passed'),('V36-RETENTION','Retain all controls/failures and restore missing workspace/evidence without overwriting existing files','passed'),('V36-RECOVERY','Establish and correct actualDDG guard loss and Meta narrow guard scope, then verify the corrected gate','unresolved')]:
 p['additional_scope_requirements'].append({'id':id,'requirement':requirement,'disposition':status,'assessment':common,'evidence':['artifacts/phase22/integration/v36-guard-recovery/'+n for n in refs]})
p['prior_audit']={'path':'v35-ddg-regression/audit.json','sha256':sha(BASE/'v35-ddg-regression/audit.json')}
p['historical_source_and_test_file_bindings']={'source':old['source'],'files':old['current_source_and_test_files'],'earlier':old['historical_source_and_test_file_bindings']}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in old['current_source_and_test_files']}
p['references_sha256'].update({'artifacts/phase22/integration/v36-guard-recovery/'+n:sha(OUT/n) for n in refs})
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='328f7af6ef80215ae70fe53f137d912e0c9bb1de',status=common,current_continuation_corpus_observations=0,new_paid_calls=0,source_only_recovery_checkpoint=True,diagnostic_proposed_observations=1,diagnostic_approved=False,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,owning_document_binding='Finalv36 documentation binding follows final status-only docs and verified seal63.')
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==102
assert p['dispositions']=={'passed':84,'unresolved':3,'explicitly user-deferred':2}
assert p['additional_scope_dispositions']=={'passed':94,'proposed documented limitation awaiting decision':5,'unresolved':3}
with (OUT/'audit.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print(p['dispositions'],p['additional_scope_dispositions'])
