"""Restore absent latest sealed members; never overwrite existing evidence."""
import hashlib,json,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parents[1];OUT=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest();latest={};indexes=[]
for version in range(1,63):
 index=json.loads((BASE/f'evidence-v{version}.json').read_text());indexes.append(index)
 assert sha((BASE/index['archive']).read_bytes())==index['sha256']
 for r in index['files']:latest[r['path']]=(version,r)
restored=[]
for version,index in enumerate(indexes,1):
 with tarfile.open(BASE/index['archive']) as archive:
  for name,(owner,row) in latest.items():
   if owner!=version:continue
   p=BASE/name;assert not p.is_symlink()
   if p.exists():assert sha(p.read_bytes())==row['sha256'],name;continue
   member=archive.getmember(name);assert member.isfile() and member.size==row['bytes'];data=archive.extractfile(member).read();assert sha(data)==row['sha256']
   p.parent.mkdir(parents=True,exist_ok=True)
   with p.open('xb') as f:f.write(data)
   restored.append({'path':name,'sha256':row['sha256'],'archive':index['archive']})
with (OUT/'evidence-restoration.json').open('x') as f:json.dump({'restored':restored,'all62_archive_hashes_verified':True,'existing_latest_members_verified':True,'overwrites':0},f,indent=2);f.write('\n')
p=Path('/private/tmp/phase22-check.py');assert not p.exists()
with tarfile.open(BASE/'v35-retained-validation.untracked.tar.gz') as archive:p.write_bytes(archive.extractfile('_diagnostics/phase22-check.py').read())
print('Restored',len(restored),'missing sealed files and exact retained check wrapper.')
