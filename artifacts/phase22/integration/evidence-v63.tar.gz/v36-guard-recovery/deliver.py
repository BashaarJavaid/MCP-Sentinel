"""Bind and deliver the source-only investigation to the existing authorized draft."""
import hashlib,json,subprocess,tarfile
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
old=read(BASE/'v35-ddg-regression/documentation-binding.json');baseline='328f7af6ef80215ae70fe53f137d912e0c9bb1de';tested='8a3db5885981f511b58eb484550229c15d11bca0'
assert run(['git','rev-parse','HEAD']).strip()==baseline
assert run(['git','branch','--show-current']).strip()=='phase22/integration'
assert not run(['git','diff','--cached'])
fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
pr=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'pre-delivery-pr37.json',pr)
assert pr['headRefOid']==baseline and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(BASE/'v35-ddg-regression/pr-body.md').read_text()
parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,state,isDraft']));write(OUT/'pre-delivery-pr36.json',parent)
assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455';run(['git','merge-base','--is-ancestor',parent['headRefOid'],'HEAD'])
inputs=old['byte_identical_quality_inputs'];assert 'README.md' not in inputs
assert not run(['git','diff',tested,'--',*inputs])
protected=old['user_files_sha256']
def verify_protected():
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision']
  assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
verify_protected()
a=read(OUT/'assessment.json');audit=read(OUT/'audit.json');assert a['approved_conditional_checkpoint_reached'] and a['corpus_observations']==0 and not a['product_test_workflow_changes']
assert not (OUT/'diagnostic-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==102
assert audit['dispositions']=={'passed':84,'explicitly user-deferred':2,'unresolved':3}
for n,d in audit['current_source_and_test_files'].items():assert sha(ROOT/n)==d,n
for label in ['v36-final-docs','v36-final-build','v36-final-distributions']:
 assert read(BASE/(label+'.json'))['exit_code']==0,label
assert read(OUT/'owned-work-final.json')['owned_processes']==[]
for n,d in read(OUT/'diagnostic-proposal.json')['files_sha256'].items():assert sha(ROOT/n)==d,n
seal=read(BASE/'evidence-v63.json');assert sha(BASE/seal['archive'])==seal['sha256']
for r in seal['files']:assert sha(BASE/r['path'])==r['sha256'],r['path']
dist=read(OUT/'final-distributions.json');assert sha(ROOT/'README.md')==dist['README_sha256']
for r in dist['distributions']:assert sha(ROOT/r['path'])==r['sha256']
refs=['assessment.json','audit.json','summary.md','pr-body.md','diagnostic-proposal.json','scoring-rubric.json','authorization.json','trace-selfcheck.json','runner-selfcheck.json','final-distributions.json','deliver.py']
b={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':baseline,'tested_workflow':tested,'scanner':a['scanner'],'byte_identical_quality_inputs':inputs,'owning_docs_sha256':{n:sha(ROOT/n) for n in old['owning_docs_sha256']},'review_packet_sha256':{n:sha(OUT/n) for n in refs},'user_files_sha256':protected,'worktrees':old['worktrees'],'authorized_staged_frozen_artifacts_sha256':old['authorized_staged_frozen_artifacts_sha256'],'evidence_seal':{'path':seal['archive'],'sha256':seal['sha256'],'members':len(seal['files'])},'new_native_observations':0,'proposed_diagnostic_observations':1,'new_paid_calls':0,'gate_passed':False,'source_recovery_approved':True,'diagnostic_approved':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Post-seal binding directly tracked. Current audit source/test/doc hashes match final files. Product/tests/workflows equal actual tested8a3db58; final README metadata distributions reverified. No new hosted pass or circular final commit binding is claimed.'}
write(OUT/'documentation-binding.json',b)
paths=list(b['owning_docs_sha256']);extra=[str(p.relative_to(ROOT)) for p in [BASE/'evidence-v63.json',BASE/'evidence-v63.tar.gz',OUT/'documentation-binding.json']]
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','add','-f','--',*extra],check=True)
assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths+extra)
subprocess.run(['git','commit','-m','Retain Phase 22 guard investigation and prepare exact diagnostic [skip ci]'],check=True)
subprocess.run(['git','push','origin','phase22/integration'],check=True)
subprocess.run(['gh','pr','edit','37','--title','Phase 22: guard investigation and diagnostic checkpoint','--body-file',str(OUT/'pr-body.md')],check=True)
head=run(['git','rev-parse','HEAD']).strip();pr=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'delivery-readback.json',pr)
assert pr['headRefOid']==head and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning';assert pr['body']==(OUT/'pr-body.md').read_text()
assert json.loads(run(['gh','pr','view','36','--json','headRefOid']))['headRefOid']==parent['headRefOid']
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached']);verify_protected()
for n,d in b['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
write(OUT/'delivery-verification.json',{'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-readback.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':0,'proposed_diagnostic_observations':1,'source_recovery_approved':True,'diagnostic_approved':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Supplemental ignored post-delivery receipt; original seal and commit remain immutable.'})
print('Verified existing OPEN draft delivery',head,pr['url'])
