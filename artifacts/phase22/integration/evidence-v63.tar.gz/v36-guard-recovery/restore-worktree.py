"""Restore only absent tracked files from the retained delivered Git objects."""
import hashlib,json,os,subprocess
from pathlib import Path
ROOT=Path('/private/tmp/mcp-phase22-options');OUT=Path(__file__).resolve().parent
ADMIN=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel/.git/worktrees/mcp-phase22-options');GIT=['git','--git-dir='+str(ADMIN),'--work-tree='+str(ROOT)]
head=subprocess.check_output(GIT+['rev-parse','HEAD'],text=True).strip();assert head=='328f7af6ef80215ae70fe53f137d912e0c9bb1de'
diff=subprocess.check_output(GIT+['diff','--name-status','HEAD'],text=True);rows=[r.split('\t') for r in diff.splitlines()];assert all(r[0]=='D' for r in rows)
(OUT/'initial-worktree-diff.txt').write_text(diff)
entries={}
for entry in subprocess.check_output(GIT+['ls-tree','-rz','HEAD']).split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t',1);mode,kind,oid=meta.decode().split();entries[name.decode()]=(mode,kind,oid)
restored=[]
for _,name in rows:
 p=ROOT/name;assert not p.exists() and not p.is_symlink();assert not any(parent.is_symlink() for parent in p.parents)
 mode,kind,oid=entries[name];assert kind=='blob' and mode in {'100644','100755'}
 data=subprocess.check_output(GIT+['cat-file','blob',oid]);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data)
 p.chmod(int(mode[-3:],8));restored.append({'path':name,'git_blob':oid,'sha256':hashlib.sha256(data).hexdigest()})
assert not (ROOT/'.git').exists();assert (ADMIN/'gitdir').read_text().strip()==str(ROOT/'.git')
(ROOT/'.git').write_text('gitdir: '+str(ADMIN)+'\n')
assert not subprocess.check_output(['git','diff','HEAD'],cwd=ROOT)
(OUT/'worktree-restoration.json').write_text(json.dumps({'source':head,'initial_git_link_absent':True,'restored':restored,'existing_files_overwritten':0,'tracked_clean':True,'qualification':'1028 tracked files and the worktree link were absent at turn start; exact retained Git objects restored without changing existing files or refs.'},indent=2)+'\n')
print('Restored',len(restored),'absent tracked files and original worktree link; tracked bytes match delivered source.')
