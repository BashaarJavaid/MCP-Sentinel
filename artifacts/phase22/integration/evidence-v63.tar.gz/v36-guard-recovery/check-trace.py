"""Verify trace transparency on scanner-owned synthetic sources only."""
import hashlib,importlib.util,json,os,sys
from dataclasses import asdict
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch
from uuid import uuid4
ROOT=Path.cwd();sys.path.insert(0,str(ROOT));OUT=Path(__file__).resolve().parent
from sentinel.config import load_configuration
from sentinel.static import engine,workers
from tests.conftest import NOW,make_target
from tests.test_ssrf_prepared_requests import PREFIX,GUARD

def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module
trace=load('guard_trace',OUT/'guard-trace.py');old=load('evaluator',OUT.parent/'v34-import-binding/evaluate.py')
source=PREFIX+GUARD+'''\n@mcp.tool()
async def fetch(url: str):
    validate(url)
    async with httpx.AsyncClient() as client:
        request = client.build_request("GET", url)
        return await client.send(request)
'''
def canonical(result):
 data=json.loads(json.dumps(asdict(result),default=lambda v:v.model_dump(mode='json') if hasattr(v,'model_dump') else str(v)))
 return old.supervisor.clean(data,old.prior.EXCLUDED)
rows=[]
for large in [False,True]:
 folder=OUT/'trace-selfcheck'/('workers' if large else 'inline');folder.mkdir(parents=True,exist_ok=False)
 with TemporaryDirectory(prefix='sentinel-guard-control-') as tmp:
  root=Path(tmp);make_target(root,target_yaml='');(root/'server.py').write_text(source+('\n#'+'padding'*20000 if large else ''))
  config=load_configuration(root,environ={},static_only=True,cli_overrides={} if large else {'rules':['SENT-015']})
  before=engine.run_static_scan(config,uuid4(),timestamp=NOW)
  with patch.dict(os.environ,{'PHASE22_GUARD_TRACE_DIR':str(folder)}),patch.object(workers,'WORKER',OUT/'trace-worker.py'),trace.install(folder):after=engine.run_static_scan(config,uuid4(),timestamp=NOW)
  assert canonical(before)==canonical(after),'Synthetic entire ordered static result changed'
  assert any(f.rule_id=='SENT-015' and '100.64.0.0/10' in f.description for f in after.findings)
  captures=[]
  for p in sorted(folder.glob('guard-*.jsonl')):
   events=[json.loads(s) for s in p.read_text().splitlines()];assert events[-1]['event']=='final' and events[-1]['stats']['restored'] and events[-1]['stats']['dropped']==0
   captures.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'stats':events[-1]['stats']})
  assert len(captures)==(2 if large else 1)
  assert any('url_sink-enter' in p.read_text() for p in folder.glob('guard-*.jsonl'))
  rows.append({'mode':'workers' if large else 'inline','entire_ordered_static_result_equal':True,'captures':captures})
with (OUT/'trace-selfcheck.json').open('x') as f:json.dump({'checks':rows,'scanner_owned_synthetic_invocations':4,'corpus_observations':0,'paid_calls':0,'target_execution':False},f,indent=2);f.write('\n')
print('Inline and worker traces preserve entire ordered synthetic reports; all hooks restored.')
