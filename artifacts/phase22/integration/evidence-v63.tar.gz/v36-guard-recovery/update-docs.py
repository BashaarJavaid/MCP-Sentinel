"""Report the actual source-only checkpoint, without claiming a correction."""
import json
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());a=read(OUT/'assessment.json');assert not a['ddg_failure_reproduced'] and a['corpus_observations']==0
text='''The approved **v36 source-only recovery investigation has reached its explicit
conditional diagnostic checkpoint**. Scanner **`a50e9b7` remains unchanged**.
Scanner-owned synthetic DDG cases preserve the guard through async callbacks,
request models/cache handling, redirects, multiple entries, separate modules,
the full rule set and isolated workers. They **do not reproduce the actual DDG
guard loss**. A separate synthetic Meta control reproduces its missing narrow
private-literal qualification. No guessed detector correction is retained.

All prototype sources, successive results and failures are preserved. An initial
full-rule test assertion incorrectly included other rules' unresolved-send
warnings; the corrected SENT-015 assertion passes in worker execution. The
prototype test edits were restored to the exact delivered source. The workspace's
missing Git link and 1,028 tracked files were restored from commit `328f7af`,
without overwriting existing files; 1,814 missing evidence members were restored
from verified seals. Existing user files and source freezes remain intact.

The exact **unapproved** fallback is
`artifacts/phase22/integration/v36-guard-recovery/diagnostic-proposal.json`:
**one instrumented `ddg-cgnat-fixed` observation** at immutable `a50e9b7`,
120-second target, **300-second native/whole-input maximum**, 15-second cleanup
maximum and **ten-minute sequence maximum**. It traces guard/predicate/request
facts and report deduplication using bounded observational wrappers. Entire
ordered output must match the retained fixed report after the established
11 volatile exclusions; JSON/SARIF, source/configuration, trace completeness and
hook/process cleanup must pass. Synthetic inline/worker report equality and
one-use/failure accounting checks pass. The initial mocked output-directory
failure and correction are retained. **No new corpus observation, comparator,
CPU profile, target execution or paid call occurred.** Any diagnostic failure
consumes its single observation; no retry or additional measurement is implied.

The actual **v35 regression still fails DDG guard coverage and Meta compatibility**:
87/87 completed at `a50e9b7`, 79 within 120 seconds, eight extended, longest
241.846285 seconds, and 36 entire ordered repeats. DDG detects both vulnerable
variants per batch; all six fixed/control sends lack the required CGNAT qualifier.
The two fixed DDG variants each have one matching generic alert. Each of two
fixed Meta image variants gains three matching alerts; their public controls
retain broader unmatched candidates. Both 31-input Python historical batches
retain 14 vulnerable hits and zero matching alerts on 17 negatives. All changed
findings and diagnostics remain source-assessed; the 87-observation budget is closed.

Engineering retains actual `8a3db58`: 2,280 passed / 36 skipped locally and in
12 hosted suites, 89.87% local branch coverage, 29 normal CI jobs, docs, verified
package sources and six zero-call production replays. Product/test/workflow bytes
are identical; no new full-suite or hosted pass is claimed for this investigation.
Original first-frozen DDG detection at `f85a90f`, its fixed-path limitation, all
original misses and every failed/closed scope remain unchanged. Prior TypeScript
compatibility and whole Linux timing retain their actual source bindings; no
partial observations are pooled into a new whole-batch pass.

The audit retains **89 original rows: 84 passed, two user-deferred, three
unresolved (R33, R65, R84)**, and **102 added rows: 94 passed, five historical
proposed limitations and three unresolved**. The added DDG correction/recovery
gates remain pending. Git campaigns stay **312/1,040 incomplete**, as requested.
Paid benchmark/pilots remain deferred; Phase 21 incomplete and Phase 24/15 unchanged.
**Phase 22 remains incomplete; technical acceptance is not requested.** The
approved recovery proposal requires separate diagnostic approval when synthetic
controls cannot establish the actual loss. After an established correction,
ordinary engineering, a new exact regression decision and final human acceptance
remain. No merge, ready-state, release, outreach or Phase 23 is authorized.
'''
old='## Current v35 exposed regression result and recovery checkpoint\n\n'+(BASE/'v35-ddg-regression/summary.md').read_text().split('\n\n',1)[1]+'\n';note='## Current v36 source-only investigation and diagnostic checkpoint\n\n'+text+'\n'
for name in read(BASE/'v35-ddg-regression/documentation-binding.json')['owning_docs_sha256']:
 p=ROOT/name;s=p.read_text();assert s.count(old)==1,name;p.write_text(s.replace(old,note))
p=ROOT/'artifacts/phase22/integration/README.md';s=p.read_text().replace('batches 1–62','batches 1–63',1);oldlinks='Review [actual regression assessment](v35-ddg-regression/assessment.json), [89 + 97 row audit](v35-ddg-regression/audit.json), [source-only recovery proposal](v35-ddg-regression/recovery-proposal.json) and the unchanged [approved scoring rubric](v34-import-binding/scoring-rubric.json). Restore seal 62 after seals 1–61, verifying all archive and member hashes in numeric order. Earlier readiness proposals remain historical and were not accepted.'
assert oldlinks in s;p.write_text(s.replace(oldlinks,'Review [source-only investigation](v36-guard-recovery/assessment.json), [89 + 102 row audit](v36-guard-recovery/audit.json), [exact unapproved diagnostic](v36-guard-recovery/diagnostic-proposal.json) and [diagnostic rubric](v36-guard-recovery/scoring-rubric.json). Restore seal 63 after seals 1–62, verifying all archive/member hashes in numeric order. The measured [v35 failure](v35-ddg-regression/assessment.json) remains unchanged.'))
(OUT/'summary.md').write_text('# Phase 22 source-only recovery: diagnostic checkpoint\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: guard investigation retained; exact diagnostic pending\n\n'+text+'\nReview `artifacts/phase22/integration/v36-guard-recovery/` for authorization, source controls, trace transparency, one-use runner checks and the exact pending proposal. Seal63 retains this preparation after all62 preceding seals.\n\nRetained CI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626907\nRetained docs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626916\n')
print('Updated14 owning docs; unchanged measured failure and unapproved one-observation diagnostic.')
