"""
Lightning Enable MCP Server

Main server module providing L402 payment capabilities to AI agents via MCP.
"""

import asyncio
import logging
import os
import sys
from typing import Any

from mcp.server import Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Tool,
    TextContent,
)

from . import __version__
from .budget_service import BudgetService, get_budget_service
from .payment_history_service import (
    PaymentHistoryService,
    get_payment_history_service,
)
from .l402_client import L402Client
from .lnd_wallet import LndWallet
from .lightning_enable_api import LightningEnableApiClient
from .nwc_wallet import NWCWallet, NWCConfig
from .opennode_wallet import OpenNodeWallet
from .strike_wallet import StrikeWallet
from .tools.access_resource import access_l402_resource
from .tools.create_account import create_lightning_enable_account
from .tools.test_l402_payment import test_l402_payment
from .tools.get_receipts import get_receipts
from .receipt_service import ReceiptService, wallet_label_from
from .tools.check_invoice_status import check_invoice_status
from .tools.confirm_payment import confirm_payment
from .tools.create_invoice import create_invoice
from .tools.create_l402_challenge import create_l402_challenge
from .tools.discover_api import discover_api
from .tools.exchange_currency import exchange_currency
from .tools.get_all_balances import get_all_balances
from .tools.get_btc_price import get_btc_price
from .tools.pay_challenge import pay_l402_challenge
from .tools.pay_invoice import pay_invoice
from .tools.send_onchain import send_onchain
from .tools.verify_l402_payment import verify_l402_payment
from .tools.wallet import check_wallet_balance
from .tools.budget import configure_budget, get_payment_history
from .tools.budget_status import get_budget_status
from .tools.discover_agent_services import discover_agent_services
from .tools.publish_agent_capability import publish_agent_capability
from .tools.request_agent_service import request_agent_service
from .tools.publish_agent_attestation import publish_agent_attestation
from .tools.get_agent_reputation import get_agent_reputation
from .tools.settle_agent_service import settle_agent_service

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("lightning-enable-mcp")


import re

_CREDENTIAL_PATTERNS = [
    re.compile(r"Bearer\s+\S+", re.IGNORECASE),
    re.compile(r"shpat_\S+", re.IGNORECASE),
    re.compile(r"sk_live_\S+", re.IGNORECASE),
    re.compile(r"sk_test_\S+", re.IGNORECASE),
    re.compile(r"[A-Za-z0-9+/]{40,}={0,2}"),  # Long base64-like tokens
]


def _sanitize_error(msg: str) -> str:
    """Remove potential credentials from error messages."""
    for pattern in _CREDENTIAL_PATTERNS:
        msg = pattern.sub("[REDACTED]", msg)
    return msg


class LightningEnableServer:
    """MCP Server for L402 Lightning payments."""

    def __init__(self) -> None:
        self.server = Server("lightning-enable", version=__version__)
        self.wallet: LndWallet | NWCWallet | OpenNodeWallet | StrikeWallet | None = None
        self.strike_wallet: StrikeWallet | None = None  # For Strike-specific features
        self.l402_client: L402Client | None = None
        self.budget_service: BudgetService | None = None  # Single source of truth for limits
        self.payment_history_service: PaymentHistoryService | None = None  # Session audit trail
        # Always available so get_receipts can read the durable log even without a
        # wallet configured (the "pull the plug" audit moment). The wallet label is
        # upgraded from "unknown" once a wallet is initialized (used only on write).
        self.receipt_service: ReceiptService | None = ReceiptService(wallet_label="unknown")
        self._nwc_config: NWCConfig | None = None  # Store NWC config for pubkey access
        self.api_client: LightningEnableApiClient | None = None  # For L402 producer tools

        self._setup_handlers()

    def _setup_handlers(self) -> None:
        """Register MCP tool handlers."""

        @self.server.list_tools()
        async def list_tools() -> list[Tool]:
            """Return the list of available tools."""
            return [
                Tool(
                    name="access_l402_resource",
                    description=(
                        "Fetch a URL with automatic L402 payment handling. "
                        "If the server returns a 402 Payment Required response, "
                        "the invoice will be automatically paid and the request retried."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "url": {
                                "type": "string",
                                "description": "The URL to fetch",
                            },
                            "method": {
                                "type": "string",
                                "description": "HTTP method (GET, POST, PUT, DELETE)",
                                "default": "GET",
                                "enum": ["GET", "POST", "PUT", "DELETE"],
                            },
                            "headers": {
                                "type": "object",
                                "description": "Optional additional request headers",
                                "additionalProperties": {"type": "string"},
                            },
                            "body": {
                                "type": "string",
                                "description": "Optional request body for POST/PUT requests",
                            },
                            "max_sats": {
                                "type": "integer",
                                "description": "Maximum satoshis to pay for this request",
                                "default": 1000,
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human operator read from the server console, for payments above the auto-approve threshold. The code is NEVER in a tool result — ask the human for it. Omit on the first call to request one.",
                            },
                        },
                        "required": ["url"],
                    },
                ),
                Tool(
                    name="test_l402_payment",
                    description=(
                        "Self-test the Lightning wallet by paying the public 1-sat L402 test "
                        "endpoint end to end. Proves the wallet is connected, returns a preimage, "
                        "and can complete an L402 payment. Costs about 1 satoshi. Use this to "
                        "verify setup or answer 'is my wallet actually working?'. If your budget "
                        "config requires confirmation for this amount, the verdict is "
                        "'needs_confirmation' and the server prints a code to its console — re-run "
                        "with confirmation_nonce set to that code."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human read from the server console, if a prior call returned test='needs_confirmation'. Omit on the first call.",
                            },
                        },
                        "required": [],
                    },
                ),
                Tool(
                    name="pay_l402_challenge",
                    description=(
                        "Manually pay an L402 or MPP invoice and receive the authorization token. "
                        "Use this if you need to handle the L402/MPP flow yourself. "
                        "Omit macaroon for MPP (Machine Payments Protocol) mode."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "invoice": {
                                "type": "string",
                                "description": "BOLT11 Lightning invoice string",
                            },
                            "macaroon": {
                                "type": ["string", "null"],
                                "description": "Base64-encoded macaroon from the L402 challenge. Omit for MPP mode (preimage-only authentication).",
                            },
                            "max_sats": {
                                "type": "integer",
                                "description": "Maximum satoshis allowed for this payment",
                                "default": 1000,
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human operator read from the server console, for payments above the auto-approve threshold. The code is NEVER in a tool result — ask the human for it. Omit on the first call to request one.",
                            },
                        },
                        "required": ["invoice"],
                    },
                ),
                Tool(
                    name="create_lightning_enable_account",
                    description=(
                        "Self-bootstrapping signup: activate a Lightning Enable account with a tiny "
                        "Lightning payment (~100 sats) and get back a merchant API key. Requires NO "
                        "Lightning Enable API key (it CREATES one) — only a connected wallet. On success "
                        "the API key is saved to ~/.lightning-enable/config.json so the producer/ASA tools "
                        "unlock. Above-threshold fees require an out-of-band confirmation code (as with "
                        "pay_l402_challenge)."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "email": {
                                "type": "string",
                                "description": "Email address to register the Lightning Enable account under.",
                            },
                            "max_sats": {
                                "type": "integer",
                                "description": "Maximum satoshis to pay for activation. The fee is ~100 sats.",
                                "default": 1000,
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human operator read from the server console, for an above-threshold activation fee. The code is NEVER in a tool result — ask the human for it. Omit on the first call to request one.",
                            },
                        },
                        "required": ["email"],
                    },
                ),
                Tool(
                    name="check_wallet_balance",
                    description="Check the connected Lightning wallet balance via NWC.",
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
                Tool(
                    name="get_payment_history",
                    description="List recent L402 payments made during this session.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of payments to return",
                                "default": 10,
                            },
                            "since": {
                                "type": "string",
                                "description": "ISO timestamp to filter payments from",
                            },
                        },
                    },
                ),
                Tool(
                    name="get_receipts",
                    description=(
                        "Read the durable, append-only payment receipt log "
                        "(~/.lightning-enable/receipts.jsonl). Unlike get_payment_history "
                        "(in-memory, this session only), receipts persist across sessions and "
                        "include the spend policy and how to revoke the wallet. Use to review "
                        "what an agent has spent and how to pull the plug."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of recent receipts to return (1-200)",
                                "default": 20,
                            },
                        },
                    },
                ),
                Tool(
                    name="configure_budget",
                    description="Set spending limits for the session.",
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "per_request": {
                                "type": "integer",
                                "description": "Maximum satoshis per individual request",
                                "default": 1000,
                            },
                            "per_session": {
                                "type": "integer",
                                "description": "Maximum total satoshis for the entire session",
                                "default": 10000,
                            },
                        },
                    },
                ),
                Tool(
                    name="pay_invoice",
                    description=(
                        "Pay a Lightning invoice directly and get the preimage as proof of payment. "
                        "Use this to pay any BOLT11 Lightning invoice without L402 protocol overhead."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "invoice": {
                                "type": "string",
                                "description": "BOLT11 Lightning invoice string to pay",
                            },
                            "max_sats": {
                                "type": "integer",
                                "description": "Maximum satoshis allowed to pay. Defaults to 1000",
                                "default": 1000,
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human operator read from the server console, for payments above the auto-approve threshold. The code is NEVER in a tool result — ask the human for it. Omit on the first call to request one.",
                            },
                        },
                        "required": ["invoice"],
                    },
                ),
                Tool(
                    name="create_invoice",
                    description=(
                        "Create a Lightning invoice to receive a payment. "
                        "Returns a BOLT11 invoice string to share with the payer."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "amount_sats": {
                                "type": "integer",
                                "description": "Amount to receive in satoshis",
                            },
                            "memo": {
                                "type": "string",
                                "description": "Optional description/memo for the invoice",
                            },
                            "expiry_secs": {
                                "type": "integer",
                                "description": "Invoice expiry time in seconds. Defaults to 3600 (1 hour)",
                                "default": 3600,
                            },
                        },
                        "required": ["amount_sats"],
                    },
                ),
                Tool(
                    name="check_invoice_status",
                    description=(
                        "Check if a Lightning invoice has been paid. "
                        "Use the invoice ID from create_invoice."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "invoice_id": {
                                "type": "string",
                                "description": "The invoice ID returned from create_invoice",
                            },
                        },
                        "required": ["invoice_id"],
                    },
                ),
                Tool(
                    name="get_all_balances",
                    description=(
                        "Get all currency balances from your wallet (USD, BTC, etc.). "
                        "Most useful with Strike wallet which supports multiple currencies."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
                Tool(
                    name="get_btc_price",
                    description=(
                        "Get the current Bitcoin price in USD. "
                        "Only available with Strike wallet."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
                Tool(
                    name="exchange_currency",
                    description=(
                        "Exchange currency within your wallet (USD to BTC or BTC to USD). "
                        "Currently only available with Strike wallet."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "source_currency": {
                                "type": "string",
                                "description": "Currency to convert from: USD or BTC",
                            },
                            "target_currency": {
                                "type": "string",
                                "description": "Currency to convert to: BTC or USD",
                            },
                            "amount": {
                                "type": "number",
                                "description": "Amount in source currency (e.g., 100 for $100 or 0.001 for 0.001 BTC)",
                            },
                        },
                        "required": ["source_currency", "target_currency", "amount"],
                    },
                ),
                Tool(
                    name="send_onchain",
                    description=(
                        "Send an on-chain Bitcoin payment to a Bitcoin address. "
                        "Currently only available with Strike wallet."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "address": {
                                "type": "string",
                                "description": "Bitcoin address to send to (e.g., bc1q...)",
                            },
                            "amount_sats": {
                                "type": "integer",
                                "description": "Amount to send in satoshis",
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": (
                                    "Confirmation code the human operator read from the server console. "
                                    "On-chain sends always require it: the first call prints a code to the "
                                    "console (never in the result) and returns requiresConfirmation; ask the "
                                    "human and call again with confirmation_nonce set to it."
                                ),
                            },
                        },
                        "required": ["address", "amount_sats"],
                    },
                ),
                Tool(
                    name="get_budget_status",
                    description=(
                        "View current budget status and spending limits (read-only). "
                        "Edit ~/.lightning-enable/config.json to change limits."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {},
                    },
                ),
                Tool(
                    name="create_l402_challenge",
                    description=(
                        "Create an L402 payment challenge to charge another agent or user for accessing a resource. "
                        "Returns a Lightning invoice and macaroon. The payer must pay the invoice and present "
                        "the L402 token (macaroon:preimage) back to you for verification. "
                        "Requires LIGHTNING_ENABLE_API_KEY with an Agentic Commerce subscription."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "resource": {
                                "type": "string",
                                "description": "Resource identifier - URL, service name, or description of what you're charging for",
                            },
                            "price_sats": {
                                "type": "integer",
                                "description": "Price in satoshis to charge",
                            },
                            "description": {
                                "type": "string",
                                "description": "Description shown on the Lightning invoice",
                            },
                        },
                        "required": ["resource", "price_sats"],
                    },
                ),
                Tool(
                    name="verify_l402_payment",
                    description=(
                        "Verify an L402 token (macaroon + preimage) to confirm payment was made. "
                        "Use this after receiving an L402 token from a payer to validate they paid "
                        "before granting access to the resource. "
                        "Requires LIGHTNING_ENABLE_API_KEY with an Agentic Commerce subscription."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "macaroon": {
                                "type": "string",
                                "description": "Base64-encoded macaroon from the L402 token",
                            },
                            "preimage": {
                                "type": "string",
                                "description": "Hex-encoded preimage (proof of payment)",
                            },
                        },
                        "required": ["macaroon", "preimage"],
                    },
                ),
                Tool(
                    name="confirm_payment",
                    description=(
                        "Confirm a pending payment using the nonce code from a previous payment request. "
                        "Call this after a payment tool returns requiresConfirmation=true with a nonce."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "nonce": {
                                "type": "string",
                                "description": "The 6-character confirmation code from the payment request",
                            },
                        },
                        "required": ["nonce"],
                    },
                ),
                Tool(
                    name="discover_api",
                    description=(
                        "Discover L402-enabled APIs. Use 'query' to search the registry for available APIs by keyword, "
                        "or use 'url' to fetch a specific API's manifest with full endpoint details and pricing. "
                        "Use 'category' to browse by category. With budget_aware=true, shows how many calls you can afford."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "url": {
                                "type": "string",
                                "description": "Base URL of the L402-enabled API, or direct URL to the manifest JSON file. If omitted, searches the registry instead.",
                            },
                            "query": {
                                "type": "string",
                                "description": "Search the L402 API registry by keyword (e.g., 'weather', 'ai', 'geocoding').",
                            },
                            "category": {
                                "type": "string",
                                "description": "Filter registry results by category (e.g., 'ai', 'data', 'finance').",
                            },
                            "budget_aware": {
                                "type": "boolean",
                                "description": "If true, annotate endpoints with affordable call counts based on remaining budget. Default: true.",
                                "default": True,
                            },
                        },
                    },
                ),
                Tool(
                    name="discover_agent_services",
                    description=(
                        "Discover agent services on the Nostr network. Search by category, hashtag, or keyword. "
                        "Returns capabilities published as kind 38400 events. "
                        "Use this to find agents that offer services you can pay for via L402."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "category": {
                                "type": "string",
                                "description": "Filter by service category (e.g., 'ai', 'data', 'translation')",
                            },
                            "hashtags": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Filter by hashtags",
                            },
                            "query": {
                                "type": "string",
                                "description": "Search query",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum results to return",
                                "default": 20,
                            },
                        },
                    },
                ),
                Tool(
                    name="publish_agent_capability",
                    description=(
                        "Publish an agent capability advertisement to the Nostr network. "
                        "Makes your agent discoverable by other agents. Creates a kind 38400 event. "
                        "Optionally creates an L402 proxy for payment settlement. "
                        "Requires LIGHTNING_ENABLE_API_KEY."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "service_id": {
                                "type": "string",
                                "description": "Unique service identifier (used as d-tag)",
                            },
                            "categories": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Service categories (e.g., ['ai', 'translation'])",
                            },
                            "content": {
                                "type": "string",
                                "description": "Description of the service",
                            },
                            "price_sats": {
                                "type": "integer",
                                "description": "Price per request in satoshis",
                            },
                            "l402_endpoint": {
                                "type": "string",
                                "description": "L402 endpoint URL for payment settlement",
                            },
                            "target_url": {
                                "type": "string",
                                "description": "Target API URL (if auto-creating an L402 proxy via Lightning Enable)",
                            },
                            "hashtags": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Hashtags for discoverability",
                            },
                        },
                        "required": ["service_id", "categories", "content", "price_sats"],
                    },
                ),
                Tool(
                    name="request_agent_service",
                    description=(
                        "Sends a service request (kind 38401 event) referencing the provider's capability. "
                        "The provider responds with agreement/settlement terms; settle via settle_agent_service. "
                        "If the provider has an L402 endpoint, you can skip this step "
                        "and use settle_agent_service directly. Requires LIGHTNING_ENABLE_API_KEY."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "capability_event_id": {
                                "type": "string",
                                "description": "Event ID of the capability to request",
                            },
                            "budget_sats": {
                                "type": "integer",
                                "description": "Maximum budget in satoshis",
                            },
                            "parameters": {
                                "type": "string",
                                "description": "Additional parameters as a JSON string",
                            },
                        },
                        "required": ["capability_event_id", "budget_sats"],
                    },
                ),
                Tool(
                    name="publish_agent_attestation",
                    description=(
                        "Publish an attestation (review) for an agent after a completed agreement. "
                        "Creates a kind 38403 event that builds the agent's on-protocol reputation. "
                        "Requires LIGHTNING_ENABLE_API_KEY."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "subject_pubkey": {
                                "type": "string",
                                "description": "Pubkey of the agent being reviewed",
                            },
                            "agreement_id": {
                                "type": "string",
                                "description": "Event ID of the agreement this review is for",
                            },
                            "rating": {
                                "type": "integer",
                                "description": "Rating from 1-5",
                            },
                            "content": {
                                "type": "string",
                                "description": "Free-text review content",
                            },
                            "proof": {
                                "type": "string",
                                "description": "Optional: hash of L402 payment preimage as proof of real transaction",
                            },
                        },
                        "required": ["subject_pubkey", "agreement_id", "rating", "content"],
                    },
                ),
                Tool(
                    name="get_agent_reputation",
                    description=(
                        "Get an agent's reputation score and reviews. "
                        "Queries kind 38403 attestation events for the given pubkey. "
                        "Returns average rating and individual reviews."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "pubkey": {
                                "type": "string",
                                "description": "Pubkey of the agent to query reputation for",
                            },
                            "limit": {
                                "type": "integer",
                                "description": "Maximum number of attestations to return",
                                "default": 20,
                            },
                        },
                        "required": ["pubkey"],
                    },
                ),
                Tool(
                    name="settle_agent_service",
                    description=(
                        "Settle an agent service agreement via L402 payment (CONSUMER/REQUESTER side). "
                        "Pays the L402 endpoint specified in the agreement, completing the service transaction. "
                        "Uses the same L402 auto-pay flow as access_l402_resource. "
                        "The L402 endpoint URL comes from discover_agent_services or request_agent_service results. "
                        "NOTE: If you are the PROVIDER (selling a service), use create_l402_challenge to generate "
                        "a Lightning invoice at the agreed price, then verify_l402_payment to confirm payment "
                        "before delivering the service."
                    ),
                    inputSchema={
                        "type": "object",
                        "properties": {
                            "l402_endpoint": {
                                "type": "string",
                                "description": "L402 endpoint URL from the service agreement",
                            },
                            "method": {
                                "type": "string",
                                "description": "HTTP method (GET, POST, PUT, DELETE). Defaults to GET",
                                "default": "GET",
                            },
                            "body": {
                                "type": "string",
                                "description": "Optional request body for POST requests (e.g., service parameters as JSON)",
                            },
                            "agreement_id": {
                                "type": "string",
                                "description": "Agreement event ID for tracking",
                            },
                            "max_sats": {
                                "type": "integer",
                                "description": "Maximum satoshis to pay",
                                "default": 1000,
                            },
                            "confirmation_nonce": {
                                "type": "string",
                                "description": "Confirmation code the human operator read from the server console, for settlements above the auto-approve threshold. The code is NEVER in a tool result — ask the human for it. Omit on the first call to request one.",
                            },
                        },
                        "required": ["l402_endpoint"],
                    },
                ),
            ]

        @self.server.call_tool()
        async def call_tool(name: str, arguments: dict[str, Any]) -> list[TextContent]:
            """Handle tool invocations."""
            try:
                # Ensure services are initialized
                if self.wallet is None or self.l402_client is None:
                    await self._initialize_services()

                # Tools that don't require a wallet connection.
                # The ASA discovery/publish/request/attestation/reputation tools
                # use the Lightning Enable API (or public registry), not the
                # wallet — only settle_agent_service needs a wallet, so it is
                # intentionally NOT in this set.
                producer_tools = {
                    "create_l402_challenge",
                    "verify_l402_payment",
                    "discover_api",
                    "confirm_payment",
                    "discover_agent_services",
                    "publish_agent_capability",
                    "request_agent_service",
                    "publish_agent_attestation",
                    "get_agent_reputation",
                }

                # test_l402_payment is allowed through even without a wallet so it can
                # return its own structured no_wallet verdict (parity with .NET), instead
                # of this generic guard string (which also wrongly suggests OpenNode, which
                # cannot do L402).
                if (
                    self.wallet is None
                    and name not in producer_tools
                    and name != "test_l402_payment"
                    and name != "get_receipts"  # reads the durable log; no wallet needed
                ):
                    return [
                        TextContent(
                            type="text",
                            text="Error: No wallet configured. Set one L402-capable wallet: "
                            "STRIKE_API_KEY, NWC_CONNECTION_STRING, or "
                            "LND_REST_HOST+LND_MACAROON_HEX. "
                            "(OPENNODE_API_KEY is receiving/invoicing only — it cannot pay "
                            "L402 challenges.) "
                            "Then run test_l402_payment to confirm the wallet works end to end.",
                        )
                    ]

                # Route to appropriate handler
                if name == "access_l402_resource":
                    result = await access_l402_resource(
                        url=arguments["url"],
                        method=arguments.get("method", "GET"),
                        headers=arguments.get("headers", {}),
                        body=arguments.get("body"),
                        max_sats=arguments.get("max_sats", 1000),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        l402_client=self.l402_client,
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                        receipt_service=self.receipt_service,
                    )

                elif name == "get_receipts":
                    result = await get_receipts(
                        limit=arguments.get("limit", 20),
                        receipt_service=self.receipt_service,
                    )

                elif name == "test_l402_payment":
                    result = await test_l402_payment(
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        l402_client=self.l402_client,
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                    )

                elif name == "pay_l402_challenge":
                    result = await pay_l402_challenge(
                        invoice=arguments["invoice"],
                        macaroon=arguments.get("macaroon"),
                        max_sats=arguments.get("max_sats", 1000),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        wallet=self.wallet,
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                    )

                elif name == "create_lightning_enable_account":
                    result = await create_lightning_enable_account(
                        email=arguments.get("email", ""),
                        max_sats=arguments.get("max_sats", 1000),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        l402_client=self.l402_client,
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                        receipt_service=self.receipt_service,
                    )

                elif name == "check_wallet_balance":
                    result = await check_wallet_balance(wallet=self.wallet)

                elif name == "get_payment_history":
                    result = await get_payment_history(
                        limit=arguments.get("limit", 10),
                        since=arguments.get("since"),
                        payment_history_service=self.payment_history_service,
                    )

                elif name == "configure_budget":
                    result = await configure_budget(
                        per_request=arguments.get("per_request", 1000),
                        per_session=arguments.get("per_session", 10000),
                        budget_service=self.budget_service,
                    )

                elif name == "pay_invoice":
                    result = await pay_invoice(
                        invoice=arguments.get("invoice", ""),
                        max_sats=arguments.get("max_sats", 1000),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        wallet=self.wallet,
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                    )

                elif name == "create_invoice":
                    result = await create_invoice(
                        amount_sats=arguments.get("amount_sats", 0),
                        memo=arguments.get("memo"),
                        expiry_secs=arguments.get("expiry_secs", 3600),
                        wallet=self.wallet,
                    )

                elif name == "check_invoice_status":
                    result = await check_invoice_status(
                        invoice_id=arguments.get("invoice_id", ""),
                        wallet=self.wallet,
                    )

                elif name == "get_all_balances":
                    result = await get_all_balances(
                        wallet=self.wallet,
                        strike_wallet=self.strike_wallet,
                        budget_service=self.budget_service,
                    )

                elif name == "get_btc_price":
                    result = await get_btc_price(
                        wallet=self.strike_wallet,
                    )

                elif name == "exchange_currency":
                    result = await exchange_currency(
                        source_currency=arguments.get("source_currency", ""),
                        target_currency=arguments.get("target_currency", ""),
                        amount=arguments.get("amount", 0),
                        wallet=self.strike_wallet,
                    )

                elif name == "send_onchain":
                    # send_onchain supports Strike and LND wallets
                    onchain_wallet = self.strike_wallet
                    if onchain_wallet is None and isinstance(self.wallet, LndWallet):
                        onchain_wallet = self.wallet
                    result = await send_onchain(
                        address=arguments.get("address", ""),
                        amount_sats=arguments.get("amount_sats", 0),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        wallet=onchain_wallet,
                        budget_service=self.budget_service,
                    )

                elif name == "get_budget_status":
                    result = await get_budget_status(
                        budget_service=self.budget_service,
                        payment_history_service=self.payment_history_service,
                    )

                elif name == "create_l402_challenge":
                    result = await create_l402_challenge(
                        resource=arguments.get("resource", ""),
                        price_sats=arguments.get("price_sats", 0),
                        description=arguments.get("description"),
                        api_client=self.api_client,
                    )

                elif name == "verify_l402_payment":
                    result = await verify_l402_payment(
                        macaroon=arguments.get("macaroon", ""),
                        preimage=arguments.get("preimage", ""),
                        api_client=self.api_client,
                    )

                elif name == "confirm_payment":
                    result = await confirm_payment(
                        nonce=arguments.get("nonce", ""),
                        budget_service=self.budget_service,
                    )

                elif name == "discover_api":
                    result = await discover_api(
                        url=arguments.get("url"),
                        query=arguments.get("query"),
                        category=arguments.get("category"),
                        budget_aware=arguments.get("budget_aware", True),
                        budget_service=self.budget_service,
                    )

                elif name == "discover_agent_services":
                    result = await discover_agent_services(
                        category=arguments.get("category"),
                        hashtags=arguments.get("hashtags"),
                        query=arguments.get("query"),
                        limit=arguments.get("limit", 20),
                        api_client=self.api_client,
                        budget_service=self.budget_service,
                    )

                elif name == "publish_agent_capability":
                    result = await publish_agent_capability(
                        service_id=arguments.get("service_id", ""),
                        categories=arguments.get("categories", []),
                        content=arguments.get("content", ""),
                        price_sats=arguments.get("price_sats", 0),
                        l402_endpoint=arguments.get("l402_endpoint"),
                        target_url=arguments.get("target_url"),
                        hashtags=arguments.get("hashtags"),
                        api_client=self.api_client,
                    )

                elif name == "request_agent_service":
                    result = await request_agent_service(
                        capability_event_id=arguments.get("capability_event_id", ""),
                        budget_sats=arguments.get("budget_sats", 0),
                        parameters=arguments.get("parameters"),
                        api_client=self.api_client,
                        budget_service=self.budget_service,
                    )

                elif name == "publish_agent_attestation":
                    result = await publish_agent_attestation(
                        subject_pubkey=arguments.get("subject_pubkey", ""),
                        agreement_id=arguments.get("agreement_id", ""),
                        rating=arguments.get("rating", 0),
                        content=arguments.get("content", ""),
                        proof=arguments.get("proof"),
                        api_client=self.api_client,
                    )

                elif name == "get_agent_reputation":
                    result = await get_agent_reputation(
                        pubkey=arguments.get("pubkey", ""),
                        limit=arguments.get("limit", 20),
                        api_client=self.api_client,
                    )

                elif name == "settle_agent_service":
                    result = await settle_agent_service(
                        l402_endpoint=arguments.get("l402_endpoint", ""),
                        method=arguments.get("method", "GET"),
                        body=arguments.get("body"),
                        agreement_id=arguments.get("agreement_id"),
                        max_sats=arguments.get("max_sats", 1000),
                        confirmation_nonce=arguments.get("confirmation_nonce"),
                        l402_client=self.l402_client,
                        budget_service=self.budget_service,
                    )

                else:
                    result = f"Unknown tool: {name}"

                return [TextContent(type="text", text=str(result))]

            except Exception as e:
                logger.exception(f"Error in tool {name}")
                # Sanitize exception message to avoid leaking credentials
                safe_msg = _sanitize_error(str(e))
                return [TextContent(type="text", text=f"Error in {name}: {safe_msg}")]

    async def _initialize_services(self) -> None:
        """Initialize wallet, L402 client, budget service, and payment history.

        Supports wallet backends (in priority order for L402):
        1. LND - Set LND_REST_HOST + LND_MACAROON_HEX (direct node, always returns preimage)
        2. NWC (Nostr Wallet Connect) - Set NWC_CONNECTION_STRING (returns preimage - best for L402)
        3. Strike - Set STRIKE_API_KEY (returns preimage via lightning.preImage - L402 works)
        4. OpenNode - Set OPENNODE_API_KEY (does NOT return preimage - L402 will NOT work)

        For L402 support, use LND, NWC, or Strike. OpenNode is for general payments only.
        """
        from .config import get_config_service

        config_service = get_config_service()
        wallet_config = config_service.configuration.wallets

        # Read env vars with config file fallback (matching .NET behavior)
        def _get_env_or_config(env_var: str, config_value: str | None) -> str | None:
            """Get value from env var, falling back to config file."""
            value = os.getenv(env_var)
            if not value or value.startswith("${"):
                return config_value
            return value

        lnd_rest_host = _get_env_or_config("LND_REST_HOST", wallet_config.lnd_rest_host)
        lnd_macaroon_hex = _get_env_or_config("LND_MACAROON_HEX", wallet_config.lnd_macaroon_hex)
        nwc_connection = _get_env_or_config("NWC_CONNECTION_STRING", wallet_config.nwc_connection_string)
        strike_api_key = _get_env_or_config("STRIKE_API_KEY", wallet_config.strike_api_key)
        opennode_api_key = _get_env_or_config("OPENNODE_API_KEY", wallet_config.opennode_api_key)

        lnd_skip_tls_verify = os.getenv("LND_SKIP_TLS_VERIFY", "").lower() == "true"

        # Always initialize API client (for producer tools, independent of wallet)
        self.api_client = LightningEnableApiClient()
        if self.api_client.is_configured:
            logger.info("Lightning Enable API client configured - producer tools available")

        has_lnd = bool(lnd_rest_host and lnd_macaroon_hex)
        has_nwc = bool(nwc_connection)
        has_strike = bool(strike_api_key)
        has_opennode = bool(opennode_api_key)

        if not has_lnd and not has_nwc and not has_strike and not has_opennode:
            logger.warning(
                "No wallet configured. Set one L402-capable wallet: STRIKE_API_KEY, "
                "NWC_CONNECTION_STRING, or LND_REST_HOST+LND_MACAROON_HEX. "
                "(OPENNODE_API_KEY is receiving/invoicing only — it cannot pay L402 "
                "challenges.) Then run test_l402_payment to confirm the wallet works."
            )
            return

        try:
            # Determine wallet priority
            # Default: LND > NWC > Strike > OpenNode
            # Can be overridden via WALLET_PRIORITY env var or config
            wallet_priority = os.getenv("WALLET_PRIORITY", "").lower() or (wallet_config.priority or "").lower()

            if wallet_priority == "lnd" and has_lnd:
                selected = "lnd"
            elif wallet_priority == "nwc" and has_nwc:
                selected = "nwc"
            elif wallet_priority == "strike" and has_strike:
                selected = "strike"
            elif wallet_priority == "opennode" and has_opennode:
                selected = "opennode"
            elif has_lnd:
                selected = "lnd"
            elif has_nwc:
                selected = "nwc"
            elif has_strike:
                selected = "strike"
            elif has_opennode:
                selected = "opennode"
            else:
                selected = None

            # Initialize wallet based on priority
            if selected == "lnd":
                logger.info("Initializing LND wallet (L402 compatible, direct node)...")
                self.wallet = LndWallet(
                    rest_host=lnd_rest_host,
                    macaroon_hex=lnd_macaroon_hex,
                    skip_tls_verify=lnd_skip_tls_verify,
                )
                await self.wallet.connect()
                logger.info("LND wallet connected - preimage always available")
            elif selected == "nwc":
                logger.info("Initializing NWC wallet (L402 compatible)...")
                self._nwc_config = NWCConfig.from_uri(nwc_connection)
                self.wallet = NWCWallet(nwc_connection)
                await self.wallet.connect()
                logger.info("NWC wallet connected - preimage support available")
            elif selected == "opennode":
                logger.info("Initializing OpenNode wallet...")
                environment = os.getenv("OPENNODE_ENVIRONMENT", "production")
                if not environment or environment.startswith("${"):
                    environment = wallet_config.opennode_environment or "production"
                self.wallet = OpenNodeWallet(
                    api_key=opennode_api_key,
                    environment=environment,
                )
                await self.wallet.connect()
                logger.info(f"OpenNode wallet connected ({environment})")
                logger.warning("OpenNode may not return preimage - L402 may not work")
            elif selected == "strike":
                logger.info("Initializing Strike wallet...")
                self.wallet = StrikeWallet(api_key=strike_api_key)
                await self.wallet.connect()
                logger.info("Strike wallet connected - preimage support available via lightning.preImage")

            # Also initialize Strike for Strike-specific features if available
            if has_strike and not isinstance(self.wallet, StrikeWallet):
                logger.info("Initializing Strike wallet for multi-currency features...")
                self.strike_wallet = StrikeWallet(api_key=strike_api_key)
                await self.strike_wallet.connect()
            elif isinstance(self.wallet, StrikeWallet):
                self.strike_wallet = self.wallet

            # Initialize the BudgetService (single source of truth for spending
            # limits + multi-tier approval + out-of-band confirmation). Uses
            # configuration from ~/.lightning-enable/config.json. The legacy
            # BudgetManager and its L402_MAX_SATS_PER_REQUEST / _PER_SESSION env
            # vars have been removed — runtime sats caps are now tightened via the
            # BudgetService.configure_budget tool (tighten-only).
            self.budget_service = get_budget_service()
            logger.info("BudgetService initialized with multi-tier approval")

            # Initialize the PaymentHistoryService (separate session audit trail).
            self.payment_history_service = get_payment_history_service()

            # Durable, append-only spend receipts (off the agent's context path).
            # Wallet label is fixed for the session, so bake it in at init.
            self.receipt_service = ReceiptService(wallet_label=wallet_label_from(self.wallet))

            # Initialize L402 client
            self.l402_client = L402Client(wallet=self.wallet)

            logger.info("Services initialized successfully")

        except Exception as e:
            logger.exception("Failed to initialize services")
            raise RuntimeError(f"Failed to initialize: {e!s}") from e

    async def run(self) -> None:
        """Run the MCP server."""
        logger.info("Starting Lightning Enable MCP server...")

        async with stdio_server() as (read_stream, write_stream):
            await self.server.run(
                read_stream,
                write_stream,
                self.server.create_initialization_options(),
            )


def main() -> None:
    """Entry point for the MCP server."""
    server = LightningEnableServer()

    try:
        asyncio.run(server.run())
    except KeyboardInterrupt:
        logger.info("Server stopped by user")
        sys.exit(0)
    except Exception as e:
        logger.exception("Server error")
        sys.exit(1)


if __name__ == "__main__":
    main()
