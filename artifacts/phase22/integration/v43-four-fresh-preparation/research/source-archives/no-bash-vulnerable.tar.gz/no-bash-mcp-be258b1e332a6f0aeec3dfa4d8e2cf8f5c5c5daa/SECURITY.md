# Security Policy: No-Bash MCP Server

## Overview

This document outlines the security architecture, threat model, and controls implemented in the No-Bash MCP Server.

## Threat Model

### Primary Threats Addressed

1. **Shell Injection**
   - **Threat**: AI agents executing arbitrary shell commands
   - **Mitigation**: No shell execution; all operations use native APIs
   - **Verification**: Code review confirms no use of `exec`, `execSync`, `spawn`, or similar with user input

2. **Directory Traversal**
   - **Threat**: Agents accessing files outside workspace (e.g., `../../etc/passwd`)
   - **Mitigation**: Path validation ensures all operations stay within `WORKSPACE_ROOT`
   - **Implementation**: `resolveSafePath()` uses `path.resolve()` and prefix checking

3. **Server-Side Request Forgery (SSRF)**
   - **Threat**: Agents making requests to internal infrastructure
   - **Mitigation**: Network allowlist with regex patterns; blocks private IPs
   - **Blocked Ranges**: 127.0.0.0/8, 10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16, 169.254.0.0/16, fc00::/7

4. **Resource Exhaustion**
   - **Threat**: Agents reading/writing massive files to consume memory/disk
   - **Mitigation**: `MAX_FILE_SIZE_MB` limit (default 10MB)
   - **Implementation**: File size checked before reading

5. **Destructive Operations**
   - **Threat**: Agents deleting critical files
   - **Mitigation**: `ALLOW_DELETION` flag (default false); deletion moves to `.mcp_trash/`
   - **Reversibility**: Git integration for full state recovery

6. **Unauthorized Script Execution**
   - **Threat**: Agents running arbitrary system commands
   - **Mitigation**: Pre-approved scripts only; HITL approval required
   - **Implementation**: Scripts validated against package.json; explicit approval prompt

## Security Controls

### Layer 1: Prevention

#### No Shell Execution
```typescript
// ✅ SAFE
fs.readFileSync(filePath, 'utf8');

// ❌ NEVER
execSync(`cat ${filePath}`);
```

All file operations use Node.js native `fs` module. No child processes spawned.

#### Path Validation
```typescript
function resolveSafePath(requestedPath: string, workspaceRoot: string) {
  const absolutePath = path.resolve(workspaceRoot, requestedPath);
  
  // Must be within workspace
  if (!absolutePath.startsWith(path.resolve(workspaceRoot))) {
    throw new Error("Security Violation: Directory traversal attempt.");
  }
  
  return absolutePath;
}
```

#### Network Allowlist
```typescript
const privateIpRegexes = [
  /^127\.\d+\.\d+\.\d+$/,      // localhost
  /^10\.\d+\.\d+\.\d+$/,        // private
  /^172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+$/, // private
  /^192\.168\.\d+\.\d+$/,       // private
  /^169\.254\.\d+\.\d+$/,       // link-local
];
```

### Layer 2: Detection

#### Immutable Audit Logs
Every tool call is logged to `mcp_audit.log`:

```json
{
  "timestamp": "2024-01-15T10:30:00.000Z",
  "tool": "read_file",
  "arguments": {
    "path": "config.yaml",
    "start_line": 1,
    "end_line": 100
  },
  "status": "success",
  "executionTimeMs": 15
}
```

Sensitive data (passwords, tokens, keys) is redacted before logging.

#### File Size Monitoring
All file reads check size against `MAX_FILE_SIZE_MB` before loading into memory.

### Layer 3: Response

#### Human-in-the-Loop (HITL)
Sensitive operations require explicit human approval:

```typescript
if (config.HITL_ENABLED) {
  const approved = await requestApproval({
    prompt: "The agent wishes to run 'npm run build'. Approve?",
    defaultApproved: false,
    timeoutMs: 60000,
  });
  
  if (!approved) {
    return { success: false, error: 'Operation denied.' };
  }
}
```

#### Reversibility
All destructive operations are reversible:

- **File Deletion** → Moved to `.mcp_trash/` (not permanent)
- **File Writes** → Git commit before changes
- **All Changes** → `git_revert_to_checkpoint` available

## Configuration

### Environment Variables

| Variable | Default | Security Impact |
|----------|---------|----------------|
| `WORKSPACE_ROOT` | `process.cwd()` | Defines sandbox boundary |
| `ALLOW_DELETION` | `false` | Prevents file deletion when false |
| `NETWORK_ALLOWLIST` | `""` | Empty = no network access |
| `MAX_FILE_SIZE_MB` | `10` | Prevents large file reads |
| `HITL_ENABLED` | `true` | Requires approval for scripts |

### Secure Configuration Example

```bash
# Production - Maximum Security
export WORKSPACE_ROOT="/app/project"
export ALLOW_DELETION="false"
export NETWORK_ALLOWLIST="api.github.com,raw.githubusercontent.com"
export MAX_FILE_SIZE_MB="5"
export HITL_ENABLED="true"

# Development - Balanced
export WORKSPACE_ROOT="/home/user/dev/project"
export ALLOW_DELETION="true"
export NETWORK_ALLOWLIST="*.github.com,registry.npmjs.org"
export MAX_FILE_SIZE_MB="50"
export HITL_ENABLED="true"

# Testing - Relaxed
export WORKSPACE_ROOT="/tmp/test-workspace"
export ALLOW_DELETION="true"
export NETWORK_ALLOWLIST="*"
export MAX_FILE_SIZE_MB="100"
export HITL_ENABLED="false"
```

## Compliance

### Security Principles

1. **Principle of Least Privilege**: Agents can only access explicitly allowed resources
2. **Defense in Depth**: Multiple layers of security controls
3. **Fail Secure**: Default deny; explicit allow required
4. **Complete Mediation**: Every access checked against policies
5. **Separation of Duties**: HITL for critical operations

### Standards Alignment

- **OWASP Top 10**: Addresses A01 (Broken Access Control), A03 (Injection), A05 (Security Misconfiguration)
- **CWE-78**: OS Command Injection (prevented by design)
- **CWE-22**: Path Traversal (prevented by path validation)
- **CWE-918**: SSRF (prevented by network allowlist)

## Incident Response

### Audit Log Analysis

```bash
# View recent operations
cat mcp_audit.log | tail -20

# Search for failed operations
cat mcp_audit.log | grep '"status": "error"'

# Find operations by tool
cat mcp_audit.log | grep '"tool": "safe_delete"'
```

### Recovery Procedures

1. **Accidental Deletion**:
   ```bash
   # Files in .mcp_trash can be restored
   cp .mcp_trash/deleted-file.txt ./restored-file.txt
   ```

2. **Unwanted Changes**:
   ```bash
   # Revert to last checkpoint
   git reset --hard HEAD
   ```

3. **Malicious Activity**:
   ```bash
   # 1. Revoke agent access
   # 2. Review mcp_audit.log
   # 3. Revert all changes
   # 4. Rotate any exposed credentials
   ```

## Vulnerability Management

### Regular Security Checks

```bash
# Audit tool configuration
npx pi audit-tools

# Check for over-prompting
npx pi bitter-pill

# Review access patterns
cat mcp_audit.log | jq '.tool' | sort | uniq -c
```

### Penetration Testing

Allowed testing vectors:
- Path traversal attempts
- Oversized file uploads
- Network access attempts
- Script execution bypass

Prohibited:
- DoS attacks
- Social engineering
- Physical access attempts
- Credential theft

## Security Contact

For security vulnerabilities or concerns:
- **Internal**: Review `mcp_audit.log` for suspicious activity
- **Configuration**: Check environment variables with `env | grep MCP`
- **Emergency**: Disable agent access by removing MCP server configuration

## Change Management

### Security Changes

Any changes to:
- Network allowlist patterns
- File size limits
- Deletion policies
- HITL requirements

Must be:
1. Reviewed by security team
2. Tested in isolated environment
3. Logged in change management system
4. Monitored for 24 hours post-deployment

## References

- OWASP Top 10: https://owasp.org/top10/
- CWE Database: https://cwe.mitre.org/
- Model Context Protocol: https://modelcontextprotocol.io/
- Node.js Security: https://nodejs.org/en/docs/guides/security/
