/**
 * Git operations for the No-Bash MCP Server
 */

import { execSync } from 'child_process';
import path from 'path';
import { GitCheckpointResult } from './types.js';

/**
 * Stages all changes and creates a git checkpoint.
 */
export function gitCheckpoint(workspaceRoot: string, message: string): GitCheckpointResult {
  try {
    execSync('git add -A', { cwd: workspaceRoot, stdio: 'pipe' });
    const result = execSync(`git commit -m "${message.replace(/"/g, '\\"')}"`, {
      cwd: workspaceRoot,
      stdio: 'pipe',
      encoding: 'utf8',
    });

    // Get the commit hash
    const hashResult = execSync('git rev-parse HEAD', {
      cwd: workspaceRoot,
      stdio: 'pipe',
      encoding: 'utf8',
    });

    return {
      success: true,
      message: 'Checkpoint created successfully.',
      commitHash: hashResult.trim(),
    };
  } catch (error: any) {
    // If there's nothing to commit, that's still a success
    if (error.stderr?.includes('nothing to commit')) {
      return {
        success: true,
        message: 'No changes to commit.',
      };
    }

    return {
      success: false,
      message: error.stderr?.toString() || error.message,
    };
  }
}

/**
 * Reverts the workspace to the last git checkpoint.
 */
export function gitRevertToCheckpoint(workspaceRoot: string): { success: boolean; message: string } {
  try {
    execSync('git reset --hard HEAD', { cwd: workspaceRoot, stdio: 'pipe' });
    execSync('git clean -fd', { cwd: workspaceRoot, stdio: 'pipe' });

    return {
      success: true,
      message: 'Workspace reverted to last checkpoint.',
    };
  } catch (error: any) {
    return {
      success: false,
      message: error.stderr?.toString() || error.message,
    };
  }
}
