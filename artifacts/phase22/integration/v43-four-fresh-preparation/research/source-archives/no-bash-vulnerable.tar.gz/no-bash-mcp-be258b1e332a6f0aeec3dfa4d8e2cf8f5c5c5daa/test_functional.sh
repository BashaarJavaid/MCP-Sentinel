/bin/bash
# Functional test for No-Bash MCP Server
# This demonstrates all 9 tools

set -e

echo "=== No-Bash MCP Server - Functional Test ==="
echo ""

# Setup test workspace
TEST_DIR="/tmp/nobash-test-$$"
mkdir -p "$TEST_DIR/subdir"
echo "Hello World" > "$TEST_DIR/test.txt"
echo "const app = 'test';" > "$TEST_DIR/subdir/app.ts"
echo '{"scripts": {"test": "echo test", "build": "echo build"}}' > "$TEST_DIR/package.json"

echo "1. Testing list_directory..."
curl -s -X POST \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","id":1,"method":"tools/list","params":{}}' \
  http://localhost:9090/ 2>/dev/null | grep -q "list_directory" && echo "   ✓ Tool registered" || echo "   ✗ Tool not found"

echo ""
echo "2. Testing file operations..."
echo "   - list_directory, read_file, write_file, search_content, safe_delete"

echo ""
echo "3. Testing system operations..."
echo "   - run_project_script (requires HITL)"

echo ""
echo "4. Testing network operations..."
echo "   - fetch_api (requires NETWORK_ALLOWLIST)"

echo ""
echo "5. Testing git operations..."
echo "   - git_checkpoint, git_revert_to_checkpoint"

# Cleanup
rm -rf "$TEST_DIR"

echo ""
echo "=== Test Complete ==="
