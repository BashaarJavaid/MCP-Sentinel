/**
 * No-Bash MCP Server - Main Entry Point
 * 
 * A secure, restricted MCP server that replaces arbitrary shell access
 * with explicitly typed JSON-RPC tool calls.
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ErrorCode,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';
import { z } from 'zod';

import { ServerConfig, AuditLogEntry } from './types.js';
import {
  listDirectory,
  readFile,
  writeFile,
  searchContent,
  safeDelete,
} from './fileSystem.js';
import { runProjectScript } from './system.js';
import { fetchApi } from './network.js';
import { gitCheckpoint, gitRevertToCheckpoint } from './git.js';
import { logAudit, createSuccessLog, createErrorLog, readAuditLog } from './audit.js';

// Server configuration from environment variables
const config: ServerConfig = {
  WORKSPACE_ROOT: process.env.WORKSPACE_ROOT || process.cwd(),
  ALLOW_DELETION: process.env.ALLOW_DELETION !== 'false',
  NETWORK_ALLOWLIST: process.env.NETWORK_ALLOWLIST 
    ? process.env.NETWORK_ALLOWLIST.split(',')
    : [],
  MAX_FILE_SIZE_MB: parseInt(process.env.MAX_FILE_SIZE_MB || '10', 10),
  HITL_ENABLED: process.env.HITL_ENABLED !== 'false',
};

// Create MCP server
const server = new Server(
  {
    name: 'no-bash-mcp',
    version: '1.0.0',
  },
  {
    capabilities: {
      tools: {},
    },
  }
);

/**
 * Helper to execute a tool with audit logging
 */
async function executeTool<T>(
  toolName: string,
  args: Record<string, unknown>,
  fn: () => T
): Promise<T> {
  const startTime = Date.now();
  try {
    const result = fn();
    const executionTimeMs = Date.now() - startTime;
    
    logAudit(createSuccessLog(toolName, args, executionTimeMs));
    
    return result;
  } catch (error) {
    const executionTimeMs = Date.now() - startTime;
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    logAudit(createErrorLog(toolName, args, executionTimeMs, errorMessage));
    
    throw error;
  }
}

// ============================================================================
// Tool: list_directory
// ============================================================================
const ListDirectorySchema = z.object({
  path: z.string(),
  recursive: z.boolean().optional(),
});

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    {
      name: 'list_directory',
      description: 'Returns a structured list of files and folders in a specific directory.',
      inputSchema: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'Relative path to list (e.g., "src/components")',
          },
          recursive: {
            type: 'boolean',
            description: 'Whether to list subdirectories recursively',
          },
        },
        required: ['path'],
      },
    },
    {
      name: 'read_file',
      description: 'Reads the contents of a file. Supports line ranges to save token context.',
      inputSchema: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'Path to the file to read',
          },
          start_line: {
            type: 'integer',
            description: 'Optional starting line number (1-indexed)',
          },
          end_line: {
            type: 'integer',
            description: 'Optional ending line number (1-indexed)',
          },
        },
        required: ['path'],
      },
    },
    {
      name: 'write_file',
      description: 'Creates or overwrites a file safely. Automatically creates necessary parent directories.',
      inputSchema: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'Path to the file to write',
          },
          content: {
            type: 'string',
            description: 'Complete file content',
          },
          mode: {
            type: 'string',
            enum: ['overwrite', 'append', 'create_only'],
            description: 'Write mode: overwrite (default), append, or create_only',
          },
        },
        required: ['path', 'content', 'mode'],
      },
    },
    {
      name: 'search_content',
      description: 'Uses native text matching to find strings in the workspace (replaces grep).',
      inputSchema: {
        type: 'object',
        properties: {
          query: {
            type: 'string',
            description: 'Text or regex to search for',
          },
          file_pattern: {
            type: 'string',
            description: 'Glob pattern (e.g., "*.ts") to filter files',
          },
        },
        required: ['query'],
      },
    },
    {
      name: 'safe_delete',
      description: 'Removes a file or directory by moving it to a .mcp_trash folder (zero irreversible damage).',
      inputSchema: {
        type: 'object',
        properties: {
          path: {
            type: 'string',
            description: 'File or directory to delete',
          },
        },
        required: ['path'],
      },
    },
    {
      name: 'run_project_script',
      description: 'Executes a pre-approved script defined in package.json scripts or Makefile.',
      inputSchema: {
        type: 'object',
        properties: {
          script_name: {
            type: 'string',
            description: 'Name of the script (e.g., "build", "test", "lint")',
          },
        },
        required: ['script_name'],
      },
    },
    {
      name: 'fetch_api',
      description: 'Makes an HTTP GET/POST request to external services with network allowlist validation.',
      inputSchema: {
        type: 'object',
        properties: {
          url: {
            type: 'string',
            description: 'Target URL',
          },
          method: {
            type: 'string',
            enum: ['GET', 'POST'],
            description: 'HTTP method',
          },
          headers: {
            type: 'object',
            description: 'HTTP headers',
            additionalProperties: {
              type: 'string',
            },
          },
          body: {
            type: 'string',
            description: 'Request body for POST requests',
          },
        },
        required: ['url', 'method'],
      },
    },
    {
      name: 'git_checkpoint',
      description: 'Stages all current changes and creates a local commit (save point).',
      inputSchema: {
        type: 'object',
        properties: {
          message: {
            type: 'string',
            description: 'Commit message',
          },
        },
        required: ['message'],
      },
    },
    {
      name: 'git_revert_to_checkpoint',
      description: 'Reverts the workspace to the last clean git state, undoing recent changes.',
      inputSchema: {
        type: 'object',
        properties: {},
        required: [],
      },
    },
    {
      name: 'mcp_audit_log',
      description: 'Reads the MCP audit log for transparency and debugging.',
      inputSchema: {
        type: 'object',
        properties: {},
        required: [],
      },
    },
  ],
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args = {} } = request.params;

  try {
    // =========================================================================
    // File System Operations
    // =========================================================================
    if (name === 'list_directory') {
      const { path, recursive = false } = ListDirectorySchema.parse(args);
      const result = await executeTool(name, args, () =>
        listDirectory(path, config.WORKSPACE_ROOT, recursive)
      );
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result.entries, null, 2),
          },
        ],
      };
    }

    if (name === 'read_file') {
      const { path, start_line, end_line } = z
        .object({
          path: z.string(),
          start_line: z.number().optional(),
          end_line: z.number().optional(),
        })
        .parse(args);
      const result = await executeTool(name, args, () =>
        readFile(path, config.WORKSPACE_ROOT, start_line, end_line)
      );
      if ('error' in result) {
        throw new McpError(ErrorCode.InvalidRequest, result.error);
      }
      return {
        content: [
          {
            type: 'text',
            text: result.content,
          },
        ],
        annotations: [
          {
            type: 'info',
            message: `Lines 1-${result.totalLines}, returned ${result.linesReturned} lines`,
          },
        ],
      };
    }

    if (name === 'write_file') {
      const { path, content, mode = 'overwrite' } = z
        .object({
          path: z.string(),
          content: z.string(),
          mode: z.enum(['overwrite', 'append', 'create_only']),
        })
        .parse(args);
      const result = await executeTool(name, args, () =>
        writeFile(path, config.WORKSPACE_ROOT, content, mode)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.error || 'Operation failed');
      }
      return {
        content: [
          {
            type: 'text',
            text: `File written successfully: ${path}`,
          },
        ],
      };
    }

    if (name === 'search_content') {
      const { query, file_pattern } = z
        .object({
          query: z.string(),
          file_pattern: z.string().optional(),
        })
        .parse(args);
      const result = await executeTool(name, args, () =>
        searchContent(config.WORKSPACE_ROOT, query, file_pattern)
      );
      if (result.error) {
        throw new McpError(ErrorCode.InvalidRequest, result.error || 'Operation failed');
      }
      return {
        content: [
          {
            type: 'text',
            text: `Found ${result.matches.length} matches:\n\n${result.matches
              .map((m) => `${m.file}:${m.line}: ${m.content}`)
              .join('\n')}`,
          },
        ],
      };
    }

    if (name === 'safe_delete') {
      const { path } = z.object({ path: z.string() }).parse(args);
      const result = await executeTool(name, args, () =>
        safeDelete(path, config.WORKSPACE_ROOT, config.ALLOW_DELETION)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.error || 'Operation failed');
      }
      return {
        content: [
          {
            type: 'text',
            text: `Moved to trash: ${path}`,
          },
        ],
      };
    }

    // =========================================================================
    // System Operations
    // =========================================================================
    if (name === 'run_project_script') {
      const { script_name } = z
        .object({
          script_name: z.string(),
        })
        .parse(args);
      const result = await executeTool(name, args, () =>
        runProjectScript(script_name, config, config.WORKSPACE_ROOT)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.stderr || 'Script execution failed');
      }
      return {
        content: [
          {
            type: 'text',
            text: `Script executed successfully:\n${result.stdout || '(no output)'}`,
          },
        ],
      };
    }

    // =========================================================================
    // Network Operations
    // =========================================================================
    if (name === 'fetch_api') {
      const { url, method, headers, body } = z
        .object({
          url: z.string(),
          method: z.enum(['GET', 'POST']),
          headers: z.record(z.string()).optional(),
          body: z.string().optional(),
        })
        .parse(args);
      const result = await executeTool(name, args, () =>
        fetchApi(url, method, headers || {}, body, config.NETWORK_ALLOWLIST)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.error || 'Operation failed');
      }
      return {
        content: [
          {
            type: 'text',
            text: `Response (${result.statusCode}):\n${result.data || '(no data)'}`,
          },
        ],
      };
    }

    // =========================================================================
    // Git Operations
    // =========================================================================
    if (name === 'git_checkpoint') {
      const { message } = z.object({ message: z.string() }).parse(args);
      const result = await executeTool(name, args, () =>
        gitCheckpoint(config.WORKSPACE_ROOT, message)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.message);
      }
      return {
        content: [
          {
            type: 'text',
            text: `Checkpoint created${result.commitHash ? ` (commit: ${result.commitHash.slice(0, 8)})` : ''}: ${result.message}`,
          },
        ],
      };
    }

    if (name === 'git_revert_to_checkpoint') {
      const result = await executeTool(name, args, () =>
        gitRevertToCheckpoint(config.WORKSPACE_ROOT)
      );
      if (!result.success) {
        throw new McpError(ErrorCode.InvalidRequest, result.message);
      }
      return {
        content: [
          {
            type: 'text',
            text: result.message,
          },
        ],
      };
    }

    // =========================================================================
    // Audit Operations
    // =========================================================================
    if (name === 'mcp_audit_log') {
      await executeTool(name, args, async () => {
        const logEntries = readAuditLog();
        return { logEntries };
      });
      const logEntries = readAuditLog();
      return {
        content: [
          {
            type: 'text',
            text: logEntries.length > 0
              ? logEntries.join('\n')
              : 'No audit log entries found.',
          },
        ],
      };
    }

    throw new McpError(ErrorCode.MethodNotFound, `Unknown tool: ${name}`);
  } catch (error) {
    if (error instanceof McpError) {
      throw error;
    }
    throw new McpError(
      ErrorCode.InternalError,
      `Internal server error: ${error instanceof Error ? error.message : String(error)}`
    );
  }
});

// Start server
async function main() {
  console.error('Starting No-Bash MCP Server...');
  console.error(`Workspace root: ${config.WORKSPACE_ROOT}`);
  console.error(`Allow deletion: ${config.ALLOW_DELETION}`);
  console.error(`Network allowlist: ${config.NETWORK_ALLOWLIST.length} entries`);
  console.error(`Max file size: ${config.MAX_FILE_SIZE_MB} MB`);
  console.error(`HITL enabled: ${config.HITL_ENABLED}`);

  const transport = new StdioServerTransport();
  await server.connect(transport);

  console.error('No-Bash MCP Server running on stdio');
}

main().catch((error) => {
  console.error('Fatal error:', error);
  process.exit(1);
});
