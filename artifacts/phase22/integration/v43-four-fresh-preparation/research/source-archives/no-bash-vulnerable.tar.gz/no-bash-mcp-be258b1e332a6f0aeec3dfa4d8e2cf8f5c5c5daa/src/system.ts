/**
 * System operations for the No-Bash MCP Server
 */

import { execSync, spawn } from 'child_process';
import path from 'path';
import { ServerConfig } from './types.js';
import { createSuccessLog, createErrorLog } from './audit.js';
import { requestApproval } from './hitl.js';

/**
 * Runs a pre-approved project script.
 */
export async function runProjectScript(
  scriptName: string,
  config: ServerConfig,
  workspaceRoot: string
): Promise<{ success: boolean; stdout?: string; stderr?: string; exitCode: number; requiresApproval?: boolean }> {
  try {
    // Read package.json to get allowed scripts
    const packageJsonPath = path.join(workspaceRoot, 'package.json');
    let allowedScripts: string[] = [];

    try {
      const packageJson = JSON.parse(require('fs').readFileSync(packageJsonPath, 'utf8'));
      allowedScripts = Object.keys(packageJson.scripts || {});
    } catch (error) {
      // No package.json or no scripts section
    }

    // Check if script is in the allowed list
    if (!allowedScripts.includes(scriptName)) {
      return {
        success: false,
        exitCode: 1,
        stderr: `Script "${scriptName}" is not in the project's package.json scripts or is not pre-approved.`,
      };
    }

    // HITL approval for script execution
    if (config.HITL_ENABLED) {
      const approved = await requestApproval({
        prompt: `The agent wishes to run 'npm run ${scriptName}' in the workspace. Approve?`,
        defaultApproved: false,
        timeoutMs: 60000,
      });

      if (!approved) {
        return {
          success: false,
          exitCode: 1,
          stderr: 'Operation denied by human operator.',
          requiresApproval: true,
        };
      }
    }

    // Execute the script
    const result = execSync(`npm run ${scriptName}`, {
      cwd: workspaceRoot,
      encoding: 'utf8',
      stdio: 'pipe',
    });

    return {
      success: true,
      stdout: result,
      stderr: undefined,
      exitCode: 0,
    };
  } catch (error: any) {
    return {
      success: false,
      stdout: error.stdout?.toString(),
      stderr: error.stderr?.toString() || error.message,
      exitCode: error.status || 1,
    };
  }
}
