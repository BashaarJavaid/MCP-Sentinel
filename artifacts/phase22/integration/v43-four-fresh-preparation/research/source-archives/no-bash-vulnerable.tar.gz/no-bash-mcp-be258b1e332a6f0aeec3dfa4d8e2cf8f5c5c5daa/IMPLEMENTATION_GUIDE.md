# Implementation Guide: No-Bash MCP Server

## Overview

The No-Bash MCP Server is a Model Context Protocol (MCP) server that provides AI agents with safe, restricted access to system resources. It eliminates the risks associated with arbitrary shell execution by replacing shell commands with explicitly typed, validated tool calls.

## Architecture

### Core Components

```
src/
├── index.ts          # MCP server entry point, tool routing
├── types.ts          # TypeScript interfaces and types
├── security.ts       # Path validation, network allowlist, file size checks
├── audit.ts          # Immutable audit logging
├── hitl.ts           # Human-in-the-Loop approval system
├── fileSystem.ts     # File operations (no shell)
├── system.ts         # Script execution with approval
├── network.ts        # HTTP client with validation
└── git.ts            # Git checkpoint and revert
```

### Security Layers

1. **Path Jail (Chroot)**: All file operations are bound to `WORKSPACE_ROOT`
2. **Type Safety**: TypeScript ensures correct parameter types at compile time
3. **Runtime Validation**: All inputs validated before use
4. **Network Allowlist**: SSRF protection via domain pattern matching
5. **File Size Limits**: Prevents resource exhaustion
6. **Immutable Logs**: All actions logged to `mcp_audit.log`
7. **Human-in-the-Loop**: Optional approval for sensitive operations
8. **Git Reversibility**: Every state change can be undone

## Tool Specifications

### 1. File System Operations

#### list_directory
Lists directory contents with optional recursion.

**Implementation Details:**
- Uses `fs.readdirSync` with `withFileTypes: true`
- Recursively scans subdirectories when enabled
- Returns file size, type, path, and modification time
- Prevents directory traversal

**Performance:**
- O(n) where n is total files
- Synchronous for simplicity (consider async for large directories)

**Limitations:**
- Max depth: unlimited (but memory constrained)
- Hidden directories starting with `.` are skipped in search

#### read_file
Reads file content with line range support.

**Implementation Details:**
- Validates file size before reading (default 10MB)
- Reads entire file into memory (consider streaming for large files)
- Optional line range selection for token efficiency

**Security:**
- Path traversal prevented
- File size enforce
