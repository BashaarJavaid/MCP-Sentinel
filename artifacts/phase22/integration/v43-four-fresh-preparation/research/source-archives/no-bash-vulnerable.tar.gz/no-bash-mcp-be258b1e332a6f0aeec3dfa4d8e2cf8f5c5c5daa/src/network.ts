/**
 * Network operations for the No-Bash MCP Server
 */

import http from 'http';
import https from 'https';
import { URL } from 'url';
import { validateNetworkRequest } from './security.js';

/**
 * Makes an HTTP request to an external service.
 */
export async function fetchApi(
  url: string,
  method: 'GET' | 'POST' = 'GET',
  headers: Record<string, string> = {},
  body?: string,
  allowlist: string[] = []
): Promise<{ success: boolean; statusCode?: number; data?: string; error?: string }> {
  // Validate URL against allowlist
  const validation = validateNetworkRequest(url, allowlist);
  if (!validation.allowed) {
    return { success: false, error: validation.error };
  }

  return new Promise((resolve) => {
    try {
      const urlObj = new URL(url);
      const isHttps = urlObj.protocol === 'https:';

      const options = {
        hostname: urlObj.hostname,
        port: urlObj.port || (isHttps ? 443 : 80),
        path: urlObj.pathname + urlObj.search,
        method,
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'No-Bash-MCP-Server/1.0',
          ...headers,
        },
      };

      const req = (isHttps ? https : http).request(options, (res) => {
        let data = '';

        res.on('data', (chunk) => {
          data += chunk;
        });

        res.on('end', () => {
          resolve({
            success: true,
            statusCode: res.statusCode,
            data,
          });
        });
      });

      req.on('error', (error) => {
        resolve({
          success: false,
          error: `Network request failed: ${error.message}`,
        });
      });

      if (body && method === 'POST') {
        req.write(body);
      }

      req.end();
    } catch (error) {
      resolve({
        success: false,
        error: `Invalid request: ${error instanceof Error ? error.message : String(error)}`,
      });
    }
  });
}
