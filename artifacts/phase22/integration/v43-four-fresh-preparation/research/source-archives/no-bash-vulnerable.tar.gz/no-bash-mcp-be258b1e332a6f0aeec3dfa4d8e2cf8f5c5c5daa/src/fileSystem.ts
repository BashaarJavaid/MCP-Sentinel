/**
 * File system operations for the No-Bash MCP Server
 */

import fs from 'fs';
import path from 'path';
import { resolveSafePath } from './security.js';
import { DirectoryEntry, FileContentResult, PathValidationResult } from './types.js';
import { validateFileSize } from './security.js';
import { createSuccessLog, createErrorLog } from './audit.js';

const TRASH_DIR = '.mcp_trash';

/**
 * Lists files and directories in a given path.
 */
export function listDirectory(
  requestedPath: string,
  workspaceRoot: string,
  recursive: boolean = false
): { entries: DirectoryEntry[]; error?: string } {
  const validation = resolveSafePath(requestedPath, workspaceRoot);
  if (!validation.safe) {
    return { entries: [], error: validation.error || 'Access denied' };
  }
  const absolutePath = validation.absolutePath;

  const entries: DirectoryEntry[] = [];
  
  function scan(dirPath: string, basePath: string) {
    const items = fs.readdirSync(dirPath, { withFileTypes: true });
    
    for (const item of items) {
      const itemPath = path.join(dirPath, item.name);
      const relativePath = path.relative(workspaceRoot, itemPath);
      
      const entry: DirectoryEntry = {
        name: item.name,
        type: item.isDirectory() ? 'directory' : 'file',
        size: item.isDirectory() ? 0 : fs.statSync(itemPath).size,
        path: relativePath,
        modified: fs.statSync(itemPath).mtime.toISOString(),
      };
      
      entries.push(entry);
      
      if (recursive && item.isDirectory()) {
        scan(itemPath, basePath);
      }
    }
  }

  try {
    scan(absolutePath, workspaceRoot);
    return { entries };
  } catch (error) {
    return {
      entries: [],
      error: `Failed to list directory: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Reads file content with optional line range.
 */
export function readFile(
  requestedPath: string,
  workspaceRoot: string,
  startLine?: number,
  endLine?: number
): FileContentResult | { error: string } {
  const validation = resolveSafePath(requestedPath, workspaceRoot);
  if (!validation.safe) {
    return { error: validation.error || 'Access denied' };
  }

  const ap = (validation as any).absolutePath as string;

  try {
    const sizeValidation = validateFileSize(ap, 10); // Use 10MB default
    if (!sizeValidation.valid) {
      return { error: sizeValidation.error! };
    }

    const content = fs.readFileSync(ap, 'utf8');
    const lines = content.split('\n');
    const totalLines = lines.length;

    let start = 0;
    let end = totalLines - 1;

    if (startLine !== undefined) {
      start = Math.max(0, startLine - 1);
    }
    if (endLine !== undefined) {
      end = Math.min(totalLines - 1, endLine - 1);
    }

    const selectedLines = lines.slice(start, end + 1);
    
    return {
      content: selectedLines.join('\n'),
      totalLines,
      linesReturned: selectedLines.length,
    };
  } catch (error) {
    return { error: `Failed to read file: ${error instanceof Error ? error.message : String(error)}` };
  }
}

/**
 * Writes content to a file.
 */
export function writeFile(
  requestedPath: string,
  workspaceRoot: string,
  content: string,
  mode: 'overwrite' | 'append' | 'create_only' = 'overwrite'
): { success: boolean; error?: string } {
  const validation = resolveSafePath(requestedPath, workspaceRoot);
  if (!validation.safe) {
    return { success: false, error: validation.error };
  }

  try {
    const dir = path.dirname(validation.absolutePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    if (mode === 'create_only' && fs.existsSync(validation.absolutePath)) {
      return { success: false, error: 'File already exists and create_only mode specified.' };
    }

    if (mode === 'append' && fs.existsSync(validation.absolutePath)) {
      fs.appendFileSync(validation.absolutePath, content, 'utf8');
    } else {
      fs.writeFileSync(validation.absolutePath, content, 'utf8');
    }

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: `Failed to write file: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Searches for text content in files.
 */
export function searchContent(
  workspaceRoot: string,
  query: string,
  filePattern?: string
): { matches: Array<{ file: string; line: number; content: string }>; error?: string } {
  try {
    const matches: Array<{ file: string; line: number; content: string }> = [];
    
    function scan(dirPath: string) {
      const items = fs.readdirSync(dirPath, { withFileTypes: true });
      
      for (const item of items) {
        const itemPath = path.join(dirPath, item.name);
        const relativePath = path.relative(workspaceRoot, itemPath);

        // Skip hidden directories and trash
        if (item.isDirectory()) {
          if (item.name.startsWith('.') || item.name === TRASH_DIR) {
            continue;
          }
          scan(itemPath);
          continue;
        }

        // Apply file pattern filter
        if (filePattern) {
          const globRegex = new RegExp(
            '^' + filePattern.replace(/\./g, '\\.').replace(/\*/g, '.*') + '$'
          );
          if (!globRegex.test(item.name)) {
            continue;
          }
        }

        // Read and search file
        try {
          const fileContent = fs.readFileSync(itemPath, 'utf8');
          const lines = fileContent.split('\n');
          
          lines.forEach((line, index) => {
            if (line.includes(query)) {
              matches.push({
                file: relativePath,
                line: index + 1,
                content: line.trim(),
              });
            }
          });
        } catch (error) {
          // Skip files that can't be read
        }
      }
    }

    scan(workspaceRoot);
    
    return { matches };
  } catch (error) {
    return {
      matches: [],
      error: `Failed to search content: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Safely deletes a file or directory by moving it to trash.
 */
export function safeDelete(
  requestedPath: string,
  workspaceRoot: string,
  allowDeletion: boolean
): { success: boolean; error?: string } {
  const validation = resolveSafePath(requestedPath, workspaceRoot);
  if (!validation.safe) {
    return { success: false, error: validation.error || 'Access denied' };
  }

  if (!allowDeletion) {
    return { 
      success: false, 
      error: 'Deletion is not allowed in the current configuration (ALLOW_DELETION=false).' 
    };
  }

  try {
    const trashPath = path.join(workspaceRoot, TRASH_DIR);
    const destinationPath = path.join(trashPath, path.relative(workspaceRoot, validation.absolutePath));
    
    // Create trash directory if it doesn't exist
    if (!fs.existsSync(trashPath)) {
      fs.mkdirSync(trashPath, { recursive: true });
    }

    // Ensure destination parent exists
    const destDir = path.dirname(destinationPath);
    if (!fs.existsSync(destDir)) {
      fs.mkdirSync(destDir, { recursive: true });
    }

    // Move to trash
    fs.renameSync(validation.absolutePath, destinationPath);

    return { success: true };
  } catch (error) {
    return {
      success: false,
      error: `Failed to delete: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}
