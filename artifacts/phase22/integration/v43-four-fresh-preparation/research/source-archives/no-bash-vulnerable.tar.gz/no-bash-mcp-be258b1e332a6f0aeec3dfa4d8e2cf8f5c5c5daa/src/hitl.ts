/**
 * Human-in-the-Loop (HITL) approval system
 */

import readline from 'readline';

interface HITLOptions {
  prompt: string;
  defaultApproved?: boolean;
  timeoutMs?: number;
}

/**
 * Prompts a human operator for approval before executing sensitive operations.
 */
export async function requestApproval(
  options: HITLOptions
): Promise<boolean> {
  if (!process.stdin.isTTY) {
    // Non-interactive mode - deny by default
    return false;
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    const timeout = setTimeout(() => {
      rl.close();
      console.log('\n⏰ Approval request timed out. Operation denied.');
      resolve(false);
    }, options.timeoutMs || 30000);

    const defaultText = options.defaultApproved ? '(Y/n)' : '(y/N)';
    
    rl.question(`${options.prompt} ${defaultText} `, (answer) => {
      clearTimeout(timeout);
      rl.close();
      
      const normalized = answer.trim().toLowerCase();
      if (normalized === '') {
        resolve(options.defaultApproved ?? false);
      } else {
        resolve(normalized === 'y' || normalized === 'yes');
      }
    });
  });
}
