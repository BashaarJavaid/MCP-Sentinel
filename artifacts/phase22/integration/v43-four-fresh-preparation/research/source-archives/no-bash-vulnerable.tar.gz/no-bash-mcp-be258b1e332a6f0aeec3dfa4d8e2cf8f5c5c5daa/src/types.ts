/**
 * Type definitions for the No-Bash MCP Server
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  ErrorCode,
  McpError,
} from '@modelcontextprotocol/sdk/types.js';

export interface ServerConfig {
  WORKSPACE_ROOT: string;
  ALLOW_DELETION: boolean;
  NETWORK_ALLOWLIST: string[];
  MAX_FILE_SIZE_MB: number;
  HITL_ENABLED: boolean;
}

export interface AuditLogEntry {
  timestamp: string;
  tool: string;
  arguments: Record<string, unknown>;
  status: 'success' | 'error';
  error?: string;
  executionTimeMs: number;
}

export interface PathValidationResult {
  safe: boolean;
  absolutePath: string;
  error?: string;
}

export interface DirectoryEntry {
  name: string;
  type: 'file' | 'directory';
  size: number;
  path: string;
  modified: string;
}

export interface FileContentResult {
  content: string;
  totalLines: number;
  linesReturned: number;
}

export interface NetworkRequestOptions {
  url: string;
  method: 'GET' | 'POST';
  headers?: Record<string, string>;
  body?: string;
}

export interface GitCheckpointResult {
  success: boolean;
  message: string;
  commitHash?: string;
}

export interface ScriptResult {
  success: boolean;
  stdout?: string;
  stderr?: string;
  exitCode: number;
}
