# No-Bash MCP Server

A secure, restricted MCP (Model Context Protocol) server that replaces arbitrary shell access (`bash`, `sh`, `zsh`, `cmd`) with explicitly typed JSON-RPC tool calls. This eliminates the risk of shell injection, accidental system destruction, and unconstrained lateral movement.

## Core Principles

### 1. Declarative Execution
Agents request state changes via JSON schemas; the server executes them using native OS APIs (e.g., Node.js `fs` module), **never** via shell sub-processes.

### 2. Path Jailing (Chroot)
All file operations are strictly bound to a designated `WORKSPACE_ROOT`. Directory traversal attempts (e.g., `../../etc/passwd`) are caught and rejected.

### 3. Reversibility
Destructive actions are either blocked, mapped to safe alternatives (e.g., moving to a `.mcp_trash` folder), or strictly tied to Git state.

### 4. Complete Observability
Every tool call is logged with structured arguments to `mcp_audit.log`, allowing for easy human auditing.

## Security Features

- **No Shell Execution**: All operations use native APIs (`fs.readFileSync`, `fs.writeFileSync`, etc.)
- **Directory Traversal Protection**: Path resolution ensures all operations stay within `WORKSPACE_ROOT`
- **SSRF Protection**: Network requests validated against `NETWORK_ALLOWLIST`; internal IPs (127.0.0.1, 169.254.x.x, private ranges) are blocked
- **File Size Limits**: Prevents agents from reading massive files into context or writing disk-filling files
- **Human-in-the-Loop (HITL)**: Optional approval prompts for sensitive operations
- **Immutable Audit Logs**: All tool calls logged with timestamps and redacted sensitive data
- **Git Integration**: Checkpoint and revert capabilities for full reversibility

## Installation

```bash
cd /home/rbergman/no-bash-mcp
npm install
npm run build
```

## Configuration

The server is configured via environment variables:

| Variable | Type | Default | Description |
|----------|------|---------|-------------|
| `WORKSPACE_ROOT` | string | `process.cwd()` | Absolute path to the allowed working directory (e.g., `/app/project_repo`) |
| `ALLOW_DELETION` | boolean | `false` | If `false`, delete operations move files to `.mcp_trash/` |
| `NETWORK_ALLOWLIST` | string (comma-separated) | `""` | Regex patterns for allowed domains (e.g., `"*.github.com,api.stripe.com"`) |
| `MAX_FILE_SIZE_MB` | integer | `10` | Maximum file size in MB for read operations |
| `HITL_ENABLED` | boolean | `true` | Enable human-in-the-loop approval prompts |

### Example Configuration

```bash
export WORKSPACE_ROOT="/home/user/my-project"
export ALLOW_DELETION="false"
export NETWORK_ALLOWLIST="*.github.com,api.stripe.com,raw.githubusercontent.com"
export MAX_FILE_SIZE_MB="10"
export HITL_ENABLED="true"
```

## MCP Configuration

Add to your Claude configuration (`claude_desktop_config.json`):

```json
{
  "mcpServers": {
    "no-bash-mcp": {
      "command": "node",
      "args": ["/home/rbergman/no-bash-mcp/dist/index.js"],
      "env": {
        "WORKSPACE_ROOT": "/path/to/workspace",
        "ALLOW_DELETION": "false",
        "NETWORK_ALLOWLIST": "*.github.com,api.stripe.com",
        "MAX_FILE_SIZE_MB": "10",
        "HITL_ENABLED": "true"
      }
    }
  }
}
```

## Available Tools

### Group A: File System Operations

#### `list_directory`
Returns a structured list of files and folders in a specific directory.

**Parameters:**
```json
{
  "path": "src/components",
  "recursive": false
}
```

**Returns:**
```json
[
  {"name": "App.tsx", "type": "file", "size": 1024, "path": "src/components/App.tsx", "modified": "2024-01-01T00:00:00.000Z"}
]
```

#### `read_file`
Reads the contents of a file with optional line range.

**Parameters:**
```json
{
  "path": "src/index.ts",
  "start_line": 1,
  "end_line": 100
}
```

**Returns:**
```json
{
  "content": "import { Server }...",
  "totalLines": 250,
  "linesReturned": 100
}
```

#### `write_file`
Creates or overwrites a file safely.

**Parameters:**
```json
{
  "path": "src/config.ts",
  "content": "export const CONFIG = {...};",
  "mode": "overwrite"
}
```

#### `search_content`
Uses native text matching to find strings (replaces `grep`).

**Parameters:**
```json
{
  "query": "TODO",
  "file_pattern": "*.ts"
}
```

**Returns:**
```
Found 5 matches:

src/index.ts:42: // TODO: Add error handling
```

#### `safe_delete`
Removes a file or directory by moving to `.mcp_trash/`.

**Parameters:**
```json
{
  "path": "temp-old-code"
}
```

### Group B: System Actions

#### `run_project_script`
Executes a pre-approved script from `package.json`.

**Parameters:**
```json
{
  "script_name": "test"
}
```

**Note:** Requires HITL approval if enabled.

### Group C: Network Operations

#### `fetch_api`
Makes an HTTP GET/POST request with allowlist validation.

**Parameters:**
```json
{
  "url": "https://api.github.com/repos/octocat/Hello-World",
  "method": "GET",
  "headers": {
    "Authorization": "Bearer ..."
  }
}
```

### Group D: Source Control

#### `git_checkpoint`
Stages all changes and creates a local commit.

**Parameters:**
```json
{
  "message": "Add user authentication module"
}
```

#### `git_revert_to_checkpoint`
Reverts workspace to last clean git state.

**Parameters:** `{}`

### Group E: Audit Operations

#### `mcp_audit_log`
Reads the MCP audit log.

**Parameters:** `{}`

## Implementation Architecture

### Directory Structure
```
no-bash-mcp/
├── src/
│   ├── index.ts          # Main server entry point
│   ├── types.ts          # TypeScript interfaces
│   ├── security.ts       # Path validation & network allowlist
│   ├── audit.ts          # Immutable audit logging
│   ├── hitl.ts           # Human-in-the-loop approval
│   ├── fileSystem.ts     # File operations (no shell)
│   ├── system.ts         # Script execution with approval
│   ├── network.ts        # HTTP client with validation
│   └── git.ts            # Git checkpoint/revert
├── dist/                 # Compiled JavaScript
├── package.json
├── tsconfig.json
└── README.md
```

### Key Security Patterns

#### 1. Path Resolution Guard
```typescript
function resolveSafePath(requestedPath: string, workspaceRoot: string) {
  const absolutePath = path.resolve(workspaceRoot, requestedPath);
  if (!absolutePath.startsWith(workspaceRoot)) {
    throw new Error("Security Violation: Attempted directory traversal.");
  }
  return absolutePath;
}
```

#### 2. No Shell Execution
```typescript
// ✅ SAFE: Native API
fs.readFileSync(filePath, 'utf8');

// ❌ NEVER: Shell execution
execSync(`cat ${filePath}`); // BANNED
```

#### 3. SSRF Protection
```typescript
const privateIpRegexes = [
  /^127\.\d+\.\d+\.\d+$/,      // localhost
  /^10\.\d+\.\d+\.\d+$/,        // private
  /^172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+$/, // private
  /^192\.168\.\d+\.\d+$/,       // private
];
```

## Development

```bash
# Build
npm run build

# Run in development mode
npm run dev

# Start (production)
npm start

# Run tests
npm test

# Lint
npm run lint
```

## Testing

The test suite validates:
- Path traversal attempts are rejected
- File operations stay within workspace root
- Network requests respect allowlist
- Delete operations move to trash
- Audit logs are written correctly
- Git checkpoint/revert works as expected

## License

MIT
