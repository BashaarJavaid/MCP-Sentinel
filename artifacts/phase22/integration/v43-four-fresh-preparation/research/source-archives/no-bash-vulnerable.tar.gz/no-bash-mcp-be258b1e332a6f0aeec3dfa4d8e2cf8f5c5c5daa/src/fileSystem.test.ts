/**
 * File System Operations - Unit Tests
 */

import { describe, it, expect, vi, beforeEach } from 'vitest';
import fs from 'fs';
import path from 'path';
import {
  listDirectory,
  readFile,
  writeFile,
  searchContent,
  safeDelete,
} from './fileSystem.js';

// Mock workspace for testing
const TEST_WORKSPACE = path.join(process.cwd(), 'test-workspace');

beforeEach(() => {
  // Create clean test workspace
  if (fs.existsSync(TEST_WORKSPACE)) {
    fs.rmSync(TEST_WORKSPACE, { recursive: true, force: true });
  }
  fs.mkdirSync(TEST_WORKSPACE, { recursive: true });
});

describe('listDirectory', () => {
  it('should list files in a directory', () => {
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.txt'), 'hello');
    fs.mkdirSync(path.join(TEST_WORKSPACE, 'subdir'));

    const result = listDirectory('', TEST_WORKSPACE, false);
    
    expect(result.error).toBeUndefined();
    expect(result.entries).toHaveLength(2);
    expect(result.entries.find(e => e.name === 'test.txt')).toBeDefined();
    expect(result.entries.find(e => e.name === 'subdir')).toBeDefined();
  });

  it('should recursively list subdirectories', () => {
    fs.mkdirSync(path.join(TEST_WORKSPACE, 'subdir'), { recursive: true });
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'subdir', 'nested.txt'), 'nested');

    const result = listDirectory('', TEST_WORKSPACE, true);
    
    expect(result.error).toBeUndefined();
    expect(result.entries).toHaveLength(2);
  });

  it('should reject directory traversal attempts', () => {
    const result = listDirectory('../../etc', TEST_WORKSPACE, false);
    
    expect(result.error).toBeDefined();
    expect(result.entries).toHaveLength(0);
  });
});

describe('readFile', () => {
  it('should read a file', () => {
    const filePath = 'test.txt';
    fs.writeFileSync(path.join(TEST_WORKSPACE, filePath), 'hello world');

    const result = readFile(filePath, TEST_WORKSPACE);
    
    expect(result.error).toBeUndefined();
    expect('content' in result ? result.content : '').toContain('hello world');
  });

  it('should read file with line range', () => {
    const content = 'line1\nline2\nline3\nline4\nline5';
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.txt'), content);

    const result = readFile('test.txt', TEST_WORKSPACE, 2, 4);
    
    expect(result.error).toBeUndefined();
    if (!('error' in result)) {
      expect(result.content).toContain('line2');
      expect(result.content).toContain('line3');
      expect(result.content).toContain('line4');
      expect(result.content).not.toContain('line1');
      expect(result.content).not.toContain('line5');
    }
  });

  it('should reject reading files outside workspace', () => {
    const result = readFile('../../etc/passwd', TEST_WORKSPACE);
    
    expect(result.error).toBeDefined();
  });

  it('should reject reading non-existent file', () => {
    const result = readFile('nonexistent.txt', TEST_WORKSPACE);
    
    expect(result.error).toBeDefined();
  });
});

describe('writeFile', () => {
  it('should create a new file', () => {
    const result = writeFile('new.txt', TEST_WORKSPACE, 'content', 'overwrite');
    
    expect(result.success).toBe(true);
    expect(fs.existsSync(path.join(TEST_WORKSPACE, 'new.txt'))).toBe(true);
  });

  it('should overwrite an existing file', () => {
    const filePath = path.join(TEST_WORKSPACE, 'existing.txt');
    fs.writeFileSync(filePath, 'old');

    const result = writeFile('existing.txt', TEST_WORKSPACE, 'new', 'overwrite');
    
    expect(result.success).toBe(true);
    expect(fs.readFileSync(filePath, 'utf8')).toBe('new');
  });

  it('should append to a file', () => {
    const filePath = path.join(TEST_WORKSPACE, 'append.txt');
    fs.writeFileSync(filePath, 'hello');

    const result = writeFile('append.txt', TEST_WORKSPACE, ' world', 'append');
    
    expect(result.success).toBe(true);
    expect(fs.readFileSync(filePath, 'utf8')).toBe('hello world');
  });

  it('should respect create_only mode', () => {
    const filePath = path.join(TEST_WORKSPACE, 'create.txt');
    fs.writeFileSync(filePath, 'exists');

    const result = writeFile('create.txt', TEST_WORKSPACE, 'new', 'create_only');
    
    expect(result.success).toBe(false);
    expect(fs.readFileSync(filePath, 'utf8')).toBe('exists');
  });

  it('should create nested directories', () => {
    const result = writeFile('a/b/c/file.txt', TEST_WORKSPACE, 'deep', 'overwrite');
    
    expect(result.success).toBe(true);
    expect(fs.existsSync(path.join(TEST_WORKSPACE, 'a/b/c/file.txt'))).toBe(true);
  });
});

describe('searchContent', () => {
  it('should find text in files', () => {
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.txt'), 'find this text');
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'other.txt'), 'no match');

    const result = searchContent(TEST_WORKSPACE, 'find');
    
    expect(result.error).toBeUndefined();
    expect(result.matches).toHaveLength(1);
    expect(result.matches[0].file).toContain('test.txt');
  });

  it('should filter by file pattern', () => {
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.ts'), 'match');
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.js'), 'match');

    const result = searchContent(TEST_WORKSPACE, 'match', '*.ts');
    
    expect(result.error).toBeUndefined();
    expect(result.matches).toHaveLength(1);
    expect(result.matches[0].file).toContain('.ts');
  });

  it('should return multiple matches', () => {
    fs.writeFileSync(
      path.join(TEST_WORKSPACE, 'test.txt'),
      'match\nmatch\nother'
    );

    const result = searchContent(TEST_WORKSPACE, 'match');
    
    expect(result.error).toBeUndefined();
    expect(result.matches).toHaveLength(2);
  });
});

describe('safeDelete', () => {
  it('should move file to trash', () => {
    const filePath = path.join(TEST_WORKSPACE, 'to_delete.txt');
    fs.writeFileSync(filePath, 'content');

    const result = safeDelete('to_delete.txt', TEST_WORKSPACE, true);
    
    expect(result.success).toBe(true);
    expect(fs.existsSync(filePath)).toBe(false);
    expect(fs.existsSync(path.join(TEST_WORKSPACE, '.mcp_trash', 'to_delete.txt'))).toBe(true);
  });

  it('should reject deletion when not allowed', () => {
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'test.txt'), 'content');

    const result = safeDelete('test.txt', TEST_WORKSPACE, false);
    
    expect(result.success).toBe(false);
    expect(result.error).toBeDefined();
    expect(fs.existsSync(path.join(TEST_WORKSPACE, 'test.txt'))).toBe(true);
  });

  it('should delete entire directories', () => {
    fs.mkdirSync(path.join(TEST_WORKSPACE, 'dir_to_delete'), { recursive: true });
    fs.writeFileSync(path.join(TEST_WORKSPACE, 'dir_to_delete', 'file.txt'), 'x');

    const result = safeDelete('dir_to_delete', TEST_WORKSPACE, true);
    
    expect(result.success).toBe(true);
    expect(fs.existsSync(path.join(TEST_WORKSPACE, 'dir_to_delete'))).toBe(false);
  });
});
