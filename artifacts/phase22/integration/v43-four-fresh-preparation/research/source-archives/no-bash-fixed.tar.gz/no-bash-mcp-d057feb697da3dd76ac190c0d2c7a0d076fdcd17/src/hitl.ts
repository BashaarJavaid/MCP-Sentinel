/**
 * Human-in-the-Loop (HITL) approval system
 */

import readline from 'readline';

interface HITLOptions {
  prompt: string;
  defaultApproved?: boolean;
  timeoutMs?: number;
}

/**
 * Prompts a human operator for approval before executing sensitive operations.
 */
export async function requestApproval(
  options: HITLOptions
): Promise<boolean> {
  if (!process.stdin.isTTY) {
    // Non-interactive mode - deny by default
    return false;
  }

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });

  return new Promise((resolve) => {
    let settled = false;
    const defaultText = options.defaultApproved ? '(Y/n)' : '(y/N)';

    const timeout = setTimeout(() => {
      if (!settled) { settled = true; rl.close(); resolve(false); }
    }, options.timeoutMs || 30000);

    rl.question(`${options.prompt} ${defaultText} `, (answer) => {
      if (settled) return;
      settled = true;
      clearTimeout(timeout);
      rl.close();
      
      const normalized = answer.trim().toLowerCase();
      if (normalized === '') {
        resolve(options.defaultApproved ?? false);
      } else {
        resolve(normalized === 'y' || normalized === 'yes');
      }
    });
  });
}
