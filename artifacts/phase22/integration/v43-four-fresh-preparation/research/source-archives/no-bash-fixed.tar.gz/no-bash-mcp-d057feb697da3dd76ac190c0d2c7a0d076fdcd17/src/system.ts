/**
 * System operations for the No-Bash MCP Server
 */

import { spawnSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { ServerConfig } from './types.js';
import { requestApproval } from './hitl.js';

/**
 * Runs a pre-approved project script.
 */
export async function runProjectScript(
  scriptName: string,
  config: ServerConfig,
  workspaceRoot: string
): Promise<{ success: boolean; stdout?: string; stderr?: string; exitCode: number; requiresApproval?: boolean }> {
  try {
    // Read package.json to get allowed scripts
    const packageJsonPath = path.join(workspaceRoot, 'package.json');
    let allowedScripts: string[] = [];

    try {
      const raw = fs.readFileSync(packageJsonPath, 'utf8');
      const packageJson = JSON.parse(raw);
      allowedScripts = Object.keys(packageJson.scripts || {});
    } catch (error) {
      // No package.json or no scripts section
    }

    // Check if script is in the allowed list
    if (!allowedScripts.includes(scriptName)) {
      return {
        success: false,
        exitCode: 1,
        stderr: `Script "${scriptName}" is not in the project's package.json scripts or is not pre-approved.`,
      };
    }

    // HITL approval for script execution
    if (config.HITL_ENABLED) {
      const approved = await requestApproval({
        prompt: `The agent wishes to run 'npm run ${scriptName}' in the workspace. Approve?`,
        defaultApproved: false,
        timeoutMs: 60000,
      });

      if (!approved) {
        return {
          success: false,
          exitCode: 1,
          stderr: 'Operation denied by human operator.',
          requiresApproval: true,
        };
      }
    }

    // Execute the script via spawnSync — NO shell, args array
    const result = spawnSync('npm', ['run', scriptName], {
      cwd: workspaceRoot,
      encoding: 'utf8',
      stdio: 'pipe',
      shell: false,
      timeout: 120_000,
    });

    return {
      success: result.status === 0,
      stdout: result.stdout || undefined,
      stderr: result.stderr || undefined,
      exitCode: result.status ?? 1,
    };
  } catch (error: any) {
    return {
      success: false,
      exitCode: error.status || 1,
      stderr: error.message,
    };
  }
}
