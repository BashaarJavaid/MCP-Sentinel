/**
 * Audit logging — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  createSuccessLog,
  createErrorLog,
} from './audit.js';

describe('createSuccessLog', () => {
  it('should redact sensitive fields', () => {
    const entry = createSuccessLog('read_file', {
      path: 'config.json',
      api_key: 'sk-1234567890',
      password: 'hunter2',
      secret_token: 'abc',
      Authorization: 'Bearer xyz',
    }, 42);

    expect(entry.tool).toBe('read_file');
    expect(entry.status).toBe('success');
    expect(entry.executionTimeMs).toBe(42);
    expect(entry.arguments.path).toBe('config.json');
    expect(entry.arguments.api_key).toBe('[REDACTED]');
    expect(entry.arguments.password).toBe('[REDACTED]');
    expect(entry.arguments.secret_token).toBe('[REDACTED]');
  });

  it('should leave non-sensitive fields unchanged', () => {
    const entry = createSuccessLog('list_directory', { path: 'src', recursive: true }, 5);

    expect(entry.arguments.path).toBe('src');
    expect(entry.arguments.recursive).toBe(true);
  });
});

describe('createErrorLog', () => {
  it('should include error message', () => {
    const entry = createErrorLog('read_file', { path: 'x' }, 100, 'File not found');

    expect(entry.status).toBe('error');
    expect(entry.error).toBe('File not found');
  });
});
