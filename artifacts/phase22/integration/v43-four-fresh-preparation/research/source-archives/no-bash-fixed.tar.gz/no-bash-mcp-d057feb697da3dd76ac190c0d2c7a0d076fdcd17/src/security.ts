/**
 * Security utilities for the No-Bash MCP Server
 */

import path from 'path';

/**
 * Resolves and validates a requested path against the workspace root.
 * Prevents directory traversal attacks.
 */
export function resolveSafePath(
  requestedPath: string,
  workspaceRoot: string
): { safe: boolean; absolutePath: string; error?: string } {
  try {
    const absolutePath = path.resolve(workspaceRoot, requestedPath);
    
    // Ensure the resolved path is within the workspace root.
    // Trailing sep prevents /app/proj from matching /app/proj_evil
    const normalizedRoot = path.resolve(workspaceRoot) + path.sep;
    if (!absolutePath.startsWith(normalizedRoot) && absolutePath !== path.resolve(workspaceRoot)) {
      return {
        safe: false,
        absolutePath,
        error: `Security Violation: Attempted directory traversal. Path "${requestedPath}" resolves to "${absolutePath}" which is outside the workspace root.`,
      };
    }

    // Additional check for null bytes and other dangerous patterns
    if (requestedPath.includes('\0')) {
      return {
        safe: false,
        absolutePath,
        error: 'Security Violation: Null byte detected in path.',
      };
    }

    return { safe: true, absolutePath };
  } catch (error) {
    return {
      safe: false,
      absolutePath: '',
      error: `Path resolution error: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Validates a URL against the network allowlist.
 */
export function validateNetworkRequest(
  url: string,
  allowlist: string[]
): { allowed: boolean; error?: string } {
  try {
    const urlObj = new URL(url);
    const hostname = urlObj.hostname.replace(/^\[|\]$/g, ''); // strip IPv6 brackets

    // Block internal/private IP ranges
    const privateIpRegexes = [
      /^127\.\d+\.\d+\.\d+$/,      // localhost
      /^10\.\d+\.\d+\.\d+$/,        // private
      /^172\.(1[6-9]|2[0-9]|3[01])\.\d+\.\d+$/, // private
      /^192\.168\.\d+\.\d+$/,       // private
      /^169\.254\.\d+\.\d+$/,       // link-local
      /^::1$/,                        // IPv6 localhost
      /^fc00:/,                       // IPv6 unique local address
    ];

    if (privateIpRegexes.some((regex) => regex.test(hostname))) {
      return {
        allowed: false,
        error: `SSRF Protection: Request to internal/private IP address "${hostname}" is blocked.`,
      };
    }

    // Check against allowlist (trim whitespace from split)
    if (allowlist.length > 0) {
      const isAllowed = allowlist.some((pattern) => {
        const trimmed = pattern.trim();
        const regex = new RegExp(
          '^' + trimmed.replace(/\./g, '\\.').replace(/\*/g, '.*').replace(/\?/g, '.') + '$'
        );
        return regex.test(hostname);
      });

      if (!isAllowed) {
        return {
          allowed: false,
          error: `Network request to "${hostname}" is not in the allowlist. Allowed domains: ${allowlist.join(', ')}`,
        };
      }
    }

    return { allowed: true };
  } catch (error) {
    return {
      allowed: false,
      error: `Invalid URL: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}

/**
 * Validates file size against maximum allowed size.
 */
export function validateFileSize(
  filePath: string,
  maxSizeMb: number
): { valid: boolean; error?: string } {
  try {
    const stats = require('fs').statSync(filePath);
    const fileSizeMb = stats.size / (1024 * 1024);
    
    if (fileSizeMb > maxSizeMb) {
      return {
        valid: false,
        error: `File size (${fileSizeMb.toFixed(2)} MB) exceeds maximum allowed size of ${maxSizeMb} MB.`,
      };
    }

    return { valid: true };
  } catch (error) {
    return {
      valid: false,
      error: `File size validation error: ${error instanceof Error ? error.message : String(error)}`,
    };
  }
}
