/**
 * Security utilities — Unit Tests
 */

import { describe, it, expect } from 'vitest';
import {
  resolveSafePath,
  validateNetworkRequest,
  validateFileSize,
} from './security.js';
import fs from 'fs';
import path from 'path';
import os from 'os';

describe('resolveSafePath', () => {
  it('should resolve a valid path within workspace', () => {
    const result = resolveSafePath('src/file.ts', '/app/workspace');
    expect(result.safe).toBe(true);
    expect(result.absolutePath).toBe('/app/workspace/src/file.ts');
  });

  it('should reject traversal with ../', () => {
    const result = resolveSafePath('../../etc/passwd', '/app/workspace');
    expect(result.safe).toBe(false);
    expect(result.error).toBeDefined();
  });

  it('should reject traversal that matches prefix but is different dir', () => {
    // The critical bug: "/app/project" should not match "/app/project_evil"
    const result = resolveSafePath('../project_evil/secret', '/app/project');
    expect(result.safe).toBe(false);
  });

  it('should reject null bytes', () => {
    const result = resolveSafePath('safe\0malicious.txt', '/app/workspace');
    expect(result.safe).toBe(false);
  });

  it('should allow the workspace root itself', () => {
    const result = resolveSafePath('.', '/app/workspace');
    expect(result.safe).toBe(true);
  });
});

describe('validateNetworkRequest', () => {
  it('should allow listed domains', () => {
    const result = validateNetworkRequest('https://api.github.com/repos/foo', ['*.github.com']);
    expect(result.allowed).toBe(true);
  });

  it('should block non-listed domains', () => {
    const result = validateNetworkRequest('https://evil.com/steal', ['*.github.com']);
    expect(result.allowed).toBe(false);
  });

  it('should block localhost (IPv4)', () => {
    const result = validateNetworkRequest('http://127.0.0.1:8080/admin', []);
    expect(result.allowed).toBe(false);
  });

  it('should block 10.x private range', () => {
    const result = validateNetworkRequest('http://10.0.0.1/api', []);
    expect(result.allowed).toBe(false);
  });

  it('should block 192.168.x.x', () => {
    const result = validateNetworkRequest('http://192.168.1.1/', []);
    expect(result.allowed).toBe(false);
  });

  it('should block 169.254.x.x (link-local)', () => {
    const result = validateNetworkRequest('http://169.254.169.254/latest/meta-data', []);
    expect(result.allowed).toBe(false);
  });

  it('should block IPv6 localhost', () => {
    const result = validateNetworkRequest('http://[::1]:8080/', []);
    expect(result.allowed).toBe(false);
  });

  it('should pass URLs with no allowlist (allowlist bypass == allow all non-private)', () => {
    const result = validateNetworkRequest('https://example.com/page', []);
    expect(result.allowed).toBe(true);
  });

  it('should handle invalid URLs gracefully', () => {
    const result = validateNetworkRequest('not-a-url', []);
    expect(result.allowed).toBe(false);
  });

  it('should trim whitespace from allowlist entries', () => {
    const result = validateNetworkRequest('https://api.github.com/test', [' *.github.com ', ' api.stripe.com ']);
    expect(result.allowed).toBe(true);
  });
});

describe('validateFileSize', () => {
  const tmpFile = path.join(os.tmpdir(), 'nobash-size-test.bin');

  afterAll(() => {
    try { fs.unlinkSync(tmpFile); } catch {}
  });

  it('should accept files under limit', () => {
    fs.writeFileSync(tmpFile, 'hi'); // 2 bytes
    const result = validateFileSize(tmpFile, 10);
    expect(result.valid).toBe(true);
  });

  it('should reject files over limit', () => {
    fs.writeFileSync(tmpFile, Buffer.alloc(100)); // 100 bytes
    const result = validateFileSize(tmpFile, 0.00005); // ~50 bytes
    expect(result.valid).toBe(false);
  });

  it('should handle missing files', () => {
    const result = validateFileSize('/nonexistent/file.txt', 10);
    expect(result.valid).toBe(false);
  });
});
