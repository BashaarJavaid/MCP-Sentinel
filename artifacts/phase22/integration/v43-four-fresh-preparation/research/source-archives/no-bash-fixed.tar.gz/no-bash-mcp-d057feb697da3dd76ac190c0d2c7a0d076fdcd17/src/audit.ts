/**
 * Audit logging for the No-Bash MCP Server
 */

import fs from 'fs';
import path from 'path';
import { AuditLogEntry } from './types.js';

const AUDIT_LOG_PATH = path.join(process.cwd(), 'mcp_audit.log');

/**
 * Writes an audit log entry to the immutable log file.
 */
export function logAudit(entry: AuditLogEntry): void {
  try {
    const logLine = JSON.stringify(entry) + '\n';

    // Append to audit log (atomic write)
    fs.appendFileSync(AUDIT_LOG_PATH, logLine, { encoding: 'utf8' });
  } catch (error) {
    console.error('Failed to write audit log:', error);
  }
}

/**
 * Creates an audit log entry for a successful tool call.
 */
export function createSuccessLog(
  tool: string,
  args: Record<string, unknown>,
  executionTimeMs: number
): AuditLogEntry {
  return {
    timestamp: new Date().toISOString(),
    tool,
    arguments: redactSensitiveData(args),
    status: 'success',
    executionTimeMs,
  };
}

/**
 * Creates an audit log entry for a failed tool call.
 */
export function createErrorLog(
  tool: string,
  args: Record<string, unknown>,
  executionTimeMs: number,
  error: string
): AuditLogEntry {
  return {
    timestamp: new Date().toISOString(),
    tool,
    arguments: redactSensitiveData(args),
    status: 'error',
    error,
    executionTimeMs,
  };
}

/**
 * Redacts sensitive data from audit logs.
 */
function redactSensitiveData(obj: Record<string, unknown>): Record<string, unknown> {
  const redacted: Record<string, unknown> = {};
  
  for (const [key, value] of Object.entries(obj)) {
    if (key.toLowerCase().includes('password') || 
        key.toLowerCase().includes('secret') ||
        key.toLowerCase().includes('token') ||
        key.toLowerCase().includes('key')) {
      redacted[key] = '[REDACTED]';
    } else {
      redacted[key] = value;
    }
  }

  return redacted;
}

/**
 * Reads the audit log.
 */
export function readAuditLog(): string[] {
  try {
    if (!fs.existsSync(AUDIT_LOG_PATH)) {
      return [];
    }
    const content = fs.readFileSync(AUDIT_LOG_PATH, 'utf8');
    return content.split('\n').filter(line => line.trim());
  } catch (error) {
    console.error('Failed to read audit log:', error);
    return [];
  }
}
