/**
 * Git operations — Unit Tests
 */

import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { gitCheckpoint, gitRevertToCheckpoint, hasGit } from './git.js';
import fs from 'fs';
import path from 'path';
import os from 'os';
import { spawnSync } from 'child_process';

const TMP = path.join(os.tmpdir(), 'nobash-git-test');

function run(...args: string[]) {
  return spawnSync('git', args, { cwd: TMP, shell: false, stdio: 'pipe', encoding: 'utf8' });
}

beforeEach(() => {
  if (fs.existsSync(TMP)) fs.rmSync(TMP, { recursive: true, force: true });
  fs.mkdirSync(TMP, { recursive: true });
  run('init');
  run('config', 'user.email', 'test@test.com');
  run('config', 'user.name', 'Test');
});

afterEach(() => {
  if (fs.existsSync(TMP)) fs.rmSync(TMP, { recursive: true, force: true });
});

describe('hasGit', () => {
  it('should detect a git repo', () => {
    expect(hasGit(TMP)).toBe(true);
  });

  it('should return false for non-repo', () => {
    expect(hasGit('/tmp/nosuchrepo')).toBe(false);
  });
});

describe('gitCheckpoint', () => {
  it('should create a commit', () => {
    fs.writeFileSync(path.join(TMP, 'test.txt'), 'hello');
    const result = gitCheckpoint(TMP, 'Add test.txt');
    expect(result.success).toBe(true);
    expect(result.commitHash).toBeDefined();
  });

  it('should return success when nothing to commit', () => {
    // First create a commit so the repo has a HEAD
    fs.writeFileSync(path.join(TMP, 'base.txt'), 'base');
    gitCheckpoint(TMP, 'initial');
    // Now try a commit with no changes
    const result = gitCheckpoint(TMP, 'empty commit');
    expect(result.success).toBe(true);
    expect(result.message).toContain('No changes');
  });

  it('should not allow shell injection in message', () => {
    fs.writeFileSync(path.join(TMP, 'test.txt'), 'x');
    const result = gitCheckpoint(TMP, '$(malicious) `backtick` ; rm -rf /');
    expect(result.success).toBe(true);
    // If injection worked, the repo would be destroyed — it's not
    expect(fs.existsSync(path.join(TMP, '.git'))).toBe(true);
  });
});

describe('gitRevertToCheckpoint', () => {
  it('should revert uncommitted changes', () => {
    fs.writeFileSync(path.join(TMP, 'keep.txt'), 'keep');
    gitCheckpoint(TMP, 'baseline');
    fs.writeFileSync(path.join(TMP, 'keep.txt'), 'should be gone');
    const result = gitRevertToCheckpoint(TMP);
    expect(result.success).toBe(true);
    expect(fs.readFileSync(path.join(TMP, 'keep.txt'), 'utf8')).toBe('keep');
  });
});
