/**
 * Git operations for the No-Bash MCP Server
 */

import { spawnSync } from 'child_process';
import { GitCheckpointResult } from './types.js';

/**
 * Does the workspace have a git repo?
 */
export function hasGit(workspaceRoot: string): boolean {
  try {
    const result = spawnSync('git', ['rev-parse', '--git-dir'], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 5000,
    });
    return result.status === 0;
  } catch {
    return false;
  }
}

/**
 * Stages all changes and creates a git checkpoint.
 * Uses spawnSync with NO shell to prevent injection.
 */
export function gitCheckpoint(workspaceRoot: string, message: string): GitCheckpointResult {
  try {
    const add = spawnSync('git', ['add', '-A'], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 30000,
    });
    if (add.status !== 0) {
      return { success: false, message: add.stderr.toString() };
    }

    const commit = spawnSync('git', ['commit', '-m', message], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 30000,
    });

    // Nothing to commit is a success, not an error
    if (commit.status !== 0) {
      const stderrStr = commit.stderr.toString();
      const stdoutStr = commit.stdout.toString();
      const combined = stderrStr + stdoutStr;
      // Simple string match avoids regex escaping issues
      if (combined.indexOf('nothing') !== -1 && combined.indexOf('commit') !== -1) {
        return { success: true, message: 'No changes to commit.' };
      }
      return { success: false, message: stderrStr || stdoutStr || 'Git commit failed.' };
    }

    const hash = spawnSync('git', ['rev-parse', 'HEAD'], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 5000, encoding: 'utf8',
    });

    return {
      success: true,
      message: 'Checkpoint created successfully.',
      commitHash: hash.stdout.trim(),
    };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}

/**
 * Reverts the workspace to the last clean git state.
 * DESTRUCTIVE - requires HITL in index.ts.
 */
export function gitRevertToCheckpoint(workspaceRoot: string): { success: boolean; message: string } {
  try {
    const reset = spawnSync('git', ['reset', '--hard', 'HEAD'], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 30000,
    });
    if (reset.status !== 0) {
      return { success: false, message: reset.stderr.toString() };
    }
    const clean = spawnSync('git', ['clean', '-fd'], {
      cwd: workspaceRoot, stdio: 'pipe', shell: false, timeout: 30000,
    });
    if (clean.status !== 0) {
      return { success: false, message: clean.stderr.toString() };
    }
    return { success: true, message: 'Workspace reverted to last checkpoint.' };
  } catch (error: any) {
    return { success: false, message: error.message };
  }
}
