"""Verify compatible engineering and historical evidence; no new measurements."""

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / "artifacts/phase22/integration"
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = OUT / "compatible-reuse.json"
    assert not destination.exists()
    prior = json.loads((BASE / "v23-v5-compatible-reuse.json").read_text())
    audit = json.loads((BASE / "v23-checkpoint-audit/packet.json").read_text())
    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    assert not subprocess.check_output(
        [
            "git",
            "diff",
            prior["source"],
            "--",
            *prior["byte_identical_product_test_package_inputs"],
            ".github",
        ],
        cwd=ROOT,
    )
    refs = dict(prior["retained_requirement_evidence_sha256"])
    for row in audit["requirements"] + audit["additional_scope_requirements"]:
        for name in row["evidence"]:
            p = ROOT / name if name.startswith("artifacts/") else BASE / name
            name = p.resolve().relative_to(ROOT).as_posix()
            if name in refs:
                assert sha(p) == refs[name], name
            refs[name] = sha(p)
    for name, digest in prior["retained_requirement_evidence_sha256"].items():
        assert sha(ROOT / name) == digest, name
    for name, digest in audit["current_source_and_test_files"].items():
        assert sha(ROOT / name) == digest, name
    delivery = json.loads((BASE / "v23-final-delivery-readback.json").read_text())
    for name, digest in delivery["user_files_preserved"].items():
        assert sha(ROOT / name) == digest, name
    assert set(
        subprocess.check_output(
            ["git", "ls-files", "--others", "--exclude-standard"], cwd=ROOT, text=True
        ).splitlines()
    ) == set(delivery["user_files_preserved"])
    main_root = Path("/Users/bashaarjavaid/Projects/MCP-Sentinel")
    assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=main_root)
    assert (
        subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=main_root, text=True
        ).strip()
        == "4cd57593b2585b9ee05c0f175930e6a0d76d362a"
    )
    seals = {}
    for n in range(1, 53):
        seal = json.loads((BASE / f"evidence-v{n}.json").read_text())
        assert sha(BASE / seal["archive"]) == seal["sha256"]
        seals[seal["archive"]] = seal["sha256"]
    result = {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "source": head,
        "measured_scanner": prior["measured_scanner"],
        "passed": True,
        "product_and_workflow_equal_tested_source": prior["source"],
        "requirement_rows": len(audit["requirements"]),
        "additional_rows": len(audit["additional_scope_requirements"]),
        "retained_evidence_sha256": refs,
        "prior_archive_sha256": seals,
        "source_and_test_files": audit["current_source_and_test_files"],
        "prior_compatible_reuse_sha256": sha(BASE / "v23-v5-compatible-reuse.json"),
        "production_request_reuse": prior["production_request_reuse"],
        "runtime_compatibility": prior["runtime_compatibility"],
        "exposed_detection_compatibility": prior["exposed_detection_compatibility"],
        "local_quality_reuse": prior["local_quality_reuse"],
        "historical_gate_sha256": prior["historical_gate_sha256"],
        "current_quality_sha256": sha(BASE / "v23-v5-quality-audit/packet.json"),
        "user_files_preserved": delivery["user_files_preserved"],
        "main_worktree_clean": True,
        "new_measurements_in_this_check": 0,
        "new_paid_calls": 0,
        "scope": "All 89 original and 56 additional rows retained. Original measurements keep their exact scanner revisions; fresh evaluation is separately authorized and assessed. No new full suite, model replay or Git campaign is claimed.",
        "helper_sha256": sha(Path(__file__)),
    }
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(
        "Verified",
        len(refs),
        "evidence references, 145 rows, 52 seals, unchanged source/workflow and protected worktrees.",
    )


if __name__ == "__main__":
    main()
