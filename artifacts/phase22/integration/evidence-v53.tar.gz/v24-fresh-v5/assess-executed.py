"""Validate retained reports and source-assess outcomes without another scan."""

import hashlib
import importlib.util
import json
import zipfile
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

from scripts.phase20_scoring import metrics, score
from scripts.phase22_corpus import frozen, input_files
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ASSETS = BASE / "v23-fresh-v5"
HOSTED = OUT / "hosted"
RAW = HOSTED / "artifacts/phase22-fresh-v5"

# Exact source explanations for every distinct retained diagnostic.
REVIEWS = {
    "Server": (
        "Server.prototype.setRequestHandler =",
        "Upstream mutates the imported SDK prototype. The scanner records a module-root rebound and declines SDK identity; this is a real conservative recognition boundary, not evidence that startup fails.",
    ),
    "this.server": (
        "this.server",
        "Class field holds the SDK Server instance; unresolved constructor identity prevents recognizing this receiver and its registered surfaces.",
    ),
    "Server.prototype.setRequestHandler.call": (
        "originalSetRequestHandler.call(",
        "Upstream wrapper invokes its saved original method with this/schema/handler and patches Zod shape on a specific error. The alias is not independently proven by the scanner.",
    ),
    "includes": (
        "BLOCKED_HOSTNAMES.includes(",
        "Fixed policy tests known metadata hostnames. This list check is distinct from the scored canonical IPv4 literal branch.",
    ),
    "URL": (
        "new URL(",
        "Fixed policy parses a URL before protocol and hostname classification. The reported binding remains unresolved; the source-only condition assumes ordinary Node URL behavior.",
    ),
    "Array.isArray": (
        "Array.isArray(",
        "Builtin array checks occur in the upstream schema compatibility patch and argument category validation. They do not establish destination restrictions.",
    ),
    "parseInt": (
        "parseInt(",
        "Fixed 172 prefix mask parses the second octet; the scored 169.254 prefix has a null mask and does not depend on this operation.",
    ),
    "ip.split": (
        "ip.split(",
        "Fixed 172 prefix mask splits the address; it is separate from the scored link-local prefix.",
    ),
    "ip.startsWith": (
        "ip.startsWith(",
        "Fixed prefix tests implement blocked ranges and the intentional loopback exception. The canonical 169.254.169.254 literal matches the blocked link-local prefix, not loopback.",
    ),
    "range.mask": (
        "range.mask(",
        "Fixed policy either accepts a null mask or calls the range predicate. The link-local entry uses the null-mask arm, so no unknown callback is needed for this label.",
    ),
    "hostname.toLowerCase": (
        "hostname.toLowerCase(",
        "Fixed metadata hostname matching normalizes case; numeric literal classification uses net.isIP separately.",
    ),
    "args.categories.every": (
        "args.categories.every(",
        "Optional category values must be strings; omitted categories satisfy the source prerequisite. This is argument typing, not URL policy.",
    ),
    "this.setupToolHandlers": (
        "this.setupToolHandlers(",
        "Constructor invokes the local method that installs the tool list and request dispatch. Failure to bind it leaves tool coverage unresolved.",
    ),
    "console.error": (
        "console.error(",
        "Logging occurs on startup, SDK and tool errors. These diagnostics are not an SSRF finding or proof of exfiltration.",
    ),
    "process.on": (
        "process.on(",
        "SIGINT cleanup callback registration is ordinary source behavior; scanner does not prove the callback receiver/effects.",
    ),
    "this.server.close": (
        "this.server.close(",
        "SIGINT callback closes the SDK server. This unresolved cleanup call does not prove the named URL condition safe.",
    ),
    "process.exit": (
        "process.exit(",
        "SIGINT callback exits after close. It does not reject the caller URL.",
    ),
    "this.server.setRequestHandler": (
        "this.server.setRequestHandler(",
        "The source registers ListTools and CallTool handlers through the upstream-patched SDK method. Scanner recognition of that dispatch is unresolved.",
    ),
    "this.handleRunAudit": (
        "this.handleRunAudit(",
        "CallTool run_audit arm forwards request.params.arguments to the local method; the performance helper also calls it. This unrecognized handler path is material to the miss.",
    ),
    "this.handleGetPerformanceScore": (
        "this.handleGetPerformanceScore(",
        "A separate tool dispatches to the performance helper, which delegates to handleRunAudit; this tool is outside the frozen named condition.",
    ),
    "chrome.kill": (
        "chrome.kill(",
        "Chrome is killed after the Lighthouse call. This is unexecuted lifecycle code, not a destination guard or verified runtime cleanup.",
    ),
    "Object.entries": (
        "Object.entries(",
        "Lighthouse category output is mapped into the response. It does not qualify the request destination.",
    ),
    "JSON.stringify": (
        "JSON.stringify(",
        "Tool output is serialized into response text. It is unrelated to initial link-local rejection.",
    ),
    "JSON.parse": (
        "JSON.parse(",
        "The performance helper parses the delegated audit response. It is outside the named run_audit destination condition.",
    ),
    "this.server.connect": (
        "this.server.connect(",
        "run connects the constructed Server to StdioServerTransport. Source evidence establishes the intended entrypoint; startup remains unexecuted.",
    ),
    "run": (
        "server.run()",
        "The module creates LighthouseServer and calls run(). The unresolved warning does not mean the source has no MCP entrypoint.",
    ),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = OUT / "assessment.json"
    assert not destination.exists()
    spec = importlib.util.spec_from_file_location("fresh", ASSETS / "runner.py")
    runner = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runner)
    proposal = runner.approved()
    retained = json.loads((HOSTED / "packet.json").read_text())
    assert retained["retention_complete"]
    for name, digest in retained["files_sha256"].items():
        assert sha(HOSTED / name) == digest, name
    packet = json.loads((RAW / "packet.json").read_text())
    assert packet["passed"] and packet["budget_closed"] and not packet["unstarted"]
    assert (
        packet["workflow_revision"]
        == retained["run"]["headSha"]
        == "86cbdc96e73b08d76786933398bcb8d31c190905"
    )
    assert (
        packet["workflow_attempt"] == "1"
        and packet["model_calls"] == 0
        and not packet["target_execution"]
    )
    assert packet["scanner"] == proposal["scanner"]
    for name, digest in packet["files_sha256"].items():
        assert sha(RAW / name) == digest, name
    assert packet["approval_sha256"] == sha(ASSETS / "authorization.json")
    assert packet["binding_sha256"] == sha(ASSETS / "binding.json")
    manifest = frozen(approval_path=ASSETS / "authorization.json")
    selected = {i.id: i for i in manifest.inputs if i.id in proposal["input_order"]}
    snapshots = {s.revision: s for s in manifest.snapshots}
    sources = {
        i: input_files(item, snapshots[item.snapshot], ROOT)
        for i, item in selected.items()
    }
    configs = json.loads((ROOT / proposal["configuration"]["path"]).read_text())
    expected = [
        (b, i) for b in proposal["batch_order"] for i in proposal["input_order"]
    ]
    assert [(a["batch"], a["input_id"]) for a in packet["attempts"]] == expected
    rows, warnings, first = [], [], {}
    for a in packet["attempts"]:
        assert a["state"] == "completed"
        runner.completed(a["timing"])
        item = selected[a["input_id"]]
        folder = RAW / a["directory"]
        result = json.loads((folder / "results.json").read_text())
        assert (
            result["scanner"] == proposal["scanner"]
            and result["model_calls"] == 0
            and not result["requests"]
        )
        assert result["manifest_sha256"] == proposal["manifest"]["sha256"]
        assert result["authorization_sha256"] == packet["approval_sha256"]
        assert result["outcomes"] == [a["outcome"]]
        native = a["batch"] != "semgrep-first"
        row = {
            "batch": a["batch"],
            "input_id": item.id,
            "label": item.label,
            "snapshot": item.snapshot,
            "tree_sha256": item.tree_sha256,
            "whole_input_seconds": a["timing"]["elapsed_seconds"],
            "cleanup_seconds": a["timing"]["elapsed_including_cleanup_seconds"]
            - a["timing"]["elapsed_seconds"],
            "timing": a["timing"],
            "outcome": a["outcome"],
            "source_condition": item.condition,
            "source_evidence": [e.model_dump(mode="json") for e in item.evidence],
        }
        if native:
            path = folder / item.id / "report.json"
            report = json.loads(path.read_text())
            validate_report_data(report)
            validate_sarif_data(json.loads(path.with_suffix(".sarif").read_text()))
            assert sha(path) == a["outcome"]["report_sha256"]
            assert (
                sha(path.parent / "configuration.json")
                == configs[item.id]["sha256"]
                == a["outcome"]["configuration_sha256"]
            )
            assert report["analysisComplete"] and report["executionSuccessful"]
            assert report["findings"] == [] and report["summary"]["total"] == 0
            assert len(report["warnings"]) == (19 if item.label == "vulnerable" else 26)
            coverage = report["static_analysis"]["coverage"]
            assert (
                coverage["surfaces"] == []
                and coverage["total_possible_surfaces"] is None
            )
            assert coverage["unresolved_flows"] == []
            assert report["static_analysis"]["scanned_file_count"] == 6
            canonical = runner.supervisor.clean(report, runner.EXCLUDED)
            if a["batch"] == "rules-first":
                first[item.id] = canonical
            else:
                assert a["ordered_repeat_equal"] and canonical == first[item.id]
            row.update(
                native_seconds=a["native_seconds"],
                timing_class=a["timing_class"],
                warnings=report["warnings"],
                coverage=coverage,
                rule_outcomes=report["static_analysis"]["rule_outcomes"],
                report_sha256=sha(path),
                ordered_repeat_equal=a.get("ordered_repeat_equal"),
                canonical_sha256=hashlib.sha256(
                    json.dumps(canonical, sort_keys=True).encode()
                ).hexdigest(),
                source_recognition="TypeScript processed; no MCP surfaces discovered; unknown total surface count. Eleven selected rules evaluated, SENT-001 skipped for missing permissions. Completion does not establish analyzed handler/sink coverage.",
            )
            source = sources[item.id]["src/index.ts"]
            for index, warning in enumerate(report["warnings"]):
                assert warning["code"] == "static_binding_unresolved"
                name = warning["message"].split("binding '", 1)[1][:-1]
                pattern, explanation = REVIEWS[name]
                lines = [
                    {"line": n, "text": text}
                    for n, text in enumerate(source.decode().splitlines(), 1)
                    if pattern in text
                ]
                assert lines, (item.id, name, pattern)
                warnings.append(
                    {
                        "batch": a["batch"],
                        "input_id": item.id,
                        "warning_index": index,
                        "warning": warning,
                        "binding": name,
                        "source_path": "src/index.ts",
                        "source_sha256": hashlib.sha256(source).hexdigest(),
                        "source_lines": lines,
                        "assessment": explanation,
                        "disposition": "Source-assessed unresolved-binding diagnostic; retained, not a finding or runtime proof.",
                    }
                )
        else:
            path = folder / item.id / "raw.json"
            raw = json.loads(path.read_text())
            assert sha(path) == a["outcome"]["raw_sha256"]
            assert (
                raw["version"] == "1.176.0"
                and raw["results"] == []
                and raw["errors"] == []
                and raw["skipped_rules"] == []
            )
            scanned = [p.split("/source/", 1)[1] for p in raw["paths"]["scanned"]]
            assert len(scanned) == 8 and {"src/index.ts", "src/types.d.ts"} <= set(
                scanned
            )
            assert set(scanned) <= sources[item.id].keys()
            row.update(
                raw_sha256=sha(path),
                error_count=0,
                scanned_paths=scanned,
                comparator_version=raw["version"],
                source_recognition="Both TypeScript files scanned by pinned OSS comparator; no match or error. No MCP semantic-coverage or superiority claim.",
            )
        row.update(
            score(label=item.label, state="completed", findings=[], assessment=None)
        )
        rows.append(row)
    assert len(warnings) == 232 and {w["binding"] for w in warnings} == set(REVIEWS)
    warning_path = OUT / "warning-source-assessment.json"
    assert not warning_path.exists()
    warning_path.write_text(
        json.dumps(
            {
                "rows": warnings,
                "count": len(warnings),
                "unique_bindings": len(REVIEWS),
                "fixed_added_bindings": sorted(
                    set(
                        w["binding"]
                        for w in warnings
                        if w["input_id"] == "lighthouse-linklocal-fixed"
                    )
                    - set(
                        w["binding"]
                        for w in warnings
                        if w["input_id"] == "lighthouse-linklocal-vulnerable"
                    )
                ),
                "repeat_deltas": [],
                "findings_assessed": 0,
                "unassessed_diagnostics": 0,
            },
            indent=2,
        )
        + "\n"
    )
    with zipfile.ZipFile(HOSTED / "logs.zip") as z:
        checkout_logs = {
            n: z.read(n).decode()
            for n in z.namelist()
            if "Check out" in n and "/3_" in n or "Check out" in n and "/4_" in n
        }
        assert len(checkout_logs) == 2
        assert any(packet["workflow_revision"] in v for v in checkout_logs.values())
        assert any(proposal["scanner"]["revision"] in v for v in checkout_logs.values())
    jobs = retained["run"]["jobs"]
    assert retained["run"]["conclusion"] == "success"
    assert sum(j["conclusion"] == "success" for j in jobs) == 1
    assert all(j["conclusion"] in {"success", "skipped"} for j in jobs)
    batch_metrics = {
        b: metrics([r for r in rows if r["batch"] == b])
        for b in proposal["batch_order"]
    }
    for m in batch_metrics.values():
        assert m["states"] == {"completed": 5} and m["vulnerable_total"] == 2
        assert (
            m["candidate"]["completed_detections"] == 0
            and m["false_alarm_conditions"] == 0
        )
    result = {
        "recorded_at": datetime.now(timezone.utc).isoformat(),
        "execution_checks_passed": True,
        "source_assessment_complete": True,
        "detection_limitation_accepted": False,
        "technical_acceptance_received": False,
        "phase22_complete": False,
        "run": 34605934302,
        "workflow": packet["workflow_revision"],
        "scanner": packet["scanner"],
        "proposal_sha256": sha(
            ROOT / "artifacts/phase22/corpus-replacement-v5/evaluation-proposal.json"
        ),
        "checkpoint_sha256": proposal["checkpoint"]["sha256"],
        "authorization_sha256": packet["approval_sha256"],
        "binding_sha256": packet["binding_sha256"],
        "raw_packet_sha256": sha(RAW / "packet.json"),
        "retention_packet_sha256": sha(HOSTED / "packet.json"),
        "warning_assessment_sha256": sha(warning_path),
        "budget": {
            "dispatches_consumed": 1,
            "native_observations": 10,
            "comparator_observations": 5,
            "completed": 15,
            "unstarted": 0,
            "remaining": 0,
            "closed": True,
            "retries": 0,
            "profiles": 0,
            "paid_calls": 0,
            "target_execution": False,
        },
        "native_within_120_seconds": 10,
        "native_extended": 0,
        "native_whole_maximum_seconds": max(
            r["whole_input_seconds"] for r in rows[:10]
        ),
        "comparator_whole_maximum_seconds": max(
            r["whole_input_seconds"] for r in rows[10:]
        ),
        "comparator_within_120_seconds": 5,
        "ordered_native_repeats_equal": 5,
        "batch_metrics": batch_metrics,
        "rows": rows,
        "warning_count": len(warnings),
        "coverage_assessment": "All 10 native reports complete with zero discovered surfaces and unknown total_possible_surfaces. Empty unresolved_flows does not erase the 232 binding warnings. No vulnerable handler/sink coverage is established; retain both misses in the completed denominator. Fixed/control silence supplies no evidence of discrimination because vulnerable reports are also silent.",
        "source_gap_assessment": "Source import Server is followed by Server.prototype.setRequestHandler reassignment. TypeScriptProgram records assignments against the module binding root as rebound (typescript_discovery.py:137-144), and resolve rejects nonunique bindings (385-402). The report retains unresolved Server/this.server/dispatch/startup warnings. Independently, SENT-015 recognized TypeScript request sinks (sent015.py:974-1013) omit Lighthouse and Chrome browser navigation. These source-defined recognition limits explain the observed miss; no counterfactual isolated scan or runtime proof was performed, so fixing only one is not claimed sufficient.",
        "scanner_source_evidence": {
            n: sha(ROOT / n)
            for n in [
                "src/sentinel/static/typescript_discovery.py",
                "src/sentinel/static/typescript_path_flow.py",
                "src/sentinel/static/rules/sent015.py",
            ]
        },
        "source_label_assessment": "Unchanged frozen source review confirms the vulnerable path has only argument checks before Chrome/Lighthouse. Fixed validateUrl rejects canonical169.254.169.254 through the null-mask169.254 prefix before Chrome; public8.8.8.8 matches no blocked prefix. Loopback is intentionally permitted; DNS failure/redirect/IPv6/other tools and actual startup/navigation remain outside the label. Two reversible renames retain one correlated vulnerability.",
        "product_implication": "A completed rules-only scan can miss this real MCP browser-mediated SSRF condition and cannot distinguish the vulnerable/fixed/control inputs. Binding warnings and unknown coverage must remain prominent. Neither zero findings, passing timing/CI nor equal comparator misses establish safety or general detection accuracy.",
        "helper_sha256": sha(Path(__file__)),
    }
    destination.write_text(json.dumps(result, indent=2) + "\n")
    print(
        "Validated 15/15, 5 ordered repeats, 232 source-assessed diagnostics; 0/2 vulnerable detections per batch. Explicit limitation disposition required."
    )


if __name__ == "__main__":
    main()
