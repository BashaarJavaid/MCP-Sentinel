"""Reconcile every requirement for the measured limitation checkpoint."""

import copy
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
BASE = OUT.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    path = OUT / "audit.json"
    assert not path.exists()
    previous = BASE / "v23-checkpoint-audit/packet.json"
    old = json.loads(previous.read_text())
    audit = copy.deepcopy(old)
    result = json.loads((OUT / "assessment.json").read_text())
    reuse = json.loads((OUT / "compatible-reuse.json").read_text())
    assert (
        result["execution_checks_passed"]
        and result["source_assessment_complete"]
        and reuse["passed"]
    )
    proposed = "proposed documented limitation awaiting decision"
    for row in audit["requirements"]:
        row["historical_assessment"] = {
            "audit": previous.relative_to(BASE).as_posix(),
            "text": row["assessment"],
        }
        row["prior_requirement_record_sha256"] = hashlib.sha256(
            json.dumps(
                next(r for r in old["requirements"] if r["id"] == row["id"]),
                sort_keys=True,
            ).encode()
        ).hexdigest()
        row["evidence"].append(
            "artifacts/phase22/integration/v24-fresh-v5/compatible-reuse.json"
        )
        row["interpretation"] = (
            "Prior source-specific evidence and scope decisions remain preserved. Current scanner/test/package bytes equal1f3f72f; workflow equals tested e1ab15c. New fresh results at workflow86cbdc9 are separately assessed. Final documentation/delivery bindings are separate; no technical acceptance is inferred."
        )
        if row["id"] in {"R66", "R88"}:
            row["disposition"] = proposed
            row["assessment"] = (
                "Novel Lighthouse source was frozen after scanner stabilization and explicitly approved before the single15-observation evaluation. All15complete and all5ordered native repeats match; all232diagnostics source-assessed. Native and comparator each miss both vulnerable variants, with zero fixed/control alerts. Source-defined SDK prototype ambiguity and unrecognized Lighthouse sink remain visible. The evaluation obligation is executed; explicit disposition of the documented limitation remains required. No threshold invented, labels changed, scanner tuned or retry authorized."
            )
            row["evidence"].extend(
                [
                    "artifacts/phase22/integration/v23-fresh-v5/authorization.json",
                    "artifacts/phase22/integration/v23-fresh-v5/binding.json",
                    "artifacts/phase22/integration/v24-fresh-v5/assessment.json",
                    "artifacts/phase22/integration/v24-fresh-v5/limitation-proposal.json",
                ]
            )
        elif row["id"] == "R84":
            row["assessment"] = (
                "Final human technical acceptance remains unrequested and unreceived. The measured fresh limitation needs its explicit disposition first. R84 stays unresolved; pilots remain explicitly deferred as a completion prerequisite."
            )
        elif row["id"] in {"R67", "R68", "R69"}:
            row["assessment"] = (
                "Fresh15observations completed and were validated with every232binding warning source-assessed, all5ordered repeats equal, all nativeJSON/SARIF valid. Zero native/comparator findings means no unmatched candidate adjudication backlog; two vulnerable misses per batch remain. Pinned Semgrep1.176.0 uses511configs/533rules and the same source records; Snyk/Cisco remain unmeasured. Unknown native tool coverage is retained; pipeline completion is not detection success."
            )
            row["evidence"].extend(
                [
                    "artifacts/phase22/integration/v24-fresh-v5/assessment.json",
                    "artifacts/phase22/integration/v24-fresh-v5/warning-source-assessment.json",
                ]
            )
        elif row["id"] in {"R62", "R83"}:
            row["assessment"] = (
                "Owning docs record the approved completed fresh evaluation,0/2native/comparator vulnerable hits, unknown native tool coverage, proposed limitation and pending human acceptance. Historical v4novelty failure and all earlier results remain source-specific history; Phase22 incomplete."
            )
        elif row["id"] in {"R71", "R72", "R73", "R74"}:
            row["assessment"] = (
                "All29normal jobs and12quality suites2194passed/36skipped retain tested e1ab15c with89.67–89.69%hosted coverage and byte-verified153wheel/166sdist members. Product/workflow unchanged by evaluation receipts. Local2194/36,89.68%coverage, six production replay bindings and Git/runtime evidence retain original sources. Affected docs/helpers/reports checked separately; no new full local or hosted matrix pass claimed."
            )
    additions = [
        (
            "V24-FRESH-EVALUATION",
            "Execute only the exact approved15observations at immutable scanner, validate identities/schemas/cleanup/ordered repeats and close budget",
            "passed",
            ["assessment.json", "dispatch-consumed.json", "hosted/packet.json"],
        ),
        (
            "V24-SOURCE-ASSESSMENT",
            "Assess every fresh diagnostic, raw outcome and coverage delta without relabeling, tuning or substituting sources",
            "passed",
            ["assessment.json", "warning-source-assessment.json"],
        ),
        (
            "V24-COMPATIBLE-VERIFICATION",
            "Reverify all89original and56prior added rows, quality/replay/runtime/source bindings and prior seals",
            "passed",
            ["compatible-reuse.json"],
        ),
        (
            "V24-LIMITATION-DISPOSITION",
            "Obtain explicit user disposition of the measured Lighthouse SDK/browser sink recognition limitation",
            proposed,
            ["limitation-proposal.json"],
        ),
    ]
    audit["additional_scope_requirements"].extend(
        {
            "id": i,
            "requirement": r,
            "disposition": d,
            "evidence": ["artifacts/phase22/integration/v24-fresh-v5/" + n for n in e],
        }
        for i, r, d, e in additions
    )
    audit.update(
        recorded_at=datetime.now(timezone.utc).isoformat(),
        source=result["workflow"],
        workflow_tested_source=reuse["product_and_workflow_equal_tested_source"],
        current_source_corpus_runs=15,
        fresh_evaluation_approved=True,
        fresh_evaluation_executed=True,
        fresh_execution_checks_passed=True,
        fresh_source_assessment_complete=True,
        fresh_limitation_disposition_received=False,
        technical_acceptance_requested=False,
        technical_acceptance_received=False,
        new_paid_calls=0,
        phase22_complete=False,
        status="Approved fresh evaluation completed; native/comparator0/2vulnerable hits and unknown native coverage require explicit limitation disposition. Final technical acceptance remains a separate pending checkpoint.",
        prior_audit={
            "path": previous.relative_to(BASE).as_posix(),
            "sha256": sha(previous),
        },
        owning_document_binding="v24-fresh-v5/documentation-binding.json records final docs and delivery source; prior bindings remain historical.",
    )
    audit["dispositions"] = dict(
        Counter(r["disposition"] for r in audit["requirements"])
    )
    audit["additional_scope_dispositions"] = dict(
        Counter(r["disposition"] for r in audit["additional_scope_requirements"])
    )
    assert audit["dispositions"] == {
        "passed": 84,
        "explicitly user-deferred": 2,
        proposed: 2,
        "unresolved": 1,
    }
    assert audit["additional_scope_dispositions"] == {
        "passed": 56,
        "unresolved": 3,
        proposed: 1,
    }
    assert (
        len(audit["requirements"]) == 89
        and len(audit["additional_scope_requirements"]) == 60
    )
    audit["references_sha256"].update(
        {
            "v24-fresh-v5/" + n: sha(OUT / n)
            for n in [
                "assessment.json",
                "warning-source-assessment.json",
                "compatible-reuse.json",
                "limitation-proposal.json",
                "dispatch-consumed.json",
            ]
        }
    )
    for row in audit["requirements"] + audit["additional_scope_requirements"]:
        for name in row["evidence"]:
            assert (
                ROOT / name if name.startswith("artifacts/") else BASE / name
            ).is_file(), name
    path.write_text(json.dumps(audit, indent=2) + "\n")
    print(audit["dispositions"], audit["additional_scope_dispositions"])


if __name__ == "__main__":
    main()
