import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=read('v16-combine-assessment.json');v=read('v16-source-verification.json');seal=read('evidence-v45.json');p=read('v15-closeout-audit/packet.json')
assert not a['all_proceed_conditions_passed'] and a['scope_stopped'] and a['remaining_authorized_executions']==0
p.update(source=a['scanner']['revision'],scanner_identity=a['scanner'],workflow_delivery=v['executed_engineering_source'],recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_diagnostic=a,prior_audit={'path':'artifacts/phase22/integration/v15-closeout-audit/packet.json','sha256':sha(b/'v15-closeout-audit/packet.json')},current_verification={'path':'artifacts/phase22/integration/v16-source-verification.json','sha256':sha(b/'v16-source-verification.json'),'actual_executed_engineering_source':v['executed_engineering_source'],'new_full_suite_or_hosted_run':False},next_combine_proposal_approved=True,next_worker_sampling_approved=False,current_source_fresh_evaluation_approved=False,new_paid_calls=0,phase22_complete=False,technical_acceptance_requested=False,technical_acceptance_received=False)
p['current_source_and_test_files']=v['source_and_test_files_sha256'];p['owning_document_binding']='Final owning-document hashes are bound after this update in v16-final-documentation-binding.json. Profile46b8786, actual engineering592a9cd and original exposed native2ac39aa remain distinct.'
for row in p['requirements']:
 row['evidence']=list(dict.fromkeys(row['evidence']+['artifacts/phase22/integration/v16-source-verification.json']))
 row['current_verification']='All code/test/workflow/package inputs equal actual engineering source592a9cd. Retained full-suite, hosted, replay and compatibility results keep their executed source; no new full suite is claimed.'
 if row['id'] in ['R63','R64','R65','R69','R85','R86']:
  row['evidence']+=['artifacts/phase22/integration/v16-combine-assessment.json'];row['latest_diagnostic']='One approved instrumented Meta operator input completed81.271s (82.947s outer), full ordered baseline match, four final worker snapshots. All three eligible CPU fractions fail the approved10% predicate. Zero optimizations;12 native performance and30 conditional exposed observations cancelled. Scope closed, no paid calls. Linux/fresh/acceptance gates remain unmet.'
 if row['id']=='R79':row['evidence']+=['artifacts/phase22/integration/evidence-v45.json']
 if row['id']=='R82':row['evidence']+=['artifacts/phase22/integration/v16-delivery-verification.json']
for i,title,evidence in [('AUTH','Exact conditional-experiment approval and source/input bindings',['v16-combine-authorization.json']),('DIAG','One bounded diagnostic with validated original semantics and report',['v16-combine-assessment.json','v16-instrumentation-selfcheck/packet.json']),('STOP','Enforce the prospective predicate and close unused maxima when it fails',['v16-combine-assessment.json']),('REUSE','Verify unchanged source and preserve actual engineering/runtime evidence',['v16-source-verification.json']),('DELIVERY','Seal and deliver the completed scope without claiming Phase22 acceptance',['evidence-v45.json','v16-delivery-verification.json'])]:
 p['additional_scope_requirements'].append({'id':'V16-'+i,'requirement':title,'disposition':'passed','evidence':evidence})
p['additional_scope_dispositions']=dict(collections.Counter(r['disposition'] for r in p['additional_scope_requirements']));assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==17 and p['additional_scope_dispositions']=={'passed':16,'unresolved':1}
p['references_sha256'].update({'artifacts/phase22/integration/'+n:sha(b/n) for n in ['v16-combine-authorization.json','v16-combine-assessment.json','v16-source-verification.json','v16-next-worker-sampling-proposal.json','evidence-v45.json']})
out=b/'v16-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
summary='''The user approved `v15-next-combine-proposal.json`; the exact receipt is
`v16-combine-authorization.json`. Its one Meta operator diagnostic completed in
**81.271s** (**82.947s** including measurement setup/finalization). The full
ordered report matches the retained native baseline after established volatile
exclusions. Native JSON/SARIF validate, all four workers have final snapshots,
and 24 synthetic comparisons preserve all Value fields, keys and cache behavior.

The prospective predicate **fails in all three active workers**. Eligible generic
combinations are frequent (83.72%, 85.54%, 84.47%), but their body CPU shares are
only **7.81% SENT-012, 5.34% SENT-015 and 6.81% SENT-016**, below the required
**10% in each worker**. Timing excludes classification counters but includes field
reductions/helpers and construction; it is instrumented attribution, not wholly
removable cost or a native gain. See `v16-combine-assessment.json`.

The stopping condition was enforced before optimization. **One profile used,
zero optimization attempts, zero native performance observations and zero exposed
regression observations.** All 12 performance and 30 conditional SSRF observations
are cancelled; no unused maximum remains open. No scanner/test code changed and
no reversion was needed. Zero paid calls.

Source/test/workflow/package inputs at diagnostic `46b8786` equal verified
`592a9cd`. The existing local and 12 hosted suites each retain 2,183 passed and
36 skipped; 29 normal jobs and docs, production replay and Git compatibility
retain their actual executed sources. No new full suite or hosted pass is claimed.
All three exposed SSRF gates remain source-compatible at measured `2ac39aa`.

The next `v16-next-worker-sampling-proposal.json` is **unapproved**: one
120-second CPU sampling profile of the same Meta operator input, at most 100Hz
per worker, zero optimizations or additional native/comparator observations and
zero paid calls. It seeks a larger whole-worker CPU concentration before another
code proposal. No further measurement, full Linux retry or fresh evaluation is
inferred. Timing/fresh evaluation/final acceptance remain unmet; Phase 22 remains
incomplete. Pilots/full paid benchmark stay deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, release, outreach or next phase.
'''
paths=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']
for name in paths:
 f=root/name;s=f.read_text()
 if name=='AGENTS.md':needle='## Current phase\n\n';assert s.count(needle)==1;s=s.replace(needle,needle+summary+'\n### Historical v15 diagnostic at `77ea21f`\n\n',1)
 else:
  level='###' if name=='ROADMAP.md' else '##';needle=level+' Current v15 diagnostic at `77ea21f`';assert s.count(needle)==1;s=s.replace(needle,level+' Current v16 diagnostic at `46b8786`\n\n'+summary+'\n'+level+' Historical v15 diagnostic at `77ea21f`',1)
 f.write_text(s)
f=b/'requirements.md';s=f.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current v15 source-bound audit','## Historical v15 source-bound audit',1)
text='''\n## Current v16 source-bound audit\n\nAll 89 original rows are mapped in `v16-closeout-audit/packet.json`:
**70 passed, 2 explicitly user-deferred, 17 unresolved**. The five v16 execution
requirements pass, including enforcing the failed predicate; the predicate itself
remains failed. All 17 additional rows retain **16 passed and 1 unresolved**
(the historical v14 performance-retention requirement). Engineering executions
remain at `592a9cd`; this single diagnostic is at `46b8786` on identical code.
No timing pass, fresh result or human acceptance is inferred.\n\n| ID | Requirement | Disposition |\n| --- | --- | --- |\n'''
for row in p['additional_scope_requirements']:
 if row['id'].startswith('V16-'):text+='| '+row['id']+' | '+row['requirement']+' | **passed** |\n'
f.write_text(title+'\n'+text+rest)
index=f'''Batch 45 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 44 prior archive hashes are verified.
Restore after batches 1–44 in separate staging using `evidence-v45.json`; existing
destinations must match identical bytes or a recorded previous hash. Stop on
unexpected conflicts. The batch retains approval, the one diagnostic, raw worker
snapshots, report comparison/validation, synthetic controls, source verification,
helpers and the unapproved next sampling proposal. Final audit/docs/delivery
bindings are tracked directly after the seal.\n\n'''
f=b/'README.md';s=f.read_text().replace('batches 1–44 and closeout audit','batches 1–45 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text((f.read_text().rstrip()+'\n\n### Evidence batch 45\n\n'+index).rstrip()+'\n')
body=(b/'v15-closeout-draft-body.md').read_text().split('\n\n',1)[0]+'\n\n'+summary+'\n[Current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v16-closeout-audit/packet.json), [diagnostic and failed predicate](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v16-combine-assessment.json), [next sampling proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v16-next-worker-sampling-proposal.json), and [evidence batches 1–45](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nThis docs/evidence-only delivery uses authorized CI skip after proving tested inputs unchanged. Final docs are checked locally; no later hosted code pass is claimed.\n'
f=b/'v16-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(p['dispositions'],p['additional_scope_dispositions'])
