from __future__ import annotations
def factory(__class__):
    def merge(self, env: dict[str, Value], branches: list[dict[str, Value]]) -> None:
        empty = UNKNOWN_VALUE
        http = [
            branch
            for branch in branches
            if branch.get("#credential:http", empty).contained
        ]
        # ponytail: follow the successful HTTP getter path; exception-prefix
        # correlation needs separate state. Keep the stdio alternative distinct.
        _count("credential.http_branches",len(http))
        branches = http or branches
        _mark("base")
        super().merge(env, branches)
        _mark("post")
        if http:
            env["#credential:http"] = Value(contained=True)
        for name in (self.absent_markers | self.opt_in_markers) & env.keys():
            _count("credential.post.markers")
            first = branches[0].get(name, empty) if branches else empty
            if all(branch.get(name, empty) is first for branch in branches[1:]):
                _count("credential.post.direct_reuse")
                env[name] = first
                continue
            _count("credential.post.recomputed")
            env[name] = (
                replace(combine([branch[name] for branch in branches]), contained=True)
                if all(branch.get(name, empty).contained for branch in branches)
                else empty
            )

    return merge
