"""In-memory merge counters; preserve production statements and super closures."""
import ast,collections,functools,hashlib,inspect,json,sys,textwrap,threading,time
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root/'src'),str(root)]
from sentinel.static import workers,path_flow
from sentinel.static.rules import sent015,sent016
out=Path(__file__).resolve().parent;rule=sys.argv[-1];counts=collections.Counter();timings=collections.Counter();stack=[];identities=[];stop=threading.Event()
def _count(key,amount=1):counts[key]+=amount
def _mark(phase):
 frame=stack[-1];wall=time.perf_counter();cpu=time.process_time()
 timings[frame['kind']+'.phase.'+frame['phase']+'.wall']+=wall-frame['wall']
 timings[frame['kind']+'.phase.'+frame['phase']+'.cpu']+=cpu-frame['cpu']
 frame.update(phase=phase,wall=wall,cpu=cpu)
def instrument(cls,kind,replacements):
 original=cls.merge;raw=textwrap.dedent(inspect.getsource(original));modified=raw
 for needle,addition in replacements:
  assert modified.count(needle)==1,(kind,needle)
  modified=modified.replace(needle,addition,1)
 before=ast.parse(raw);after=ast.parse(modified);removed=0
 for node in ast.walk(after):
  for field in ('body','orelse','finalbody'):
   body=getattr(node,field,None)
   if not isinstance(body,list):continue
   kept=[]
   for statement in body:
    if isinstance(statement,ast.Expr) and isinstance(statement.value,ast.Call) and isinstance(statement.value.func,ast.Name) and statement.value.func.id in {'_count','_mark'}:removed+=1
    else:kept.append(statement)
   setattr(node,field,kept)
 assert removed and ast.dump(before)==ast.dump(after),(kind,'production AST changed')
 # Recompile within a closure holding the original class, preserving zero-arg super.
 source='from __future__ import annotations\ndef factory(__class__):\n'+textwrap.indent(modified,'    ')+'\n    return merge\n'
 file=out/(rule+'-'+kind+'-instrumented.py');file.write_text(source)
 namespace=dict(original.__globals__,_count=_count,_mark=_mark);exec(compile(source,str(file),'exec'),namespace)
 merged=namespace['factory'](cls)
 @functools.wraps(original)
 def wrapped(self,env,branches):
  wall=time.perf_counter();cpu=time.process_time();frame={'kind':kind,'phase':'pre','wall':wall,'cpu':cpu,'child_wall':0.,'child_cpu':0.};stack.append(frame)
  _count(kind+'.calls');_count(kind+'.branches_before',len(branches));_count(kind+'.branch_entries_before',sum(map(len,branches)));_count(kind+'.env_entries_before',len(env))
  _count(kind+'.initial_single',len(branches)==1);_count(kind+'.initial_multiple',len(branches)>1)
  try:return merged(self,env,branches)
  finally:
   _mark('end');elapsed_wall=time.perf_counter()-wall;elapsed_cpu=time.process_time()-cpu;assert stack.pop() is frame
   timings[kind+'.inclusive.wall']+=elapsed_wall;timings[kind+'.inclusive.cpu']+=elapsed_cpu
   timings[kind+'.exclusive.wall']+=elapsed_wall-frame['child_wall'];timings[kind+'.exclusive.cpu']+=elapsed_cpu-frame['child_cpu']
   if stack:stack[-1]['child_wall']+=elapsed_wall;stack[-1]['child_cpu']+=elapsed_cpu
 identities.append({'class':cls.__name__,'original_sha256':hashlib.sha256(raw.encode()).hexdigest(),'instrumented_sha256':hashlib.sha256(source.encode()).hexdigest(),'production_ast_preserved':True,'injected_statements':removed,'original_super_class_preserved':True})
 cls.merge=wrapped
 return original
path_original=instrument(path_flow.PathFlow,'path',[
 ('        branches = branches[:1]','        _count("path.whole_equal")\n        _count("path.collapsed_branches",len(branches)-1)\n        branches = branches[:1]'),
 ('    if len(branches) == 1:','    _mark("dispatch")\n    if len(branches) == 1:'),
 ('        env.update(branches[0])','        _count("path.single")\n        _mark("single_update")\n        env.update(branches[0])\n        _mark("single_normalize")'),
 ('        for name, value in branches[0].items():','        for name, value in branches[0].items():\n            _count("path.single.keys")'),
 ('                env[name] = Value(contained=value.contained)','                _count("path.single.path_normalized")\n                env[name] = Value(contained=value.contained)'),
 ('                env[name] = replace(','                _count("path.single.guard_stripped")\n                env[name] = replace('),
 ('    unknown = UNKNOWN_VALUE','    _count("path.multiple_or_empty")\n    _mark("multi_setup")\n    unknown = UNKNOWN_VALUE'),
 ('    for name in set().union(*(b.keys() for b in branches)):','    _mark("multi_values")\n    for name in set().union(*(b.keys() for b in branches)):\n        _count("path.multi.keys")'),
 ('            env[name] = value','            _count("path.multi.direct_reuse")\n            env[name] = value'),
 ('        values = [branch.get(name, default) for branch in branches]','        _count("path.multi.path_normalized",name.startswith("#path:"))\n        _count("path.multi.combine_instances",not name.startswith("#path:"))\n        _count("path.multi.combine_inputs",len(branches) if not name.startswith("#path:") else 0)\n        values = [branch.get(name, default) for branch in branches]'),
])
url_original=instrument(sent015.URLFlow,'url',[
 ('    for marker in set().union(*(branch.keys() for branch in branches)):','    for marker in set().union(*(branch.keys() for branch in branches)):\n        _count("url.pre.keys")'),
 ('        origin = marker.removeprefix("#url-truth:")','        _count("url.truth_markers")\n        origin = marker.removeprefix("#url-truth:")'),
 ('        checks = frozenset.intersection(','        _count("url.partial_truth_markers")\n        _count("url.truth_value_visits",sum(map(len,possible)))\n        checks = frozenset.intersection('),
 ('            conditional[origin] = checks','            _count("url.conditional_checks")\n            conditional[origin] = checks'),
 ('    super().merge(env, branches)','    _mark("base")\n    super().merge(env, branches)\n    _mark("post")'),
 ('    for key in env.keys() & self.fact_keys.keys():','    for key in env.keys() & self.fact_keys.keys():\n        _count("url.post.fact_keys")'),
])
credential_original=instrument(sent016.CredentialFlow,'credential',[
 ('    branches = http or branches','    _count("credential.http_branches",len(http))\n    branches = http or branches'),
 ('    super().merge(env, branches)','    _mark("base")\n    super().merge(env, branches)\n    _mark("post")'),
 ('    for name in (self.absent_markers | self.opt_in_markers) & env.keys():','    for name in (self.absent_markers | self.opt_in_markers) & env.keys():\n        _count("credential.post.markers")'),
 ('            env[name] = first','            _count("credential.post.direct_reuse")\n            env[name] = first'),
 ('        env[name] = (','        _count("credential.post.recomputed")\n        env[name] = ('),
])
def snapshot(final=False):
 data={'rule':rule,'methods':identities,'counts':dict(counts),'timings_seconds':dict(timings),'final_worker_snapshot':final,'source_values_recorded':False,'timing_limit':'Instrumented method/phase intervals include counter/timer overhead. Parent base phases include nested PathFlow intervals; never sum overlapping inclusive intervals. Exclusive excludes nested instrumented merge methods only. Interrupted active intervals may be absent.'}
 path=out/(rule+'-merge-profile.json');tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def snapshots():
 while not stop.wait(15):snapshot()
if __name__=='__main__':
 thread=threading.Thread(target=snapshots,daemon=True);thread.start()
 try:workers._worker()
 finally:stop.set();thread.join();snapshot(True)
