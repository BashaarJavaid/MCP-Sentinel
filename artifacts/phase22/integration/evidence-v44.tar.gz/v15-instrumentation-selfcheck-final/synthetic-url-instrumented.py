from __future__ import annotations
def factory(__class__):
    def merge(self, env: dict[str, Value], branches: list[dict[str, Value]]) -> None:
        conditional = {}
        unknown = UNKNOWN_VALUE
        for marker in set().union(*(branch.keys() for branch in branches)):
            _count("url.pre.keys")
            if not marker.startswith("#url-truth:"):
                continue
            _count("url.truth_markers")
            origin = marker.removeprefix("#url-truth:")
            possible = [
                branch
                for branch in branches
                if branch.get(marker, unknown).key != "False"
            ]
            if not possible or len(possible) == len(branches):
                continue
            _count("url.partial_truth_markers")
            _count("url.truth_value_visits",sum(map(len,possible)))
            checks = frozenset.intersection(
                *(
                    frozenset().union(
                        *(
                            value.url_checks
                            for value in branch.values()
                            if value.key == origin
                        )
                    )
                    for branch in possible
                )
            )
            if checks:
                _count("url.conditional_checks")
                conditional[origin] = checks
        _mark("base")
        super().merge(env, branches)
        _mark("post")
        for origin, checks in conditional.items():
            key = _key("conditional-url", origin, *sorted(checks))
            self.conditional_checks[key] = checks
            env["#url-conditional:" + origin] = Value(key=key)
        for key in env.keys() & self.fact_keys.keys():
            _count("url.post.fact_keys")
            env[key] = replace(
                env[key],
                contained=all(
                    branch.get(key, unknown).contained for branch in branches
                ),
            )

    return merge
