from __future__ import annotations
def factory(__class__):
    def merge(self, env: dict[str, Value], branches: list[dict[str, Value]]) -> None:
        if branches and all(branch == branches[0] for branch in branches[1:]):
            _count("path.whole_equal")
            _count("path.collapsed_branches",len(branches)-1)
            branches = branches[:1]
        _mark("dispatch")
        if len(branches) == 1:
            # Most helper exits have one surviving branch. Avoid re-combining
            # every unchanged member, preserving the same protection semantics.
            _count("path.single")
            _mark("single_update")
            env.update(branches[0])
            _mark("single_normalize")
            for name, value in branches[0].items():
                _count("path.single.keys")
                if name.startswith("#path:"):
                    _count("path.single.path_normalized")
                    env[name] = Value(contained=value.contained)
                elif not value.sources and (
                    value.contained
                    or value.checked_path_parent
                    or value.option_safe
                    or value.url_checks
                ):
                    _count("path.single.guard_stripped")
                    env[name] = replace(
                        value,
                        contained=False,
                        checked_path_parent=False,
                        option_safe=False,
                        url_checks=frozenset(),
                    )
            return
        _count("path.multiple_or_empty")
        _mark("multi_setup")
        unknown = UNKNOWN_VALUE
        first, *rest = branches or [{}]
        second = rest[0] if len(rest) == 1 else None
        _mark("multi_values")
        for name in set().union(*(b.keys() for b in branches)):
            _count("path.multi.keys")
            default = self.member_defaults.get(name, unknown)
            value = first.get(name, default)
            if (
                not name.startswith("#path:")
                and (
                    value.sources
                    or not (
                        value.contained
                        or value.checked_path_parent
                        or value.option_safe
                        or value.url_checks
                    )
                )
                and (
                    (other := second.get(name, default)) is value or other == value
                    if second is not None
                    else all(
                        (other := branch.get(name, default)) is value or other == value
                        for branch in rest
                    )
                )
            ):
                _count("path.multi.direct_reuse")
                env[name] = value
                continue
            _count("path.multi.path_normalized",name.startswith("#path:"))
            _count("path.multi.combine_instances",not name.startswith("#path:"))
            _count("path.multi.combine_inputs",len(branches) if not name.startswith("#path:") else 0)
            values = [branch.get(name, default) for branch in branches]
            env[name] = (
                Value(contained=all(value.contained for value in values))
                if name.startswith("#path:")
                else self.combine_instances(values)
            )

    return merge
