# Complete Phase 22 continuation prompt — PortunusMCP Sentinel — handoff v2

Finish the remaining Phase 22 technical work for PortunusMCP Sentinel. Implement,
integrate, verify, document and deliver the **COMPLETE authorized scope below**.

This is a continuation of substantial existing work, not a request to restart or
produce another plan. Do not stop at a plan, synthetic regression suite, milestone,
approval packet, passing unit tests or draft PR. Do not omit difficult requirements,
silently reduce scope, or confuse source-specific evidence with final acceptance.
Finish every independent authorized technical requirement before stopping at a
genuine external checkpoint. The current implementation is substantially unfinished.

This prompt preserves the full original product requirements and final gates,
updates the implementation/evidence state through September 8, 2026 at committed
source 020cde8, supersedes the earlier handoff, and replaces
the earlier per-increment PR/CI workflow. Historical status paragraphs describe
their own source revisions; later facts below supersede stale handoff descriptions.

## 1. Correct workspace, environment and authoritative instructions

Repository: `/Users/bashaarjavaid/Projects/MCP-Sentinel`

**Active integration worktree:** `/private/tmp/mcp-phase22-options`

**Active branch:** `phase22/integration`

Original clean consolidated-workflow handoff:
`68fa702` — Adopt user-approved consolidated Phase 22 delivery workflow.

**Current committed HEAD:**
`020cde82dbe39d49f79187a3bfbac20d5f70f3e3`
— Cache immutable class lookups and avoid repeated member-key hashing.

**The integration worktree is CLEAN at this handoff.** `git status --short` is
empty; `git diff HEAD` is empty. Empty tracked-diff SHA-256:
`e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.
There are 41 new local commits after the earlier `1eead8f` handoff.

The previous handoff was dirty at `1eead8f` (five tracked files plus untracked
`typescript_registration_flow.py`). That work and its failing registration tests
were preserved and corrected in `96712f3` and subsequent commits. The older
constructor handoff at `83c9985` was completed in `fec9215`. Do NOT reapply either
old patch, recreate resolved failures or restart from an old checkpoint.

Verify actual state before editing: HEAD, branch, status, diff, untracked and
ignored source/evidence. If another agent has changed it, preserve those changes
and inspect their evidence before continuing. Do not reset, clean, discard,
overwrite or blindly commit. Clean Git status does not establish completed gates;
many expanded evidence files are intentionally ignored and remain valuable.

The main checkout is `/Users/bashaarjavaid/Projects/MCP-Sentinel`, currently
`phase22/python-containment` at `4cd5759`. Do not implement there, switch it
unnecessarily or restart from main. The integration worktree has a complete
checkout and uses the main repository's shared Git administration and locked env.
If `/private/tmp/mcp-phase22-options` is unavailable, locate `phase22/integration`
and recover its existing history in a suitable worktree. Verify any later dirty
changes from retained patches/untracked archives; HEAD alone never recovers them.

Preserve the historical recovery packet:
`handoff-20260908-unfinished.json/.tar.gz` in the integration evidence directory.
Its SHA-256 is
`bea7819d1e56f8f8e6f822b580ee4e3373a450e70ee5d4ad9623d69958a29c4f`.
It is an OLD dirty snapshot, not the current source and not a passing checkpoint.

A new supplemental evidence snapshot is retained locally:

- `artifacts/phase22/integration/handoff-20260908-v2-post14.tar.gz`
- `artifacts/phase22/integration/handoff-20260908-v2-post14.json`
- Archive SHA-256:
  `052cb86202faf56d02f72905290dbf759f56579dc02b37cb991e2ecdbc8f317a`
- 258 members, all read back against original per-file SHA-256; 2,024,135 bytes.
- Contains added/changed expanded evidence after sealed batches 1–14, snapshot
  script and the EMPTY tracked patch at `020cde8`.
- This is a supplemental handoff archive, not final acceptance or a Git-history
  backup. Committed code remains in the local integration branch. This prompt
  and supplemental packet are local artifacts; do not assume they are pushed.

Preserve detached measurement checkouts and their source/coverage identities:

- `/private/tmp/mcp-phase22-verify-f12e891`: `f12e891`, older full milestone.
- `/private/tmp/mcp-phase22-runtime-80bd278`: `80bd278`, Git runtime campaign.
- `/private/tmp/mcp-phase22-auth-fixed`: `34220b7`, auth condition measurement.
- `/private/tmp/mcp-phase22-asgi-fixed`: `3a2a276`, older nine-input measurement.
- `/private/tmp/mcp-phase22-fast-static`: `77825e4`, latest nine-input measurement.

These are verification checkouts, not alternative implementation branches.
Check actual `git worktree list`; preserve other historical worktrees too.

At the status inspection around 11:43 a.m. Pacific, no long-running scanner or
test process was visible. The latest retained check finished at 11:17 a.m.
This does not prove a CLI session has terminated. Before writing, check for other
active agents/checks on the same worktree. Do not run concurrent implementation
agents there or kill unrelated processes. If another writer is still active,
coordinate ownership with the user before edits; read-only investigation can proceed.

`/private/tmp` is temporary storage. Do not delete existing worktrees, diagnostic
sources or expanded evidence during implementation. Before eventual cleanup,
preserve necessary implementation, tests, evidence, manifests and reproduction
instructions durably and verify recovery; local commits alone are not remote
backup. Do not make cleanup a substitute for completing Phase 22, and do not
change the active worktree merely because its path is temporary.

Use the existing locked environment:
`/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv`.
Put it FIRST on PATH. Outside the root checkout use:

```sh
PYTHONPATH=src /Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python ...
```

Ensure imports come from the active worktree, not the older editable root install.
Verify source imports explicitly for detached verification/measurement drivers.

Read applicable `AGENTS.md`. Read `mcp-sentinel-buildplan.md` FIRST for historical
context, then use these active authorities:

- `ARCHITECTURE.md`
- `ROADMAP.md`, especially §1 and Phase 22
- `docs/phase22-technical.md`
- `docs/phase22-implementation-status.md`
- `docs/phase22-corpus-review.md`
- `artifacts/phase22/authorization.json`
- `artifacts/phase22/integration/requirements.md`
- `artifacts/phase22/integration/progress.md`
- `artifacts/phase22/integration/README.md`

Read relevant source/tests before changing them. Documentation, generated schema
literals and summaries are not proof of implemented behavior. The requirement
map now has **86 rows**, most still open. Complete the requirement-to-evidence
mapping; do not treat a few checked boxes as overall completion.

## 2. User-approved consolidated delivery workflow

The user explicitly approved reducing repeated PR/CI overhead:

- Finish on ONE integration branch: `phase22/integration`.
- Preserve old draft PRs and their evidence as historical checkpoints.
- Make separate reviewable local commits.
- Do not create a PR per increment, maintain the old stack, update every parent
  branch or repeatedly push merely to checkpoint local implementation.
- Batch PR delivery when the integrated candidate is ready.
- During implementation use focused regressions and applicable lint/type checks.
- Run full local checks at substantial integration milestones, not every edit.
- Run the complete benchmark and hosted OS/Python matrix on the final candidate.
- After failures/changes rerun affected checks; broaden when justified.
- Preserve commands, exit codes, logs, exact source identities and failures.
- Package evidence and update owning documentation in batches.
- Do not repeatedly poll CI while independent implementation remains.
- Do not trigger full CI for branch consolidation or evidence-only bookkeeping.
- Existing workflows/final gates are unchanged; no immediate workflow-YAML
  rewrite was requested.

Existing PR updates trigger 12 quality jobs, 12 wheel jobs, Docker/isolation checks
and two frozen Phase 20 reproductions. Avoid repeatedly triggering these across
branches.

Final delivery must be one consolidated, reviewable **DRAFT** against an
appropriate existing delivered parent. Actual ancestry/PR metadata were inspected:

- Chosen parent/base: **`phase22/description-poisoning`**, PR **#36**.
- Parent head: **`8b6b0ddf1d6f6cf5a8da3ab9421471865b801455`**.
- Git merge-base matched that head; remote evidence is retained under
  `delivery-parent-pr36-permitted`.
- Preserve this evidence and recheck actual ancestry/base state before final
  delivery; do not guess from an older summary if repository state changes.
- Identify the final parent and exact consolidated scope in the draft description.

**No consolidated final draft exists.** No pushes/new PRs/hosted runs/paid calls/
merges/releases/outreach were performed during this continuation. Do not merge,
publish or release without explicit authorization.

## 3. Authorization and hard boundaries

Already authorized; do NOT ask again:

- All ten historical Phase 20 benchmark families.
- All five compatibility areas.
- Phase 22 corpus freeze.
- Adoption of the separately versioned tested Git SDK environment `mcp==1.29.0`.
- Local implementation, commits, integration, verification and draft delivery.

Exact approval packets are in `artifacts/phase22/authorization.json`.

Frozen Phase 22 manifest:
`artifacts/phase22/corpus-review/manifest.json`

SHA-256, reverified at this handoff:
`a5ea6930e9cd5522f9420bef57875fea5d44d1d1c45fb5136a02a7c0292a9c67`.

The frozen corpus has **50 source-only inputs**: ten independent vulnerable/fixed
pairs, twenty paired mutations, ten controls, repository-level development/holdout
separation, recorded projections/licenses and evaluator-authored description fixes.

Authorized separate Git environment:
`artifacts/phase22/git-environment-v1-tested/packet.json`

Packet SHA-256, reverified at this handoff:
`a3481db5cfc181de2c0c1a51beca88a332570de00443655016945060394491d7`.

SDK: `mcp==1.29.0`.
Recorded image:
`sha256:420b998fc52bd814a2e937e780f9ddc0ede656f19e46ca0df02cf76242c1469a`.

Verify actual packet/image identities. This is a separate Phase 22 benchmark
environment; preserve Phase 20's original source/configuration/environment.

Still requires explicit authorization:

- NEW paid model calls, after a concrete bounded approval packet.
- PR merge, publication, release and acceptance decisions.
- Outreach, source sharing and maintainer attribution.

No paid packet is ready; no new paid calls have been made. A tool permission or
existing permissive command prefix does not authorize paid calls or publication.

Phase 21 recruitment is deferred. Five external workflows and ranked blockers
remain required. Technical work cannot manufacture pilot evidence or satisfy
the full pilot-dependent Phase 22 gate. Do not expand into outreach.

Finish independent authorized implementation, offline verification, documentation
and delivery work before stopping for external checkpoints. Prepare exact,
reviewable approval packets; do not use future approval needs to leave unrelated
technical work unfinished.

Preserve all Phase 20 source, configuration, labels, captures, costs, results and
historical completion records. Preserve stable rule identities/meanings.

Static analysis must NEVER import or execute target code, follow symlinks, render
Helm charts or execute target tooling. Interpreting source ASTs is not permission
to run constructors or target modules. Runtime targets execute only in
Sentinel-controlled Docker sandboxes under the accepted isolation contract.

Deterministic rules/probes must not require third-party live services.
`--rules-only` stays offline and bypasses model/cache/network/Docker/target execution.

Reuse the current pipeline, canonical Finding/report models, installed engines,
parsers, issue templates and benchmark infrastructure. No new languages/parsers,
speculative plugin frameworks, independent AI discovery, stateful exploitation,
telemetry, automatic patches, outreach or other deferred scope. Simplicity skills
must not reduce explicit requirements, validation, boundaries or evidence.
Prefer shared root-cause fixes over repository-specific special cases.

## 4. Preserve delivered history and source-specific evidence

Historical integration includes delivered corrections through PR #36,
`2c057c5` (explicitly unfinished SENT-014 checkpoint), `47974d0` (preserved report/
review draft with delivered parents), `6e3cd58` (consolidation), and `68fa702`
(approved consolidated workflow). Consolidation does not establish correctness.

Preserve draft checkpoints:

- #22/#23: execution and Python containment.
- #24: TypeScript containment and coordinate fixes.
- #33: workspaces.
- #34: shared containment/constructor hardening.
- #35: filesystem condition follow-up.
- #36: SENT-013 description poisoning.

Do not recreate these increments. Reverify behavior affected by integration;
old CI cannot establish correctness of the final candidate.

Preserve earlier evidence directories:
`artifacts/phase22/typescript-correction/`, `workspaces/`,
`shared-containment/`, `containment-conditions/`, `description-poisoning/`.

Preserved verified behavior and limits:

1. TypeScript coordinates use exact retained UTF-8 Semgrep/source snapshots.
   LF/CRLF and Unicode regressions cover imported bindings/findings/locations.
   Windows-compatible temp files and explicit encodings remain. PR #24 hosted
   checks passed, including Windows Python 3.10–3.13, at that historical source.
2. Workspaces: strict-JSON diagnostics restored without weakening parsing; four
   loopback tests passed with socket permission. Corrected deterministic runs
   completed 45/45 twice with matching stable results. Older 41/45 repeat and
   failures remain explicitly incomplete and preserved; archive hashes retain
   raw measurements.
3. Shared containment distinguishes genuine injected SDK Context from caller
   input, fake/rebound aliases and impersonating modules. Bounded local factories,
   inherited methods and replacement remain conservative around custom
   constructors/decorators/unknown state. Preserve PR #23's narrow claim: four
   vulnerable Git inputs and four fixed partners. Two earlier 45-input shared-flow
   runs had no finding changes relative to workspace source; they did not show
   new recall.
4. Filesystem: shared TS collection/normalization/closure/component/physical-parent
   flow; inaccessible inherited compiler config disclosed without reading outside
   the boundary. Four exposed inputs completed, two vulnerable condition hits,
   zero fixed condition-matched alerts. Eight unrelated fixed candidates separately
   source-reviewed with uncertainty. Full suite at that source: 798 passed,
   36 skipped, 86.88% coverage.
5. SENT-013 default detector `src/sentinel/static/rules/sent013.py`: imported/static
   metadata, low-level list-tool descriptions, parameter descriptions, ANSI/
   invisible Unicode, negative controls. Five approved development inputs
   completed offline: two vulnerable condition hits, zero named-condition alerts
   on two fixed partners and one safe control. `safe_calculator` shares a snapshot
   with a separate poisoned tool: the unrelated poisoned-tool alert is NOT a
   safe-condition false alarm. Twenty-five synthetic credential candidates and
   that unrelated poisoning candidate were separately reviewed; credential validity
   was not tested. Full suite at `fe40322`: 823 passed, 36 skipped, 86.74%.
   This is not fresh holdout, reviewed retention or runtime proof.

Original report/review preservation: `229d50e`; optional archive
`/private/tmp/phase22-report-preserved-20260907.tar.gz`. Incorporated into history;
do not discard it or treat it as finished.

## 5. Integration commits already present — inspect before extending

Earlier integration commits retained:

- `37f2190`: typed-pattern runtime binding identity; fixes the original unrelated
  and replaced TypeScript SENT-014 guard failures.
- `855a95d`: lexical/nested/returned Python handlers, mutable argv, selector
  rejection, list allocation/copy and branch controls.
- `dde2d49`: source-established wrapper/dataclass callback registration,
  `registration_flow.py`, unresolved bindings/deadline behavior.
- `ab4834b`: preserve caller evidence locations; draft Finding/report schemas;
  actual supplied cross-file review blocks.
- `192296d`: selector/token/member guards, SENT-014 CLI contracts/docs.
- `355f0f7`: conditional tests no longer contaminate returned argument values.
- `da52eb3`: multiline secret redaction preserves LF/CRLF/CR source-line identity;
  unchanged single-line redaction retains previous output.
- `d3fcf79`: initial default SENT-015 Python/TS URL/request flows and destination
  checks, CLI/catalog/docs integration.
- `dbb2464`: standard JSON containers remain one fixed-prefix argv token; custom
  encoders/scalars/reassignment stay conservative.
- `536bb69`: fixed public authority plus caller path suffix distinguished from
  caller-controlled authority.
- `be2d058`: evidence batch 1 and explicit remaining gates.
- `86ac2dd`: error/None-returning validators protect only when their result is
  enforced on the actual requested URL.
- `6d9bee9`: shared Python HTTP discovery/direct HTTP credential fallback.
- `e2b0346`: Python member/alias/helper mutations, dict spread/copy/update,
  branch state and optional guarded values.
- `e1b23b8`: authoritative amended shared HTTP SENT-015 entries; FastAPI-injected
  dependencies excluded from ordinary caller arguments.
- `d259126`: dataclass callbacks, bound receivers/lambdas; custom constructors,
  decorated/replaced guards remain unresolved.
- `aaa759a`: profile-driven immutable discovery/caller caching and selective HTTP
  scope inspection; fixes SSRF helper tuple generic annotation.
- `de1af5a`: genuine SDK HTTP request getter vs stdio/local SDK impersonation;
  SENT-016 CLI contracts.
- `b6cf0d1`: evidence batches 2/3.
- `83c9985`: computed record/member selectors, dataclass defaults, known kwargs;
  unsupported layouts remain unresolved.

Commits since the older constructor handoff:

- `fec9215`: finishes bounded constructor/escape work; real read-only builtin/dict
  inspections, constructor reflection controls. 253 focused regressions.
- `3f75327`: implements ordered bounded runtime attempts, campaign settings,
  schema 1.7 linkage/counts, consumers, migration and repeated proof preservation.
- `a9c097e`: corrects orchestration test fixtures whose fabricated proof violated
  the stronger report validator; 56 affected checks pass.
- `9d396a4`: registered lifespan/mount-to-context flow; optional records, real `id`
  inspection and constructor fields; 266 focused checks.
- `400659e`: seals evidence batch 4, including retained failed milestone.
- `c71e43e`: bounded C3 mixin initializer resolution, genuine Protocol bases,
  exact positional/keyword forwarding including present nullable keywords,
  descriptors and source-established record truth; 280 focused checks.
- `1abade5`: measured repeated default-allocation correction in merges and initial
  no-command-syntax precheck; no detector disabling.
- `a2b88f1`: genuine external `atlassian.Jira`/`Confluence` token/password sinks;
  no inference from URL/username, local impersonation, rebound/shadowed bindings.
- `cc283a1`: command precheck follows included import closure from registrations/
  handlers/lifespans, including relative imports, re-exports/cycles/ambiguity.
- `ee6c9f5`: URL facts reuse actual evaluated expressions, avoiding repeated
  validator side effects; 301 focused checks plus style/type checks.
- `4d88844`: genuine bounded `dataclasses.replace`, shallow member aliases,
  read-only type checks and known literal selector branches; predicates keep
  distinct identity and branch guard snapshots; 314 focused checks.
- `752e910`: evidence batch 5 and incomplete-condition documentation.
- `f12e891`: real dataclass class/MRO `isinstance` truth, conservative custom
  metaclasses; 316 focused checks; fixed-source full milestone below.
- `1d83b9c51c48e5166e90b7316bdcf97887f80702`: shared explicit TypeScript HTTP
  registration, direct credential/URL flow and impossible-branch corrections.
- `5065f160f39f6bf6b356c6d9173177e94f69d58a`: shared TS shell execution through
  imported helpers and SDK low-level dispatch; command meaning preserved.
- `1eead8f006f0fc2e5cc96efdc8d7da9ac9ebbf5a`: evidence batch 6/status update.

Further local integration commits, oldest first (inspect actual changes; commit
titles do not establish condition completion):

- `96712f3`: Preserve factory registration origins and successful helper guards.
- `4dfd24c`: Trace configured workbook paths and distinguish lexical output guards.
- `45ea165`: Preserve fixed URL authority and reject replaced launch assumptions.
- `2a332f2`: Retain enforced guards on returned TypeScript status fields.
- `9bf74b0`: Retain fixed-source containment milestone and continuation evidence.
- `80bd278`: Trace directory fallback loops and retain initial path preconditions.
- `ecdf579`: Preserve exact source lines for manifest review contexts.
- `4dcf658`: Retain bounded Git campaigns and review source evidence.
- `d26bd62`: Track branch-selected operator credentials without leaking control facts.
- `9b3d4b8`: Reuse unchanged flow state and preserve ordinary helper truth.
- `156ee17`: Preserve presence checks and reduce repeated static lookup work.
- `e2b6345`: Carry reachable helper state and preserve assignment receivers.
- `1aef24c`: Seal auth flow corrections and incomplete measurement evidence.
- `a3a11f5`: Report distinct source limitations without repeated flow warnings.
- `b5a565d`: Skip impossible conditional-expression branches in Python flow.
- `5ac300e`: Retain enforced literal choices across Python helper branches.
- `7734643`: Separate assigned field presence from uncertain field values.
- `34220b7`: Keep declared record fields stable across repeated lifespan analysis.
- `2066ca7`: Follow TypeScript class receivers and evaluate calls once.
- `9f0e777`: Seal authentication condition and TypeScript receiver evidence.
- `b51aee1`: Track ordered TypeScript arguments and recording output containment.
- `761b9c2`: Seal native mobile recording condition evidence.
- `7ab3214`: Share HTTP client identity and preserve request evaluation order.
- `10cc14c`: Follow source-defined tool decorators and captured callbacks.
- `49f36ce`: Track request-local Python context variables and reset tokens.
- `bfc6a7c`: Follow current Atlassian service URLs at supported requests.
- `43f5c96`: Seal Python context and service request evidence.
- `1352a9e`: Preserve current HTTP request state across included helpers.
- `20e5d85`: Connect source-established ASGI middleware to HTTP tool state.
- `3a2a276`: Reuse immutable application and mount metadata across tool analysis.
- `a25c864`: Seal middleware integration diagnostics and regression evidence.
- `f577204`: Interpret nested source decorators with distinct closure identities.
- `af67e21`: Preserve source-constructed services in HTTP request state.
- `18e385f`: Preserve alternative service fields and validated URL authority.
- `fe11d74`: Seal completed native outcomes and service-flow evidence batch 14.
- `247f960`: Propagate helper guard facts in one environment pass.
- `d4228fe`: Reuse bounded startup and HTTP state with independent handler copies.
- `7daa9c6`: Skip leaf values during helper state traversal.
- `2a18d13`: Use bounded Semgrep workers and retain performance and replay audits.
- `77825e4`: Run Semgrep inside the selected root to avoid per-file discovery processes.
- `020cde8`: Cache immutable class lookups and avoid repeated member-key hashing.

Do not treat the old assertion “ProbeCampaign.bindings is still rule-keyed” as
current. It is now a tuple of ordered bindings. The coordinated migration needs
final audit/measurement, not recreation from an obsolete architectural summary.

## 6. Source-specific verification milestones and caveats

- `192296d`: 891 passed, 36 skipped, 86.84% branch coverage. Audit, lock, notices,
  generated artifacts, strict docs and sdist/wheel build passed at recorded sources.
- `d259126`: 1010 passed, 36 skipped, 87.38% branch coverage, 819.19s. Ruff,
  formatting, schemas, docs, generated artifacts, notices and permitted lock check
  passed. Whole-project mypy initially failed on the SSRF tuple annotation.
- `aaa759a`: annotation corrected; recorded whole-project mypy passes; 195
  affected regressions/Ruff/format pass.
- `de1af5a`: 201 affected regressions, three new-rule CLI contract cases,
  whole-project mypy, corrected Ruff/format pass.
- `83c9985`: 237 focused regressions and style/type checks pass.
- Original dirty constructor work: 243 focused passes at its retained patch;
  superseded by `fec9215` with 253 focused passes and completed checks.
- `campaign-milestone-suite`: **FAILED**, 1073 passed, 36 skipped, two fake-proof
  orchestration failures. Later source edits overlapped it; the reported 84.49%
  coverage read changed source and included unexecuted lifespan code. It is NOT
  clean fixed-revision coverage evidence. Preserve failure/correction records.
- **`f12e891478f424d07853748fd7eb9314d6b357bf` fixed detached checkout:**
  **1138 passed, 36 skipped, 87.94% branch coverage, 927.50 seconds**.
  `service-milestone-fixed-suite` records exact source/imports and empty final diff.
  Coverage database: `service-milestone-f12.coverage`; export:
  `service-milestone-coverage.json`; original database remains in fixed checkout.
  Export paths reference the fixed checkout. This pass covers that source only,
  NOT later TS HTTP/shell or subsequent integration changes.
- `1d83b9c`: 235 affected regressions, Ruff/format/strict mypy pass at retained
  patch. Six/14/21 earlier TS controls are narrower milestones. A valid prior
  source counterexample is `typescript-http-f12-counterexample` (exit 1).
  Initial wrong-manifest fixtures classified as Python do NOT establish TS
  behavior; retain them as failed/inapplicable attempts.
- `5065f16`: five new shell controls pass; 220 compatibility regressions pass
  (`cross-file-shell-compatibility`, 293.23s); Ruff/format/mypy pass. Last edits
  before commit only reflowed source/tests and updated docs. Exact measured patch
  remains in each record; do not silently attach results to different bytes.
- Batch-6 strict docs first failed on denied uv cache access; permitted rerun
  `evidence-v6-docs-permitted` passed. Both logs remain. This occurred after sealing
  v6 and is included in the new handoff recovery archive, not retroactively in v6.

Newer verified milestones:

- `4dfd24c2654dffbd9cd92850179ff3493bf08b97`: **1215 passed, 36 skipped,
  88.27% branch coverage**. Source/test bytes were held fixed during the full
  milestone; retained coverage/database identities are in batch 7. Schema/notices
  also passed. This is NOT a full-suite pass for the later 020cde8 source.
- `34220b7`: 425 affected regressions plus type/style checks; real auth condition
  evidence is separately described below.
- `2066ca7`: 366 TS affected regressions; first run overlapped formatting.
  `typescript-class-format-equivalence.json` verifies identical ASTs for all
  five changed scanner files and the test, while retaining both byte versions.
- `20e5d85`: 606 affected tests after a retained 601-pass/one-failure optional
  member bug; strict mypy/style checks passed at recorded sources.
- `f577204`: 610 affected passes; `af67e21`: 616 affected passes;
  `18e385f`: 550 affected + 79 shared tests, with strict mypy/style checks.
- `7daa9c6`: 631 affected passes in 64.27s, strict mypy/style checks.
- Latest `continuation-class-metadata-shared`: **632 passed in 58.24s**, exit 0.
  The recorded base is `77825e4` plus tracked patch SHA
  `adda85e265f5e9173818f508e67db08037fc6b7de6a753992ff5785f10d4088a`.
  At handoff, its patch was compared byte-for-byte with `git diff 77825e4 020cde8`
  and matched exactly. Ruff and formatting check records use the same patch.
  `continuation-class-metadata-types` passed on an earlier pre-format patch
  (`9be59553de9c0d555011c80c8cc575e870b63cf4267809b02c6f04444eab57e9`);
  do not silently present that earlier patch as exact final-source mypy evidence.
- Latest full-input command `continuation-upload-fixed-metadata` completed on
  clean `020cde8`; its result and timing limits are below. Harness exit 0 alone
  is not condition acceptance.

Original SENT-014 command:
`pytest tests/test_command_options.py tests/test_typescript_discovery.py --no-cov -q`.
Its two unrelated/replaced-guard failures were reproduced and fixed in `37f2190`.
Preserve them and the root-cause typed binding fix; do not recreate or call all
SENT-014 acceptance complete based on them.

## 7. Current implementation, verified development progress and immediate work

This section supersedes the old dirty-work/missing-condition status. Do not
reimplement these changes or weaken their controls. All results are tied to their
recorded source; they still require final integrated verification.

### A. Preserved registration, workbook and TypeScript class/array work

`96712f3` resolves actual outer wrapper registration origins, SDK-instance unknown
escape invalidation and successful void-helper guard propagation. Preserve
`typescript_registration_flow.py`, exact name/schema/description/callback identity,
real SDK instance checks and Cast runtime value handling. Multiple calls sharing
one inner registerTool statement must retain distinct tool/evidence identities.
Coverage must not double-count the internal SDK call and the outer registration.
The old origin/escape failures and earlier 286-pass partial run remain historical.

`4dfd24c` interprets explicit parameterless FastMCP launch functions and global
configuration assignments with transport source evidence; unresolved launches
retain unconfigured analysis plus warnings. Genuine source-bound openpyxl
workbook loads/saves and enforced realpath/commonpath boolean helpers are covered.
Unknown/replaced workbook receivers and unsafe launch replacement/deletion/escape
remain conservative. Preserve genuine binding checks, not spelling exemptions.

`2066ca7` supports included plain TypeScript classes, real instance/static receivers,
constructor fields, helper writes and branch-local members. Ordinary vs arrow
receivers differ. Replacement/computed writes/deletion/unknown escape invalidate
assumptions. Callee/argument memoization lasts for ONE source call, avoiding
repeated constructor/factory effects across rule delegation.

`b51aee1` adds ordered TS argv with aliases, helper appends, branch layouts and
slice copies. Limits are 32 layouts of 256 positions; unsupported/repeated options,
computed writes and escape must not establish guessed ordering. SENT-014 uses
actual evaluated argv through Node processes and simple-git; short-circuit effects
remain ordered. The mobilecli screenrecord output contract at genuine Node
process sinks requires source-selected executable/argument identity. No arbitrary
list containing a command spelling establishes an executable.

### B. Excel, mobile and Mastra development measurements

- **Excel at `4dfd24c`: five inputs completed, two vulnerable condition hits,
  zero fixed/control condition-matched alerts.** Remote-mode EXCEL_FILES_PATH
  prerequisites are distinct from stdio's intended unrestricted local policy.
  The earlier all-five/18-SENT-012-alert workbook run remains a failed historical
  condition attempt. Preserve source establishment of configured transports and
  all workbook loads/saves; do not infer runtime mode by a function name.
- **Mobile at `b51aee1`: five inputs completed, two vulnerable condition hits,
  each covering both screenshot and recording; zero fixed/control condition
  alerts.** `mobile-recording-b51-development/` retains reports/scoring. Each
  input adds one recording candidate; earlier candidate content is unchanged.
  Fixed/control candidates explicitly concern physical/symlink uncertainty,
  outside the frozen ordinary non-symlink-parent condition. Six physical-gap
  candidates and fifteen unchanged unrelated candidates stay separate. No target
  device/toolchain was executed and Node runtime remains unsupported.
- **Mastra at `80bd278`: five development inputs completed, two vulnerable
  condition hits, zero fixed/control condition alerts.** Evidence:
  `mastra-fallback-loop-continuation/condition-adjudication.json`. The shared flow
  preserves returned `isSecurityViolation` field facts and initial input prefix
  preconditions through fallback. The while-loop model interprets zero or one
  iteration; later loop-carried state remains unresolved. It does not establish
  safety for prefix siblings, symlinks or derived parent paths. Other findings
  remain visible; unrelated-policy review and final evaluation remain required.

Condition scoring must match the frozen prerequisites and actual source/evidence.
Do not relabel a fixed alert as an unrelated physical/nondefault-policy candidate
unless its actual evidence establishes that distinction. These are implementation-
agent source judgments, not independent human acceptance or whole-repo cleanliness.

### C. Atlassian authentication now has an independent development result

At immutable `34220b70640403a5c012a5e15f0c1b38b016e98a`,
`auth-fixed342-development/` records **4/4 completed, two vulnerable condition hits,
zero fixed-condition alerts**. There is no safe input in this historical family.
Native JSON/SARIF validate. All eight fixed nondefault candidates are qualified
by the actual ALLOW_GLOBAL_CRED_FALLBACK path; incidental per-user paths are not
substitutes for the condition. `condition-adjudication.json` retains evidence.

The decisive corrections were reachable member/global state, exact evaluated
assignment receivers, branch-selected operator credentials, source setting/default
facts, presence checks, literal selectors and stable declared fields across repeated
lifespan analyses. The second tool previously made declared fields spuriously
optional; a durable repeated-tool regression catches that failure.

Wall durations were 112.408, 120.065, 121.641 and 117.430 seconds. Reporting follows
the unchanged 120-second STATIC deadline; do not equate total wall >120 with a
static timeout or use that distinction to hide actual timeouts. This source has
no runtime confirmation/final repeat/fresh holdout/reviewed retention/human acceptance.
Session-based client credentials and remaining applicable compatibility still need
audit. Later shared changes require integrated auth remeasurement.

### D. Atlassian SSRF/upload: newest raw outcomes outrun status docs

`7ab3214`, `bfc6a7c`, `1352a9e`, `20e5d85` and later changes connect shared HTTP
client/request identity, actual SDK REST destinations, genuine current request,
source-established ASGI app/middleware ordering and request state to tools.
`f577204` handles nested included source decorators with distinct callable closure
identity and the existing 64-frame bound. `af67e21` retains source-created fetchers
in HTTP state, including genuine known-field setattr. `18e385f` keeps bounded
alternative service fields and checked base authority when appending literal URL
paths; nullable/deleted/replaced/escaped state stays conservative.

Preserve the older `atlassian-asgi-3a2-development/` run: **4/9 complete**, four
SSRF inputs plus five upload timeouts. Fixed SSRF still had a permission-search
candidate at that older source. Later traces alone did not supersede those reports.

**NEWER fixed `77825e4d00d5559144bf1be0087fee329456e1e9`:**
`atlassian-fast-778-development/results.json` and
`continuation-atlassian-fast-nine-native-ready.*` contain the completed nine-input
campaign, **6/9 completed**, harness exit 0, no model calls:

- Upload vulnerable and vulnerable mutation: complete, 98 findings each.
- Upload fixed, fixed mutation and download-path safe: INCOMPLETE, actual
  120-second static deadline failures.
- All four SSRF inputs: complete, approximately 60.8–65.8 seconds total each.
- Both vulnerable SSRF reports have three SENT-015 request locations:
  `jira/client.py:184`, `jira/users.py:62`, `jira/users.py:208–214`.
- Both fixed SSRF reports have ZERO SENT-015. All four retain an unrelated
  SENT-012 attachment candidate and other rule candidates.
- This promising new distinction still needs frozen-condition adjudication and
  changed/unrelated-candidate review. Rule counts alone do not complete a gate.

Driver is `/private/tmp/phase22-atlassian-fast-native.py`, with fixed checkout
`/private/tmp/mcp-phase22-fast-static`. The first command launched before that
checkout was ready and failed; the `-ready` command is the measured run. Read the
actual retained script and records; do not invent a `-nine-native.py` script name.

**LATEST clean `020cde82dbe39d49f79187a3bfbac20d5f70f3e3`:**
`upload-fixed-metadata/results.json` and `continuation-upload-fixed-metadata.*`
record the original upload FIXED input as completed, 96 findings, exit 0, 123.271s
total including reporting. The diagnostic wrapper timed existing scanner functions
without executing target code. SENT-012 32.704s, SENT-015 41.409s, SENT-016 37.278s;
Semgrep 2.325s. Driver: `/private/tmp/phase22-upload-fixed-metadata.py`.

Only that one upload input has been remeasured at 020cde8. Do NOT claim the safe
control/fixed mutation completed, the full upload family passes, or all 96 findings
are condition-correct. Finish native measurements and condition adjudication for
all five upload inputs, retaining both vulnerable/fixed structural mutations and
safe control. Validate real HTTP service-factory/open relationships, not just
stdio traces. Then reverify affected SSRF/auth paths on the final source.

### E. Profile-driven performance work: preserve semantics and hard deadline

Recent work removes measured repeated helper/metadata overhead:

- `247f960`: propagate guard facts in one environment pass.
- `d4228fe`: reuse bounded startup records/prepared HTTP state with independent
  per-handler copies; exclude callable/workbook/argument-tuple state and explicit
  launch states from unsupported reuse. Preserve mutation/isolation controls.
- `7daa9c6`: skip scalar leaves without reachable member/alias/tuple/closure/
  receiver/unknown-member state during traversal.
- Semgrep worker experiment was reverted after it failed to solve the deadline.
  Read actual final code, not the `2a18d13` title as an adopted-worker claim.
- `77825e4`: run Semgrep in the already validated scan root. Pinned Semgrep 1.176.0
  had performed per-file discovery for explicit paths outside subprocess CWD.
  Isolated work drops from about 26s to 2.56s with the same 312 selected files and
  35 canonical rule/location/snippet/capture records. Relative results resolve
  against the new CWD; absolute/relative/escaping-path controls remain enforced.
  The first comparison incorrectly compared CWD-dependent internal check_id
  prefixes; failure and corrected canonical comparison are both retained.
- `020cde8`: immutable class-lookup caching and avoiding repeated member-key hashing.
  Latest 632-test patch exactly matches the committed change, as recorded above.

No detector is disabled; no relevant source is excluded; deadline is still 120s.
Further optimization requires real profiles, unchanged-source/result comparisons
and cache mutation/deadline controls. Diagnostic inclusive nested times are not
additive throughput and concurrent verification is not an isolated benchmark.

### F. Meta operator fallback remains the principal unresolved real boundary

These are approved Phase 22 DEVELOPMENT sources, not Phase 20 or fresh holdout.
`continuation-meta-development-source-identity` verifies 106 vulnerable and 108
fixed projected files. The first wrong-manifest identity script selected zero
inputs; preserve it without treating it as validation.

Included `meta_api_tool` source decorators now lead through
`get_current_access_token`, carrying operator META_ACCESS_TOKEN into get_ad_accounts
and make_api_request. Genuine request-local ContextVars support allocation/default,
set and matching single-use reset tokens across included helpers; handler requests
remain isolated. Unknown/escaped/replaced/reused operations, manual context switches
and spawned tasks remain unresolved. Preserve all negative tests.

The retained actual Meta trace still has 41 tools, no established HTTP entries and
two unresolved launches. No HTTP caller-to-operator SENT-016 condition is established.
Complete actual source-selected HTTP launch, middleware attachment/patch/provider
relationships, ContextVar caller state and fixed rejection BEFORE continuation.
The shared explicit ASGI middleware support does not automatically model Meta's
dynamic provider patches or BaseHTTPMiddleware dispatch. Establish required bounded
source relationships conservatively; names/annotations/nearby checks are not proof.
Measure all five approved development inputs with paired mutations and safe control.
Do not spend the entire continuation on synthetic ContextVar/decorator cases.

### G. Git campaigns, candidate context and replay: progress with exact limits

`git-campaigns-80bd278/results.json` records all 13 eligible Git inputs in the
approved separate mcp==1.29.0 environment. Each planned 80 attempts, started/tested
24, retained 56 unstarted, returned exit 3 and passed cleanup. One compatible
fixed-source campaign was reused; twelve were run sequentially. No model calls.
This is measured bounded incomplete coverage, not 80 tested attempts or defense.

`git-native-80bd278/` additionally runs the staging vulnerable input through the
production orchestrator with explicit degraded review, no API key and cache off.
Native JSON/SARIF validate; console says INCOMPLETE and exit remains 3. Final-source
compatibility/reverification and all campaign acceptance behaviors remain required.

`ecdf579` fixes manifest context parsing, fabricated out-of-range primary windows
and Unicode separator line drift; 92 affected review/campaign/report tests pass.
The 160-total-source-line budget, boundary checks and proof blocks remain.
`historical-request-compatibility-v2.json` reproduces ALL 35 frozen historical
prepared requests exactly and validates captures via checked ledger/hash transport
and response validation with zero model calls. Initial diagnostic found only the
original 17 captures and wrongly called 18 changed; corrected completion-v2 lookup
retains both attempts. This does NOT rebuild current detector candidates/context,
identify final affected requests, or establish current reviewed retention.

Meta image's five-input composition repeat preserves two vulnerable condition hits
and zero fixed/control condition alerts. Of 240 earlier unrelated instances, 20
fixed-authority false alarms were corrected; 220 remain source-reviewed uncertain
framework/schema/resource/operator-policy cases in the v2 adjudication. This is
not independent acceptance. Finish all later changed/unrelated findings, keeping
the historical 70-warning backlog explicitly unchanged and unadjudicated.

### H. Remaining work is a complete acceptance task, not just remaining code

Use all 86 requirement rows and the full contracts below. Current checklist/docs
can lag finished commands; reconcile against actual source/report identities.
The newest native outcomes above supersede stale claims that those runs are still
running. No final 45-input repeat pair, fresh holdout, pinned comparator, final
candidate review-request preparation, final full quality/hosted matrix or consolidated
draft exists. No paid packet is ready. Finish every independent authorized part.

## 8. Required source paths and preserved earlier diagnostic history

Current statuses are in section 7. The earlier measurements below remain retained
history; do not mistake superseded misses for instructions to restart completed work.
Authorized exposed sources live under `/private/tmp/phase22-development`.
Recover missing inputs through validated corpus infrastructure; never import or
execute target modules. Old Phase 20 `held_out` labels were already exposed and
are authorized development inputs. Fresh Phase 22 holdout source remains unopened
for tuning; that separation must be preserved.

### A. Atlassian authentication

Use the complete source directory:
`/private/tmp/phase22-development/atlassian-auth-full-vulnerable`.
Tree SHA-256:
`afd629310b07685052de0f3479be57da6e5c5fd5d1f692f1cfae90f6cf49f930`.
The older `atlassian-auth-vulnerable` directory may be partial; do not treat it
as a full benchmark input.

Frozen condition: unauthorized HTTP fallback to operator-global Jira/Confluence
credentials, not every auth-related change in the upstream patch.
Prerequisites: HTTP MCP operation; global credentials configured; no caller
credential; `ALLOW_GLOBAL_CRED_FALLBACK` unset; relevant OAuth proxy/ignore-header
overrides disabled.

Required real relationships:

- `servers/dependencies.py`: `_ServiceSpec`, `_jira_spec`, `_confluence_spec`,
  `_get_fetcher`. Genuine SDK HTTP request, request state, per-user auth paths,
  fallthrough to lifespan configuration and `spec.fetcher_class(config=config)`.
- Fixed source tracks HTTP context and rejects global fallback unless the explicit
  flag enables it. Missing Authorization in vulnerable middleware can continue.
- `_get_app_lifespan_ctx` reads genuine SDK
  `Context.request_context.lifespan_context.app_lifespan_context`.
- `main_lifespan` constructs environment-derived JiraConfig/ConfluenceConfig,
  MainAppContext, and yields application context. AtlassianMCP receives the
  lifespan and mounts child servers. All 90 tools were linked in retained diagnostics.
- HTTP app installs UserTokenMiddleware; state writes and enforced auth errors
  must be connected to actual tool continuation. Middleware names/annotations
  are not proof.
- `JiraConfig.from_env` establishes operator origin. `JiraFetcher` inherits
  JiraClient through mixins. JiraClient carries config into actual external
  `atlassian.Jira` token/password/session arguments.
- Per-user config uses `dataclasses.replace`, optional OAuth/PAT/basic fields and
  real class tests. Do not mistake incidental per-user client candidates for the
  missing-caller/global-fallback condition.

Measured history:

- At `d259126`, first profile timed out at 120s; harness zero, INPUT INCOMPLETE.
- At `aaa759a`, repeated instrumented run completed: 84.2s static, 93.2s including
  reporting, 90 SENT-003 + one SENT-012, ZERO SENT-016 condition hits.
- Post-constructor `fec9215` exposed run completed at 79.765s reported scan time,
  again 91 unrelated findings and zero condition hits; overlapping non-static
  edits disclosed, not isolated throughput.
- `c71e43e` and later service runs timed out. `ee6c9f5` instrumented stages:
  SENT-012 44.652s, SENT-014 1.390s, SENT-015 40.371s, then deadline before
  SENT-016 finishes. Preserve all incomplete reports.
- `f12e891` single-tool diagnostics reduced four incidental client candidates to
  two OAuth/PAT candidates; these do NOT establish the frozen condition. No
  complete full-auth condition measurement existed at that older handoff. Section 7
  records the subsequent four-input condition result at 34220b7.
- Profiling justified merge allocation correction, import-aware command precheck
  and avoiding repeated URL expression interpretation. One URL single-tool profile
  fell from ~83 million calls/23.302s to ~5.8 million/1.738s. These are diagnostic
  timings, not isolated throughput or condition scores.

Keep 120s. No deadline increase, detector disabling or relevant-source exclusion.
Do not add optimization without profiling actual repeated work.

### B. Atlassian SSRF/upload

SSRF vulnerable/fixed revisions differ from auth. Fixed validators can return
error/None; middleware must enforce that result on the actual requested service
URL before storage/use. DNS rebinding is outside the claim.
Upload requires actual Python service-factory/input/guard/sink support.
At `f12e891`, both original SSRF inputs completed (~103.525/101.799s) with 63
SENT-003 + four incidental SENT-016 and **zero SENT-015**. The credential candidates
are unrelated to SSRF and need adjudication. Both original upload inputs timed out.

### C. Meta operator fallback

Real HTTP authentication integration uses ContextVars and bounded wrapper/patch
relationships around `get_current_access_token`. Missing caller auth can select
operator `META_ACCESS_TOKEN`. Fixed source rejects relevant missing/wrong auth
before continuing. Establish caller-to-tool/operator relationships and actual
enforcement; nearby checks cannot exempt them. This remains incomplete.

### D. dbt

Nested factory tool definitions and mutable command lists are partly supported.
Preserve actual `node_selection` flow and working development condition while
finishing shared-flow/command semantics; an argv list or `--select` alone does
not protect against extra options.

### E. Mobile output

Materialized originals:
`/private/tmp/phase22-development/mobile-output-vulnerable` and `mobile-output-fixed`.

Frozen condition: on Linux, screenshot/recording output cannot write outside both
`process.cwd()` and `os.tmpdir()` using an ordinary non-symlink parent.
Prerequisites include functioning device/toolchain, supported extension, existing
output parent outside both roots. Node runtime is unsupported by the current
Docker target tier; do not execute mobile tools on host.

`src/server.ts` exports `createMcpServer`, constructs real McpServer, and defines
a local `tool(name,title,description,schema,annotations,cb)` wrapper. It registers
a cast async callback which calls `cb(args)`. Screenshot callback writes caller
`saveTo` through `fs.writeFileSync`; recording passes `outputPath` into a supported
device/tool command. The later source-selected recording sink support and its
five-input measurement are recorded in section 7; preserve those controls.

Fixed `src/utils.ts`:

- `getAllowedRoots`: tmpdir/cwd, Darwin additions, `path.resolve` mapping.
- `isPathUnderRoot`: `path.relative`, rejection of empty/absolute/`..`, success flag.
- `resolveWithSymlinks`: resolve path, physical parent via realpath, basename/join;
  catch returns the resolved path.
- `validateOutputPath`: collection `.some`, platform-dependent lowercasing,
  custom helper enforcement, throw when not allowed.
- Screenshot enforces extension/output validators before the write.

`mobile-development-wrapper/`: 5/5 complete, still missed condition before cast fix.
`mobile-development-cast/`: original pair **2/2 complete**, four findings each:
one SENT-005, two SENT-006, one SENT-012 screenshot candidate. Vulnerable candidate
is `src/server.ts:591`; fixed still alerts at that old source. That run was NOT a
passing pair and did not remeasure mutations/control after the cast correction.
Recording and fixed-validator handling were open then; the later five-input
result at b51aee1 is recorded in section 7.

### F. Kubernetes shell — development condition now measured

`5065f16` adds shared ShellFlow alongside retained legacy execution support.
It follows low-level SDK request dispatch and imported helpers, actual source
aliases/re-exports, reassignment and parser-lowered `+=`. No new parser was needed:
installed Semgrep emits augmented assignment as Assign + Plus.

`exec`/`execSync` are shell sinks. Added `execFile`/`spawn` paths require established
`shell: true`; separate argv alone is not a shell-injection finding. Preserve
existing other SENT-002 execution/deserialization meaning and SENT-014 separation.
Source binding/unknown shell option forms still require complete contract audit.

`kubernetes-development-shared/`: five approved inputs completed, 24 findings on
each vulnerable variant and seven on each fixed variant/control. One named
`kubectl_get` SENT-002 hit in each vulnerable variant; zero named-condition alerts
on fixed/fixed mutation/safe. Dispatch in `src/index.ts` passes actual
`request.params.arguments` to `kubectlGet`; caller fields concatenate into
`command` then `execSync` at `src/tools/kubectl-get.ts:143`. Fixed uses fixed
`execFileSync` executable and separate argv. Mutation aliases the import as
`runKubectlProcess` without changing semantics.

Scoring: `kubernetes-development-shared/condition-adjudication.json`.
First scorer failed by expecting original spelling in the alias mutation; corrected
scorer validates actual import/source. Both attempts retained.
Thirty-two new unrelated shell candidates were source-reviewed: 30 supported static
candidates, two uncertain context-selection instances. No runtime confirmation or
independent human acceptance. Existing SENT-006/SENT-012 candidates stay separate.
This is development evidence, not final historical repeat, holdout or runtime proof.

### G. Eighteen-input fixed-source development gap measurement

`exposed-pairs-f12/` used the detached `f12e891` scanner/harness and original
vulnerable/fixed inputs for all families except atlassian-auth.
**16 complete, two upload timeouts.** It is not the final 45-input repeat and
includes no paired mutations/control/Phase 22 holdout.

Observed counts/locations, NOT condition adjudication by rule/line alone:

- git-staging vulnerable: 10 SENT-003, SENT-012 server.py:135, SENT-014:152/266.
  Fixed: 10 SENT-003, SENT-014:136/153/267, no SENT-012.
- git-arguments vulnerable: 10 SENT-003, SENT-012:129/353,
  SENT-014:119/146/182/234. Fixed: 10 SENT-003, SENT-012:134/363,
  SENT-014:151/244.
- git-repository vulnerable: 10 SENT-003, SENT-012:134/363, SENT-014:151/244.
  Fixed: 10 SENT-003, SENT-012:134, SENT-014:151/265.
  Git paths are `src/mcp_server_git/server.py`.
- filesystem vulnerable: twelve SENT-012 locations in index.ts
  204/268/334/360/405/594/609/628/652/664/679/753.
  Fixed: four at 354/358/667/671; prior unrelated fixed candidates exist. Do not
  assume those four are named-condition false alarms.
- Atlassian SSRF: misses described above; both upload inputs incomplete.
- Excel original pair: seven SENT-003 each, no SENT-012 at this older source.
- Mobile original pair: two SENT-006 + one SENT-005 each, no SENT-012.
- Kubernetes original pair: four SENT-006 + three SENT-012 each, no SENT-002;
  later `5065f16` development measurement supersedes this execution miss only.

Git/filesystem condition scoring and incidental-candidate adjudication remain
open for this run. Concurrent verification timing is not isolated throughput.

## 9. Complete all five compatibility areas and containment requirements

Required areas, all authorized:

1. Imported handlers and schemas.
2. Local imports, aliases/re-exports, statically bound helpers and methods.
3. Cross-file caller input, enforced validation and sink relationships.
4. Required low-level SDK registration and dispatch forms.
5. Declared Python/TypeScript workspaces.

Feed relevant detectors through shared support. Inventory recognition alone is
not detector support. Complete imported schemas/aliases, source-established
factory-returned objects and bound methods, cross-file caller/guard/sink identity,
genuine injected SDK Context vs fake/rebound/caller/local impersonation,
Atlassian upload/service factories, TypeScript custom normalization and component-
safe prefixes, Mastra security-failure return flags/fallbacks, and filesystem,
Atlassian, Excel and mobile containment conditions.

Durable regressions BEFORE fixes must cover traversal, absolute paths, prefix
collisions, applicable symlinks, unrelated/discarded validation, replaced values,
vulnerable/fixed structural mutations and ambiguous/dynamic/unsupported bindings.
Never infer an implementation/authorization boundary from return annotations,
validator names, nearby middleware or unsuccessful exploitation.

Workspace acceptance must include uv/npm/pnpm membership/exclusions, local package
exports, TS aliases/inherited local compiler settings, structured per-member
coverage, inaccessible/unsupported members, no nested config application during
aggregate scans, consistent discovered-file/surface counts without double-counting
shared files, ambiguous resolution/dynamic imports/reflection/unsupported schemas,
repository escapes/symlinks, aggregate-root vs individual-package configuration,
and dynamic scans requiring selection of one Python package.

Recognized Helm templates retain original bytes for text/secret scanning and
explicitly disclose omission of structured YAML analysis. Ordinary YAML and
Sentinel configuration remain strict. Static deadline remains 120 seconds/input.

Shared Python support already includes allocated mappings/records and members,
alias/helper mutations, ordered spread/copy/dict/update and dynamic keys,
optional/default values without contaminating guarded members, bound callbacks,
lambdas/closures, dataclass defaults/known keyword expansion, caller/operator/
fallback distinctions, containment/command/URL guard properties, bounded source
initializers/mixins, replacement invalidation, registered lifespans and exact class
tests. Reuse it; preserve branch isolation and exact binding/value identity.

Constructor work must stay conservative for custom hooks/decorators, reflection,
`__dict__`/`__class__`, computed getattr/vars/setattr and unknown mutation. Real
builtin/dict inspection controls were fixed in `fec9215`; do not restore blanket
invalidation or whitelist functions by spelling. Broader inherited/descriptor/
receiver conventions must be investigated against current code, not assumed solved.

## 10. Complete every rule contract and named condition

All ten historical families are REQUIRED:
`atlassian-auth`, `atlassian-ssrf`, `atlassian-upload`, `excel-boundary`,
`filesystem-prefix`, `git-arguments`, `git-repository`, `git-staging`,
`kubernetes-shell`, `mobile-output`.

Stable contracts:

- SENT-012: path containment failure; High impact / ASI02.
- SENT-013: explicit tool-description poisoning; High impact / ASI01.
- SENT-014: command-option injection; Critical impact / ASI05.
- SENT-015: SSRF; High impact / ASI02.
- SENT-016: unauthorized caller-to-operator credential fallback; High / ASI03.
- SENT-002: Kubernetes shell injection under its existing execution meaning.

Preserve impact vs calculated severity: High impact plus theoretical likelihood
currently produces initial Medium severity.

SENT-013 must detect explicit overrides, secret exfiltration and cross-tool
redirection in recoverable tool/parameter descriptions, with benign instructions
and quoted warnings as controls. Finish discovery, holdout and reviewed retention.

SENT-014 must follow caller Git refs into unsafe option positions, recognize
enforced rejection and command-specific handling, reject terminators placed after
the unsafe argument, avoid treating argv lists as protection or every command as
having identical terminators, distinguish Git object APIs from raw option positions,
follow helpers/reassignment, cover applicable Python/TS controls, and retain the
actual approved dbt `node_selection`/`--select` path. Synthetic controls alone do
not establish independent condition gates.

SENT-015 must follow actual caller URLs into requests, detect prohibited schemes
and literal private/loopback destinations, recognize enforced protection of the
requested value, and preserve fixed public authority plus caller path suffix.
DNS rebinding is outside the claim; do not overstate redirects/DNS coverage.

SENT-016 must establish unauthorized caller/operator authority crossing, not
ordinary stdio owner credentials or nearby unrelated checks. Complete applicable
Python/TS and real client/middleware/service/lifecycle paths. Current committed
direct TS support is limited to explicit module-level Express routes, imported
handlers/re-exports, global fetch/node-fetch/undici.fetch credential headers,
unshadowed process.env, OR/nullish/imperative fallback and actual rejection.
The complete applicable factory/middleware/client scope is NOT established by
those direct TypeScript controls. Python ContextVars and shared clients have since
been added, but the actual Meta HTTP boundary is still unresolved as described in
section 7. Source-only SDK getter/client construction support is not condition proof.

Approved Phase 22 development families:

- `mastra-directory-fallback` — SENT-012
- `integsec-calculator-poisoning` — SENT-013
- `dbt-option-selection` — SENT-014
- `meta-image-ssrf` — SENT-015
- `meta-operator-fallback` — SENT-016

Use each frozen condition and prerequisites for scoring. A fixed/safe label covers
the named condition, not every behavior in a repository.

For EVERY rule complete default enablement, stable selection, inline suppression,
baseline identity/behavior, severity behavior, canonical Finding/evidence/
provenance/remediation, OWASP rationale, false-positive and unsupported-scope docs,
applicable Python/TS positive/negative controls, approved development pairs/
mutations/controls and the existing rule-acceptance checklist.

Preserve regressions for helper execution, unrelated validation, authentication
without enforcement, hashing without trusted comparison, source/binding replacement
and all historical safety counterexamples.

At `536bb69`, dbt and Meta image families each completed 5/5 with two vulnerable
condition hits and zero named-condition alerts on fixed/fixed mutation/safe.
These are development results, not holdout. Five unrelated dbt codegen false
positives were corrected; eight unrelated dbt candidates remain source-reviewed
as uncertain. Meta reports have **240 unrelated candidate instances at that earlier source; section 7 records
the subsequent source review, 20 corrections and 220 uncertain cases**. The historical **70-warning backlog remains unadjudicated**.

## 11. Finish candidate-bound review context and capture compatibility

Complete the preserved review changes after detector interfaces stabilize:

- Carry relevant source/guard/sink locations through canonical evidence/provenance.
- Supply primary AND cross-file blocks within **160 SOURCE LINES TOTAL PER
  CANDIDATE**. Deduplicate overlaps and explicitly record omitted context.
- Validate redaction, repo boundaries, symlink rejection and source references
  against the exact supplied blocks.
- Preserve LF/CRLF/CR line identity and original single-line redaction output.
- Preserve request/cache identities when requests are unchanged.
- Determine actual affected requests with compatibility checks; reuse compatible
  captures and prepare replacements only for affected requests.
- Preserve Finding identities, nullable reviews and ALL runtime proof through
  context construction, review and merge.
- Model review remains candidate-bound; no independent AI discovery.

Finish offline context, response-validation, cache-compatibility and proof tests
before requesting paid replacements. A preserved draft or schema literal does not
establish the full report/review contract is integrated or shipped.

## 12. Finish and verify bounded ordered runtime campaigns

`3f75327` implements the main migration. Inspect current code and retain working
fresh baseline/attack/security-condition logic. Do not rebuild the old four-rule
architecture, but audit every required behavior/consumer and close all gaps.

Expand ONLY SENT-008 through SENT-011:

- Enumerate supported probe/tool/argument/mutation combinations from runtime
  discovery, using existing inert mutations and actual schema validation.
- Ordered attempts, multiple attempts per rule; no rule-keyed binding/outcome
  assumptions in scheduling, reporting, observation lookup or other consumers.
- Deterministic rounds across tools; rotate eligible rules/arguments per tool.
- Valid GPT priorities may reorder within a round but cannot remove attempts or
  starve later tools.
- Stable attempt ID derives from probe, tool, argument path and mutation.
- Schema fingerprints are separate drift data, never part of attempt identity.
- No random scan ID, timing or schema fingerprint in attempt identity.

Budgets:

- Default **24 STARTED attempts OR 120 seconds**, whichever first.
- Count an attempt when execution starts, including startup failures.
- Start campaign timing BEFORE runtime discovery, AFTER dependency-image prep.
- Discovery and execution consume campaign budget; cleanup still runs afterward.

Isolation/outcomes:

- Separate fresh baseline and attack containers for EVERY attempt.
- Invalid baseline prevents that attempt's attack.
- Record every planned attempt and ALL unstarted remainder.
- Explicit incomplete discovery, unsupported/inconclusive checks, startup/
  execution failures and interruption.
- Empty/incomplete discovery cannot fabricate attempts or coverage.
- Budget exhaustion with eligible work remaining returns exit **3**.
- Findings require existing observable security conditions. Discovery is not
  exploitation; failed attacks are not proof of defense or false positives.

Positive integer settings, **CLI > environment > file > default**:

- `--max-probe-attempts`, `SENTINEL_MAX_PROBE_ATTEMPTS`,
  `[sandbox].max_probe_attempts`.
- `--campaign-timeout-seconds`, `SENTINEL_CAMPAIGN_TIMEOUT_SECONDS`,
  `[sandbox].campaign_timeout_seconds`.

Rules-only bypasses runtime settings. Verify GitHub Action consumes repository
configuration. Reuse actual sandbox/config/CLI structures.

Durable tests must cover safe alphabetically first tool + vulnerable later tool,
multiple relevant parameters, fair ordering/GPT constraints, attempt/time budget
exhaustion, discovery time, schema drift, invalid baselines, startup failures
counted as started, interruption/cleanup, all unstarted remainder, empty/incomplete
enumeration and preservation of every observable runtime proof.

Inspect `dynamic/prober.py`, `DynamicScanResult.complete`, summary construction,
observation lookup, `src/sentinel/orchestrator.py` failure paths, `dynamic.merge`,
review handling, repeated finding keys and all consumers. Earlier fixture Docker
checks eventually passed with native/SARIF validation after retained socket/daemon/
fixture failures, but **final-source Git campaign verification remains open**. The 13-input
80bd278 campaign and its explicit unstarted remainder are recorded in section 7.

## 13. Complete native schema 1.7.0 and ALL consumers

Treat this as a coordinated migration, already partly implemented:

- Link planned bindings, discovery snapshots, outcomes and proof by attempt ID.
- Multiple attempts under one rule; unique IDs and matching references.
- Validate `tested <= started <= eligible <= planned`.
- Validate started <= attempt budget and remaining eligible = eligible - started.
- Totals must match actual attempt records; unavailable information stays honest.
- Validate structured workspace coverage and its inventory consistency.
- Accept/migrate 1.3, 1.4, 1.5 and 1.6 reports/baselines to explicit LEGACY attempts.
- Unknown historical coverage stays unknown; no invented eligibility/mutations.
- Preserve Finding identities, suppression records, nullable reviews and all proof.
- Repeated attempts merged into findings retain every relevant proof, never
  overwrite by rule ID or same rule/tool/argument finding key.
- Finish console, native JSON, SARIF consumers and offline SARIF 2.1.0 validation.
- Regenerate ALL affected packaged Finding/report schemas.

Update Architecture, native schema/migration docs, rules, compatibility,
configuration examples, onboarding, Action docs and public usage/version references.
Find EVERY old rule-keyed/version consumer across source/tests/scripts/docs, not
only primary JSON models. Current validators are stronger and proof fixtures were
corrected; still verify empty discovery, totals, references, consumer consistency
and final-source migrations. A `1.7.0` literal is not a shipped migration.

## 14. Final offline measurement gates

Reuse `scripts/phase20_measurements.py`, `phase20_scoring.py`, `phase20_corpus.py`,
`phase22_corpus.py`, existing runner/provenance/capture ledger/evidence tooling.
The Phase 22 runner validates authorized rules-only selections, rejects modified
input records and unsupported paid/replay treatments. Extend only as required,
without bypassing authorization/provenance.

Development uses exposed Phase 20 and approved Phase 22 development cases.
Fresh Phase 22 holdout SOURCE stays outside tuning. Hash/archive validation does
not authorize inspecting holdout source for implementation. It has not been opened
or used for tuning in this integration work; preserve that fact.

After implementation stabilizes:

1. Run ALL **45 Phase 20 inputs TWICE deterministically** on the FINAL integrated
   implementation, with the unchanged **120s/input** deadline. Both runs must
   complete; explain differences. Require condition-correct findings on all
   **20 exposed vulnerable inputs** and no condition-matched fixed/safe alerts.
2. Keep correlated variants, support and completion denominators explicit.
3. Evaluate frozen Phase 22 holdout separately, without inventing an accuracy
   threshold. If it informs a fix, mark that case exposed and prepare replacement
   holdout through the freeze process; never quietly reuse it as fresh.
4. Complete all approved development pairs/mutations/controls on the final source.
5. Adjudicate all NEW/CHANGED unrelated findings, including remaining Meta
   uncertainties and later deltas, incidental Atlassian credentials, Excel/mobile
   changes and later integration candidates.
   Keep historical 70 unchanged/unadjudicated. Distinguish implementation-agent
   source review, uncertainty and independent human acceptance.
6. Rerun comparable PINNED Semgrep measurements. Snyk/Cisco comparative performance
   remains unmeasured; do not claim unmeasured superiority.
7. Reverify Helm omissions, strict ordinary YAML/configuration and execution
   performance. Distinguish concurrent latency/profiling from isolated throughput.
8. Integrate the approved separate Git `mcp==1.29.0` environment, retaining exact
   image/dependency/environment identities and Phase 20 originals. Produce
   reproducible Docker startup, discovery and bounded campaign evidence on
   eligible inputs; record exclusions/incomplete/inconclusive outcomes honestly.

A harness exit zero does NOT mean every input completed. Inspect per-input state,
deadlines, report status, condition scoring and denominators. Discovery success
does not establish exploit confirmation.

## 15. Paid checkpoint and reviewed evaluation

No NEW paid calls before explicit approval. After offline gates pass, prepare a
concrete packet containing exact cases AND exact requests, purpose per request,
actual configured model/settings, compatible captures reused, replacements needed,
request/token/dollar ceilings, stopping conditions, bounded failure/retry policy,
and request/source/configuration identities. Inspect actual model configuration;
do not assume it. Do not expose secrets in packets/logs.

Obtain explicit approval for that packet. Continue independent authorized work
while approval is pending. An approval packet is not completed reviewed evaluation.

After approval:

- Compare deterministic and reviewed static tiers on identical inputs.
- Require reviewed completion of all 45 historical inputs and retention of correct
  vulnerable candidates.
- Count needs_review, abstentions and incorrect suppressions explicitly.
- Retain reviewed holdout separately.
- Report recall, false alarms, support/completion denominators, retained findings,
  latency, tokens, compatible cache/capture reuse and actual cost.
- Stop at the approved ceiling or required evidence; no unbounded retry/spend.
- Preserve unaffected captures and label replay evidence.

Do not accidentally trigger paid generation via convenience commands. Distinguish
offline generated/judge artifact checks from live capture/artifact generation.

## 16. Evidence infrastructure and exact reproduction

Owning directory: `artifacts/phase22/integration/`.
Key tracked files: `README.md`, `requirements.md`, `progress.md`,
`dbt-adjudication.json`, `development-conditions.json`, numbered evidence packets.

Sealed committed archives, each lossless and read back against per-file hashes:

- v1: 441 files, source work through `536bb69`.
- v2: 237 files, through `d259126`, excluding then-running second full milestone.
- v3: 111 files, through `de1af5a`, completed second milestone/failures/profile.
- v4: 437 files, campaign/constructor/lifespan work through `9d396a4`, including
  failed/overlapping milestone and Docker corrections; committed in `400659e`.
- v5: 439 files, through `4d88844`, service construction/exact evaluation/record
  corrections and incomplete auth profiles; committed in `752e910`.
- v6: 251 files through `5065f16`, 94,420,419 raw bytes, 2,778,399 compressed;
  fixed `f12e891` full milestone/coverage, 18-input gap measurement, TS HTTP,
  Kubernetes measurement/scoring/failures; committed in `1eead8f`.

Further sealed evidence batches, all manifests recording per-member readback:

- v7: 531 files, through `2a332f2`, archive SHA-256
  `68cdc015de92912b4dd746000f28ca6a5b1521ab9bc4f74d6e78a7ec434837f6`.
- v8: 235 files, through `ecdf579`, archive SHA-256
  `15e833494a8fb0293e8517fad40645e6bc1b42721c5484905ed046a5ca0c3fd8`.
- v9: 485 files, through `e2b6345`, archive SHA-256
  `20a66027e1c736102f8e23149894d8467bcda47b211b923386d32f4c660a378c`.
- v10: 385 files, through `2066ca7`, archive SHA-256
  `d5e418d9b4ac1ef0a3a4cf63673481936336794cbe9f8e3b7ef1a83f9dab3997`.
- v11: 170 files, through `b51aee1`, archive SHA-256
  `9b20ec89321f4e6e763d30ccea59f6d21b13a6ae10f61cb9b99df07c39dac7dc`.
- v12: 293 files, through `bfc6a7c`, archive SHA-256
  `5f48d05b48cf3e33926e83aac6360a0813c3d2cc19e62c414665af38029837db`.
- v13: 313 files, through `3a2a276`, archive SHA-256
  `d2bfffadaf65fd3a3f8438209d0a3b058441665d32f21a44997faa174e63ccb9`.
- v14: 251 files, through `18e385f`, archive SHA-256
  `b602ea8e884350005a4210bae8abcb7ff4b95e83e04884443c066d17edddd2a8`.

Batch 7 retains the fixed 4dfd24c coverage database; v8 Git/Mastra/context; v9
auth intermediate failures; v10 completed auth/class work; v11 mobile recording;
v12 clients/decorators/ContextVars; v13 ASGI state; v14 completed older nine-input
outcomes and later service/URL corrections. Post-v14 includes the newest nine-input
run, fixed-upload completion, metadata/Semgrep/performance and replay diagnostics.

Expanded logs/reports are mostly ignored by Git. Fresh checkouts must extract
archives per README. Extract in numeric order into one evidence directory;
verify each batch against its manifest before the next batch overwrites any
shared diagnostic path with a later version. Do not overwrite sealed archives.

The original dirty snapshot and NEW post-v14 supplemental evidence archive are
retained in section 1. Add the next numbered batch after v14 (or any newer seal
already present), including all completed post-v14 runs and their diagnostic
sources. Do not relabel the supplemental snapshot as final passing evidence.

Inspect before using `/private/tmp/phase22-check.py`:

```sh
/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python \
  /private/tmp/phase22-check.py UNIQUE_LABEL command arguments...
```

It sets active cwd/PYTHONPATH/PATH and records exact command, cwd, overrides,
source commit, tracked diff SHA, tracked patch, untracked src/tests/scripts tar,
wrapper/absolute `/private/tmp/*.py` diagnostic source, exit, duration/timestamp,
and raw log. Use UNIQUE labels; do not overwrite failed attempts or prior records.
Inspect source identities when exploratory checks overlap edits. A commit label
alone does not bind dirty/untracked source. Earliest logs lacked some untracked/
intermediate diagnostic bytes; that limitation is already disclosed. Do not
retroactively claim exact reconstruction of missing intermediate bytes.

Helpful retained/local scripts include:

- `phase22-package-evidence.py`, `-v2.py` through `-v14.py` (do not rerun over seals).
- `phase22-handoff-snapshot-20260908.py` and `phase22-handoff-snapshot-20260908-v2.py`
  (refuse existing archives; old script captures OLD source only).
- `phase22-fixed-suite.py`, `phase22-exposed-pairs-f12.py`.
- `phase22-kubernetes-development.py`, `phase22-score-kubernetes-shared.py`.
- `phase22-materialize-exposed-gaps.py` (requires absent destinations).
- `phase22-excel-development.py`, `phase22-mobile-development.py`,
  `phase22-mobile-cast-pair.py`, `phase22-mobile-wrapper-trace.py`.
- `phase22-atlassian-fast-native.py`, `phase22-upload-fixed-metadata.py`, and
  later continuation profile/replay/condition-scoring scripts whose exact paths
  and snapshots are retained in their command JSON/untracked archives.
- Earlier Atlassian profile/service/lifespan/replace diagnostic scripts, preserved
  in command-specific untracked diagnostic archives and numbered diagnostic tars.

Preserve source/harness/corpus/config/environment/report identities. Keep raw
failures: original TS guard cases, schema drift/incomplete inputs, socket/cache/
network restrictions, permitted reruns, nonexistent-test/import diagnostics,
redaction/type/format failures, all Atlassian deadlines, fake-proof/full-suite/
Docker failures, dbt false alarms, wrong TS fixtures, nullish/imperative branches,
Kubernetes alias scorer failure, workbook fixed alerts and all wrapper/cast/
escape/origin regressions. Later passes do not erase earlier failures.

## 17. Final quality, documentation, delivery and acceptance

Inspect actual Makefile, pyproject/lock and workflows for owning commands and
matrix. Makefile currently owns lint, format, mypy, pytest, audit, schema,
notices, offline artifacts, strict docs and build; do not substitute narrower
focused commands for final project-wide checks.

On FINAL integrated candidate retain:

- Ruff and formatting checks.
- Strict mypy.
- Lockfile checks using locked environment.
- Generated Finding/report schemas; native JSON validation.
- SARIF 2.1.0 validation.
- Full pytest with existing **80% branch-coverage floor**.
- Dependency audit and third-party notices.
- Required generated/judge artifacts in OFFLINE check mode.
- Strict documentation build.
- sdist/wheel build and installed-wheel checks.
- Applicable Docker and Action checks.
- Rules-only network isolation.
- Supported fixtures and historical report/baseline migration regressions.
- Hosted Linux/macOS/Windows and Python **3.10, 3.11, 3.12, 3.13** quality/wheel
  matrix and existing required isolation/Docker checks.

Owning Makefile commands include `make lint`, `format-check`, `typecheck`,
`schema-check`, `test`, `audit`, `notices-check`, `artifacts-check`, `docs-check`
and `build`. `make check` includes lint/format/mypy/schema/test/audit/notices/docs,
but does NOT alone cover every final requirement: artifacts, lock validation,
installed wheel, Action/isolation, full comparator/corpus and hosted gates still
need their owning commands. `make artifacts-live` is paid generation and is NOT
authorized. Inspect actual commands before running. `uv run` outside the original
checkout must not create/select the wrong environment; establish the locked env
and worktree imports explicitly rather than relying on editable-install resolution.

Existing hosted Phase 20 jobs reproduce a PINNED HISTORICAL scanner, not this
integration. They cannot replace final Phase 22 measurements.

Fix failures on the final candidate and rerun affected checks. Do not attach old
passes to changed behavior without establishing byte/behavior compatibility.
Respect actual sandbox approvals. A recent strict docs attempt needed uv cache
access outside sandbox; retain denial and permitted rerun, not a silent bypass.

Prepare a reproducible technical acceptance packet mapping EVERY requirement to:
implementation files/commits, durable tests, exact commands/exits, retained logs/
reports, source/harness/corpus/config/environment identities, measurements,
failed/incomplete attempts, exclusions/limitations, unrelated-finding adjudication,
and remaining ownership/authorization/external evidence gaps. Keep archives
lossless, hashed, read back, extractable and documented.

Update ROADMAP/status/owning docs to distinguish delivered code, verified technical
gates, paid evaluation, human acceptance and pilot-dependent external acceptance.
Do not mark Phase 22 complete while the full gate is unmet.

Deliver the consolidated DRAFT with final scope, explicit delivered parent/base,
verified behavior, reproducible evidence links and remaining external gates.
Write for a reviewer who has not read this conversation. Omit abandoned approaches
unless they explain a material tradeoff. Preserve older drafts. Do not merge or
publish. Draft creation alone is not technical completion.

## 18. Completion standard and autonomy

“Complete” means all authorized implementation, integration, documentation,
measurements, regression checks and draft delivery above are actually finished
and evidenced. Do not substitute:

- roadmap checkboxes for implementation;
- coverage percentage for detection accuracy;
- inventory recognition for detector support;
- discovery for exploitation;
- failed attacks for defense or false-positive determinations;
- author-run scans for external pilots;
- draft PRs for verification;
- partial approval packets/replay/synthetic tests for reviewed independent gates;
- schema/model literals for coordinated migration;
- successful harness exit for complete input measurements.

Maintain and audit the full requirement checklist. Do not quietly defer authorized
requirements as TODOs or follow-ups. Proceed autonomously within authorization.
Ask only for genuinely missing information or explicit external checkpoints, made
concrete and reviewable first. Do not ask again for approved corpus/Git/technical/
draft work. Do not call unrelated unfinished technical work “externally blocked.”

Paid calls, human acceptance and external pilots remain real external gates.
Phase 21 recruitment stays deferred; the five external workflows/ranked blockers
cannot be fabricated. Complete all independent authorized work before stopping
for those dependencies.

At this handoff the tree is clean and the original dirty regressions are fixed,
but unmet independent conditions, incomplete upload/control measurements, final
audits/benchmarks, paid preparation and consolidated draft delivery remain. There is **no basis to declare Phase 22 technically complete**.

When finally reporting delivery or a genuine external checkpoint, state exactly:

1. What is complete.
2. What passed, on which exact source.
3. Where reproducible evidence is retained.
4. Where the consolidated draft is and its explicit parent/base.
5. What paid approval, human acceptance or external pilot dependencies remain.
6. Any authorized technical work still unfinished.

Never claim the entire task is complete while authorized technical work remains.
Start by verifying/preserving the current 020cde8 integration state, checking for
other active writers, reading the latest native outcomes and remaining Meta source
relationships, and continuing the complete authorized work. Do not restart the
resolved registration/constructor handoffs. If a true product decision, missing
information or external approval is required, ask the user a concrete question;
continue independent authorized work. Routine implementation choices already
covered by the contracts do not require renewed permission.
