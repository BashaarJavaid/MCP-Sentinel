# Meta fixed-label review: Streamable HTTP with SSE responses

The frozen condition excludes a caller with neither Bearer nor Pipeboard
credentials from using the operator META_ACCESS_TOKEN. It does not restrict
response format. The fixed snapshot's normal JSON mode attaches its rejecting
middleware, but `--sse-response` selects a different provider from the SDK's
served application.

The source relationship is:

1. `core/server.py:226` defines `--sse-response`; line 339 sets
   `mcp_server.settings.json_response = not args.sse_response`.
2. `core/http_auth_integration.py:200–207` wraps `streamable_http_app` for JSON
   responses and `sse_app` otherwise.
3. `core/server.py:387` launches with `transport="streamable-http"`.
4. MCP 1.29.0 routes that transport to `run_streamable_http_async`, which calls
   `streamable_http_app` regardless of response encoding
   (`server.py:282–303,780–784` in the installed SDK).
5. The source run wrapper still patches the token getter. Without the request
   middleware, its ContextVar defaults to None and the original getter can select
   configured META_ACCESS_TOKEN (`core/http_auth_integration.py:159–168`;
   `core/auth.py:443–455`).

The retained source-only witness supplies empty caller headers and follows
successful initialization:

| Snapshot | JSON response | Attached layers | Reaches downstream |
| --- | --- | --- | --- |
| Vulnerable | true | 1 | yes |
| Vulnerable | false | 0 | yes |
| Fixed | true | 1 | no |
| Fixed | false | 0 | yes |

This is source-level evidence, not runtime exploit confirmation. No target/SDK
code or endpoint was executed. [packet.json](packet.json) links the exact command,
source patch, hashes, raw trace, frozen condition and SDK identity. Original
manifests and evidence remain unchanged.

A decision is needed before changing the frozen label/condition or the
no-fixed-condition-alert scoring gate. Recommended: retain the condition and
original manifest, add an approved erratum for the disputed fixed configuration,
and distinguish this source counterexample from detector false alarms.
Alternatively, explicitly narrow a versioned condition amendment to default
JSON-response startup and retain the alternate path separately. Independent
technical work continues while this is reviewed.
