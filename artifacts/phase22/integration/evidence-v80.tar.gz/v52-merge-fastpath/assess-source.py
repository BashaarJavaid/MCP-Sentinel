"""Bind exactly the approved fast-path reorder and complete synthetic evidence."""
import ast,hashlib,json,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=(out/'baseline-typescript-path-flow.py').read_text();current=(root/'src/sentinel/static/typescript_path_flow.py').read_text()
fallback='''            root = name.removeprefix("#record:")
            initial = (
                Value(key=root)
                if name.startswith("#record:")
                and root in self.objects
                and any(name not in branch for branch in branches)
                else UNKNOWN_VALUE
            )
'''
expected=old.replace(fallback,'',1).replace('value = first.get(name, initial)','value = first.get(name)',1).replace('''                not name.startswith("#guard:")
''','''                value is not None
                and not name.startswith("#guard:")
''',1).replace('(other := branch.get(name, initial))','(other := branch.get(name))',1).replace('            values = [branch.get(name, initial) for branch in branches]',fallback+'            values = [branch.get(name, initial) for branch in branches]',1)
assert current==expected
validation=json.loads((out/'synthetic-validation.json').read_text());assert validation['passed'] and validation['semantic_cases']==10944 and validation['fallback_preparations_avoided']==8 and validation['used_fallbacks_preserved']==13
assert validation['candidate_source_sha256']==sha(root/'src/sentinel/static/typescript_path_flow.py')
source=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert source=='a36f696c504e4e8d1f90de5dc84e8942d06316ca'
packet={'scanner':source,'attempts':1,'authorization_sha256':sha(out/'authorization.json'),'baseline_source_sha256':sha(out/'baseline-typescript-path-flow.py'),'candidate_source_sha256':sha(root/'src/sentinel/static/typescript_path_flow.py'),'entire_file_change_exactly_approved_reorder':True,'synthetic_validation_sha256':sha(out/'synthetic-validation.json'),'proof':'An actual Value from every branch is required before early unchanged reuse. None denotes missing entries under internal dict[str, Value], including when a Value represents a null target literal. Guard markers and source-free safety claims cannot take the early path. Missing or unequal values retain exact fallback preparation, branch ordering and conservative combined/metadata handling. All other source bytes are unchanged. There is no new cache, dependency, analysis truncation or deadline change.','synthetic_scope':'10944comparisons preserve environment, every flow attribute and input dictionaries across empty/one/two/three/eight branches, every missing position, equal/unequal Values, registered roots and path/array/record/URL/guard state. Eight additional shared/distinct-equal cases show zero record-registry checks before early return; the baseline makes one per case. All13needed root fallback allocations remain.','limits':'Synthetic equivalence and avoided lookup work do not establish native speedup or300-second completion. All-present eligible prevalence remains unknown. Existing four-source and compatibility outcomes retain actual scanner identities; no corpus/profile execution is authorized.','historical_bindings':{'v44':'24first-frozen observations, four failed fresh gates at2e0efb2','v46':'17b4784native timeout;204unstarted closed','v47':'17b4784sampled timeout,partial snapshots','v49':'6e4fd67native timeout;204unstarted closed','v50':'invalid interrupted sampler attempt,stale17broot,no usable samples','v51':'6e4fd67bound sampled timeout,4worker identities and79307partial samples'},'next_gate':'Required engineering, frozen candidate and separate exact regression approval. Prior shared Python recovery still lacks completed corpus validation, so Python87 compatibility cannot be skipped.','corpus_observations':0,'profiles':0,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False}
with (out/'source-recovery-assessment.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Exact fast-path reorder and10944full-state comparisons bound; eight fallback preparations skipped,13needed allocations preserved.')
