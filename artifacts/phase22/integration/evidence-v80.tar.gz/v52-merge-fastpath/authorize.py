import ast
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
proposal = out.parent / 'v51-faf-bound-sampling/optimization-proposal.json'
source = Path('src/sentinel/static/typescript_path_flow.py')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(proposal) == '00b9d4b4d1e35b086a3082bf8222fd25c03a40d5b02f8e3cda72830c4015c888'
assert sha(source) == 'fe9f1f6b88a1d2e8ec932cc86b07a52f5496ae003dab47d1790a3b5fd0fc9e3d'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == '91acb856fa9dbfb71d77e402d2aebee3f115a13e'
assert not subprocess.check_output(['git', 'diff', 'HEAD'])
old = json.loads((out.parent/'v51-faf-bound-sampling/documentation-binding.json').read_text())
for name, expected in old['user_files_sha256'].items():
    assert sha(Path(name)) == expected, name
with (out/'baseline-typescript-path-flow.py').open('xb') as stream:
    stream.write(source.read_bytes())
module = ast.parse(source.read_text())
cls = next(n for n in module.body if isinstance(n, ast.ClassDef) and n.name == 'TypeScriptPathFlow')
method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'merge')
with (out/'baseline-merge.py').open('x') as stream:
    stream.write(''.join(source.read_text().splitlines(keepends=True)[method.lineno-1:method.end_lineno]))
receipt = {'decision': 'appproved', 'interpretation': 'User approved the exact one source-only optimization proposal after verified91acb85delivery; typo interpreted as approval. No corpus/profile/paid approval.', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'proposal': str(proposal), 'proposal_sha256': sha(proposal), 'starting_delivery': head, 'baseline_source_sha256': sha(source), 'baseline_merge_sha256': sha(out/'baseline-merge.py'), 'bounds': json.loads(proposal.read_text())['bounds'], 'user_files_sha256': old['user_files_sha256'], 'technical_acceptance_received': False, 'phase22_complete': False}
with (out/'authorization.json').open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
print('Approved attempt recorded; exact baseline and protected files bound before edits.')
