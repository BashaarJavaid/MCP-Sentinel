"""Retain the initial formatting failure and its successful correction."""
import hashlib,json
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
failed={p.stem:read(p) for p in base.glob('v52-*.json') if 'exit_code' in read(p) and read(p)['exit_code']!=0}
assert set(failed)=={'v52-format'},failed.keys()
assert 'Would reformat: tests/test_typescript_discovery.py' in (base/'v52-format.log').read_text()
assert read(base/'v52-format-corrected.json')['exit_code']==0
p={'failed_checks':{'v52-format':{'receipt_sha256':sha(base/'v52-format.json'),'log_sha256':sha(base/'v52-format.log'),'assessment':'Initial Ruff format check found only the new test list-comprehension layout. Ruff format changed test whitespace before candidate commit; corrected format check passed. No product semantic change and no corpus/profile retry.','corrected_receipt_sha256':sha(base/'v52-format-corrected.json')}},'prior_failures':'All earlier failures retain their original packets and closed budgets, including v48 environment deletion, v50 stale worker root and v51 metadata-client failure followed by verified REST correction. This continuation does not relabel them.','helper_syntax_validation':read(out/'helper-syntax-validation.json'),'helper_syntax_validation_sha256':sha(out/'helper-syntax-validation.json'),'source_only_attempts':1,'corpus_observations':0,'profiles':0,'paid_calls':0}
with (out/'check-failure-assessment.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('Retained initial formatting failure and corrected pass; no other current failed check.')
