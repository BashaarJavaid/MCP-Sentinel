"""Inventory absent tracked files from preserved Git indexes without modifying them."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir'],text=True).strip()).resolve()
admins=[p for p in (common/'worktrees').iterdir() if (p/'gitdir').is_file()]
rows=[]
for admin in admins:
 target=Path((admin/'gitdir').read_text().strip()).parent
 assert target.is_relative_to('/private/tmp')
 git=['git','--git-dir='+str(admin),'--work-tree='+str(target)]
 head=subprocess.check_output([*git,'rev-parse','HEAD'],text=True).strip()
 entries=[]
 for line in subprocess.check_output([*git,'ls-files','--stage','-z']).decode().split('\0'):
  if not line:continue
  meta,name=line.split('\t',1);mode,blob,stage=meta.split();assert stage=='0'
  path=target/name
  if not path.exists() and not path.is_symlink():
   assert mode in {'100644','100755'},(target,name,mode)
   entries.append({'path':name,'blob':blob,'mode':mode})
 if entries or not (target/'.git').exists():
  rows.append({'root':str(target),'admin':str(admin),'head':head,'index_sha256':hashlib.sha256((admin/'index').read_bytes()).hexdigest(),'missing_git_link':not (target/'.git').exists(),'missing':entries})
result={'recorded_at':datetime.now(timezone.utc).isoformat(),'worktrees':rows,'scope':'Restore only absent indexed files and missing registered Git links, preserving all existing bytes, heads and indexes. No corpus or profile run.','total_files':sum(len(r['missing']) for r in rows),'git_links':sum(r['missing_git_link'] for r in rows)}
with (out/'worktree-restoration-plan.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Affected worktrees',len(rows),'missing files',result['total_files'],'missing links',result['git_links'])
