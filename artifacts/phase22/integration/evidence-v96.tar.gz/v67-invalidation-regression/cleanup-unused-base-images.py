"""Remove five inventoried unused public base images; preserve project images/data."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
raw=Path('/Users/bashaarjavaid/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw')
def run(*args):return subprocess.check_output(['docker',*args],text=True,stderr=subprocess.STDOUT)
selected=['94c362db08c5','35d3a4a3d5e4','581429e3df12','6ef67a2f0d2f','6a097f68bae7']
keep=json.loads((out.parent/'v48-merge-allocation/docker-cleanup-before.json').read_text())['keep']
containers=run('ps','-aq','--no-trunc').splitlines();volumes=run('volume','ls','-q').splitlines()
used=set(run('inspect','--format','{{.Image}}',*containers).splitlines()) if containers else set()
images=[json.loads(l) for l in run('image','ls','--no-trunc','--format','{{json .}}').splitlines()]
records=[]
for short in selected:
 d=json.loads(run('image','inspect',short))[0]
 expected_repository='python' if short in selected[:3] else 'mcr.microsoft.com/devcontainers/python' if short==selected[3] else 'ubuntu/squid'
 assert d.get('RepoTags')==[expected_repository+'@'+d['Id']] and d['Id'] not in used|set(keep)
 history=run('image','history','--no-trunc','--format','{{.CreatedBy}}',short)
 if short in selected[:3]:assert 'ENV PYTHON_VERSION=' in history
 elif short==selected[3]:assert d['Config']['Labels']['dev.containers.source']=='https://github.com/devcontainers/images'
 else:assert d['Config']['Labels']['org.opencontainers.image.ref.name']=='ubuntu'
 records.append({'id':d['Id'],'tags':d.get('RepoTags'),'size':d['Size'],'kind':'unused public base image','selected_short_id':short})
packet={'recorded_at':datetime.now(timezone.utc).isoformat(),'user_authorization':'Check Docker and free unneeded space.','selected':records,'containers_before':containers,'volumes_before':volumes,'images_before':images,'approved_images':keep,'raw_allocated_bytes_before':raw.stat().st_blocks*512,'host_available_bytes_before':os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,'commands':[],'paid_calls':0,'profiles':0}
with (out/'base-image-cleanup-started.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
for row in records:
 command=['docker','image','rm',row['id']]
 r=subprocess.run(command,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 packet['commands'].append({'command':command,'exit_code':r.returncode,'stdout':r.stdout})
 print(row['selected_short_id'],r.returncode,r.stdout[-200:],flush=True)
 assert r.returncode==0
remaining=set(run('image','ls','-aq','--no-trunc').splitlines());removed={r['ID'] for r in images}-remaining
assert removed<={r['id'] for r in records}
assert set(run('ps','-aq','--no-trunc').splitlines())==set(containers)
assert set(run('volume','ls','-q').splitlines())==set(volumes)
for image in keep:assert run('image','inspect','--format','{{.Id}}',image).strip()==image
packet.update(passed=True,removed_image_ids=sorted(removed),project_images_containers_volumes_preserved=True,raw_allocated_bytes_after=raw.stat().st_blocks*512,host_available_bytes_after=os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,summary_after=run('system','df'))
packet['physical_docker_bytes_reclaimed']=packet['raw_allocated_bytes_before']-packet['raw_allocated_bytes_after']
with (out/'base-image-cleanup.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Removed',len(removed),'unused public base images; preserved project images, all containers and volumes.')
