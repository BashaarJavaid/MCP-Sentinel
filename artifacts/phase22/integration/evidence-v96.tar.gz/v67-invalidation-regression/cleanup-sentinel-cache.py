"""Remove only two explicitly identified unused Sentinel pipx cache records."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
raw=Path('/Users/bashaarjavaid/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw')
def run(*args):return subprocess.check_output(['docker',*args],text=True,stderr=subprocess.STDOUT)
def cache():return {r['ID']:r for r in map(json.loads,run('buildx','du','--format','json').splitlines())}
before=cache();selected={'saixwxlwwfhm4aafg0t1k47qf','t98bj5uese43fmun0szgwbk85'}
assert selected<=before.keys()
assert all(before[k]['Reclaimable'] and not before[k]['Mutable'] and not before[k]['Shared'] and 'sentinel' in before[k]['Description'].lower() for k in selected)
containers=run('ps','-aq','--no-trunc');volumes=run('volume','ls','-q');images=run('image','ls','-aq','--no-trunc')
keep=json.loads((out.parent/'v48-merge-allocation/docker-cleanup-before.json').read_text())['keep']
packet={'recorded_at':datetime.now(timezone.utc).isoformat(),'user_authorization':'there is not enough space in my laptop that might be the reason. check Docker and free up space from there if you dont need more docker space.','selected':{k:before[k] for k in sorted(selected)},'commands':[],'scope':'Only two exact unused Sentinel pipx build-cache IDs, with all/filter and zero reserved-space policy for this prune invocation only. No global prune, image/container/volume deletion or daemon-policy change.','raw_allocated_bytes_before':raw.stat().st_blocks*512,'host_available_bytes_before':os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,'paid_calls':0,'profiles':0}
with (out/'docker-cleanup-started.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
for identity in sorted(selected):
 command=['buildx','prune','--all','--force','--reserved-space','0','--filter','id='+identity]
 result=subprocess.run(['docker',*command],text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 packet['commands'].append({'command':['docker',*command],'stdout':result.stdout,'exit_code':result.returncode})
 print(identity,result.returncode,result.stdout[-500:],flush=True)
 assert result.returncode==0
 after=cache();assert set(before)-set(after)<=selected
assert run('ps','-aq','--no-trunc')==containers and run('volume','ls','-q')==volumes
assert set(run('image','ls','-aq','--no-trunc').splitlines())==set(images.splitlines())
for image in keep:assert run('image','inspect','--format','{{.Id}}',image).strip()==image
packet.update(passed=True,removed_ids=sorted(set(before)-set(after)),remaining_selected=sorted(selected&after.keys()),unselected_cache_records_preserved=True,all_images_containers_volumes_preserved=True,raw_allocated_bytes_after=raw.stat().st_blocks*512,host_available_bytes_after=os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,docker_summary_after=run('system','df'))
packet['physical_docker_bytes_reclaimed']=packet['raw_allocated_bytes_before']-packet['raw_allocated_bytes_after']
with (out/'docker-cleanup.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Removed',len(packet['removed_ids']),'selected cache records; preserved all images/containers/volumes and unselected cache.')
