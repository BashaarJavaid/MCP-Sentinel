"""Reverify the unused approved launch after exact missing-file restoration."""
import hashlib,importlib.util,json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent;root=out.parents[3];base=out.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert read(out/'worktree-restoration.json')['passed'] and read(out/'sealed-evidence-restoration.json')['passed']
assert not subprocess.check_output(['git','diff','HEAD'],cwd=root)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()=='c60b7a858497c355326044b959d9f6ad8d755a80'
binding=read(out/'documentation-binding.json')
for key in ['user_files_sha256','additional_normative_docs_sha256','owning_docs_sha256','review_packet_sha256']:
 for name,digest in binding[key].items():assert sha(root/name)==digest,name
for name,digest in read(base/'v66-invalidation-contract/local-checks.json')['candidate_engineering_files_sha256'].items():assert sha(root/name)==digest,name
rows={}
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
 fields=line.strip().split(None,2)
 if len(fields)==3:rows[int(fields[0])]=(int(fields[1]),fields[2])
ancestors=set();pid=os.getpid()
while pid in rows and pid not in ancestors:ancestors.add(pid);pid=rows[pid][0]
owned=[p for p,(_,cmd) in rows.items() if p not in ancestors and any(m in cmd for m in ['v68-','v67-','phase22-check.py'])]
assert not owned,owned
for selector in ['label=com.securemcp.sentinel=true','name=sentinel']:
 assert not subprocess.check_output(['docker','ps','-aq','--filter',selector])
for image in read(base/'v48-merge-allocation/docker-cleanup-before.json')['keep']:
 assert subprocess.check_output(['docker','image','inspect','--format','{{.Id}}',image],text=True).strip()==image
spec=importlib.util.spec_from_file_location('diagnostic',out/'diagnostic.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
p,manifest=runner.approved();assert p==read(out/'diagnostic-proposal.json')
assert not subprocess.check_output(['git','status','--porcelain'])
assert not (out/'diagnostic-consumed.json').exists() and not (base/'v68-invalidation-sampling').exists()
result={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'proposal_sha256':sha(out/'diagnostic-proposal.json'),'approval_sha256':sha(out/'diagnostic-authorization.json'),'retained_original_preflight_sha256':sha(out/'diagnostic-preflight.json'),'initial_failure_sha256':sha(out/'launch-preflight-failure.json'),'restored_tracked_files':25941,'restored_git_links':6,'restored_expanded_evidence_files':7667,'protected_user_documents_verified':9,'restored_user_documents':2,'engineering_inputs_verified':303,'owned_processes':[],'owned_containers':[],'profile_attempts':0,'paid_calls':0,'budget_consumed':False,'qualification':'The first launcher failed during read-only provenance preflight, before creating any token/output or executing an input. Exact restoration and approved source/configuration checks pass; the original single-profile approval is still unused. Resuming this launcher is not a second profile/input or a reopened spent budget.'}
with (out/'restored-launch-preflight.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Restored source, all9 protected documents, runtime images and exact unused profile approval verified. Zero inputs attempted.')
