"""Restore absent registered worktree files, using APFS clones for shared blobs."""
import ctypes,hashlib,json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent;root=Path.cwd()
plan=json.loads((out/'worktree-restoration-plan.json').read_text())
libc=ctypes.CDLL(None,use_errno=True)
clonefile=libc.clonefile;clonefile.argtypes=[ctypes.c_char_p,ctypes.c_char_p,ctypes.c_int];clonefile.restype=ctypes.c_int
known={};checked={};rows=[];started=time.monotonic()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
for item in plan['worktrees']:
    target=Path(item['root']);admin=Path(item['admin']);git=['git','--git-dir='+str(admin),'--work-tree='+str(target)]
    assert hashlib.sha256((admin/'index').read_bytes()).hexdigest()==item['index_sha256']
    assert subprocess.check_output([*git,'rev-parse','HEAD'],text=True).strip()==item['head']
    assert not (target/'.git').is_symlink()
    target.mkdir(parents=True,exist_ok=True)
    if item['missing_git_link']:
        assert not (target/'.git').exists()
        with (target/'.git').open('x') as f:f.write('gitdir: '+str(admin)+'\n')
    else:
        assert Path((target/'.git').read_text().removeprefix('gitdir: ').strip())==admin
    cloned=written=0
    for entry in item['missing']:
        path=target/entry['path'];identity=entry['blob'];source=known.get(identity)
        assert not path.exists() and not path.is_symlink(),path
        assert all(not p.is_symlink() for p in path.parents)
        if source is None:
            candidate=root/entry['path']
            if candidate.is_file() and not candidate.is_symlink():
                if candidate not in checked:checked[candidate]=blob(candidate.read_bytes())
                if checked[candidate]==identity:source=candidate;known[identity]=source
        path.parent.mkdir(parents=True,exist_ok=True)
        if source is not None:
            if clonefile(os.fsencode(source),os.fsencode(path),0):raise OSError(ctypes.get_errno(),str(path))
            assert path.stat().st_ino!=source.stat().st_ino
            cloned+=1
        else:
            data=subprocess.check_output(['git','cat-file','blob',identity])
            assert blob(data)==identity
            with path.open('xb') as f:f.write(data)
            known[identity]=path;written+=1
        path.chmod(0o755 if entry['mode']=='100755' else 0o644)
    assert hashlib.sha256((admin/'index').read_bytes()).hexdigest()==item['index_sha256']
    assert subprocess.check_output([*git,'rev-parse','HEAD'],text=True).strip()==item['head']
    assert not subprocess.check_output([*git,'ls-files','--deleted'])
    rows.append({'root':str(target),'head':item['head'],'missing_git_link_restored':item['missing_git_link'],'cloned':cloned,'written_unique_blobs':written,'index_unchanged':True,'remaining_tracked_changes':subprocess.check_output([*git,'diff','--name-status'],text=True).splitlines()})
    (out/'worktree-restoration-progress.json').write_text(json.dumps({'completed':rows,'elapsed_seconds':time.monotonic()-started},indent=2)+'\n')
    print(target.name,cloned,'clones',written,'unique writes',flush=True)
packet={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'worktrees':rows,'restored_files':sum(r['cloned']+r['written_unique_blobs'] for r in rows),'copy_on_write_files':sum(r['cloned'] for r in rows),'existing_files_overwritten':0,'heads_and_indexes_unchanged':True,'elapsed_seconds':time.monotonic()-started,'user_authorized_restore':True,'corpus_observations':0,'paid_calls':0}
with (out/'worktree-restoration.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Restored',sum(r['missing_git_link_restored'] for r in rows),'Git links and',packet['restored_files'],'missing files with',packet['copy_on_write_files'],'APFS clones.')
