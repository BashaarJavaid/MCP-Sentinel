"""Restore absent latest-version expanded evidence from all verified seals."""
import hashlib,json,tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
out=Path(__file__).resolve().parent;base=out.parent
sha=lambda data:hashlib.sha256(data).hexdigest()
indexes=[json.loads((base/f'evidence-v{n}.json').read_text()) for n in range(1,96)]
latest={}
for version,index in enumerate(indexes,1):
 for row in index['files']:latest[row['path']]={**row,'seal':version}
restored=[];checked=0;archives=[]
for version,index in enumerate(indexes,1):
 archive=base/index['archive'];assert sha(archive.read_bytes())==index['sha256']
 with tarfile.open(archive) as t:
  members=t.getmembers();assert len(members)==len(index['files'])
  for member,row in zip(members,index['files'],strict=True):
   name=PurePosixPath(row['path']);assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
   assert not name.is_absolute() and '..' not in name.parts
   data=t.extractfile(member).read();assert sha(data)==row['sha256'];checked+=1
   if latest[row['path']]['seal']!=version:continue
   path=base/name;assert not path.is_symlink() and all(not p.is_symlink() for p in path.parents)
   if path.exists():assert sha(path.read_bytes())==row['sha256'],('Existing evidence differs from latest sealed bytes',str(path))
   else:
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(data)
    assert sha(path.read_bytes())==row['sha256']
    restored.append({'path':row['path'],'seal':version,'sha256':row['sha256'],'bytes':len(data)})
 archives.append({'version':version,'sha256':index['sha256']})
 print('Verified seal',version,'restored total',len(restored),flush=True) if version%10==0 else None
result={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'archives':archives,'checked_members':checked,'latest_members_verified':len(latest),'restored':restored,'existing_files_overwritten':0,'historical_versions_preserved':True,'paid_calls':0,'corpus_observations':0,'profiles':0}
with (out/'sealed-evidence-restoration.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Verified all95 archives and restored',len(restored),'missing latest expanded files.')
