import hashlib, json, subprocess, time, zipfile, sys
from pathlib import Path

root = Path("/private/tmp/mcp-phase22-options")
out = root / "artifacts/phase22/integration/v23-v5-quality"
out.mkdir(exist_ok=False)
head = sys.argv[1]
sha = lambda data: hashlib.sha256(data).hexdigest()
packet = {
    "source": head,
    "frozen_product_scanner": "1f3f72f0f25c597b53c9f833e2e4bec99728d328",
    "runs": {},
    "archives": {},
    "artifact_files": [],
    "classification": "Fresh normal CI/docs verification at the explicitly recorded source after the approved optional workflow change. Scanner bytes remain1f3f72f. The separate diagnostic is not part of normal CI; historical reproductions retain their pinned scanner.",
}
pending = json.loads(
    (root / "artifacts/phase22/integration/v23-v5-run-ids.json").read_text()
)
while pending:
    for kind, run in list(pending.items()):
        p = subprocess.run(
            [
                "gh",
                "run",
                "view",
                str(run),
                "--json",
                "databaseId,headSha,status,conclusion,jobs,url,workflowName",
            ],
            cwd=root,
            capture_output=True,
            text=True,
            check=True,
        )
        data = json.loads(p.stdout)
        assert data["headSha"] == head
        print(
            kind,
            data["status"],
            data["conclusion"],
            [
                (
                    j["name"],
                    [
                        s["name"]
                        for s in j.get("steps", [])
                        if s["status"] == "in_progress"
                    ],
                )
                for j in data["jobs"]
                if j["status"] == "in_progress"
            ],
            flush=True,
        )
        if data["status"] != "completed":
            continue
        packet["runs"][kind] = data
        target = out / (kind + "-logs.zip")
        with target.open("wb") as stream:
            subprocess.run(
                [
                    "gh",
                    "api",
                    f"repos/BashaarJavaid/MCP-Sentinel/actions/runs/{run}/logs",
                ],
                cwd=root,
                stdout=stream,
                check=True,
            )
        with zipfile.ZipFile(target) as archive:
            assert archive.testzip() is None
            packet["archives"][kind] = {
                "sha256": sha(target.read_bytes()),
                "members": [
                    {
                        "path": n,
                        "bytes": len(archive.read(n)),
                        "sha256": sha(archive.read(n)),
                    }
                    for n in archive.namelist()
                ],
            }
        if kind != "docs":
            subprocess.run(
                [
                    "gh",
                    "run",
                    "download",
                    str(run),
                    "--dir",
                    str(out / "artifacts" / kind),
                ],
                cwd=root,
                check=True,
            )
        (out / (kind + "-retained.json")).write_text(
            json.dumps(
                {
                    "run": data,
                    "archives": packet["archives"].get(kind),
                    "complete": True,
                },
                indent=2,
            )
            + "\n"
        )
        del pending[kind]
    if pending:
        time.sleep(30)
for p in sorted((out / "artifacts").rglob("*")):
    assert not p.is_symlink()
    if p.is_file():
        packet["artifact_files"].append(
            {
                "path": p.relative_to(out).as_posix(),
                "bytes": p.stat().st_size,
                "sha256": sha(p.read_bytes()),
            }
        )
packet["engineering_passed"] = (
    packet["runs"]["ci"]["conclusion"] == "success"
    and packet["runs"]["docs"]["conclusion"] == "success"
)
(out / "packet.json").write_text(json.dumps(packet, indent=2) + "\n")
print(
    "RETAINED", packet["engineering_passed"], len(packet["artifact_files"]), flush=True
)
