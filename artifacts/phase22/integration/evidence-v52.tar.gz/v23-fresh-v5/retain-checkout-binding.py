"""Retain the synthetic PR checkout identity and verify its complete Git tree."""

import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / "artifacts/phase22/integration"


def main():
    output = BASE / "v23-v5-checkout-binding.json"
    assert not output.exists()

    def api(endpoint):
        return json.loads(subprocess.check_output(["gh", "api", endpoint], cwd=ROOT))

    head = subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip()
    assert head == "e1ab15c513ae736bedfb7665ac53efabff85f790"
    ref = api("repos/BashaarJavaid/MCP-Sentinel/git/ref/pull/37/merge")
    merge = api("repos/BashaarJavaid/MCP-Sentinel/git/commits/" + ref["object"]["sha"])
    tree = subprocess.check_output(
        ["git", "rev-parse", head + "^{tree}"], cwd=ROOT, text=True
    ).strip()
    assert merge["tree"]["sha"] == tree
    assert head in [p["sha"] for p in merge["parents"]]
    output.write_text(
        json.dumps(
            {
                "recorded_at": datetime.now(timezone.utc).isoformat(),
                "head": head,
                "synthetic_merge": merge["sha"],
                "tree": tree,
                "complete_tree_equal_to_head": True,
                "ref": ref,
                "commit": merge,
                "helper_sha256": hashlib.sha256(
                    Path(__file__).read_bytes()
                ).hexdigest(),
                "qualification": "Normal pull-request jobs use checkout default merge ref. After log retention, verify the actual checkout SHAs match this source binding; this read alone is not proof of the executed checkout.",
                "fresh_observations": 0,
                "paid_calls": 0,
            },
            indent=2,
        )
        + "\n"
    )
    print(head, merge["sha"], tree)


if __name__ == "__main__":
    main()
