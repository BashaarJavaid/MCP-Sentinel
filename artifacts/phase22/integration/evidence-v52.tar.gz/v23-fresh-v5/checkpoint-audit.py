"Reconcile all original and added rows at the failed freshness checkpoint."

import copy
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    output = BASE / "v23-checkpoint-audit"
    assert not output.exists()
    quality = json.loads((BASE / "v23-v5-quality/packet.json").read_text())
    assert quality["engineering_passed"]
    assert (BASE / "v23-v5-quality-audit/packet.json").is_file()
    previous = BASE / "v22-closeout-audit/packet.json"
    old = json.loads(previous.read_text())
    audit = copy.deepcopy(old)
    assert (
        len(old["requirements"]) == 89
        and len(old["additional_scope_requirements"]) == 51
    )
    audit["historical_source_and_test_file_bindings"] = {
        "source": old["source"],
        "files": old["current_source_and_test_files"],
    }
    audit["current_source_and_test_files"] = {
        name: sha(BASE.parents[2] / name)
        for name in old["current_source_and_test_files"]
    }
    audit["per_file_test_counts_basis"] = {
        "kind": (
            "Compatible retained local suite counts; "
            "current hosted suites separately verified"
        ),
        "local_executed_source": "1f3f72f0f25c597b53c9f833e2e4bec99728d328",
        "hosted_executed_source": quality["source"],
        "new_full_local_suite_executed": False,
    }
    audit["full_sequence_status_basis"] = (
        "The accepted scoped historical gate reuses the whole25 development batch "
        "and passed both whole45 historical repeats under the explicit amendment. "
        "This does not relabel the failed original V21 sequence or reopen its budget."
    )
    audit["recorded_at"] = datetime.now(timezone.utc).isoformat()
    audit["source"] = quality["source"]
    audit["scanner_identity"]["revision"] = "1f3f72f0f25c597b53c9f833e2e4bec99728d328"
    audit["workflow_tested_source"] = quality["source"]
    audit["prior_audit"] = {
        "path": previous.relative_to(BASE).as_posix(),
        "sha256": sha(previous),
    }
    for row in audit["requirements"]:
        row["historical_assessment"] = {
            "audit": "v22-closeout-audit/packet.json",
            "text": row["assessment"],
        }
        row["prior_requirement_record_sha256"] = hashlib.sha256(
            json.dumps(
                next(r for r in old["requirements"] if r["id"] == row["id"]),
                sort_keys=True,
            ).encode()
        ).hexdigest()
        row["evidence"].append(
            "artifacts/phase22/integration/v23-v5-compatible-reuse.json"
        )
        row["interpretation"] = (
            "Original measured sources and historical judgments rema"
            "in preserved. Current product/test/package bytes equal1"
            "f3f72f; changed optional workflow is verified ate1ab15c"
            ". Final document hashes are bound separately. No indepe"
            "ndent fresh outcome or human acceptance is claimed."
        )
        if row["id"] in {"R66", "R88"}:
            row["assessment"] = (
                "Replacement-v4 fails source novelty before execution: v"
                "ulnerable21-file tree identical to original held-out so"
                "urce, fixedsrc files identical with only package metada"
                "ta differences. Original native/comparator reports pred"
                "ate scanner freeze. No v4 approval, dispatch or observa"
                "tion; source-only recovery is approved; novel Lighthous"
                "e v5 packet passes source preparation and awaits separa"
                "te exact evaluation approval. Independent fresh evidenc"
                "e remains required, not waived."
            )
            row["evidence"].extend(
                [
                    "artifacts/phase22/integration/v23-freshness-assessment.json",
                    (
                        "artifacts/phase22/integration/v23-fresh-v4/recovery-pro"
                        "posal.json"
                    ),
                    (
                        "artifacts/phase22/integration/v23-source-only-recovery-"
                        "authorization.json"
                    ),
                    "artifacts/phase22/corpus-replacement-v5/preparation.json",
                ]
            )
        elif row["id"] == "R84":
            row["assessment"] = (
                "Final human technical acceptance has not been requested"
                " or received. Fresh evaluation awaits its exact approva"
                "l and outcomes; Phase22 remains incomplete. Pilot and p"
                "aid benchmark deferrals retain their actual user decisi"
                "ons and later-phase limits."
            )
        elif row["id"] in {"R62", "R83"}:
            row["assessment"] = (
                "Owning documentation records failedv4 source novelty an"
                "d the approved source-only recovery and unapproved v5 e"
                "valuation proposal. SearXNG, prospective120/300timing, "
                "closed profiling scopes and existing suppression suppor"
                "t are reconciled. Phase22 remains incomplete; prior res"
                "ults remain source-specific history."
            )
        elif row["id"] in {"R71", "R72", "R73", "R74"}:
            row["assessment"] = (
                "Normal CI/docs ate1ab15c pass29normal jobs and all12qua"
                "lity suites,2194passed/36skipped; distribution source m"
                "embers are verified. Unchanged local checks retain1f3f7"
                "2f with89.68%branch coverage. Optional measurement jobs"
                " are skipped; no fresh observation or paid call."
            )
            row["evidence"].extend(
                [
                    "artifacts/phase22/integration/v23-v5-quality/packet.json",
                    "artifacts/phase22/integration/v23-v5-quality-audit/packet.json",
                ]
            )
        elif row["disposition"] == "passed" and row["id"] not in {
            "R18",
            "R19",
            "R20",
            "R21",
            "R22",
            "R23",
            "R24",
            "R25",
            "R26",
            "R27",
            "R35",
            "R63",
            "R64",
            "R65",
            "R67",
        }:
            row["assessment"] = (
                "Prior requirement-specific judgments retain their exact"
                " evidence and compatible product/test/package sources. "
                "New optional-workflow quality passes ate1ab15c; current"
                "-source binding verified without reexecuting corpus inp"
                "uts, requests or Git campaigns."
            )
    for row in audit["additional_scope_requirements"]:
        if row["id"] == "V21-FRESH-PROPOSAL":
            row["superseded_disposition"] = row["disposition"]
            row["disposition"] = "unresolved"
            row["scope_closed"] = True
            row["recovery_scope"] = "V23-SOURCE-RECOVERY"
            row["current_correction"] = (
                "Historical preparation/integrity checks passed, but the"
                " independent-source claim fails comparison against the "
                "original corpus. See V23-FRESHNESS; no historical resul"
                "t or status is overwritten."
            )
    additions = [
        (
            "V23-PREPARATION",
            (
                "Prepare exact runner/workflow, materialization and synt"
                "hetic safeguards without evaluation"
            ),
            "passed",
            [
                "v23-fresh-v5/preparation-final.json",
                "../corpus-replacement-v5/preparation.json",
            ],
        ),
        (
            "V23-FRESHNESS",
            (
                "Verify independent source novelty against every earlier"
                " corpus before requesting evaluation"
            ),
            "passed",
            [
                "v23-freshness-assessment.json",
                "v23-source-only-recovery-authorization.json",
                "../corpus-replacement-v5/provenance/novelty.json",
            ],
        ),
        (
            "V23-REUSE",
            (
                "Verify140retained requirement/scope rows and compatible"
                " source/review/runtime bindings"
            ),
            "passed",
            ["v23-v5-compatible-reuse.json"],
        ),
        (
            "V23-QUALITY",
            ("Verify current optional workflow and all normal engineering jobs"),
            "passed",
            [
                "v23-v5-quality/packet.json",
                "v23-v5-quality-audit/packet.json",
            ],
        ),
    ]
    additions.append(
        (
            "V23-SOURCE-RECOVERY",
            (
                "Prepare one novel SENT-015 source pair with two reversi"
                "ble renames and one control; zero evaluation until sepa"
                "rate approval"
            ),
            "passed",
            [
                "v23-source-only-recovery-authorization.json",
                "../corpus-replacement-v5/preparation.json",
                "v23-source-selection.json",
            ],
        )
    )
    audit["additional_scope_requirements"].extend(
        {"id": i, "requirement": r, "disposition": d, "evidence": e}
        for i, r, d, e in additions
    )
    audit["dispositions"] = dict(
        Counter(r["disposition"] for r in audit["requirements"])
    )
    audit["additional_scope_dispositions"] = dict(
        Counter(r["disposition"] for r in audit["additional_scope_requirements"])
    )
    audit.update(
        current_source_corpus_runs=0,
        historical_refresh_observations_retained=98,
        fresh_evaluation_approved=False,
        technical_acceptance_requested=False,
        technical_acceptance_received=False,
        new_paid_calls=0,
        phase22_complete=False,
        status=(
            "Replacement-v4 source novelty failed before execution. "
            "Independent fresh evaluation and final acceptance remai"
            "n unmet; source-only recovery approved, v5 evaluation u"
            "napproved."
        ),
    )
    audit["owning_document_binding"] = (
        "v23-final-documentation-binding.json records final corr"
        "ected document hashes; earlier source-specific document"
        "ation hashes remain historical."
    )
    audit["references_sha256"] = {
        n: sha(BASE / n)
        for n in [
            "v23-v5-compatible-reuse.json",
            "v23-freshness-assessment.json",
            "v23-v5-quality/packet.json",
            "v23-v5-quality-audit/packet.json",
            "v23-fresh-v4/recovery-proposal.json",
            "v23-source-only-recovery-authorization.json",
            "../corpus-replacement-v5/evaluation-proposal.json",
            "evidence-v52.json",
        ]
    }
    assert audit["dispositions"] == {
        "passed": 84,
        "unresolved": 3,
        "explicitly user-deferred": 2,
    }
    assert audit["additional_scope_dispositions"] == {"passed": 53, "unresolved": 3}
    for row in audit["requirements"] + audit["additional_scope_requirements"]:
        for name in row["evidence"]:
            path = (
                BASE.parents[2] / name if name.startswith("artifacts/") else BASE / name
            )
            assert path.is_file(), name
    output.mkdir()
    (output / "packet.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(audit["dispositions"], audit["additional_scope_dispositions"])


if __name__ == "__main__":
    main()
