# ruff: noqa: E501
# Long prose literals preserve the exact review text; executable checks remain linted.
"""Write current preparation results only after hosted evidence is complete."""

import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[4]
BASE = ROOT / "artifacts/phase22/integration"
ASSETS = Path(__file__).resolve().parent


def main():
    retained = json.loads((BASE / "v23-v5-quality/packet.json").read_text())
    checked = json.loads((BASE / "v23-v5-quality-audit/packet.json").read_text())
    assert (
        retained["engineering_passed"]
        and retained["source"] == "e1ab15c513ae736bedfb7665ac53efabff85f790"
    )
    assert len(checked["quality"]) == 12
    assert all(r["passed"] == 2194 and r["skipped"] == 36 for r in checked["quality"])
    cover = [r["branch_coverage_percent"] for r in checked["quality"]]
    coverage = f"{min(cover):.2f}\u2013{max(cover):.2f}%"
    text = (
        "\nCurrent preparation CI **34578515990** and docs **34578515965** pass at\n"
        "**`e1ab15c`**: all **29 normal jobs**, all **12 quality suites with\n"
        "2,194 passed / 36 skipped**, and three optional measurement jobs skipped.\n"
        "CI checkout is synthetic merge `c044a1a`, whose complete tree equals `e1ab15c`.\n"
        f"Hosted branch coverage is **{coverage}**; wheel/sdist source members\n"
        "are byte-verified against that Git revision. The earlier `1942760` CI\n"
        "retains 28 successful jobs and one cancelled final hook job; all its\n"
        "12 test suites completed, but it is **not** a whole CI pass.\n"
        "The new 56-row added-scope audit retains three historical failed checkpoints\n"
        "with budgets closed or never approved; its other 53 rows pass. The original 89-row audit\n"
        "remains 84 passed, two user-deferred and three unresolved. Zero fresh\n"
        "observations or additional paid calls. Exact source-only preparation,\n"
        "novelty, approval and execution-proposal bindings are retained; evaluation\n"
        "and technical acceptance remain unapproved.\n"
    )
    for name in [
        "AGENTS.md",
        "ROADMAP.md",
        "docs/phase22-technical.md",
        "docs/phase22-implementation-status.md",
        "docs/phase22-ssrf-follow-up.md",
        "docs/phase22-corpus-review.md",
        "docs/phase22-timeout-policy.md",
        "artifacts/phase22/integration/README.md",
        "artifacts/phase22/integration/requirements.md",
        "artifacts/phase22/integration/progress.md",
    ]:
        path = ROOT / name
        old = path.read_text()
        marker = "Final human technical acceptance has not been requested."
        assert (
            old.count(marker) >= 1
            and "Current preparation CI **34578515990**" not in old
        )
        path.write_text(old.replace(marker, text + "\n" + marker, 1))
    summary = BASE / "v23-checkpoint-summary.md"
    assert not summary.exists()
    summary.write_text(
        """# Phase 22 source-only replacement checkpoint

Phase 22 remains incomplete. Source-only recovery is approved; replacement-v5 evaluation and final technical acceptance are not.

- Scanner: `1f3f72f0f25c597b53c9f833e2e4bec99728d328`, frozen before curation. Workflow/tested revision: `e1ab15c513ae736bedfb7665ac53efabff85f790`. The 29 normal-job checkout logs bind synthetic merge `c044a1aec17e8f3f826eb2f2c1a966a8b85c21e4`, whose entire tree equals that head. A later documentation/evidence delivery retains these actual executed sources.
- Proposal: [replacement-v5/evaluation-proposal.json](../corpus-replacement-v5/evaluation-proposal.json), SHA-256 `3b3013ae4a116804421bc8c028d8a1fe800fb288ae6637ce593c3d0bd30f19f6`.
- Checkpoint: [checkpoint-1f3f72f.json](../corpus-replacement-v5/checkpoint-1f3f72f.json), SHA-256 `ae4d6c817446b4cf675ec2b1f74a99323e3e21de5a2b1545f29264e4513cf60e`.
- Source-only decision: [authorization receipt](v23-source-only-recovery-authorization.json). No evaluation receipt or final execution binding exists.

Replacement-v4 failed novelty: its vulnerable tree and all fixed source files were already evaluated in the original held-out corpus. Preserve that proposal, original results and [comparison](v23-freshness-assessment.json); its proposed budget was never approved or consumed. The preliminary Git source research was rejected because it cannot occupy the unchanged SENT-015 slot. No evaluated-case replacement or detector-driven selection occurred.

Replacement-v5 retains all 12 files per Lighthouse MCP revision, MIT license and complete upstream fix/report metadata. Its repository and source-file hashes are absent from six previous corpora and 92 effective trees. The source condition is `run_audit` rejection of literal `http://169.254.169.254/` before Chrome launch. Fixed public control: `http://8.8.8.8/`. Two reversible argument-predicate renames yield five correlated inputs from one vulnerability. The other 45 records remain equal. Both source archives, every file, mutation reversal, materialization/configuration and isolated staging validate without target execution.

This source review occurred after immutable scanner freeze by the implementation agent. It is neither independent human review nor an unseen-source claim. No native support/hit is predicted. Upstream intentionally allows loopback; DNS failures, redirects, IPv6, actual network success, audit results and runtime exploitation are outside these narrow labels. Package 0.1.12/0.1.13, stale lock-root 0.1.11 and runtime 0.1.0 metadata are disclosed; exact revision and lock bytes govern.

The separately proposed evaluation is exactly 10 native + 5 Semgrep observations: rules-first, rules-repeat, semgrep-first, five ordered inputs each, one standard Linux 90-minute job. Target 120 seconds / whole-input maximum 300 seconds, cleanup 15 seconds, internal stop 88 minutes, upload reserve 2 minutes. No profiles, retries, target execution or paid calls. Infrastructure/execution/identity/schema/cleanup/ordered-repeat failures close the unused budget. Detection misses/false alerts remain collected outcomes requiring source assessment and explicit disposition; no tuning or automatic acceptance.

"""
        + text
        + """
Retained historical gates remain source-specific: whole 25 development reused under the explicit amendment and whole 45 + 45 historical batches at 1f3f72f;98/98 refresh complete, 72 within 120 seconds, 26 extended, maximum 176.032 seconds. Each historical 45 batch has 20 vulnerable hits and zero matching alerts on 25 negatives; entire ordered reports agree after the existing 11 volatile exclusions. Development retains 10 vulnerable hits, two raw Meta erratum alerts and 13 valid negative controls. The old 15/25 Linux result and 62-attempt stale-assessment stop remain failures with closed budgets. The Kubernetes additional suspicion and all 1,191 preparatory diagnostic assessments remain visible.

All three exposed SSRF families retain measured 2ac39aa regressions and deadline-only compatibility with 1f3f72f. Original holdout remains 10 completed / 10 unsupported / 5 incomplete with 0 hits among 4 completed vulnerable inputs out of 10 total vulnerable inputs. Six production requests remain source-bound and compatible with zero new calls. Git's 13 campaigns remain incomplete:312 of 1,040 attempts, 728 remaining; the narrower demo is separate. Local full-suite 2194/36 and 89.68% coverage retain their original 1f3f72f source.

The [audit](v23-checkpoint-audit/packet.json) covers all 89 original and 56 added rows. Historical failed V14 retention, V21 sequence and v4 novelty preparation remain preserved, not reopened. The formerly passed V21-FRESH-PROPOSAL row is explicitly corrected to unresolved, preserving its prior judgment; successful v5 source recovery has its own row. R66/R88 need approved fresh outcomes and assessment; R84 needs explicit human technical acceptance. Paid-review rows R77/R78 and external pilots retain actual user deferrals. Phase 21 remains incomplete; Phase 24/15 unchanged. No merge, release, ready-state, outreach or Phase 23 authorization.

Seal 52 retains completed raw evidence, checks, helper sources and failures after writers stop; all 51 earlier archives and every new member are verified. Final audit, documentation bindings and delivery verification are directly tracked after that seal. The post-push readback is a separate local receipt. Main worktree and seven user documents remain unchanged. Draft PR 37 remains based on phase22/description-poisoning.
"""
    )
    original = (ASSETS / "draft-body.md").read_text()
    final = original.replace(
        "Current hosted validation will retain the exact executed workflow revision; no fresh benchmark or new full local-suite pass is claimed.",
        f"Current CI 34578515990/docs 34578515965 pass all 29 normal jobs at e1ab15c; all 12 quality suites pass 2194/36 with {coverage} branch coverage and byte-verified distributions. The prior 1942760 CI was cancelled in its final hook job; it remains a partial result. No fresh benchmark or new full local-suite pass is claimed.",
    )
    final = final.replace(
        "two user-deferred (paid benchmark and pilots)",
        "two user-deferred paid-review rows (pilots also remain separately deferred)",
    )
    path = ASSETS / "final-draft-body.md"
    assert not path.exists()
    path.write_text(final)
    print("Prepared current source-only checkpoint docs and draft body.")


if __name__ == "__main__":
    main()
