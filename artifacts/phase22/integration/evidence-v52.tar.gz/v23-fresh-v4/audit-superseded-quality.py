import hashlib, json, re, subprocess, tarfile, zipfile, sys
from collections import Counter
from pathlib import Path

root = Path("/private/tmp/mcp-phase22-options")
b = root / "artifacts/phase22/integration"
source = b / "v23-preparation-quality"
old = json.loads((source / "packet.json").read_text())
head = old["source"]
sha = lambda d: hashlib.sha256(d).hexdigest()
jobs = old["runs"]["ci"]["jobs"]
assert len(jobs) == 32 and sum(j["conclusion"] == "success" for j in jobs) == 28
assert sum(j["conclusion"] == "cancelled" for j in jobs) == 1
assert sorted(j["name"] for j in jobs if j["conclusion"] == "skipped") == [
    "Approved Phase 22 historical_first",
    "Approved Phase 22 historical_second",
    "Approved Phase 22 replacement-v4 evaluation",
]
p = {
    "source": head,
    "retention_packet_sha256": sha((source / "packet.json").read_bytes()),
    "whole_ci_passed": False,
    "quality": [],
    "distributions": [],
    "historical_reproductions": {},
    "classification": "Cancelled prior CI retains28successful jobs and one cancelled final hook job at1942760; not a whole hosted pass. Individual completed suite and distribution evidence is assessed below; scanner bytes remain1f3f72f. Replacement-v4 was not dispatched and fails independent source novelty. Historical reproductions keep their pinned scanner; prior exposed results remain measured at2ac39aa.",
}
with zipfile.ZipFile(source / "ci-logs.zip") as z:
    assert z.testzip() is None
    for name in z.namelist():
        if name.startswith("Quality (") and name.endswith(
            "Test with branch coverage.txt"
        ):
            data = z.read(name)
            text = data.decode()
            matched = re.search(r"(\d+) passed, (\d+) skipped in ([\d.]+)s", text)
            assert matched, name
            coverage = float(re.search(r"Total coverage: ([\d.]+)%", text)[1])
            assert coverage >= 80
            p["quality"].append(
                {
                    "job": name.split("/")[0],
                    "passed": int(matched[1]),
                    "skipped": int(matched[2]),
                    "seconds": float(matched[3]),
                    "branch_coverage_percent": coverage,
                    "member": name,
                    "sha256": sha(data),
                }
            )
assert len(p["quality"]) == 12 and all(
    r["passed"] == 2194 and r["skipped"] == 36 for r in p["quality"]
)
tracked = set(
    subprocess.check_output(
        ["git", "ls-tree", "-r", "--name-only", head], cwd=root, text=True
    ).splitlines()
)
for archive in sorted((source / "artifacts/ci/portunusmcp-sentinel-dist").iterdir()):
    if archive.suffix == ".whl":
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            members = {n: z.read(n) for n in z.namelist() if not n.endswith("/")}
        mapping = {}
        for n in members:
            if n.startswith("sentinel/_fixtures/"):
                mapping[n] = "tests/fixtures/" + n.removeprefix("sentinel/_fixtures/")
            elif n.startswith("sentinel/_schemas/"):
                mapping[n] = "schemas/" + n.removeprefix("sentinel/_schemas/")
            elif n.startswith("sentinel/"):
                mapping[n] = "src/" + n
    else:
        with tarfile.open(archive) as t:
            members = {m.name: t.extractfile(m).read() for m in t if m.isfile()}
        mapping = {
            n: n.split("/", 1)[1] for n in members if n.split("/", 1)[1] in tracked
        }
    checked = []
    for name, path in mapping.items():
        data = subprocess.check_output(["git", "show", head + ":" + path], cwd=root)
        assert data == members[name], (archive.name, name)
        checked.append({"member": name, "source_path": path, "sha256": sha(data)})
    assert any(
        x["source_path"] == "src/sentinel/static/typescript_path_flow.py"
        for x in checked
    )
    for cassette_stage, fp in [
        (
            "typescript-smoke",
            "b6f0b465a1d2cb7fb4bbbd1b886e4f1a62ba2d3371c766390e07a63130c0293f",
        ),
        ("phase17", "b826810055334d200c918b50ba4d78b12046244ccc02bfa06b83db0b1f928e39"),
    ]:
        assert any(
            x["source_path"] == f"src/sentinel/_cassettes/{cassette_stage}/{fp}.json"
            for x in checked
        )
    p["distributions"].append(
        {
            "path": str(archive.relative_to(b)),
            "sha256": sha(archive.read_bytes()),
            "git_blob_members_verified": checked,
            "remaining_metadata_members": [n for n in members if n not in mapping],
        }
    )
for kind in ["rules", "replay"]:
    paths = list(
        (source / "artifacts/ci" / f"phase20-{kind}-verification").rglob("results.json")
    )
    assert len(paths) == 1
    raw = json.loads(paths[0].read_text())
    p["historical_reproductions"][kind] = {
        "scanner": raw["scanner"],
        "states": dict(Counter(x["state"] for x in raw["outcomes"])),
        "sha256": sha(paths[0].read_bytes()),
    }
out = b / "v23-preparation-quality-audit"
out.mkdir(exist_ok=False)
(out / "packet.json").write_text(json.dumps(p, indent=2) + "\n")
print(
    json.dumps(
        {
            "quality": p["quality"],
            "historical_states": {
                k: v["states"] for k, v in p["historical_reproductions"].items()
            },
            "distribution_members": [
                len(v["git_blob_members_verified"]) for v in p["distributions"]
            ],
        },
        indent=2,
    )
)
