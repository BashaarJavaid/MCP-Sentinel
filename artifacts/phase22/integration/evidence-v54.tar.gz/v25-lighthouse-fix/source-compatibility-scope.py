"""Inspect retained source metadata only; do not scan or execute a corpus input."""
import hashlib,json,subprocess
from collections import Counter
from pathlib import Path
r=Path.cwd();b=r/'artifacts/phase22/integration';o=b/'v25-lighthouse-fix'
p=b/'v21-historical-assessment-refresh-proposal.json';d=json.loads(p.read_text());rows={}
for name,item in d['manifests'].items():
 rows[name]={'manifest_path':item['path'],'manifest_sha256':item['sha256'],'input_count':len(item['input_ids']),'declared_languages':dict(Counter(i['language'] for i in item['inputs'])),'typescript_families':sorted(set(i['family'] for i in item['inputs'] if i['language']=='typescript'))}
assert rows['development']['input_count']==25 and rows['historical']['input_count']==45
q={'basis_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_metadata':rows,'changed_product_files':subprocess.check_output(['git','diff','--name-only','1f3f72f','b830027','--','src'],text=True).splitlines(),'assessment':'The correction changes shared TypeScript discovery/registration/path and URL flows, plus a narrow report qualifier. The development batch contains10 TypeScript inputs and the historical batch14. Earlier three exposed SSRF families are TypeScript. Therefore current full ordered-report/condition compatibility is not claimed by blanket byte equality or by the passing synthetic suite. Approved1f3f72f whole25+45+45 results remain historical passes. A separately justified measurement scope is required where current-source compatible reuse cannot be established; do not pool old Python results with new TypeScript results into a whole-batch pass. The immediate prepared Lighthouse ten-observation gate is independent of those remaining decisions.','scope':'Source metadata and code diff only; no scanner, target or comparator execution.','new_corpus_observations':0,'paid_calls':0}
(o/'source-compatibility-scope.json').write_text(json.dumps(q,indent=2)+'\n');print(rows)
