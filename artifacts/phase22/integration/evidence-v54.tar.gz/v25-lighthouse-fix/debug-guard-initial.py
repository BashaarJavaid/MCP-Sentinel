"""Inspect only the synthetic unit case; never a corpus source."""
import importlib.util
import tempfile
from pathlib import Path

from sentinel.static.rules.sent015 import TypeScriptURLFlow
from sentinel.static.typescript_discovery import name_of


class Debug(TypeScriptURLFlow):
    def function(self, symbol, args, captured=None):
        result = super().function(symbol, args, captured)
        print('FUNCTION', self.program.text(symbol.file, symbol.node)[:65], result.key, self.conditions.get(result.key), self.function_effects)
        return result

    def call(self, file, node, env):
        value = super().call(file, node, env)
        name = name_of(node['Call'][0])
        if name and ('startsWith' in name or 'isIP' in name):
            print('CALL',name,self.conditions.get(value.key), self.url_parts.get(value.key))
        return value

    def statement(self, file, node, env, returned):
        if 'For' in node:
            print('FOR before', {k:v for k,v in env.items() if not k.startswith('#')})
        alive=super().statement(file,node,env,returned)
        if 'For' in node:
            print('FOR after',alive,self.enforced(env),len(returned))
        return alive


spec=importlib.util.spec_from_file_location('unit_test',Path('tests/test_typescript_sdk_wrappers.py'))
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.TypeScriptURLFlow=Debug
with tempfile.TemporaryDirectory() as d:
    m.test_lighthouse_linklocal_guard_remains_narrow(Path(d),True)
