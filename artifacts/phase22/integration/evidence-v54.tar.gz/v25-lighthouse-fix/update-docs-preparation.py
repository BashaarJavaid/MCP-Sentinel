"""Record the authorized correction without changing historical outcomes."""
from pathlib import Path

root = Path(__file__).resolve().parents[4]
common = """The user instructed **“fix it.”** after the replacement-v5 miss. The receipt is
`artifacts/phase22/integration/v25-lighthouse-fix/authorization.json`.
The source correction follows actual module class construction and saved SDK
setter forwarding, recognizes Lighthouse URL sinks, and retains a narrow
link-local IPv4 rejection qualifier. Unknown mutations and unresolved control
flow do not establish protection. The broader SSRF candidate remains visible.

Synthetic verification passes **457 affected tests**, including 35 new cases.
Ruff, formatting and strict mypy pass; the complete local suite and fresh hosted
verification are pending. Product bytes now differ from immutable `1f3f72f`;
prior engineering or corpus results are not a current-source verification claim.
The original scanner worktree, labels, archives and first frozen results remain
unchanged. No additional corpus scan, comparator observation or paid call is
approved by this correction instruction.

The original Lighthouse result remains **0/2 vulnerable hits** in each native
batch and in Semgrep, with all **15/15 observations completed** and the budget
closed. These sources are now exposed; a corrected result would be an exposed
regression, not fresh generalization. The earlier limitation proposal was not
accepted. An exact bounded evaluation proposal, source compatibility checks and
final human technical acceptance remain separate checkpoints. **Phase 22 is
incomplete.** Historical timing and detection passes keep their measured sources;
no old budget is reopened. Paid benchmark/pilots remain deferred, Git campaigns
incomplete (312/1,040), Phase 21 incomplete and Phase 24/15 unchanged.
"""
names = [
    'AGENTS.md', 'ROADMAP.md', 'docs/phase22-technical.md',
    'docs/phase22-implementation-status.md', 'docs/phase22-ssrf-follow-up.md',
    'docs/phase22-timeout-policy.md', 'docs/phase22-corpus-review.md',
    'artifacts/phase22/integration/README.md',
    'artifacts/phase22/integration/requirements.md',
    'artifacts/phase22/integration/progress.md',
]
for name in names:
    path = root / name
    level = '###' if name == 'ROADMAP.md' else '##'
    marker = level + ' Current replacement-v5 result and pending disposition\n'
    text = path.read_text()
    assert text.count(marker) == 1, name
    path.write_text(text.replace(marker, level + ' Current Lighthouse correction under verification\n\n' + common + '\n' + level + ' Historical v24 replacement-v5 result and proposed disposition\n', 1))
(root / 'artifacts/phase22/integration/v25-lighthouse-fix/preparation-status.md').write_text('# Authorized Lighthouse correction\n\n' + common)
