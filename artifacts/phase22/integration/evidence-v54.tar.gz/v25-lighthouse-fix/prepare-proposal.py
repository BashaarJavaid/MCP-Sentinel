"""Bind one source-only exposed-regression proposal at the corrected revision."""
import hashlib,json,subprocess
from pathlib import Path
from scripts.phase20_measurements import scanner_identity
from scripts.phase20_corpus import input_files
from scripts.phase22_corpus import validate
r=Path.cwd(); o=r/'artifacts/phase22/integration/v25-lighthouse-fix'
sha=lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((r/'artifacts/phase22/corpus-replacement-v5/evaluation-proposal.json').read_text())
m=validate(r/old['manifest']['path'])
scanner=scanner_identity(); assert scanner['revision']=='b8300271baadf41621aeb10fb2f4ce6fb865fd7d'
assert not subprocess.check_output(['git','diff','HEAD','--','src','tests','scripts'])
files=json.loads((r/'artifacts/phase22/integration/v23-fresh-v5/binding.json').read_text())['files']
files.pop('.github/workflows/ci.yml',None)
for name,digest in files.items(): assert sha(r/name)==digest,name
for name in ['.github/workflows/ci.yml', 'artifacts/phase22/integration/v25-lighthouse-fix/evaluate.py', 'artifacts/phase22/integration/v24-fresh-v5/assessment.json']:
 files[name]=sha(r/name)
witnesses={}
for i in m.inputs:
 if i.id not in old['input_order']: continue
 tree=input_files(i,next(s for s in m.snapshots if s.revision==i.snapshot))
 text=tree['src/index.ts'].decode().splitlines()
 sinks=[n for n,line in enumerate(text,1) if 'await lighthouse(args.url, options)' in line]
 assert len(sinks)==1
 witnesses[i.id]={'label':i.label,'path':'src/index.ts','source_sha256':hashlib.sha256(tree['src/index.ts']).hexdigest(), 'tree_sha256':i.tree_sha256,'sink_line':sinks[0], 'source_sink':text[sinks[0]-1].strip(), 'condition':i.condition}
p={'status':'prepared_not_approved','scanner':scanner,'lock_sha256':sha(r/'uv.lock'),
'purpose':'Verify the authorized source correction against the now-exposed Lighthouse pair. This is a regression check and never replaces the first frozen fresh miss.',
'corpus':{'manifest':old['manifest']['path'],'sha256':old['manifest']['sha256'],'input_ids':old['input_order'],'treatments':['rules']},
'configuration_path':old['configuration']['path'],'batch_order':['rules-first','rules-repeat'],
'bounds':{'dispatches':1,'native_observations':10,'comparator_observations':0,'profiles':0,'retries':0,'paid_calls':0,'target_execution':False,'normal_target_seconds':120,'native_and_whole_input_maximum_seconds':300,'nominal_input_minutes':50,'cleanup_maximum_seconds_per_input':15,'job_limit_minutes':60,'internal_stop_minutes':58,'reserved_upload_minutes':2},
'runner':'artifacts/phase22/integration/v25-lighthouse-fix/evaluate.py','workflow':'.github/workflows/ci.yml','workflow_input':'phase22_lighthouse_regression','runner_class':'Standard ubuntu-latest; no larger or paid runner upgrade.',
'files_sha256':files,'witnesses':witnesses,
'gate':'Each whole five-input native batch must complete with two vulnerable condition hits and no matching condition alert on the two fixed inputs and control. Require a source-bound SENT-015 candidate at the frozen Lighthouse sink. Vulnerable candidates must not claim initial link-local rejection. Fixed/control candidates must retain the precise link-local rejection qualifier; broader SSRF candidates stay visible and are not counted as an allegation of this narrow condition. Assess every finding, warning and unknown surface after the run; no runtime proof inferred. All five complete ordered repeats must agree after only the existing 11 volatile exclusions.',
'stop':'Stop on the first incomplete, late, identity/schema/cleanup failure, named-condition gate failure or ordered-repeat mismatch. Retain attempted/partial reports; close every unstarted observation on stop. No source/label/guard/deadline change, tuning, retries, comparator or target execution inside the budget. End after ten attempts even if successful.',
'first_frozen_result':{'scanner':old['scanner'],'assessment_path':'artifacts/phase22/integration/v24-fresh-v5/assessment.json','native_hits_per_batch':'0/2','comparator_hits':'0/2','completed':15,'budget_closed':True},
'exposure':'One repository and one correlated vulnerability, curated by the implementation agent. Sources, conditions and misses are exposed. This correction and any subsequent pass cannot be called fresh generalization or independent human review.',
'not_authorized_by_this_proposal':['Historical corpus timing remeasurement','Other exposed-family observations','Another fresh-source evaluation','Any paid call','Merge, release, ready-state or outreach','Final Phase 22 technical acceptance'],
'following_checkpoint':'Source compatibility of all three earlier exposed SSRF families and current-source timing remains to be reconciled after the correction. Prepare the smallest justified verification scope where compatible reuse cannot be established. The fresh evaluation miss still requires an explicit final disposition or separately approved fresh freeze/evaluation; technical acceptance is separate.',
'approval_received':False,'phase22_complete':False}
path=o/'evaluation-proposal.json'; assert not path.exists(); path.write_text(json.dumps(p,indent=2)+'\n')
print('Proposal',sha(path),'scanner',scanner)
