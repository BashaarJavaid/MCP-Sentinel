"""Publish verified engineering and the next exact, still-unapproved checkpoint."""
import hashlib,json
from pathlib import Path
r=Path.cwd();b=r/'artifacts/phase22/integration';o=b/'v25-lighthouse-fix'
q=json.loads((b/'v25-final-quality-audit/packet.json').read_text())
assert len(q['quality'])==12 and all(x['passed']==2230 and x['skipped']==36 for x in q['quality'])
assert json.loads((b/'v25-final-full-suite.json').read_text())['exit_code']==0
proposal=o/'evaluation-proposal-final.json';digest=hashlib.sha256(proposal.read_bytes()).hexdigest()
coverage=[x['branch_coverage_percent'] for x in q['quality']]
local_coverage=json.loads((b/'v25-final-full-suite-coverage.json').read_text())['totals']['percent_covered']
common=f'''The requested Lighthouse source correction is implemented at **`6db3858`**.
It follows actual module class construction and saved SDK setter forwarding,
recognizes Lighthouse URL sinks, and retains narrow initial link-local IPv4
rejection evidence. Replaced/escaped methods, wrong receivers, callback changes,
unknown array aliases and ineffective guards remain conservative. A qualified
finding still leaves other destinations, DNS, redirects and IPv6 unresolved.

The initial `b830027` candidate passed 2,229 tests locally and in all 12 suites,
but a later synthetic import-alias counterexample found another binding gap.
Canonical SDK identity invalidation corrects it at `6db3858`. That counterexample,
the original successful engineering results and both unexecuted proposals are
preserved; no corpus observation was consumed during this correction.

Verification passes **2,230 tests / 36 skips** locally and in all 12 hosted
Linux/macOS/Windows × Python 3.10–3.13 suites. Local branch coverage is **{local_coverage:.2f}%**;
hosted coverage is **{min(coverage):.2f}–{max(coverage):.2f}%**. All **29 normal CI jobs**
and documentation pass at workflow **`51fd2cb`**
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34615835606),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34615835565)).
Wheel/sdist sources are byte-verified. Six actual production requests regenerate
and checked-replay with unchanged fingerprints/request hashes and **zero paid
calls**. The owned Docker demo completes 20/20 attempts with 14 findings and
cleanup; the unchanged approved Git runtime retains 13 incomplete campaigns,
312/1,040 attempts. This demo is separate from corpus evaluation.

The exact **unapproved** proposal is
`artifacts/phase22/integration/v25-lighthouse-fix/evaluation-proposal-final.json`
(SHA-256 `{digest}`). It requests the same five exposed Lighthouse inputs twice:
**ten native observations**, one standard Linux job capped at **60 minutes**,
120-second target / 300-second whole-input maximum, 15-second cleanup cap,
**zero retries, profiles, comparator runs, target execution or paid calls**.
Stop at the first execution, named-condition or ordered-repeat failure and close
all unstarted observations. All four optional corpus jobs are disabled in normal
CI. No corrected-source corpus observation has occurred.

The first fresh result stays **0/2 vulnerable hits** per native batch and in
Semgrep at frozen **`1f3f72f`**: all 15 observations completed, all five ordered
native repeats equal, zero findings, unknown tool coverage and 232 source-assessed
diagnostics. Its budget is closed. The user chose correction rather than accepting
the limitation-only proposal. Any corrected Lighthouse result is an exposed
regression, not fresh generalization or independent human review.

The **89-row audit is 82 passed, two user-deferred and five unresolved**;
66 added rows are 61 passed and five unresolved, including three closed historical
failures. Current-source compatibility of the three earlier exposed SSRF families
and whole timing/condition gates remains to be established after the TypeScript
changes. Their passes retain measured `2ac39aa` / `1f3f72f`; no pooled or new
whole-batch claim, silent waiver or reopened budget. R66/R88 and explicit final
human technical acceptance remain open. **Phase 22 is incomplete.** Paid benchmark
and pilots remain deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge,
release, ready-state, outreach or Phase 23 work. “v25” names evidence only.
'''
names=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','docs/phase22-timeout-policy.md','docs/phase22-corpus-review.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/requirements.md','artifacts/phase22/integration/progress.md']
for name in names:
 p=r/name;s=p.read_text();level='###' if name=='ROADMAP.md' else '##';start=s.index(level+' Current Lighthouse correction under verification\n');end=s.index(level+' Historical v24 replacement-v5 result and proposed disposition\n',start)
 s=s[:start]+level+' Current Lighthouse correction and evaluation checkpoint\n\n'+common+'\n'+s[end:]
 if name=='artifacts/phase22/integration/README.md':
  s=s.replace('batches 1–53','batches 1–54',1)
  marker=level+' Current Lighthouse correction and evaluation checkpoint\n\n'
  s=s.replace(marker,marker+'Review the [correction summary](v25-lighthouse-fix/summary.md),\n[89 + 66 row audit](v25-lighthouse-fix/audit.json) and [exact unapproved proposal](v25-lighthouse-fix/evaluation-proposal-final.json).\nRestore seal 54 after seals 1–53 using the existing numeric-order procedure;\nverify every archive/member hash and preserve earlier results unchanged.\n\n',1)
 p.write_text(s)
p=r/'ARCHITECTURE.md';s=p.read_text();s=s.replace('Correction\nverification is in progress; no new corpus result or generalization is claimed.','Engineering\nverification passes at `51fd2cb`; the exposed evaluation remains unapproved.\nNo corrected-source corpus result or generalization is claimed.',1);p.write_text(s)
(o/'summary.md').write_text('# Phase 22 corrected Lighthouse checkpoint\n\n'+common+'''
The user’s correction receipt, synthetic failure history, source snapshot binding,
current local checks, runtime/replay compatibility and source-only prior-gate scope
review are retained in this directory. The complete hosted artifacts/logs and
package source audit are in `../v25-final-quality/` and `../v25-final-quality-audit/`.
All earlier evidence seals remain unchanged; the new seal includes the correction
and its verification. Final documentation/delivery bindings are supplemental.

The next decision approves only the exact ten-observation exposed regression.
It does not approve additional historical/fresh experiments or final technical
acceptance. Further current-source gates and the first fresh miss must receive
an explicit disposition before Phase 22 acceptance is requested.
''')
(o/'pr-body.md').write_text('Phase 22 integrates bounded source discovery, containment/SSRF/credential findings, workspace coverage and ordered runtime campaigns. Technical acceptance remains open.\n\n'+common+'\nReview `artifacts/phase22/integration/v25-lighthouse-fix/summary.md`, its full audit, and the exact unapproved evaluation proposal. Original held-out misses, the v4 novelty failure, all earlier failed attempts/errata and measured source bindings remain preserved in evidence seals 1–54.\n')
print('Updated final owning docs and draft body; no technical acceptance inferred.')
