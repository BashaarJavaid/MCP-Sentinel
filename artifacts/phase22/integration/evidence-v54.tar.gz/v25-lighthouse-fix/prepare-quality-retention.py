"""Retain the complete ordinary CI results at this correction's workflow."""
import json
from pathlib import Path
b=Path('artifacts/phase22/integration'); o=b/'v25-lighthouse-fix'
s=(b/'v23-fresh-v5/retain-quality.py').read_text()
s=s.replace('v23-v5-quality','v25-quality').replace('v23-v5-run-ids.json','v25-run-ids.json')
s=s.replace('"frozen_product_scanner": "1f3f72f0f25c597b53c9f833e2e4bec99728d328"','"frozen_product_scanner": "b8300271baadf41621aeb10fb2f4ce6fb865fd7d"')
a=s.index('    "classification": ('); e=s.index('\n    ),',a)+len('\n    ),')
s=s[:a]+'''    "classification": "Fresh ordinary CI for the corrected scanner b830027 at workflow f9b1102. Optional exposed corpus evaluation remains unapproved and skipped. Historical reproductions retain pinned scanner8824014; no current-source corpus run or paid call.",'''+s[e:]
(o/'retain-quality.py').write_text(s)
(b/'v25-run-ids.json').write_text(json.dumps({'ci':34611522522,'docs':34611522526},indent=2)+'\n')
