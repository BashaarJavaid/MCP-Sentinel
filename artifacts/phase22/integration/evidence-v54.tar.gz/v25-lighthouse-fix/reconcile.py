"""Reconcile every requirement after the authorized correction's engineering checks."""
import copy,hashlib,json,xml.etree.ElementTree as ET
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
r=Path.cwd();b=r/'artifacts/phase22/integration';o=b/'v25-lighthouse-fix'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((b/'v24-fresh-v5/audit.json').read_text());p=copy.deepcopy(old)
quality=json.loads((b/'v25-final-quality-audit/packet.json').read_text()); assert len(quality['quality'])==12 and all(x['passed']==2230 and x['skipped']==36 for x in quality['quality'])
assert json.loads((b/'v25-final-full-suite.json').read_text())['exit_code']==0
assert json.loads((o/'local-source-binding-final.json').read_text())['current_product_tests_packages_equal_corrected_commit']
proposal=json.loads((o/'evaluation-proposal-final.json').read_text());assert not proposal['approval_received']
counts=defaultdict(Counter)
for tc in ET.parse(b/'v25-final-full-suite-junit.xml').iter('testcase'):
 state='skipped' if tc.find('skipped') is not None else 'failed' if tc.find('failure') is not None or tc.find('error') is not None else 'passed'
 counts[tc.attrib['classname'].replace('.','/')+'.py'][state]+=1
assert sum(x['passed'] for x in counts.values())==2230 and sum(x['skipped'] for x in counts.values())==36
assert counts['tests/test_typescript_sdk_wrappers.py']['passed']==36
refs=['v25-final-quality/packet.json','v25-final-quality-audit/packet.json','v25-final-full-suite.json','v25-final-full-suite-junit.xml','v25-final-full-suite-coverage.json','v25-final-production-capture-revalidation/packet.json','v25-lighthouse-fix/compatibility-final.json','v25-lighthouse-fix/source-compatibility-scope-final.json','v25-lighthouse-fix/local-source-binding-final.json','v25-lighthouse-fix/authorization.json','v25-lighthouse-fix/evaluation-proposal-final.json','v25-lighthouse-fix/failure-assessment.json','v25-lighthouse-fix/alias-correction.json','v25-lighthouse-fix/alias-regression-before.log','v25-lighthouse-fix/alias-regression-after.log','v25-lighthouse-fix/final-preparation-pr-readback.json']
for row in p['requirements']:
 row['prior_requirement_record_sha256']=hashlib.sha256(json.dumps(next(x for x in old['requirements'] if x['id']==row['id']),sort_keys=True).encode()).hexdigest()
 row['historical_assessment']={'audit':'v24-fresh-v5/audit.json','text':row['assessment']}
 row['interpretation']='Historical measurements and explicit scope decisions keep their original source and budget. Corrected scanner6db3858 receives fresh engineering atworkflow51fd2cb, but no corrected-source corpus observation. Proposed Lighthouse exposed regression is not approved. No human technical acceptance.'
 row['evidence'].extend('artifacts/phase22/integration/'+x for x in refs)
 if row['id'] in {'R66','R88'}:
  row['disposition']='unresolved';row['assessment']='The approved first fresh Lighthouse evaluation completed15/15 at1f3f72f, with0/2 vulnerable hits per native batch and comparator, and232 source-assessed diagnostics. The user requested correction instead of accepting the proposed limitation. Corrected source is now exposed and synthetic-tested; its prepared ten-observation regression requires exact approval. No new independent fresh-source or accepted limitation claim; final disposition remains open.'
 elif row['id'] in {'R87','R89'}:
  row['disposition']='unresolved';row['assessment']='The recorded2ac39aa exposed gate remains a historical pass. This correction changes shared TypeScript discovery/flow, so current-source compatibility is not asserted from byte equality. Source-compatible current regression evidence remains required; no old observation budget is reopened.'
 elif row['id']=='R84':
  row['assessment']='Final human technical acceptance remains unrequested and unreceived. The user requested a correction, not acceptance. Pilots remain explicitly removed as a prerequisite; Phase22 incomplete.'
 elif row['id'] in {'R62','R83'}:
  row['assessment']='Owning docs distinguish the corrected and verified scanner from the preserved first fresh miss, the unapproved exposed-regression proposal, historical source-bound passes, remaining current-source compatibility gates and final human acceptance. Phase22 remains incomplete; paid/pilot deferrals and later-phase gates are unchanged.'
 elif row['id'] in {'R44','R70','R75','R76'}:
  row['assessment']+=' Current correction: six actual production requests regenerated and accepted with exactly the prior fingerprints/request hashes, zero paid calls. The approved Git image and runtime/catalog/config/report components match retained evidence; all13 Git campaigns remain incomplete312/1040, with no new Git execution.'
 elif row['id'] in {'R71','R72','R73','R74'}:
  row['assessment']='Current local and all12 hosted suites pass2230 tests/36 skips, with branch coverage above80%. All29 normal jobs and docs pass atworkflow51fd2cb; wheel/sdist members bind exact Git source. Ruff/format/strict mypy/lock/schemas/artifacts/notices, audit, hooks, installed-wheel consumers, Docker and isolation checks pass. Local source snapshot is byte-bound to corrected6db3858; no new corpus run is inferred.'
 elif row['id'] in {'R63','R64','R65','R18','R19','R20','R21','R22','R23','R24','R25','R26','R27'}:
  row['assessment']+=' Retained historical-source gate only: this is not a whole-batch remeasurement at6db3858. Current-source empirical compatibility is separately unresolved inV25-PRIOR-COMPATIBILITY.'
for row in p['additional_scope_requirements']:
 if row['id']=='V24-LIMITATION-DISPOSITION':
  row['disposition']='passed';row['assessment']='The user explicitly requested fixing the miss. This chooses correction rather than accepting the limitation-only proposal. The detector miss remains historical and R66/R88 remain unresolved; no detection hit or technical acceptance follows.';row['evidence'].append('artifacts/phase22/integration/v25-lighthouse-fix/authorization.json')
additions=[
 ('V25-AUTH','Record the requested correction, preserve the frozen scanner and prohibit new observations/paid calls without approval','passed'),
 ('V25-CORRECTION','Follow source-established SDK forwarding/class startup and narrow URL guard evidence with synthetic counterexamples','passed'),
 ('V25-ENGINEERING','Fresh local/hosted quality, packaging, exact production replay and runtime compatibility','passed'),
 ('V25-PROPOSAL','Prepare one exact bounded exposed Lighthouse regression without executing it','passed'),
 ('V25-EXPOSED-REGRESSION','Obtain exact approval and complete/source-assess the corrected Lighthouse repeat gate','unresolved'),
 ('V25-PRIOR-COMPATIBILITY','Establish current-source compatibility of earlier exposed and timing/condition gates without pooling or relabeling historical batches','unresolved'),
]
p['additional_scope_requirements'].extend({'id':i,'requirement':s,'disposition':d,'evidence':['artifacts/phase22/integration/'+x for x in refs]} for i,s,d in additions)
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='51fd2cb41e02a6a76ccefea2ffda694bb706ba28',scanner_identity=proposal['scanner'],workflow_tested_source='51fd2cb41e02a6a76ccefea2ffda694bb706ba28',current_tests_by_file=dict(counts),current_source_corpus_runs=0,technical_acceptance_requested=False,technical_acceptance_received=False,new_paid_calls=0,phase22_complete=False,fresh_limitation_disposition_received=True,fresh_limitation_accepted=False,fresh_limitation_disposition="User chose source correction; no limitation acceptance.",status='Authorized source correction passes current engineering; exposed Lighthouse evaluation unapproved, earlier gate compatibility and final fresh/human disposition remain unresolved.',prior_audit={'path':'v24-fresh-v5/audit.json','sha256':sha(b/'v24-fresh-v5/audit.json')},owning_document_binding='Final v25 documentation/delivery bindings are separate from this pre-seal audit.',per_file_test_counts_basis='Actual completed final v25 full-suite JUnit; committed source independently byte-bound to corrected6db3858.',full_sequence_status_basis='Historical approved1f3f72f result only; current-source compatibility remains unresolved.')
p['fresh_evaluation_status_basis']='The approved first frozen15-observation evaluation at1f3f72f only. Its misses and source assessment remain unchanged; this does not approve or execute the corrected-source exposed proposal.'
p['current_exposed_evaluation_approved']=False
p['current_exposed_evaluation_executed']=False
p['historical_source_and_test_file_bindings']={'source':old['source'],'files':old['current_source_and_test_files'],'earlier':old['historical_source_and_test_file_bindings']}
p['current_source_and_test_files']={name:sha(r/name) for name in old['current_source_and_test_files']};p['current_source_and_test_files']['tests/test_typescript_sdk_wrappers.py']=sha(r/'tests/test_typescript_sdk_wrappers.py')
p['references_sha256'].update({n:sha(b/n) for n in refs})
p['dispositions']=dict(Counter(x['disposition'] for x in p['requirements']));p['additional_scope_dispositions']=dict(Counter(x['disposition'] for x in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==66
assert p['dispositions']=={'passed':82,'explicitly user-deferred':2,'unresolved':5}
assert p['additional_scope_dispositions']=={'passed':61,'unresolved':5}
dest=o/'audit.json';assert not dest.exists();dest.write_text(json.dumps(p,indent=2)+'\n');print(p['dispositions'],p['additional_scope_dispositions'])
