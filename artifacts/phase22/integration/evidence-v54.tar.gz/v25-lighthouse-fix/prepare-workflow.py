"""Add a separately gated exposed-regression job; ordinary CI remains required."""
from pathlib import Path
p=Path('.github/workflows/ci.yml')
s=p.read_text()
assert 'phase22_lighthouse_regression' not in s
marker='  workflow_call:\n'
s=s.replace(marker, '      phase22_lighthouse_regression:\n        description: Run only the separately approved exposed Lighthouse regression\n        type: boolean\n        default: false\n'+marker, 1)
s=s.replace('!inputs.phase22_fresh_v5 }}', '!inputs.phase22_fresh_v5 && !inputs.phase22_lighthouse_regression }}')
s=s.replace("&& github.ref == 'refs/heads/phase22/integration' }}", "&& !inputs.phase22_lighthouse_regression && github.ref == 'refs/heads/phase22/integration' }}")
s+='''
  phase22-lighthouse-regression:
    name: Approved Phase 22 exposed Lighthouse regression
    if: ${{ github.event_name == 'workflow_dispatch' && inputs.phase22_lighthouse_regression && !inputs.phase22_fresh_v5 && !inputs.phase22_historical && github.ref == 'refs/heads/phase22/integration' }}
    runs-on: ubuntu-latest
    timeout-minutes: 60
    steps:
      - name: Start the internal deadline and reserve upload time
        run: >-
          python3 -c 'import os, pathlib, time;
          pathlib.Path(os.environ["RUNNER_TEMP"], "phase22-lighthouse-deadline").write_text(str(time.monotonic() + 3480))'
      - name: Check out the approved runner and bindings
        uses: actions/checkout@34e114876b0b11c390a56381ad16ebd13914f8d5
        with:
          persist-credentials: false
      - name: Check out the immutable corrected scanner
        uses: actions/checkout@34e114876b0b11c390a56381ad16ebd13914f8d5
        with:
          ref: b8300271baadf41621aeb10fb2f4ce6fb865fd7d
          path: .phase22-scanner
          persist-credentials: false
      - name: Set up Python
        uses: actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065
        with:
          python-version: "3.12"
      - name: Set up uv
        uses: astral-sh/setup-uv@d0cc045d04ccac9d8b7881df0226f9e82c39688e
        with:
          version: 0.8.22
      - name: Install locked scanner dependencies
        working-directory: .phase22-scanner
        run: uv sync --frozen --extra dev --python 3.12
      - name: Run the exact approved ten exposed observations
        working-directory: .phase22-scanner
        env:
          PATH: ${{ github.workspace }}/.phase22-scanner/.venv/bin:/usr/local/bin:/usr/bin:/bin
        run: >-
          .venv/bin/python -I ../artifacts/phase22/integration/v25-lighthouse-fix/evaluate.py run
          "${{ runner.temp }}/phase22-lighthouse-regression"
          "${{ runner.temp }}/phase22-lighthouse-deadline"
      - name: Retain every attempt, including failures
        if: always()
        uses: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02
        with:
          name: phase22-lighthouse-regression
          path: ${{ runner.temp }}/phase22-lighthouse-regression
          if-no-files-found: error
'''
p.write_text(s)
