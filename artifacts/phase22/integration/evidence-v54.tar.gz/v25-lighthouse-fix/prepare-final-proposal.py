"""Supersede the unexecuted proposal after the SDK alias regression correction."""
import hashlib,json,subprocess
from pathlib import Path
from scripts.phase20_measurements import scanner_identity
r=Path.cwd();o=r/'artifacts/phase22/integration/v25-lighthouse-fix';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((o/'evaluation-proposal.json').read_text());p=json.loads((o/'evaluation-proposal.json').read_text())
scanner=scanner_identity();assert scanner['revision']=='6db3858f1368033642354ab5ebb53aef76315a16'
assert not subprocess.check_output(['git','diff','HEAD','--','src','tests','scripts'])
runner=(o/'evaluate.py').read_text().replace('ASSETS / "evaluation-proposal.json"','ASSETS / "evaluation-proposal-final.json"').replace('ASSETS / "evaluation-authorization.json"','ASSETS / "evaluation-authorization-final.json"')
(o/'evaluate-final.py').write_text(runner)
w=r/'.github/workflows/ci.yml';s=w.read_text();assert s.count('ref: b8300271baadf41621aeb10fb2f4ce6fb865fd7d')==1
s=s.replace('ref: b8300271baadf41621aeb10fb2f4ce6fb865fd7d','ref: '+scanner['revision']).replace('v25-lighthouse-fix/evaluate.py run','v25-lighthouse-fix/evaluate-final.py run');w.write_text(s)
p['scanner']=scanner;p['runner']='artifacts/phase22/integration/v25-lighthouse-fix/evaluate-final.py'
p['supersedes']={'path':'artifacts/phase22/integration/v25-lighthouse-fix/evaluation-proposal.json','sha256':sha(o/'evaluation-proposal.json'),'reason':'Additional synthetic import-alias regression failed at b830027. Shared constructor identity invalidation corrects it at6db3858; all458 affected tests pass. Neither proposal was approved or executed.'}
p['files_sha256']['.github/workflows/ci.yml']=sha(w)
p['files_sha256'][p['runner']]=sha(o/'evaluate-final.py')
p['files_sha256']['artifacts/phase22/integration/v25-lighthouse-fix/alias-correction.json']=sha(o/'alias-correction.json')
assert p['bounds']==old['bounds'] and p['corpus']==old['corpus'] and p['witnesses']==old['witnesses']
path=o/'evaluation-proposal-final.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print('Final proposal',sha(path),scanner)
