"""Version current-source verification separately from the first candidate."""
from pathlib import Path
p=Path('artifacts/phase22/integration/v25-lighthouse-fix')
source_old='b8300271baadf41621aeb10fb2f4ce6fb865fd7d';source_new='6db3858f1368033642354ab5ebb53aef76315a16'
workflow_old='f9b1102b1cbfc31619528f7a24ce143f9bdc7b6a';workflow_new='51fd2cb41e02a6a76ccefea2ffda694bb706ba28'
for old,new in [('retain-quality.py','retain-final-quality.py'),('audit-quality.py','audit-final-quality.py'),('verify-compatibility.py','verify-final-compatibility.py')]:
 s=(p/old).read_text().replace('v25-quality','v25-final-quality').replace('v25-run-ids','v25-final-run-ids').replace('v25-checkout-binding','v25-final-checkout-binding').replace('v25-production-capture-revalidation','v25-final-production-capture-revalidation').replace(source_old,source_new).replace(workflow_old,workflow_new).replace('b830027','6db3858').replace('f9b1102','51fd2cb').replace('2229','2230')
 if new=='verify-final-compatibility.py': s=s.replace("'compatibility.json'","'compatibility-final.json'")
 (p/new).write_text(s)
for name in ['reconcile.py','final-docs.py','seal.py','delivery-bindings.py']:
 s=(p/name).read_text().replace('v25-quality','v25-final-quality').replace('v25-full-suite','v25-final-full-suite').replace('v25-production-capture-revalidation','v25-final-production-capture-revalidation').replace(source_old,source_new).replace(workflow_old,workflow_new).replace('b830027','6db3858').replace('f9b1102','51fd2cb').replace('2229','2230').replace('2,229','2,230').replace('compatibility.json','compatibility-final.json').replace('local-source-binding.json','local-source-binding-final.json').replace('local-checks.json','local-checks-final.json').replace('evaluation-proposal.json','evaluation-proposal-final.json').replace('evaluation-authorization.json','evaluation-authorization-final.json').replace('preparation-pr-readback.json','final-preparation-pr-readback.json').replace('34611522522','34615835606').replace('34611522526','34615835565')
 if name=='reconcile.py': s=s.replace("['passed']==35","['passed']==36")
 if name=='final-docs.py':
  s=s.replace("coverage=[x['branch_coverage_percent'] for x in q['quality']]", "coverage=[x['branch_coverage_percent'] for x in q['quality']]\nlocal_coverage=json.loads((b/'v25-final-full-suite-coverage.json').read_text())['totals']['percent_covered']")
  s=s.replace('**89.76%**','**{local_coverage:.2f}%**')
  s=s.replace('Verification passes **2,230', '''The initial `b830027` candidate passed 2,229 tests locally and in all 12 suites,
but a later synthetic import-alias counterexample found another binding gap.
Canonical SDK identity invalidation corrects it at `6db3858`. That counterexample,
the original successful engineering results and both unexecuted proposals are
preserved; no corpus observation was consumed during this correction.

Verification passes **2,230''')
 (p/name).write_text(s)
