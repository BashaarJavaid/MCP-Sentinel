"""Verify the precommit full-suite source snapshot against the corrected commit."""
import hashlib,json,subprocess,tarfile,tempfile
from pathlib import Path
r=Path.cwd();b=r/'artifacts/phase22/integration';o=b/'v25-lighthouse-fix'
metadata=json.loads((b/'v25-full-suite.json').read_text())
assert metadata['exit_code']==0
assert metadata['source_commit']=='d466c8ba374eabdc74e0cc71734ab17741c41591'
sha=lambda d:hashlib.sha256(d).hexdigest()
patch=(b/'v25-full-suite.patch').read_bytes();assert sha(patch)==metadata['diff_sha256']
corrected='b8300271baadf41621aeb10fb2f4ce6fb865fd7d'
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',corrected,'--','src'],text=True).splitlines()
with tempfile.TemporaryDirectory(prefix='phase22-v25-source-binding-') as tmp:
 root=Path(tmp)
 for name in paths:
  p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(subprocess.check_output(['git','show',metadata['source_commit']+':'+name]))
 subprocess.run(['git','apply','--include=src/**','--unsafe-paths','-'],input=patch,cwd=root,check=True)
 for name in paths: assert (root/name).read_bytes()==subprocess.check_output(['git','show',corrected+':'+name]),name
archive=b/metadata['untracked_source_archive'];assert sha(archive.read_bytes())==metadata['untracked_source_sha256']
with tarfile.open(archive) as t:
 test=t.extractfile('tests/test_typescript_sdk_wrappers.py').read()
 assert test==subprocess.check_output(['git','show',corrected+':tests/test_typescript_sdk_wrappers.py'])
assert not subprocess.check_output(['git','diff',corrected,'HEAD','--','src','tests','scripts','schemas','tests/fixtures','pyproject.toml','uv.lock','action.yml'])
p={'corrected_scanner':corrected,'wrapper_source_before_commit':metadata['source_commit'],'wrapper_patch_sha256':metadata['diff_sha256'],'untracked_test_archive_sha256':metadata['untracked_source_sha256'],'all_product_files_match_corrected_commit':len(paths),'new_test_matches_corrected_commit':True,'current_product_tests_packages_equal_corrected_commit':True,'full_suite_sha256':sha((b/'v25-full-suite.json').read_bytes())}
(o/'local-source-binding.json').write_text(json.dumps(p,indent=2)+'\n');print('Full-suite snapshot bound:',len(paths),'product files plus new tests.')
