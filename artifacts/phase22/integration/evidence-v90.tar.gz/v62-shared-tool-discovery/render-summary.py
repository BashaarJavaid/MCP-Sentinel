"""Render reviewable candidate evidence without treating engineering as technical acceptance."""
import hashlib,json
from pathlib import Path
out=Path(__file__).resolve().parent; base=out.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(out/'audit.json');f=read(out/'freeze.json');p=read(out/'evaluation-proposal.json');local=read(out/'local-checks.json')
assert a['engineering_passed'] and not a['regression_approved']
c=local['coverage_totals'];branch=100*c['covered_branches']/c['num_branches']
summary=f'''# Shared TypeScript discovery verified; regression approval pending

**The one approved source-only attempt passes synthetic and full local/hosted engineering at `1948bf9`. No current-source corpus observation or profile has run. Phase 22 remains incomplete.**

The exact user decision `approved` binds [authorization](authorization.json) to the v61 proposal SHA-256 `2f32e71cf4a90b43c33cdea253cdffac1296ab9308086c352c90bbcf6e75619c`. The one implementation attempt is consumed and closed. Candidate `{f['scanner']['revision']}` has source SHA-256 `{f['scanner']['source_sha256']}` and harness SHA-256 `{f['scanner']['harness_sha256']}`. [Freeze](freeze.json) records the complete clean checkout at `{f['frozen_checkout']}`. The locked dependencies, existing four workers, shared 1800-second deadline and 15-second cleanup policy are unchanged.

## Source and synthetic assessment

[Source proof](source-proof.json) establishes that the original `tools()` discovery traversal is AST-identical to `_discover_tools()`. Only three product files change: `typescript_discovery.py`, `model.py`, and `workers.py`. Two existing test files and the changelog also change; every other mapped engineering input retains its baseline bytes. Registration discovery completes once in the parent and is reused by the existing four workers and parent coverage. The snapshot carries files, trees, synthetic import bindings, ordered tools, warnings and module option effects in one pickle graph; workers rebuild their integer identity indexes. There is no global or cross-scan cache, HTTP-result cache, pruning, new dependency or resource change.

The public consumption path restores warning and option-cache effects at their original point, preserving ordered deduplication. Every rule-specific analysis still executes. Empty completed discovery remains a valid result; failed, interrupted or expired production cannot install a cached success. Reuse checks the deadline even when a result already exists. A different source identity cannot borrow a snapshot.

[Equivalence](discovery-equivalence.json) records **125 complete original-versus-candidate discovery comparisons** across **157 existing scanner-owned tests**, preserving all ordered binding fields, warnings and module options. The **272-test affected suite** also passes. New cold/warm and pickle controls cover direct, factory, class, empty and rebound registrations, source ranges, file/tree/node aliases and restored synthetic imports. Every SENT-012–016 complete rule state is compared. Full serial/parallel reports agree for Python, TypeScript and declared mixed workspaces, including findings, ordered warnings, summary, coverage/surfaces and incomplete state under the existing volatile handling. Call accounting establishes one eligible TypeScript producer, zero worker producers and every detector invocation. Existing small-input, selected-rule, module/workspace, SDK/constructor/setter, target-import and cleanup paths remain covered by the complete suites.

The v61 partial profile identified duplicate discovery work, but these checks measure semantic equivalence and avoided invocation only. **No native speedup, removable-cost fraction, complete FAF runtime or 1800-second completion is established.** Discovery itself and later rule-specific/HTTP/coverage work may still exceed the limit.

## Engineering and compatibility

[Local checks](local-checks.json) and the [hosted audit](../v62-candidate-quality-audit/packet.json) bind **2,418 passed / 36 skipped** locally and in every one of **12 hosted suites**. All **29 normal CI jobs** and docs pass in [34793663094](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34793663094) / [34793663105](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34793663105). The actual synthetic merge checkout `a93b425c925cd2dcaa57371597656767a32ede34` has the exact candidate tree. Combined statement/branch coverage is **{c['percent_covered']:.2f}%**, branch-only **{branch:.2f}%**; these are distinct metrics.

Strict lint, formatting and mypy, locked dependency consistency/advisory audit, schemas, third-party notices, offline artifacts and strict docs pass. Built wheel/sdist members bind actual candidate Git blobs; the hosted matrix covers installed distributions, Docker, isolation, Action and hook behavior. Historical Phase 20 rules/replay CI jobs retain their explicit `8824014` scanner binding; they are not new candidate corpus observations. Four optional evaluation jobs remain skipped.

[Runtime compatibility](compatibility.json) binds **six entire production requests**, regenerated through production and checked-replayed exactly against approved captures with **zero model calls**, plus 19 unchanged runtime components and the approved image. The owned synthetic Docker demo retains 20 attempts and 14 findings. Historical two paid calls remain $0.071799; no new paid call occurred. Git campaigns are not rerun.

[Initial check failures](check-failure-assessment.json) remain visible with their source snapshots, logs and corrections: new test imports/formatting, unsupported fixture language override, undeclared mixed workspace, and one long string. These were fixture/lint failures; there was no product equivalence failure. Sandbox/read-only helper access errors are retained separately. Final successful results do not erase these initial attempts.

## Exact separate evaluation proposal

[Proposal](evaluation-proposal.json), SHA-256 `{sha(out/'evaluation-proposal.json')}`, is **prepared, unapproved and unexecuted**. [Launcher binding](launcher-binding.json) and [rubric](scoring-rubric.json) preserve the exact original source records, labels, complete report references, named sinks, fixed/control prerequisites, qualification rules and ordered schedule:

| Scope | Observations |
| --- | ---: |
| Four exposed repositories: FAF, no-bash, Lightning Python, Engram | 24 |
| Earlier TypeScript compatibility | 94 |
| Earlier Python compatibility | 87 |
| Total | **205 on 110 inputs, 95 entire ordered pairs** |

The shared worker orchestration affects both languages and mixed workspaces; prior shared recovery still lacks completed current-source regression. Both language schedules therefore remain necessary. Fifteen Python development inputs run once; no extra repeats or combined whole Linux batch are claimed.

One serial local macOS sequence uses the existing locked interpreter and frozen scanner. Bounds: **1800 seconds per native/whole input**, **15 seconds cleanup**, **120 seconds informational target**, and **6275 minutes outer cap** (104 hours 35 minutes), with 6274 minutes internal stop. This is a worst-case bound, not a runtime estimate. Evaluator bytes exactly match v59; only the launcher output directory changes. Eight deadline controls and the existing synthetic condition/process-group checks pass. Missing-approval preflight rejects before creating a launch token or future output directory. All 110 selected source records and their complete manifests validate without scanner or target execution.

There are **zero retries, profiles, comparators, new repositories, target executions or paid calls**. Infrastructure, identity, execution, native/whole timeout, schema, cleanup or ordered-repeat failure stops and closes the entire unused budget. Detection/support failures remain results for source assessment after the other authorized observations. No tuning or substitution occurs during collection. All 95 entire ordered report pairs must agree after only the established 11 volatile exclusions; no sorting or omission is added.

Actual source assessment must cover all four-repository findings, diagnostics and surfaces, plus every change on previous-language inputs against bound full reports. Quiet unsupported paths do not pass. FAF must carry the caller path to the actual read; no-bash must carry the checked return to actual write; Lightning must establish the actual HTTPX route and terminal literal link-local rejection; Engram must establish the initial home guard and actual manifest write while retaining unresolved reconstructed-path containment. Narrow lexical/physical and resolved-copy qualifiers are not broad runtime safety. Every historical source-support condition and erratum remains.

## Historical gates and acceptance

[The audit](audit.json) preserves **all 335 prior rows** and adds ten: **345 total, 89 original + 256 added**. Each prior row remains byte-equivalent, except V61 delivery and optimization decision retain their complete previous rows alongside actual receipts. Current-source/test hashes and test counts are provided for every prior requirement; old corpus passes remain at their actual scanner sources. Before supplemental delivery, original rows retain 84 passed, two user-deferred, two proposed limitations and one unresolved human acceptance. Added rows have 234 passed, six proposed historical closures and 16 unresolved. No limitation is accepted by the agent.

All five native timeouts at `17b4784`, `6e4fd67`, `a36f696`, `dc73715` and `7bf4c6e` remain one incomplete plus 204 unstarted closed each. Four valid partial profiles retain 86,659 / 79,307 / 78,769 / 432,756 samples at their actual sources. The invalid stale-worker-root attempt remains invalid and V49-DIAGNOSTIC-PREPARATION unresolved. Both singleton equivalence failures remain closed and unaccepted; the later separately approved credential correction does not erase them. No previous budget is reused.

The original four-source fresh evaluation at `2e0efb2` retains 24 complete observations and 12 equal ordered pairs, but **all four repository gates failed**: FAF, Lightning and Engram missed named vulnerable sinks; no-bash had fixed/control false alerts. Later results are exposed regression. Earlier TS94/47 pairs at `2e0efb2`, Python87/36 pairs at `8c62567`, and whole25 development reuse plus45+45 Linux at `1f3f72f` retain exact source bindings and the Meta operator erratum. Original memory-keeper false alerts, DDG unsupported fixed-send path and incorrect TypeScript metadata despite Python execution, Lighthouse misses, and held-out10 complete/10 unsupported/5 incomplete with zero hits among four completed vulnerable inputs out of ten vulnerable total remain visible.

Engineering and same-agent assessment do not establish independent human validation, training-data novelty, broad accuracy or runtime safety. Git remains **312/1,040 incomplete**, 728 deferred; paid benchmark/pilots deferred, Phase21 incomplete, Phase24/15 unchanged. **Phase22 remains incomplete** pending separately authorized current-source evaluation and actual gate/source assessment, then explicit human technical acceptance and verified accepted closeout. Approval of this source change is neither evaluation approval nor technical acceptance. No merge, ready-state change, release, outreach or Phase23 is authorized.
'''
(out/'summary.md').write_text(summary)
url='https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v62-shared-tool-discovery/'
body=f'''Static workers repeatedly computed the same TypeScript tool discovery. Candidate `1948bf9` now shares its completed result through the existing worker IPC and parent coverage, preserving ordered warnings, source-node identity and every rule-specific analysis.

[Review packet]({url}summary.md) · [345-row audit]({url}audit.json) · [exact regression proposal]({url}evaluation-proposal.json)

Synthetic equivalence and full engineering pass: 2,418 tests / 36 skips locally and in all 12 hosted suites; all 29 normal CI jobs and docs pass. Six complete production requests replay identically with zero paid calls. No native speedup or 1800-second completion is established.

The separate regression is unapproved and unexecuted:205 observations on110 inputs/95 ordered pairs (24 four-source+94 TypeScript+87 Python),1800-second input maximum,15-second cleanup,6275-minute worst-case outer cap. No retry/profile/comparator,new repository,target execution or paid call. All historical failures and closed budgets remain preserved.

Phase22 remains incomplete pending actual current-source gates, separate explicit human technical acceptance and accepted closeout. Git312/1040 remains incomplete; paid benchmark/pilots deferred,Phase21 incomplete,Phase24/15 unchanged. No merge,ready-state,release,outreach or Phase23.
'''
(out/'pr-body.md').write_text(body)
print('Rendered complete review packet and concise draft PR description.')
