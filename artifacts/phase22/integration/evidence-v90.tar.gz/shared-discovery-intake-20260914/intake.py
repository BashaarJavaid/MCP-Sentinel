"""Read-only handoff verification; performs no scan or optimization attempt."""

import hashlib
import importlib
import importlib.metadata
import json
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/private/tmp/mcp-phase22-options')
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'artifacts/phase22/integration/v61-faf-long-timeout-sampling'


def run(*args):
    return subprocess.check_output(args, cwd=ROOT, text=True)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


binding = json.loads((BASE / 'documentation-binding.json').read_text())
proposal = json.loads((BASE / 'optimization-proposal.json').read_text())
reuse = json.loads((BASE / 'compatible-reuse.json').read_text())
checks = {}
for key in ('owning_docs_sha256', 'review_packet_sha256',
            'additional_normative_docs_sha256', 'user_files_sha256'):
    checks[key] = {name: (ROOT / name).is_file() and sha(ROOT / name) == value
                   for name, value in binding[key].items()}
for key, values in [('proposal_source', proposal['source_files_sha256']),
                    ('engineering', reuse['engineering_files_sha256']),
                    ('engineering_evidence', reuse['bindings_sha256'])]:
    checks[key] = {name: (ROOT / name).is_file() and sha(ROOT / name) == value
                   for name, value in values.items()}
head = run('git', 'rev-parse', 'HEAD').strip()
pr = json.loads(run('gh', 'api', 'repos/BashaarJavaid/MCP-Sentinel/pulls/37'))
remote = json.loads(run('gh', 'api', 'repos/BashaarJavaid/MCP-Sentinel/git/ref/heads/phase22/integration'))
checks['identity'] = {
    'local_remote_pr': head == pr['head']['sha'] == remote['object']['sha'] == '637a25cbb5f5bc6fcf8b3a7b30b4274aa8ea44fb',
    'draft_open_base': pr['draft'] and pr['state'] == 'open' and pr['base']['ref'] == 'phase22/description-poisoning',
    'proposal': sha(BASE / 'optimization-proposal.json') == '2f32e71cf4a90b43c33cdea253cdffac1296ab9308086c352c90bbcf6e75619c',
    'pr_body': hashlib.sha256(pr['body'].encode()).hexdigest() == '8079561432a6f20bcf264ea5155178250166c9b7813917f2883a4cd12f82ed07',
    'no_optimization_receipt': not (BASE / 'optimization-authorization.json').exists(),
    'v62_unused': not (BASE.parent / 'v62-shared-tool-discovery').exists(),
}
sys.path.insert(0, str(ROOT / 'src'))
imports = {name: importlib.import_module(name).__file__ for name in
           ('sentinel.static.workers', 'sentinel.static.typescript_path_flow', 'sentinel.static.typescript_discovery')}
worktrees = run('git', 'worktree', 'list', '--porcelain')
user_files = dict(binding['user_files_sha256'])
prompt = 'docs/phase22-shared-discovery-acceptance-closeout-agent-prompt.md'
user_files[prompt] = sha(ROOT / prompt)
receipt = {
    'recorded_at': datetime.now(timezone.utc).isoformat(), 'head': head,
    'checks': checks, 'passed': all(all(group.values()) for group in checks.values()),
    'user_files_sha256': user_files, 'imports': imports,
    'python': platform.python_version(),
    'versions': {name: importlib.metadata.version(name) for name in ('semgrep', 'mcp', 'pytest', 'pydantic')},
    'worktrees': worktrees,
    'status_including_ignored': run('git', 'status', '--porcelain=v1', '--ignored=matching'),
    'staged_diff': run('git', 'diff', '--cached', '--stat'),
    'tracked_diff': run('git', 'diff', '--stat'),
    'main_status': run('git', '-C', '/Users/bashaarjavaid/Projects/MCP-Sentinel', 'status', '--porcelain=v1'),
    'pr': {key: pr[key] for key in ('state', 'draft', 'title', 'body')},
    'authorization': 'Intake and source review only; optimization decision pending.',
    'new_scans': 0, 'new_profiles': 0, 'paid_calls': 0,
    'script_sha256': sha(Path(__file__)),
}
with (OUT / 'intake.json').open('x') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps({'passed': receipt['passed'], 'checks': {key: [name for name, ok in values.items() if not ok] for key, values in checks.items()}, 'user_files': len(user_files), 'prompt_sha256': user_files[prompt], 'versions': receipt['versions'], 'python': receipt['python'], 'imports': imports, 'receipt': str(OUT / 'intake.json')}, indent=2))
