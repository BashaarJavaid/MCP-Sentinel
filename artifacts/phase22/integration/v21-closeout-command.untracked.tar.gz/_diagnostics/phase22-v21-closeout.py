import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read('v21-source-verification.json');d=read('v21-sequence-assessment/packet.json');delta=read('v21-source-delta-assessment/packet.json');seal=read('evidence-v50.json');prior=read('v20-closeout-audit/packet.json');assert delta['all_deltas_assessed']
full=d['passed'];fresh=root/'artifacts/phase22/corpus-replacement-v4/evaluation-proposal.json';assert fresh.exists();rows=[]
for old in prior['requirements']:
 row={**old,'prior_requirement_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),'historical_assessment':{'audit':'v20-closeout-audit/packet.json','text':old['assessment']},'evidence':list(dict.fromkeys(old['evidence']+['artifacts/phase22/integration/v21-source-verification.json','artifacts/phase22/integration/v21-hosted-audit/packet.json']))}
 row['assessment']='Scanner/test/runtime/package bytes remain identical to1f3f72f. Fresh normal CI/docs pass at e7131f0 after the optional sequence change. Prior requirement-specific source judgments are preserved separately; current source compatibility is verified. No fresh-evaluation or human-acceptance result is inferred.'
 if row['id'] in [f'R{n}' for n in range(18,28)]+['R35','R63','R64','R65']:
  row['disposition']='passed' if full else 'unresolved';row['assessment']='The approved current-source Linux sequence '+('passes25/25 development and both complete45/45 historical batches. Development preserves10 vulnerable hits, exactly2raw Meta erratum alerts and0matching alerts on13valid negatives. Each historical batch has20vulnerable hits and0matching alerts on25negatives. Whole ordered historical repeats and source-assessed deltas pass.' if full else 'did not pass; consumed attempts and unused closed budget are preserved in the sequence assessment. No pooled result, retry or implicit waiver.')+' All timing is classified against the approved120-second target and300-second native/whole-input maximum; original15/25 at120seconds remains unchanged.'
  row['evidence']+=['artifacts/phase22/integration/v21-sequence-assessment/packet.json','artifacts/phase22/integration/v21-source-delta-assessment/packet.json']
 if row['id'] in ['R35','R65']:
  row['disposition']='passed';row['assessment']='The complete25-input current-source development batch passes its300-second timing, condition and source-delta gates. All10Meta inputs complete, including operator fallback. Raw Meta erratum and13valid-negative distinction are preserved. This pass does not substitute for the incomplete historical pair.'
 if row['id'] in ['R66','R88']:
  row['assessment']='Replacement-v4 is source-curated after freezing1f3f72f, with exact archives/manifests/configuration, direct upstream pair, reversible mutations, safe control and exposure disclosure. No native/comparator evaluation is approved or run. The15-observation proposal awaits explicit approval; no independent-human/unseen-source/generalization claim.';row['evidence']+=['artifacts/phase22/corpus-replacement-v4/evaluation-proposal.json','artifacts/phase22/integration/v21-fresh-proposal-verification.json']
 if row['id']=='R84':row['assessment']='Final technical acceptance is not requested or received. Fresh evaluation remains unmet; Phase22 stays incomplete, Phase21 deferred/incomplete and Phase24/15 unchanged.'
 if row['id'] in ['R77','R78']:row['assessment']='Full paid benchmark explicitly user-deferred, not passed. No new paid call occurred.'
 if row['id']=='R79':row['evidence'].append('artifacts/phase22/integration/evidence-v50.json')
 if row['id']=='R82':row['evidence'].append('artifacts/phase22/integration/v21-delivery-verification.json')
 rows.append(row)
additional=[{**r,'scope':'Preserved historical approved scope; unused maxima do not reopen.'} for r in prior['additional_scope_requirements']]
for suffix,title,evidence,status in [('APPROVAL','Bind exact115-observation approval and one consumed dispatch',['v21-full-sequence-authorization.json','v21-dispatch-consumed.json'],'passed'),('SUPERVISOR','Enforce uniform whole-input limit, predecessor gates and process cleanup',['v21-full-linux-v1/runner.py','v21-supervisor-selfchecks/selfcheck.json'],'passed'),('SEQUENCE','Complete25+45+45 and ordered historical repeat gate',['v21-sequence-assessment/packet.json','v21-source-delta-assessment/packet.json'],'passed' if full else 'unresolved'),('VERIFY','Verify normal CI and source-bound compatibility',['v21-source-verification.json','v21-hosted-audit/packet.json'],'passed'),('FRESH-PROPOSAL','Prepare post-freeze independent source packet without evaluation',['v21-scanner-freeze-before-curation.json','v21-fresh-proposal-verification.json'],'passed'),('DELIVERY','Seal evidence and deliver to existing draft',['evidence-v50.json','v21-delivery-verification.json'],'passed')]:additional.append({'id':'V21-'+suffix,'requirement':title,'disposition':status,'evidence':evidence})
counts=dict(collections.Counter(r['disposition'] for r in rows));assert len(rows)==89;assert counts==({'passed':84,'unresolved':3,'explicitly user-deferred':2} if full else {'passed':72,'unresolved':15,'explicitly user-deferred':2})
p={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':v['source'],'scanner_identity':v['scanner'],'measured_scanner':v['measured_scanner'],'requirements':rows,'dispositions':counts,'additional_scope_requirements':additional,'additional_scope_dispositions':dict(collections.Counter(r['disposition'] for r in additional)),'prior_audit':{'path':'v20-closeout-audit/packet.json','sha256':sha(b/'v20-closeout-audit/packet.json')},'current_tests_by_file':prior['current_tests_by_file'],'current_source_and_test_files':v['source_and_test_files_sha256'],'references_sha256':{n:sha(b/n) for n in ['v21-source-verification.json','v21-hosted-audit/packet.json','v21-sequence-assessment/packet.json','v21-source-delta-assessment/packet.json','v21-fresh-proposal-verification.json','v21-full-sequence-disposition.json','v21-historical-assessment-refresh-proposal.json','evidence-v50.json']},'original_failed_gate':v['original_failed_gate'],'policy_approved':True,'native_and_whole_input_hard_limit_seconds':300,'performance_target_seconds':120,'current_source_corpus_runs':d['attempts_consumed'],'full_sequence_approved':True,'full_sequence_passed':full,'fresh_evaluation_approved':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'new_paid_calls':0,'phase22_complete':False,'status':('Full Linux sequence passed; fresh evaluation and final human acceptance remain unmet.' if full else 'Full Linux sequence failed; preserved attempts and closed unused budget. Fresh evaluation and final acceptance remain unmet.'),'owning_document_binding':'v21-final-documentation-binding.json supersedes audit-stage owning-document hashes only.'}
out=b/'v21-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
target=d['classification_counts'].get('completed_within_target',0);extended=d['classification_counts'].get('completed_using_extended_time',0)
summary=f'''The approved full Linux sequence at scanner **`1f3f72f`**, workflow **`e7131f0`**,
run **34555414891**, **{'passes' if full else 'does not pass'}**. It consumed
**{d['attempts_consumed']}/115 native observations**: **{target}** completed within
the 120-second target and **{extended}** used extended time within the uniform
300-second native/whole-input maximum. Raw durations, cleanup, reports, condition
scores and source-assessed deltas are retained in `v21-sequence-assessment/` and
`v21-source-delta-assessment/`. The dispatch budget is closed; no retry, profile,
source tuning, target execution or paid call occurred.

'''
if full:summary+='''Development completes **25/25**, detects **10/10 vulnerable conditions**, preserves
exactly the **two raw Meta operator erratum alerts**, and has **zero matching
alerts on 13 valid negatives**. Each historical batch completes **45/45**, detects
**20/20 vulnerable conditions**, and has **zero matching alerts on 25 negatives**.
All 45 entire ordered historical reports match their repeats, excluding only the
recorded volatile fields. Unrelated findings and diagnostics retain their source
assessments and uncertainty; these results do not establish general security.

'''
else:summary+='''Development passes25/25. All37attempted historical inputs also complete within
300seconds; there are **zero timeouts among62attempts**. The run stops on
`kubernetes-shell-vulnerable` because the old assessment expects24findings and
the current scanner produces25. Source review confirms the added `kubectl_logs`
cronjob command-injection suspicion is separate from the named `kubectl_get`
condition, whose existing hit remains. Post-run source review records19/19
observed vulnerable condition hits and0matching alerts on18observed negatives.
The original gate stays failed,8inputs in the first historical batch remain
unstarted, and the entire45-input repeat is skipped. All53unused observations
are closed; these are not timeout failures or permission to resume.

The next exact proposal is **unapproved**:
`v21-historical-assessment-refresh-proposal.json`. It requests **98new native
observations**, two dispatches:8preparatory inputs to freeze complete source-bound
assessments, then two **whole45-input historical batches**. It explicitly asks
to reuse the already passed whole25-input development batch at identical1f3f72f
bytes. The37+8preparatory reports never count as a whole45execution pass. The
limits remain300seconds per whole input and120seconds as the target, with
60/245/245-minute job limits, zero retries/profiles/comparators/paid calls, and
no detector/label change. A failing or unresolved preparatory condition closes
the90-run final budget. Strict identity and ordered-repeat checks remain in the
final pair. See the disposition for exact source evidence and timing.

''' 
summary+=f'''This is a completion result under the approved timing policy, not a speedup.
The original Linux result at `7555a9d` remains **15/25 complete, ten Meta timeouts
at 120 seconds and both historical batches skipped**. Scanner/test/package bytes
remain `1f3f72f`. Fresh CI **34555415861** passes all **29 normal jobs**; every one
of 12 quality suites passes **2,194 tests with 36 skips**. Docs **34555415860**
passes. Prior local coverage, six zero-call production replays and Git runtime
compatibility retain their exact source bindings. Git campaigns remain incomplete;
all three exposed SSRF families retain their passing regressions at `2ac39aa`.

A later separate checkpoint is the **unapproved replacement-v4 freeze/evaluation** in
`artifacts/phase22/corpus-replacement-v4/`. Its independent auth-fetch-mcp source
pair was curated after the scanner freeze, without running a detector/comparator.
The proposal permits **10 native and 5 Semgrep observations** in one standard
Linux job, 300 seconds per whole input, 75 nominal input-minutes, a 90-minute job
limit and zero paid calls. Source exposure and correlated variants are disclosed;
there is no independent human or unseen-source review claim.

All 89 original requirements are **{counts['passed']} passed, 2 user-deferred,
{counts['unresolved']} unresolved**. **Phase 22 remains incomplete** pending the
remaining gates and explicit final human acceptance. The original held-out result
remains 10 completed, 10 unsupported, 5 incomplete, with 0 hits among 4 completed
vulnerable inputs out of 10 vulnerable inputs total. Paid benchmark/pilots remain
deferred; Phase 21 incomplete and Phase 24/15 unchanged. No merge/release/outreach.
'''
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']:
 f=root/name;s=f.read_text();start=s.index('The approved Linux diagnostic **passes all four observations**');prefix=s[:start].replace('Current v20 Linux diagnostic','Current v21 full Linux sequence');s=prefix+summary+'\n### Historical v20 diagnostic and full-sequence proposal checkpoint\n\n'+s[start:]
 if name=='AGENTS.md' and full:s=s.replace('all three exposed SSRF gates and four Linux diagnostic observations pass; full timing, fresh evaluation and acceptance pending; paid benchmark/pilots deferred','all three exposed SSRF gates and full Linux sequence pass; fresh evaluation and acceptance pending; paid benchmark/pilots deferred',1)
 f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text().replace('## Current v20 diagnostic audit',f'''## Current v21 full-sequence audit

All 89 original rows are mapped in `v21-closeout-audit/packet.json`: **{counts['passed']} passed,
2 explicitly user-deferred, {counts['unresolved']} unresolved**. The 45 added rows include
approval, supervision, complete-sequence measurement, source verification,
fresh-proposal preparation and delivery. Historical failed attempts remain
preserved and never reopen a consumed budget. Fresh evaluation and final human
acceptance remain pending. No paid calls.

## Historical v20 diagnostic audit''',1);f.write_text(s)
index=f'''Batch 50 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 49 prior archives were verified. Restore
after batches 1–49 in separate staging using `evidence-v50.json`; require existing
destinations to match identical bytes or their recorded prior hash. Stop on
unexpected conflict. Raw sequence/CI outputs, failed attempts, assessments,
authorization, source verification and helper sources are retained. The new
replacement-v4 source packet and final audit/docs/delivery bindings are tracked
directly; no evaluation of the proposed fresh inputs has run.
'''
f=b/'README.md';f.write_text(f.read_text().replace('batches 1–49 and closeout audit','batches 1–50 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1));f=b/'progress.md';f.write_text(f.read_text().rstrip()+'\n\n### Evidence batch50\n\n'+index)
f=root/'docs/phase22-timeout-policy.md';f.write_text(f.read_text().rstrip()+'\n\n## Current full-sequence result\n\n'+summary)
f=root/'docs/phase22-corpus-review.md';s=f.read_text();s=s.replace('## Historical proposal','The replacement-v4 source packet is prepared after freezing `1f3f72f`, with\nno detector/comparator execution. Its exact checkpoint and bounded proposal are\nin `artifacts/phase22/corpus-replacement-v4/`; explicit evaluation approval remains\npending. All v1/v2/v3 original results and exposed regressions are preserved.\n\n## Historical proposal',1);f.write_text(s)
body=summary+'\n[Sequence assessment](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v21-sequence-assessment/packet.json), [audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v21-closeout-audit/packet.json), [historical refresh proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v21-historical-assessment-refresh-proposal.json), [later fresh proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/corpus-replacement-v4/README.md), [evidence1–50](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nFinal docs/evidence delivery uses authorized CI skip after proving code/test/workflow/package inputs equal tested e7131f0; it is not a new hosted code pass.\n';f=b/'v21-closeout-draft-body.md';assert not f.exists();f.write_text(body);print(counts,p['additional_scope_dispositions'])
