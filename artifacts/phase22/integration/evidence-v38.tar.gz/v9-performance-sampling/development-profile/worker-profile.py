import collections,json,sys,threading,time
from pathlib import Path
sys.path.insert(0,'/private/tmp/mcp-phase22-options/src')
from sentinel.static import workers
out=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v9-performance-sampling/development-profile');rule=sys.argv[-1];counts=collections.Counter();main=threading.get_ident();stop=threading.Event()
def snapshot():
 (out/(rule+'-samples.json')).write_text(json.dumps({str(k):v for k,v in counts.copy().items()},indent=2))
def samples():
 last=time.monotonic()
 while not stop.wait(0.005):
  frame=sys._current_frames().get(main)
  if frame is not None:
   counts[(frame.f_code.co_filename,frame.f_lineno)]+=1
  if time.monotonic()-last>20:snapshot();last=time.monotonic()
thread=threading.Thread(target=samples,daemon=True);thread.start();start=time.monotonic();cpu=time.process_time()
try:workers._worker()
finally:
 stop.set();thread.join();snapshot()
 (out/(rule+'-timing.json')).write_text(json.dumps({'wall':time.monotonic()-start,'cpu':time.process_time()-cpu}))
