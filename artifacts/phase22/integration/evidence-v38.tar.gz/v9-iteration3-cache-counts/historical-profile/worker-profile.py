import json,sys,threading,time
from pathlib import Path
sys.path.insert(0,'/private/tmp/mcp-phase22-options/src')
from sentinel.static import workers,path_flow
from sentinel.static.rules import sent015,sent016
out=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v9-iteration3-cache-counts/historical-profile');rule=sys.argv[-1];stop=threading.Event()
def snapshot():
 values={name:fn.cache_info()._asdict() for name,fn in [('credential_facts',sent016._credential_guard_facts),('fixed_destination',sent015.fixed_destination),('combine',path_flow._combine),('key',path_flow._key)]}
 (out/(rule+'-cache-counts.json')).write_text(json.dumps(values,indent=2))
def snapshots():
 while not stop.wait(20):snapshot()
thread=threading.Thread(target=snapshots,daemon=True);thread.start();start=time.monotonic();cpu=time.process_time()
try:workers._worker()
finally:
 stop.set();thread.join();snapshot()
 (out/(rule+'-timing.json')).write_text(json.dumps({'wall':time.monotonic()-start,'cpu':time.process_time()-cpu}))
