"""Bind and deliver the verified exposed regression and acceptance packet to the existing authorized draft."""
import hashlib,json,subprocess,tarfile,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
old=read(BASE/'v37-ddg-trace/documentation-binding.json');baseline='b90abdb1089c8032d6efbbc22c723116ae2b5b35';tested='8c6256725f0948ee593eb4b73e90baf6f7b0d76a'
assert run(['git','rev-parse','HEAD']).strip()==baseline
assert run(['git','branch','--show-current']).strip()=='phase22/integration'
assert not run(['git','diff','--cached'])
fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
pr=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'pre-delivery-pr37-corrected.json',pr)
assert pr['headRefOid']==baseline and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(BASE/'v37-ddg-trace/pr-body.md').read_text()
parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,state,isDraft']));write(OUT/'pre-delivery-pr36-corrected.json',parent)
assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455';run(['git','merge-base','--is-ancestor',parent['headRefOid'],'HEAD'])
inputs=old['byte_identical_quality_inputs'];assert 'README.md' not in inputs
assert not run(['git','diff',tested,'--',*inputs])
protected=old['user_files_sha256']
def verify_protected():
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision']
  assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
frozen=str(ROOT.parent/'mcp-phase22-frozen-8c62567');old['worktrees'][frozen]={'revision':tested,'clean':True}
verify_protected()
a=read(OUT/'assessment.json');audit=read(OUT/'audit-final.json');assert a['detection_and_coverage_gate_passed'] and a['completed']==87 and a['whole_ordered_repeats']==36
assert read(BASE/'v37-ddg-trace/evaluation-authorization.json')['approved'] and read(BASE/'v37-ddg-trace/execution-consumed.json')['budget_consumed']
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==108
assert audit['dispositions']=={'passed':86,'explicitly user-deferred':2,'unresolved':1}
for n,d in audit['current_source_and_test_files'].items():assert sha(ROOT/n)==d,n
for label in ['v38-corrected-docs','v38-corrected-build','v38-corrected-distributions']:
 assert read(BASE/(label+'.json'))['exit_code']==0,label
assert read(OUT/'owned-work-corrected.json')['owned_processes']==[]
for n,d in read(BASE/'v37-ddg-trace/evaluation-proposal.json')['files_sha256'].items():assert sha(ROOT/n)==d,n
seal=read(BASE/'evidence-v66.json');assert sha(BASE/seal['archive'])==seal['sha256']
for r in seal['files']:assert sha(BASE/r['path'])==r['sha256'],r['path']
dist=read(OUT/'final-distributions-corrected.json');assert sha(ROOT/'README.md')==dist['README_sha256']
for r in dist['distributions']:assert sha(ROOT/r['path'])==r['sha256']
refs=['assessment.json','audit-final.json','summary-final.md','pr-body-final.md','acceptance-proposal-final.json','validation.json','condition-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','other-source-assessment.json','final-distributions-corrected.json','delivery-preflight-correction.json','deliver-final.py']
b={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':baseline,'tested_workflow':tested,'scanner':a['scanner'],'byte_identical_quality_inputs':inputs,'owning_docs_sha256':{n:sha(ROOT/n) for n in old['owning_docs_sha256']},'review_packet_sha256':{n:sha(OUT/n) for n in refs},'user_files_sha256':protected,'worktrees':old['worktrees'],'authorized_staged_frozen_artifacts_sha256':old['authorized_staged_frozen_artifacts_sha256'],'evidence_seal':{'path':seal['archive'],'sha256':seal['sha256'],'members':len(seal['files'])},'new_native_observations':87,'current_scanner_corpus_observations':87,'remaining_regression_observations':0,'new_paid_calls':0,'gate_passed':True,'source_recovery_approved':True,'diagnostic_approved':True,'regression_approved':True,'technical_acceptance_requested':True,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Post-seal binding directly tracked. Current audit source/test/doc hashes match final files. Product/tests/workflows equal actual tested8c62567; final README metadata distributions reverified. No new hosted pass or circular final commit binding is claimed.'}
write(OUT/'documentation-binding.json',b)
paths=list(b['owning_docs_sha256']);extra=[str(p.relative_to(ROOT)) for p in [BASE/'evidence-v65.json',BASE/'evidence-v65.tar.gz',BASE/'evidence-v66.json',BASE/'evidence-v66.tar.gz',OUT/'documentation-binding.json']]
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','add','-f','--',*extra],check=True)
assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths+extra)
subprocess.run(['git','commit','-m','Deliver Phase 22 regression pass and explicit acceptance packet [skip ci]'],check=True)
subprocess.run(['git','push','origin','phase22/integration'],check=True)
subprocess.run(['gh','pr','edit','37','--title','Phase 22: regression passed; technical acceptance pending','--body-file',str(OUT/'pr-body-final.md')],check=True)
head=run(['git','rev-parse','HEAD']).strip();readbacks=[]
for attempt in range(5):
 pr=json.loads(run(['gh','pr','view','37','--json',fields]));readbacks.append(pr)
 if pr['headRefOid']==head and pr['body']==(OUT/'pr-body-final.md').read_text():break
 time.sleep(2)
write(OUT/'delivery-readback-history.json',readbacks);write(OUT/'delivery-readback.json',pr)
assert pr['headRefOid']==head and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning';assert pr['body']==(OUT/'pr-body-final.md').read_text()
assert json.loads(run(['gh','pr','view','36','--json','headRefOid']))['headRefOid']==parent['headRefOid']
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached']);verify_protected()
for n,d in b['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
write(OUT/'delivery-verification.json',{'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-readback.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':87,'current_scanner_corpus_observations':87,'remaining_regression_observations':0,'source_recovery_approved':True,'diagnostic_approved':True,'regression_approved':True,'technical_acceptance_requested':True,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Supplemental ignored post-delivery receipt; original seal and commit remain immutable.'})
print('Verified existing OPEN draft delivery',head,pr['url'])
