"""Refresh final documentation hashes after editing; preserve the sealed initial audit."""
import copy,hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
assert read(BASE/'v38-draft-delivery.json')['exit_code']==1 and not subprocess.check_output(['git','diff','--cached'])
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='b90abdb1089c8032d6efbbc22c723116ae2b5b35'
old=read(OUT/'audit.json');binding=read(BASE/'v37-ddg-trace/documentation-binding.json');stale={n:{'recorded':d,'actual_before_correction':sha(ROOT/n)} for n,d in old['current_source_and_test_files'].items() if sha(ROOT/n)!=d}
assert set(stale)==set(old['current_source_and_test_files'])&set(binding['owning_docs_sha256'])
note='The initial delivery preflight stopped before staging, commit or push because six\nstatus-document hashes in the audit had not been refreshed after documentation\nedits. The failed receipt and seal 65 remain preserved. Final documentation\nbindings are corrected in supplemental seal 66; scanner and evaluation evidence\nare unchanged.\n\n'
for name in binding['owning_docs_sha256']:
 path=ROOT/name;s=path.read_text();needle='The reconciled audit accounts for **89 original requirements:';assert s.count(needle)==1,name
 s=s.replace(needle,note+needle).replace('v38-guard-regression/acceptance-proposal.json','v38-guard-regression/acceptance-proposal-final.json')
 if name=='artifacts/phase22/integration/README.md':s=s.replace('batches 1–65','batches 1–66',1).replace('(v38-guard-regression/audit.json)','(v38-guard-regression/audit-final.json)').replace('Restore seal 65 after seals 1–64','Restore seal 66 after seals 1–65')
 path.write_text(s)
for src,dest in [('summary.md','summary-final.md'),('pr-body.md','pr-body-final.md')]:
 s=(OUT/src).read_text().replace('The reconciled audit accounts for **89 original requirements:',note+'The reconciled audit accounts for **89 original requirements:').replace('v38-guard-regression/acceptance-proposal.json','v38-guard-regression/acceptance-proposal-final.json').replace('Seal65 preserves new evidence after all64 preceding seals.','Seal65 preserves the regression evidence; supplemental seal66 preserves corrected final documentation bindings and the failed preflight. Use audit-final.json and acceptance-proposal-final.json for the current decision.')
 with (OUT/dest).open('x') as f:f.write(s)
p=copy.deepcopy(old);p['historical_initial_v38_audit']={'path':'v38-guard-regression/audit.json','sha256':sha(OUT/'audit.json'),'initial_stale_document_bindings':stale}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in old['current_source_and_test_files']};p['final_documentation_source_files']={n:sha(ROOT/n) for n in binding['owning_docs_sha256']}
p['owning_document_binding']='Corrected finalv38 documentation binding follows documentation/package checks and supplemental seal66. Six status-document hashes were refreshed after editing; original stale audit and failed preflight remain in seal65 and supplemental evidence. All scanner/test hashes are unchanged.'
write('audit-final.json',p)
a=read(OUT/'acceptance-proposal.json');a['supersedes_initial_v38_acceptance_proposal']={'path':'v38-guard-regression/acceptance-proposal.json','sha256':sha(OUT/'acceptance-proposal.json'),'reason':'Refresh six documentation hashes after final status edits; no technical gate or scope change.'}
a['current_audit']='v38-guard-regression/audit-final.json';a['current_audit_sha256']=sha(OUT/'audit-final.json');a['files_sha256']['v38-guard-regression/audit-final.json']=sha(OUT/'audit-final.json');a['files_sha256']['v38-guard-regression/summary-final.md']=sha(OUT/'summary-final.md');a['evidence_seal']='evidence-v66.json (supplements preserved seal65; hash bound in final documentation/delivery record)'
for n,d in a['files_sha256'].items():assert sha(BASE/n)==d,n
write('acceptance-proposal-final.json',a)
write('delivery-preflight-correction.json',{'failed_command_receipt_sha256':sha(BASE/'v38-draft-delivery.json'),'failed_log_sha256':sha(BASE/'v38-draft-delivery.log'),'stale_document_bindings':stale,'cause':'Audit copied six prior documentation hashes before status docs were updated; preflight correctly rejected the stale values.','correction':'Refresh current document hashes after final edits; preserve initial audit/proposal/seal65 and use final versioned decision files with supplemental seal66.','original_head_unchanged':True,'nothing_staged_committed_or_pushed_by_failed_preflight':True,'scanner_tests_workflows_unchanged':True,'new_observations':0,'paid_calls':0,'final_audit_sha256':sha(OUT/'audit-final.json'),'final_proposal_sha256':sha(OUT/'acceptance-proposal-final.json')})
print('Corrected six final documentation hashes; sealed prior records remain unchanged.')
