"""Preserve full ordered reference differences and bind every changed occurrence to source."""
import collections,gzip,hashlib,importlib.util,json,re,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];PREP=OUT.parent/'v89-regression-preparation';DEST=OUT/sys.argv[1];DEST.mkdir(exist_ok=False)
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_corpus import validate,input_files
from scripts.phase22_corpus import frozen
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();packet=read(OUT/'raw/packet.json');number=int(sys.argv[2]);selected=packet['attempts'][:number];assert len(selected)==number and all(row['state']=='completed' for row in selected)
validation={'observations':[{**row,'report_sha256':sha(OUT/'raw'/row['directory']/row['input_id']/'report.json'),'reference_sha256':sha(ROOT/p['groups'][row['group']]['inputs'][row['input_id']]['reference_report'])} for row in selected]}
schema_spec=importlib.util.spec_from_file_location('unseen_corpus',PREP/'corpus.py');schema=importlib.util.module_from_spec(schema_spec);sys.modules['unseen_corpus']=schema;schema_spec.loader.exec_module(schema)
excluded=set(p['volatile_exclusions']);manifests={};sources={};contexts={};inventory=[];summaries=[];counts=collections.Counter()
def changes(a,b,path=()):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():return [d for k in a for d in changes(a[k],b[k],path+(k,))]
 return [{'path':list(path),'before':a,'after':b}]
def files_for(group,input_id):
 g=p['groups'][group];expected=g['inputs'][input_id]['input'];tree=expected['tree_sha256']
 if tree not in sources:
  if group not in manifests:
   manifests[group]=schema.frozen(approval_path=PREP/'source-freeze-authorization.json') if g['corpus_kind']=='unseen_v1_exposed' else (validate() if group.endswith('historical') else frozen(approval_path=ROOT/g['source_freeze_approval']))
  m=manifests[group];item=next(i for i in m.inputs if i.id==input_id);snapshot=next(s for s in m.snapshots if s.revision==item.snapshot)
  assert item.model_dump(mode='json')==expected
  files=input_files(item,snapshot,ROOT);prefix='' if item.scan_root=='.' else item.scan_root+'/'
  sources[tree]={name[len(prefix):]:data for name,data in files.items() if name.startswith(prefix)}
 return tree,sources[tree]
def bind(files,tree,path,line=None):
 data=files[path];digest=hashlib.sha256(data).hexdigest();key=f'{tree}:{path}:{line if line is not None else "file"}'
 if key not in contexts:
  lines=data.decode().splitlines();c={'tree_sha256':tree,'path':path,'source_sha256':digest,'line':line,'source_location_precision':'exact line' if line is not None else 'file only; diagnostic supplies no exact line'}
  if line is not None:
   assert 0<line<=len(lines),(path,line)
   c.update(statement=lines[line-1],excerpt=[f'{n+1}: {lines[n]}' for n in range(max(0,line-5),min(len(lines),line+5))])
  else:c['full_source']=data.decode()
  contexts[key]=c
 return key
def locate(entry,kind,files,tree):
 if kind in ('finding','surface'):
  loc=entry['location'];keys=[bind(files,tree,loc['path'],loc['range']['start_line'])]
  if kind=='finding':keys.extend(bind(files,tree,loc['path'],loc['range']['start_line']) for loc in entry['evidence'].get('flow_locations',[]) if loc.get('kind')=='file')
  return keys
 msg=entry['message'];match=re.fullmatch(r'SENT-\d+ at (.+):(\d+): (.+)',msg)
 if match:return [bind(files,tree,match[1],int(match[2]))]
 match=re.fullmatch(r'Skipped a computed TypeScript tool name at (.+):(\d+)',msg)
 if match:return [bind(files,tree,match[1],int(match[2]))]
 match=re.match(r'^(.+?):(\d+): ',msg)
 if match and match[1] in files:return [bind(files,tree,match[1],int(match[2]))]
 if ' is declared at multiple source locations: ' in msg:
  return [bind(files,tree,path,int(line)) for path,line in (loc.rsplit(':',1) for loc in msg.split(' is declared at multiple source locations: ',1)[1].split(', '))]
 # File-only diagnostics retain exact full source and do not invent a binding occurrence.
 paths=[path for path in files if msg.startswith(path+': ')]
 assert len(paths)==1,('Unlocated diagnostic requires explicit review',msg)
 return [bind(files,tree,paths[0])]
with gzip.open(DEST/'complete-report-differences.jsonl.gz','xt',encoding='utf-8') as stream:
 for row in validation['observations']:
  if row['state']!='completed':continue
  group=row['group'];input_id=row['input_id'];item=p['groups'][group]['inputs'][input_id];files_for(group,input_id)
  current_path=OUT/'raw'/row['directory']/input_id/'report.json';reference_path=ROOT/item['reference_report']
  assert sha(current_path)==row['report_sha256'] and sha(reference_path)==row['reference_sha256']
  before=r.supervisor.clean(read(reference_path),excluded);after=r.supervisor.clean(read(current_path),excluded);delta=changes(before,after)
  reconstructed=json.loads(json.dumps(before))
  for d in delta:
   target=reconstructed
   for key in d['path'][:-1]:target=target[key]
   assert d['path'] and target[d['path'][-1]]==d['before']
   target[d['path'][-1]]=d['after'];counts['/'.join(d['path'])]+=1
  assert reconstructed==after
  common={'group':group,'input_id':input_id,'batch':row['batch'],'current_report':str(current_path.relative_to(ROOT)),'current_report_sha256':sha(current_path),'reference_report':item['reference_report'],'reference_report_sha256':sha(reference_path)}
  stream.write(json.dumps({**common,'changes':delta},separators=(',',':'))+'\n')
  summary={**common,'changed_paths':['/'.join(d['path']) for d in delta],'ordered_reconstruction_verified':True,'entire_ordered_reference_equal':not delta,'source_tree_sha256':item['input']['tree_sha256'],'counts':{},'changed_occurrences':0}
  categories=[('finding',before['findings'],after['findings']),('warning',before['warnings'],after['warnings']),('unresolved_flow',before['static_analysis']['coverage']['unresolved_flows'],after['static_analysis']['coverage']['unresolved_flows']),('surface',before['static_analysis']['coverage']['surfaces'],after['static_analysis']['coverage']['surfaces'])]
  for kind,old,new in categories:
   serial=lambda x:json.dumps(x,sort_keys=True,separators=(',',':'))
   left=collections.Counter(map(serial,old));right=collections.Counter(map(serial,new));number=0
   for direction,entries,remaining in [('removed',old,left-right),('added',new,right-left)]:
    for index,entry in enumerate(entries):
     identity=serial(entry)
     if remaining[identity]<=0:continue
     remaining[identity]-=1;tree,files=files_for(group,input_id)
     inventory.append({**common,'kind':kind,'direction':direction,'original_index':index,'entry':entry,'contexts':locate(entry,kind,files,tree)})
     number+=1
   summary['counts'][kind]={'reference':len(old),'current':len(new),'changed_occurrences':number,'unchanged_occurrences':sum((left&right).values())};summary['changed_occurrences']+=number
  summaries.append(summary)
  print(group,input_id,row['batch'],len(delta),'changed paths;',summary['changed_occurrences'],'changed occurrences',flush=True)
result={'scanner':p['scanner'],'rows':summaries,'changed_occurrences':inventory,'contexts':contexts,'source_file_bindings':{tree:{name:hashlib.sha256(data).hexdigest() for name,data in files.items()} for tree,files in sources.items()},'comparisons':len(summaries),'changed_paths':dict(counts),'volatile_exclusions':p['volatile_exclusions'],'complete_ordered_reconstruction_passed':True,'full_differences_sha256':sha(DEST/'complete-report-differences.jsonl.gz'),'source_assessment_pending':True,'qualification':'Full ordered differences retained; counters describe occurrence identity only and never replace ordered comparisons. Source trees include exact mutation overlays. Unchanged occurrences require their original source-assessment bindings; changed occurrences require explicit current judgment. File-only diagnostic contexts establish no invented caller or line.'}
with (DEST/'difference-inventory.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Compared',len(summaries),'reports;',len(inventory),'changed occurrences;',len(contexts),'source contexts. Assessment remains pending.')
