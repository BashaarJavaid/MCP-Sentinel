"""Verify stopped owned work and unchanged tested source after the sole approved run."""
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent
ROOT=OUT.parents[3]
PREP=OUT.parent/'v89-regression-preparation'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
command=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True)
binding=read(PREP/'documentation-binding.json');preflight=read(PREP/'execution-preflight.json')
intake={'head':preflight['integration_head'],'worktrees':binding['worktrees'].replace('worktree '+str(ROOT)+'\nHEAD '+binding['baseline_delivery'],'worktree '+str(ROOT)+'\nHEAD '+preflight['integration_head'],1),'runtime':preflight['runtime'],'protected_user_files_sha256':binding['user_files_sha256']}
proposal=read(PREP/'evaluation-proposal.json')
assessment=read(OUT/'final-assessment/assessment.json')
execution=read(OUT/'execution.json')
assert not assessment['all_narrow_conditions_passed'] and assessment['entire_ordered_pairs_equal']==3 and assessment['source_assessment_complete']
packet=read(OUT/'raw/packet.json')
assert packet['budget_closed'] and len(packet['attempts'])==6 and not packet['unstarted'] and packet['remaining_observation_budget']==0
assert assessment['completed']==6
assert execution['timing']['returncode']==0 and execution['paid_calls']==0
assert command('git','rev-parse','HEAD').strip()==intake['head']
assert not command('git','diff','HEAD')
assert command('git','worktree','list','--porcelain')==intake['worktrees']
assert not command('git','-C','/Users/bashaarjavaid/Projects/MCP-Sentinel','status','--short')
frozen=Path(proposal['frozen_checkout'])
assert not command('git','-C',str(frozen),'status','--short')
for name,digest in read(PREP/'staging.json')['staged_files_sha256'].items():
    assert sha(ROOT/name)==sha(frozen/name)==digest,name
inputs=read(OUT.parent/'v88-literal-metadata-correction/local-checks.json')['candidate_engineering_files_sha256']
assert len(inputs)==305
for name,digest in inputs.items():
    assert sha(ROOT/name)==sha(frozen/name)==digest,name
for name,digest in proposal['files_sha256'].items():
    assert sha(ROOT/name)==digest,name
user_files=intake['protected_user_files_sha256']
assert len(user_files)==11
assert set(command('git','ls-files','--others','--exclude-standard').splitlines())==set(user_files)
for name,digest in user_files.items():
    assert sha(ROOT/name)==digest,name
os.chdir(frozen)
sys.path[:0]=[str(frozen/'src'),str(frozen)]
from scripts.phase20_measurements import scanner_identity
from sentinel.static import engine,workers,path_flow,typescript_path_flow,semgrep_adapter,discovery,module_dispatch
assert scanner_identity()==proposal['scanner']
assert engine.STATIC_TIMEOUT_SECONDS==1800 and semgrep_adapter.SEMGREP_TIMEOUT_SECONDS==10
imports={m.__name__:m.__file__ for m in (engine,workers,path_flow,typescript_path_flow,semgrep_adapter,discovery,module_dispatch)}
assert all(Path(p).is_relative_to(frozen/'src') for p in imports.values())
runtime={n:importlib.metadata.version(n) for n in intake['runtime']}
assert runtime==intake['runtime']
processes={}
for line in command('ps','-axo','pid=,ppid=,command=').splitlines():
    parts=line.strip().split(None,2)
    if len(parts)==3:processes[int(parts[0])]={'parent':int(parts[1]),'command':parts[2]}
ancestors=set();pid=os.getpid()
while pid in processes and pid not in ancestors:
    ancestors.add(pid);pid=processes[pid]['parent']
markers=['phase22-check.py','/launch.py','/evaluate.py','mcp-phase22-four-fresh-']+[f'v{i}-' for i in range(73,91)]
owned=[{'pid':pid,**row} for pid,row in processes.items() if pid not in ancestors and any(m in row['command'] for m in markers) and ('phase22' in row['command'] or any(f'v{i}-' in row['command'] for i in range(73,91)))]
managed=command('docker','ps','-aq','--filter','label=com.securemcp.sentinel=true').splitlines()
named=command('docker','ps','-aq','--filter','name=sentinel').splitlines()
assert not owned and not managed and not named,(owned,managed,named)
result={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),
    'scanner':proposal['scanner'],'imports':imports,'runtime':runtime,
    'engineering_inputs_verified':305,'proposal_bound_files_verified':len(proposal['files_sha256']),
    'protected_user_files_sha256':user_files,'worktrees_unchanged':True,'main_clean':True,
    'integration_head':intake['head'],'owned_processes':owned,'managed_container_ids':managed,
    'sentinel_named_container_ids':named,'available_bytes':shutil.disk_usage(ROOT).free,
    'normal_static_deadline_seconds':1800,'normal_semgrep_rule_timeout_seconds':10,
    'experimental_semgrep_rule_timeout_seconds':None,'completed_observations':6,
    'ordered_pairs_equal':3,'budget_closed':True,'remaining':0,'new_paid_calls':0,
    'assessment_sha256':sha(OUT/'final-assessment/assessment.json'),'execution_sha256':sha(OUT/'execution.json'),
    'technical_acceptance_received':False,'phase22_complete':False,
    'qualification':'Post-V90 read-only source/ownership verification. All6approved observations completed and3ordered pairs equal; Proxmox remains a failed detection/support gate. The305engineering files retain actual5142a3fverification (2596passed/36skips locally and all12hosted suites). No new hosted pass, tuning, profile, retry or paid call. All11protected documents/worktrees remain; explicit human technical acceptance and verified closeout are absent.'}

with (OUT/'completion-verification.json').open('x') as stream:
    json.dump(result,stream,indent=2);stream.write('\n')
print('Closed6-observation budget,3ordered pairs,305tested files,11protected documents and stopped owned work verified; Proxmox gate remains failed; normal1800/10policy intact.')
