"""Validate the sole completed or stopped V75 sequence; never launch an input."""
import hashlib,importlib.util,json,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];PREP=OUT.parent/'v89-regression-preparation';RAW=OUT/'raw';DEST=OUT/'final-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('runner',PREP/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
p=r.verify();packet=read(RAW/'packet.json');execution=read(OUT/'execution.json');launch=read(OUT/'launch.json');approval=read(PREP/'evaluation-authorization.json')
assert packet['budget_closed'] and packet['remaining_observation_budget']==0
assert packet['scanner']==p['scanner'] and packet['model_calls']==0 and not packet['target_execution']
assert packet['proposal_sha256']==sha(PREP/'evaluation-proposal.json')==execution['proposal_sha256']==launch['proposal_sha256']==approval['proposal_sha256']
assert packet['approval_sha256']==sha(PREP/'evaluation-authorization.json')==launch['approval_sha256']
assert approval['approved'] and approval['scanner']==p['scanner'] and approval['bounds']==p['bounds'] and approval['order']==p['order']
assert approval['rubric_sha256']==sha(PREP/'scoring-rubric.json') and approval['intake_sha256']==sha(PREP/'intake.json')
assert approval['launcher_binding_sha256']==sha(PREP/'launcher-binding.json')==launch['launcher_binding_sha256']
assert launch['command']==p['prepared_command'] and launch['cwd']==p['frozen_checkout']
timing=execution['timing'];assert timing['cleanup_verified'] and not timing['remaining_group_killed']
assert timing['elapsed_including_cleanup_seconds']-timing['elapsed_seconds']<=15
assert execution['paid_calls']==0
assert packet['unstarted']==p['order'][len(packet['attempts']):]
for name,digest in packet['files_sha256'].items():assert sha(RAW/name)==digest,name
first={};checked=[];pairs=0
for row,expected in zip(packet['attempts'],p['order']):
 assert all(row[k]==v for k,v in expected.items())
 folder=RAW/row['directory'];path=folder/row['input_id']/'report.json';g=p['groups'][row['group']];item=g['inputs'][row['input_id']]
 if row['state']!='completed':
  checked.append({**row,'partial_report_present':path.exists(),'source_assessment_pending':True});continue
 r.completed(row['timing']);report=read(path);result=read(folder/'results.json')
 assert result['scanner']==p['scanner'] and result['manifest_sha256']==g['manifest_sha256'] and result['model_calls']==0 and not result['requests']
 if g['source_freeze_approval']:
  source_approval=PREP/'source-freeze-authorization.json' if g['corpus_kind']=='unseen_v1_exposed' else Path(p['frozen_checkout'])/g['source_freeze_approval']
  assert result['authorization_sha256']==sha(source_approval)
 assert len(result['outcomes'])==1 and result['outcomes'][0]['state']=='completed' and result['outcomes'][0]['report_sha256']==sha(path)
 assert sha(path.parent/'configuration.json')==item['configuration_sha256']
 runtime=read(folder.with_name(folder.name+'-runtime-binding.json'))
 assert runtime['scanner']==p['scanner'] and runtime['configuration_sha256']==item['configuration_sha256']
 assert runtime['normal_static_deadline_seconds']==1800 and runtime['semgrep_rule_timeout_seconds']==10
 assert runtime['maximum_existing_flow_workers_per_input']==4 and not runtime['runtime_policy_override'] and runtime['verified_before_target_access']
 assert runtime['imports']=={'sentinel.static.'+name:str(Path(p['frozen_checkout'])/'src/sentinel/static'/(name+'.py')) for name in ['engine','workers','path_flow','typescript_path_flow','semgrep_adapter','discovery','module_dispatch']}
 validate_report_data(report);validate_sarif_data(read(path.with_suffix('.sarif')))
 assert report['analysisComplete'] and report['executionSuccessful'] and report['static_analysis']['duration_ms']<=1800000
 if g['corpus_kind']=='unseen_v1_exposed':
  witness=p['witnesses'][row['group']][row['input_id']]
  matches=[f for f in report['findings'] if f['rule_id']==witness['rule_id'] and f['location']['path']==witness['path'] and f['location']['range']['start_line']==witness['sink_line']]
  condition={'condition_passed':None,'provisional_sink_candidates':len(matches),'source_assessment_pending':True}
 else:
  condition=r.condition(report,read(ROOT/item['reference_report']),item['assessment'],item['input']['label'],set(p['volatile_exclusions']),p['witnesses'].get(row['group'],{}).get(row['input_id']))
 assert condition==read(folder/'condition.json')
 if 'condition' in row:assert condition==row['condition']
 canonical=r.supervisor.clean(report,set(p['volatile_exclusions']))
 if row['batch']=='repeat':
  equal=canonical==first[row['input_id']];assert row['ordered_repeat_equal']==equal
  pairs+=int(equal)
  if packet['passed']:assert equal
 else:first[row['input_id']]=canonical
 checked.append({**row,'report_sha256':sha(path),'reference_sha256':sha(ROOT/item['reference_report']),'sarif_sha256':sha(path.with_suffix('.sarif')),'finding_count':len(report['findings']),'warning_count':len(report['warnings']),'unresolved_flow_count':len(report['static_analysis']['coverage']['unresolved_flows']),'surface_count':len(report['static_analysis']['coverage']['surfaces'])})
completed=sum(x['state']=='completed' for x in checked)
if packet['passed']:
 assert timing['returncode']==0 and not timing['timed_out'] and timing['elapsed_seconds']<=p['bounds']['sequence_maximum_minutes']*60
 assert len(checked)==completed==6 and pairs==3 and not packet['unstarted']
else:assert packet.get('stop_reason') and timing['returncode']!=0
DEST.mkdir(exist_ok=False)
with (DEST/'validation.json').open('x') as f:json.dump({'validation_passed':True,'execution_gate_passed':packet['passed'],'scanner':p['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),'approval_sha256':sha(PREP/'evaluation-authorization.json'),'observations':checked,'attempted':len(checked),'completed':completed,'entire_ordered_pairs_equal':pairs,'unstarted_closed':len(packet['unstarted']),'stop_reason':packet.get('stop_reason'),'source_assessment_pending':True,'budget_closed':True,'remaining':0,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Exact approved exposed regression on frozen5142a3f. All original fresh failures remain source-bound; no result becomes accepted through collection completion. Source support requires separate assessment.'},f,indent=2);f.write('\n')
print('Validated',completed,'completed of',len(checked),'attempted;',pairs,'entire ordered pairs;',len(packet['unstarted']),'unstarted closed.')
