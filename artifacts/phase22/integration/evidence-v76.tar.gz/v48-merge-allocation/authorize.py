import ast
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

out = Path(__file__).resolve().parent
proposal = out.parent / 'v47-faf-sampling/optimization-proposal.json'
source = Path('src/sentinel/static/typescript_path_flow.py')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(proposal) == '68c6e209007a894df21e4af6189a516eb5a95e339d92b31067d2dce3b65c88ee'
assert sha(source) == 'f7764bf9829bac73ed71e6503c3e381de2a7f57c55a42512a3c5d7e5ce6edd3f'
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()
assert head == 'b9c756a04f37ec9dc35a4363cdee8ae9b4dadf1d'
assert not subprocess.check_output(['git', 'diff', 'HEAD'])
old = json.loads((out.parent/'v47-faf-sampling/documentation-binding.json').read_text())
for name, expected in old['user_files_sha256'].items():
    assert sha(Path(name)) == expected, name
with (out/'baseline-typescript-path-flow.py').open('xb') as stream:
    stream.write(source.read_bytes())
module = ast.parse(source.read_text())
cls = next(n for n in module.body if isinstance(n, ast.ClassDef) and n.name == 'TypeScriptPathFlow')
method = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == 'merge')
with (out/'baseline-merge.py').open('x') as stream:
    stream.write(''.join(source.read_text().splitlines(keepends=True)[method.lineno-1:method.end_lineno]))
receipt = {'decision': 'approved', 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'proposal': str(proposal), 'proposal_sha256': sha(proposal), 'starting_delivery': head, 'baseline_source_sha256': sha(source), 'baseline_merge_sha256': sha(out/'baseline-merge.py'), 'bounds': json.loads(proposal.read_text())['bounds'], 'user_files_sha256': old['user_files_sha256'], 'technical_acceptance_received': False, 'phase22_complete': False}
with (out/'authorization.json').open('x') as stream:
    json.dump(receipt, stream, indent=2); stream.write('\n')
print('Approved attempt recorded; exact baseline and protected files bound before edits.')
