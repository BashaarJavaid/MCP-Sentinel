"""Retain initial engineering/permission failures and their bounded corrections."""
import hashlib
import json
from pathlib import Path
out=Path(__file__).resolve().parent; base=out.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
expected={
'v48-full-suite':('v48-full-suite-restored','The first full run finished2383passed/36skips/1failure after123tracked files disappeared atmidnight. The worker failed importing missing sentinel.workspaces; coverage omitted deleted modules and is not accepted. Exact Git restoration and a new complete suite are separately retained; no product change.'),
'v48-lint':('v48-lint-corrected','One new test line exceeded88characters; Ruff formatting corrected it.'),
'v48-format':('v48-format-corrected','The same test needed the standard formatter; no product behavior changed.'),
'v48-affected':('v48-affected-corrected','The initial command named nonexistent test_typescript_imports.py and collected0tests. The actual test_typescript_modules.py and complete affected set were then run:514passed.'),
'v48-commit-candidate':('v48-commit-candidate-authorized','Sandbox denied creating the Git worktree index.lock before staging; the same explicitly authorized commit succeeded with reviewed filesystem escalation.'),
'v48-hosted-checkout':('v48-hosted-checkout-authorized','Restricted-network metadata read failed before creating a binding; the authorized read-only query succeeded and bound the actual hosted merge tree.')}
failed={p.stem for p in base.glob('v48-*.json') if 'exit_code' in read(p) and read(p)['exit_code']!=0}
assert failed==set(expected),failed
rows=[]
for initial,(corrected,reason) in expected.items():
    assert read(base/(corrected+'.json'))['exit_code']==0
    rows.append({'initial':initial,'initial_receipt_sha256':sha(base/(initial+'.json')),'initial_log_sha256':sha(base/(initial+'.log')),'corrected':corrected,'corrected_receipt_sha256':sha(base/(corrected+'.json')),'assessment':reason})
packet={'failures':rows,'push_review':{'initial_action':'git push origin phase22/integration','review_rejected':True,'reason':'Automatic approval review could not establish explicit authorization for exact payload and remote destination.','new_evidence':'Read section3 of the user-invoked prompt authorizing commits/delivery to existing draftPR37. Verified origin URL, exact five-file commit6e4fd67, remote base/head/open/draft and absence of user files/credentials/archives in the payload.','resolution':'Explicit SHA fast-forward push6e4fd671a97d92f6297dffc900c4dd9e18faad2c to refs/heads/phase22/integration was then approved by automatic review and completed. No bypass or alternate destination used.'},'communication_erratum':'An intermediate update mistakenly said14,688 synthetic cases; corrected promptly to the actual receipt10944. All source/checkpoint/audit evidence uses10944.','maintenance_assessment':'User confirmed unintentional deletion and authorized restoration/cleanup. The first sealed-member verification found3historical replacements that correctly match later seals36/40; the corrected latest-version check passes. Initial Docker cache verification expected6removals but Docker retained2; final validation records4actual removals,21image tags and3.7GiB recovered. Global builder prune was rejected and never executed; narrowed exact-image/cache actions were reviewed and approved. Older worktree inventory initially failed because38.gitlinks were missing; exact Git-admin restoration preserves indexes/HEADs/existing files.', 'other_read_errors':'Read-only attempts to inspect nonexistent .pre-commit-config.yaml and a guessed verify-final-distributions.py name were corrected by repository inventory. No code check or measurement was inferred from those failed reads.','scope':'No failed native gate, corpus budget or optimization attempt was retried. These are corrections within ordinary engineering for the single approved predicate change.','new_corpus_observations':0,'profiles':0,'paid_calls':0}
with (out/'check-failure-assessment.json').open('x') as stream:json.dump(packet,stream,indent=2);stream.write('\n')
print('Retained6initial engineering/permission failures, corrected checks and resolved push review.')
