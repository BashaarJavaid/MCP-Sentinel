import datetime
import hashlib
import json
import subprocess
from pathlib import Path
out = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(['git', *args], text=True).strip()
assert git('rev-parse', 'HEAD') == 'b9c756a04f37ec9dc35a4363cdee8ae9b4dadf1d'
assert git('branch', '--show-current') == 'phase22/integration'
assert not git('diff', '--cached', '--name-only')
allowed = ['CHANGELOG.md', 'src/sentinel/static/typescript_path_flow.py', 'tests/test_typescript_discovery.py']
assert set(git('diff', '--name-only').splitlines()) == set(allowed)
auth = json.loads((out/'authorization.json').read_text())
for name, expected in auth['user_files_sha256'].items():
    assert sha(Path(name)) == expected
    assert not git('ls-files', '--', name)
validation = json.loads((out/'synthetic-validation.json').read_text())
assert validation['passed'] and validation['unused_fallbacks_avoided'] > 0
checkpoint = {'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'status': 'candidate implemented; full engineering pending', 'authorization_sha256': sha(out/'authorization.json'), 'synthetic_validation_sha256': sha(out/'synthetic-validation.json'), 'source_change': 'Construct known-record fallback only when a branch lacks that record name; preserve all other merge code.', 'files_sha256': {name: sha(Path(name)) for name in allowed}, 'semantic_cases': validation['semantic_cases'], 'closed_budgets': 'Original regression: 1 incomplete, 204 unstarted closed. Sampling: 1 incomplete, budget closed. No corpus observation or profile authorized by this source-only approval.', 'corpus_observations': 0, 'paid_calls': 0, 'technical_acceptance_received': False, 'phase22_complete': False}
(out/'source-checkpoint.json').write_text(json.dumps(checkpoint, indent=2)+'\n')
subprocess.run(['git', 'add', '--', *allowed], check=True)
selected = [str(out.relative_to(Path.cwd())/name) for name in ['authorization.json', 'source-checkpoint.json']]
subprocess.run(['git', 'add', '-f', '--', *selected], check=True)
assert set(git('diff', '--cached', '--name-only').splitlines()) == set(allowed + selected)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
subprocess.run(['git', 'commit', '-m', 'Avoid unused TypeScript record fallback allocations'], check=True)
assert not git('diff', '--name-only')
with (out/'candidate-commit.json').open('x') as stream:
    json.dump({'source': git('rev-parse', 'HEAD'), 'parent': auth['starting_delivery'], 'files_sha256': {name: sha(Path(name)) for name in allowed + selected}, 'full_engineering': 'pending', 'corpus_observations': 0, 'paid_calls': 0}, stream, indent=2); stream.write('\n')
print(git('rev-parse', 'HEAD'))
