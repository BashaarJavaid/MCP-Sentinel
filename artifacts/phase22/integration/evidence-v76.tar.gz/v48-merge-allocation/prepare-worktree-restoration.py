"""Inventory missing worktree links/files using preserved Git administration data."""
import hashlib,json,subprocess
from pathlib import Path
out=Path(__file__).resolve().parent
common=Path(subprocess.check_output(['git','rev-parse','--git-common-dir'],text=True).strip()).resolve()
inventory=json.loads((out/'other-worktree-restoration-inventory.json').read_text())
admins={Path((p/'gitdir').read_text().strip()).parent:p for p in (common/'worktrees').iterdir() if (p/'gitdir').exists()}
rows=[]
for item in inventory:
    if item.get('exit_code')!=129:continue
    root=Path(item['path']);admin=admins[root]
    assert root.is_relative_to('/private/tmp') and not (root/'.git').exists()
    git=['git','--git-dir='+str(admin),'--work-tree='+str(root)]
    assert subprocess.check_output([*git,'rev-parse','HEAD'],text=True).strip()==item['head']
    entries=[]
    for line in subprocess.check_output([*git,'ls-files','--stage','-z']).decode().split('\0'):
        if not line:continue
        meta,name=line.split('\t',1);mode,blob,stage=meta.split()
        assert stage=='0'
        path=root/name
        if not path.exists() and not path.is_symlink():
            assert mode in {'100644','100755'},(root,name,mode)
            entries.append({'path':name,'blob':blob,'mode':mode})
    rows.append({'root':str(root),'admin':str(admin),'head':item['head'],'index_sha256':hashlib.sha256((admin/'index').read_bytes()).hexdigest(),'missing':entries})
with (out/'worktree-restoration-plan.json').open('x') as f:json.dump({'worktrees':rows,'scope':'Restore missing.gitlinks and only absent index-tracked files; preserve HEAD,index,existing files and any prior modifications.'},f,indent=2);f.write('\n')
print('Plan:',len(rows),'missing Git links and',sum(len(r['missing']) for r in rows),'missing indexed files; no mutation.')
