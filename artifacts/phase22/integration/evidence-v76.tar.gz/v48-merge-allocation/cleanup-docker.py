"""Remove user-authorized unused Sentinel test images; preserve all runtime data."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
raw=Path('/Users/bashaarjavaid/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw')
def run(*args):return subprocess.check_output(['docker',*args],text=True)
def lines(*args):return run(*args).splitlines()
def save(name,data):
    with (out/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
keep={'sha256:420b998fc52bd814a2e937e780f9ddc0ede656f19e46ca0df02cf76242c1469a'}
demo='mcp-sentinel-deps:5f27d80dba6a811d9aaa599843e14aae8529cd8e6e6648c57baa1dde0b50e2d6'
keep.add(run('image','inspect','--format','{{.Id}}',demo).strip())
images=[json.loads(s) for s in lines('image','ls','--no-trunc','--format','{{json .}}')]
containers=lines('ps','-aq','--no-trunc');volumes=lines('volume','ls','-q')
used=set(run('inspect','--format','{{.Image}}',*containers).splitlines()) if containers else set()
selected=[r for r in images if r['Repository'].startswith(('mcp-sentinel-deps','sentinel-phase22-','sentinel-phase15-')) and r['ID'] not in keep|used and r['Tag']!='<none>']
refs=[r['Repository']+':'+r['Tag'] for r in selected]
save('docker-cleanup-before.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'user_decision':'Restore unintentionally missing files and clear Docker test storage.','summary':run('system','df'),'raw_allocated_bytes':raw.stat().st_blocks*512,'available_bytes':os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,'keep':sorted(keep),'selected':selected,'containers':containers,'volumes':volumes,'scope':'Only inventoried unused Sentinel test-image tags; no cache prune, container/volume deletion, build,pull,target execution or paid call.'})
output=run('image','rm',*refs) if refs else ''
assert set(lines('ps','-aq','--no-trunc'))==set(containers)
assert set(lines('volume','ls','-q'))==set(volumes)
for i in keep:assert run('image','inspect','--format','{{.Id}}',i).strip()==i
remaining={r['Repository']+':'+r['Tag'] for r in (json.loads(s) for s in lines('image','ls','--no-trunc','--format','{{json .}}'))}
assert not set(refs)&remaining
assert {r['Repository']+':'+r['Tag'] for r in images if r['Tag']!='<none>'}-set(refs)<=remaining
save('docker-cleanup.json',{'passed':True,'removed_tags':refs,'command':['docker','image','rm',*refs],'stdout':output,'summary_after':run('system','df'),'raw_allocated_bytes_after':raw.stat().st_blocks*512,'available_bytes_after':os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,'runtime_images_all_containers_volumes_and_other_tags_preserved':True,'paid_calls':0,'corpus_observations':0})
print('Removed',len(refs),'unused Sentinel test-image tags; runtime images and all containers/volumes preserved.')
print(run('system','df'))
