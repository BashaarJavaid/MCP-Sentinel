"""Record actual cleanup after Docker retained two selected cache records."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
run=lambda *args:subprocess.check_output(['docker',*args],text=True)
start=json.loads((out/'sentinel-cache-cleanup-started.json').read_text())
original={r['ID']:r for r in (json.loads(s) for s in Path('/private/tmp/phase22-docker-build-cache.jsonl').read_text().splitlines())}
current={r['ID']:r for r in (json.loads(s) for s in run('buildx','du','--format','{{json .}}').splitlines())}
removed=set(original)-set(current);selected=set(start['selected'])
assert len(removed)==4 and removed<=selected
retained=selected&set(current);assert len(retained)==2
before=json.loads((out/'docker-cleanup-before.json').read_text())
assert set(run('ps','-aq','--no-trunc').splitlines())==set(before['containers'])
assert set(run('volume','ls','-q').splitlines())==set(before['volumes'])
for identity in before['keep']:assert run('image','inspect','--format','{{.Id}}',identity).strip()==identity
raw=Path('/Users/bashaarjavaid/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw')
allocated=raw.stat().st_blocks*512
p={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'image_tags_removed':21,'cache_records_selected':6,'cache_records_removed':sorted(removed),'cache_records_retained_by_docker':sorted(retained),'unselected_cache_records_preserved':True,'containers_volumes_and_required_runtime_images_preserved':True,'raw_allocated_bytes_before':before['raw_allocated_bytes'],'raw_allocated_bytes_after':allocated,'physical_docker_bytes_reclaimed':before['raw_allocated_bytes']-allocated,'host_available_bytes':os.statvfs(out).f_bavail*os.statvfs(out).f_frsize,'docker_summary':run('system','df'),'initial_assertion':'All six exact-ID prune commands returned success, but verification found two selected entries still present. The assertion was retained; actual cleanup is four cache records. No further deletion or broad prune was attempted. Per-command stdout was not retained before that assertion; no claim of its byte totals is made.','approval_review':'The original global builder prune was rejected because it might include unrelated cache; it was never executed. Revised image-only removal and six exact Sentinel wheel cache IDs were reviewed and authorized.','paid_calls':0,'corpus_observations':0}
with (out/'docker-cleanup-validation.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('Verified21test-image tags and4exact cache records removed;',round(p['physical_docker_bytes_reclaimed']/1024**3,3),'GiB physical Docker space recovered.')
