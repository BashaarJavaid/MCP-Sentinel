"""Adapt the already reviewed sequence without launching or approving it."""
from pathlib import Path
out=Path(__file__).resolve().parent
old=out.parent/'v45-four-source-recovery'
for name in ['prepare-regression.py','evaluate.py','launch.py']:
    text=(old/name).read_text().replace('v45-four-source-recovery','v48-merge-allocation').replace('v45-candidate-quality','v48-candidate-quality').replace('v45-full-suite','v48-full-suite').replace('v46-four-source-regression','v49-allocation-regression')
    if name=='prepare-regression.py':
        text=text.replace('Shared code changed in both languages, so current compatibility cannot reuse the old Python87 unchanged-source proof.', 'This allocation change is TypeScript-only, but the earlier17b4784 source recovery changed both languages and its205-observation sequence stopped before any completed input. The Python87 and TypeScript94 compatibility gates therefore both remain necessary; no closed remainder is reused.')
        text=text.replace('Measure the four exposed source corrections and every affected prior Python/TypeScript input after current engineering verification.', 'Measure the approved allocation candidate, the four previously exposed source corrections and every still-unvalidated prior Python/TypeScript input after current engineering verification.')
    (out/name).write_text(text)
print('Prepared runner sources only; no authorization, output directory or observation created.')
