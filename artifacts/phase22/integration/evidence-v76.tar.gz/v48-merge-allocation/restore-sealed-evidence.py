"""Validate all75archives; restore absent expanded members without overwriting."""
import hashlib
import json
import tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
out=Path(__file__).resolve().parent;base=out.parent
sha=lambda data:hashlib.sha256(data).hexdigest()
restored=[];checked=0;conflicts=[];archives=[]
for version in range(1,76):
    index=json.loads((base/f'evidence-v{version}.json').read_text()); archive=base/index['archive']
    assert sha(archive.read_bytes())==index['sha256'],archive
    with tarfile.open(archive) as stream:
        members=stream.getmembers();assert len(members)==len(index['files'])
        for member,row in zip(members,index['files'],strict=True):
            name=PurePosixPath(row['path'])
            assert member.isfile() and member.name==row['path'] and member.size==row['bytes']
            assert not name.is_absolute() and '..' not in name.parts
            path=base/name
            assert not path.is_symlink() and all(not p.is_symlink() for p in path.parents)
            data=stream.extractfile(member).read();assert sha(data)==row['sha256']
            if path.exists():
                if sha(path.read_bytes())!=row['sha256']:conflicts.append({'path':row['path'],'seal':version})
            else:
                path.parent.mkdir(parents=True,exist_ok=True)
                with path.open('xb') as target:target.write(data)
                restored.append({'path':row['path'],'seal':version,'sha256':row['sha256'],'bytes':len(data)})
            checked+=1
    archives.append({'version':version,'sha256':index['sha256']})
packet={'recorded_at':datetime.now(timezone.utc).isoformat(),'archives':archives,'checked_members':checked,'restored':restored,'conflicts_left_untouched':conflicts,'existing_files_overwritten':0,'paid_calls':0,'corpus_observations':0}
with (out/'sealed-evidence-restoration.json').open('x') as target:json.dump(packet,target,indent=2);target.write('\n')
assert not conflicts,conflicts[:10]
print('Verified',checked,'members in75archives; restored',len(restored),'absent expanded files; no overwrite.')
