"""Verify latest sealed member versions, retaining three historical replacements."""
import hashlib,json
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
latest={}
for version in range(1,76):
    index=json.loads((base/f'evidence-v{version}.json').read_text())
    for row in index['files']:latest[row['path']]={**row,'seal':version}
for name,row in latest.items():assert (base/name).is_file() and sha(base/name)==row['sha256'],name
old=json.loads((out/'sealed-evidence-restoration.json').read_text())
assert len(old['conflicts_left_untouched'])==3
assert all(c['seal']<latest[c['path']]['seal'] and not any(r['path']==c['path'] for r in old['restored']) for c in old['conflicts_left_untouched'])
packet={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'latest_members_verified':len(latest),'restored_expanded_files':len(old['restored']),'restoration_receipt_sha256':sha(out/'sealed-evidence-restoration.json'),'historical_replacements':[{'earlier':c,'current_latest':latest[c['path']]} for c in old['conflicts_left_untouched']],'assessment':'The first recovery assertion compared every historical version against current bytes. Three existing files correctly matched their later seals36/40 rather than earlier34/39, so that assertion stopped. No existing file was overwritten. Latest-version verification now passes for every member;6655absent expanded files were restored from verified archives.','existing_files_overwritten':0,'corpus_observations':0,'paid_calls':0}
with (out/'restoration-validation.json').open('x') as stream:json.dump(packet,stream,indent=2);stream.write('\n')
print('Verified',len(latest),'latest member versions;6655missing expanded files restored;3historical replacements preserved.')
