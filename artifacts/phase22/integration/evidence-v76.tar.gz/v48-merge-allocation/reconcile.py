"""Preserve every prior requirement and reconcile the approved allocation candidate."""
import copy
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
out=Path(__file__).resolve().parent; base=out.parent; root=Path.cwd(); olddir=base/'v47-faf-sampling'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (out/name).open('x') as stream:json.dump(data,stream,indent=2);stream.write('\n')
assert read(out/'restoration-validation.json')['passed'] and read(out/'worktree-restoration.json')['passed'] and read(out/'docker-cleanup-validation.json')['passed']
old=read(olddir/'audit.json'); audit=copy.deepcopy(old)
assert len(old['requirements'])==89 and len(old['additional_scope_requirements'])==150
rows=audit['additional_scope_requirements']
for row in rows:
    if row['id'] in {'V47-DELIVERY','V47-OPTIMIZATION-DECISION'}:
        row['previous_row']=copy.deepcopy(row)
        row['disposition']='passed'
        row['evidence']=[str((olddir/'delivery-verification.json' if row['id']=='V47-DELIVERY' else out/'authorization.json').relative_to(root))]
        row['assessment']='Exact previous draft delivery verified; user then explicitly approved the single source-only allocation attempt. Neither decision authorizes a corpus observation or technical acceptance.'
new=[
('V48-AUTH','Bind the one approved source-only attempt and preserve baseline before editing','passed',['authorization.json','baseline-merge.py']),
('V48-SOURCE','Apply only the approved fallback predicate and verify semantics and allocation reduction synthetically','passed',['source-recovery-assessment.json','synthetic-validation.json']),
('V48-ENGINEERING','Complete current-source local and hosted engineering, packages and zero-call production compatibility','passed',['local-checks.json','../v48-candidate-quality-audit/packet.json','compatibility.json']),
('V48-PREPARATION','Freeze the verified candidate and prepare an exact new native sequence with no reopened budget','passed',['freeze.json','evaluation-proposal.json','launcher-binding.json','frozen-source-validation.json']),
('V48-REGRESSION','Obtain exact approval, execute and source-assess the candidate regression before claiming corrected gates','unresolved',['evaluation-proposal.json']),
('V48-RESTORATION','Restore unintentionally deleted files and historical worktrees from exact Git/sealed evidence without overwriting existing work','passed',['tracked-restoration.json','restoration-validation.json','worktree-restoration.json']),
('V48-DOCKER-CLEANUP','Perform user-authorized disposable Docker test cleanup while preserving approved runtime images,containers and volumes','passed',['maintenance-authorization.json','docker-cleanup-validation.json']),
('V48-DELIVERY','Seal the candidate evidence and verify delivery of the exact pending proposal to existing draft PR37','unresolved',[])]
for identity,requirement,disposition,evidence in new:
    rows.append({'id':identity,'requirement':requirement,'disposition':disposition,'evidence':[str((out/n).resolve().relative_to(root)) for n in evidence],'assessment':'Approved source-only attempt verified; current native performance, corrected four-source detection and affected compatibility remain unmeasured. No historical failure is waived.'})
assert len(rows)==158 and len({r['id'] for r in audit['requirements']+rows})==247
for prior,current in zip(old['requirements']+old['additional_scope_requirements'],audit['requirements']+rows,strict=False):
    assert prior==current or current.get('previous_row')==prior
local=read(out/'local-checks.json'); quality=read(base/'v48-candidate-quality/packet.json')
assert quality['engineering_passed'] and local['states']=={'passed':2384,'skipped':36}
assert read(out/'frozen-source-validation.json')['new_corpus_observations']==0
p=read(out/'evaluation-proposal.json');assert len(p['order'])==205
assert not (out/'evaluation-authorization.json').exists() and not (base/'v49-allocation-regression').exists()
audit['historical_v47_status_fields']={k:old[k] for k in ['optimization_prepared','optimization_approved','optimization_attempts','status']}
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(),prior_audit={'path':str((olddir/'audit.json').relative_to(root)),'sha256':sha(olddir/'audit.json')},additional_scope_dispositions=dict(Counter(r['disposition'] for r in rows)),optimization_approved=True,optimization_attempts=1,optimization_synthetic_verified=True,candidate_scanner=p['scanner'],current_regression_prepared=True,current_regression_approved=False,current_regression_executed=False,new_paid_calls=0,acceptance_packet_ready=False,technical_acceptance_received=False,phase22_complete=False,status='One approved merge-allocation predicate implemented at6e4fd67;10,944 equal synthetic states,2384 local/12-hosted passes and36skips. New205-observation proposal prepared,unapproved,unexecuted. Original regression/profile timeouts and fresh failures remain preserved; corrected corpus gates and human acceptance unresolved.')
audit['current_evidence']={name:sha(out/name) for name in ['authorization.json','source-recovery-assessment.json','synthetic-validation.json','local-checks.json','freeze.json','evaluation-proposal.json','launcher-binding.json','frozen-source-validation.json']}
for identity in ['R66','R88']:
    audit['current_requirement_interpretations'][identity]='Original24first-frozen observations and all4failed fresh gates remain at2e0efb2. Corrected17b4784native regression stopped at1incomplete/204unstarted closed; separately approved sampled profile also timed out. The approved source-only allocation change at6e4fd67 passes synthetic and engineering checks only. New205-observation proposal is unapproved; no native speedup, corrected detection or current compatibility is established and no limitation accepted.'
write('audit.json',audit)
write('prior-row-preservation.json',{'prior_audit_sha256':sha(olddir/'audit.json'),'retained_prior_rows':239,'updated_rows':['V47-DELIVERY','V47-OPTIMIZATION-DECISION'],'rows':{r['id']:hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']}})
coverage=local['coverage_totals']
summary=f'''# Merge allocation candidate and pending native regression

**The single approved source-only attempt is implemented and engineering-verified at `6e4fd67`. Phase 22 remains incomplete. The new 205-observation regression is prepared, unapproved and unexecuted.**

The [authorization](authorization.json) binds the user's `approved` decision to the prior optimization proposal SHA `68c6e209007a894df21e4af6189a516eb5a95e339d92b31067d2dce3b65c88ee`. The exact baseline was preserved before editing. [Source assessment](source-recovery-assessment.json) verifies that the only product change adds the dictionary-membership condition in `TypeScriptPathFlow.merge`: construct `Value(key=root)` only if a branch needs the fallback. All other merge, traversal, guard, metadata, identity/equality and missing-record behavior remains unchanged.

[10,944 synthetic comparisons](synthetic-validation.json) preserve the result environment, every flow attribute and input dictionaries across empty/one/two/three/eight branches, missing positions, equal/unequal values, known/unknown roots, guard markers, source-free protection and record/array/path/URL metadata. Separate allocation accounting avoids four all-present fallback constructions and preserves every needed fallback in the synthetic cases. Four durable tests check all-present and missing-first/middle/last behavior. **These checks establish no native percentage speedup or completion within 300 seconds.** The membership predicate has its own cost; earlier overlapping sample shares are not promised savings.

The 514 affected tests pass. Full local and all 12 hosted suites pass **2,384 tests / 36 skips**. Local configured combined statement/branch coverage is **{coverage['percent_covered']:.2f}%**; branch-only coverage is **{coverage['percent_branches_covered']:.2f}%**. All **29 normal CI jobs** and documentation pass in [34743452798](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452798) / [34743452818](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452818). The actual hosted merge `3b11d543be3f08ba2cdb171ca4d56a00f5f18da5` has the complete candidate tree `5af35b242632286fa13d040263e96192e722a2d3`. All four optional corpus jobs are skipped. Normal CI's historical reproductions retain pinned `8824014`; they are not current-source corpus results.

Local/hosted wheel and sdist source members match candidate Git blobs; schema, lock, Ruff/format/strict mypy, notices, offline artifacts, advisory and documentation checks pass. Six actual production requests regenerate and checked-replay with unchanged fingerprints/full-request hashes and **zero model calls**; the owned Docker fixture completes 20/20 attempts with 14 findings. Nineteen unchanged runtime components and the approved Git image retain their exact bindings. The first full local run failed after 123 tracked files disappeared during testing; the worker could not import missing sentinel.workspaces. Its 2,383 passes / 36 skips / one failure and incomplete coverage remain preserved. Exact missing-only Git restoration, sealed-evidence recovery and a fresh full-suite pass are separately retained. The installed macOS /tmp cleaner schedule and 00:01 directory changes suggest environmental cleanup, but its log contains no confirming entry; the user reported laptop space pressure and confirmed no intentional deletion. Initial formatting/test-selection, Git permission and metadata-network failures also retain their corrections.

The user confirmed the deletions were unintentional and authorized restoration and Docker cleanup. Recovery restored 123 tracked files, 6,655 expanded evidence files and the missing indexed state of 38 historical worktrees using copy-on-write where possible. All 75 archives and 32,494 latest member versions validate; three historical member replacements retain their later seal versions. Docker cleanup removed 21 unused Sentinel test-image tags and four exact Sentinel wheel cache records, recovering 3.7 GiB of physical Docker storage. Two selected cache records remained; no global cache prune ran. Required Git/current-demo images, all application containers/volumes and unrelated cache entries remain intact.

The [new proposal](evaluation-proposal.json), SHA-256 `{sha(out/'evaluation-proposal.json')}`, freezes scanner `{p['scanner']['revision']}`, source SHA-256 `{p['scanner']['source_sha256']}` and harness `{p['scanner']['harness_sha256']}`. Its [launcher binding](launcher-binding.json), SHA-256 `{sha(out/'launcher-binding.json')}`, enforces the outer deadline and refuses missing approval before output or budget mutation.

One serial locked local macOS sequence proposes **205 native observations: 24 four-repository + 94 TypeScript + 87 Python**, on 110 unique exposed inputs with 95 entire ordered repeat pairs. The four repositories remain FAF and no-bash (TypeScript), Lightning and Engram (Python). This change is TypeScript-only, but the earlier shared source recovery at `17b4784` has no completed corpus observation; both prior-language compatibility schedules remain necessary. Original configurations, source prerequisites, named conditions, narrow qualifiers and complete-report references remain bound. No new repository or mutation is added. Language subsets are never pooled into a new whole Linux batch.

Bounds remain **120 seconds target, 300 seconds native/whole-input maximum, 15 seconds cleanup**, one **1,150-minute outer sequence** with a 1,149-minute internal stop. Stop and close all unstarted observations on execution, identity, timeout, schema, cleanup or ordered-repeat failure. Detection or negative-support failures remain results for full source assessment under the unchanged collection policy. All 95 entire ordered repeats must match after only the established 11 volatile exclusions. Source-assess every four-repository finding/diagnostic/surface and every prior-report delta; quiet unsupported paths cannot pass discrimination. **Zero retries, profiles, comparators, target executions, new repositories or paid calls.** No approval or execution token exists.

The previous native attempt at `17b4784` remains one incomplete input at 300.002159 seconds with 204 unstarted closed. Its separate single sampled profile remains incomplete at 300.001970 seconds, with four partial snapshots and 86,659 samples; no report and zero remaining budget. This candidate does not reopen either budget. The original four-repository first-frozen result remains 24 complete observations, 12 equal pairs and all four failed fresh gates at `2e0efb2`. Later fixes on these sources are exposed regression, never unseen-source success.

The [audit](audit.json) preserves all **239 prior requirements** and adds eight, **247 total**: all 89 original rows retain 84 passed, two user-deferred, two proposed documented limitations and one pending human acceptance. All 158 additional rows remain; their six historical failed-attempt closure proposals are unaccepted. Current corrected detection/compatibility and explicit human technical acceptance remain unresolved. Delivery gets a separate verified post-commit receipt, never a premature pass.

Memory-keeper's original fresh false alerts, DDG's initially unsupported fixed send and erroneous TypeScript manifest label despite actual Python execution, Lighthouse original misses/later exposed passes, and every prior stopped/failed attempt retain their actual source bindings. TS94 at `2e0efb2` and Python87 at `8c62567` remain historical passes. Whole 25 development reuse and 45+45 Linux timing/conditions remain at `1f3f72f`, with the Meta operator erratum. The original held-out result remains 10 completed, 10 unsupported, five incomplete, and zero hits among four completed vulnerable inputs out of ten vulnerable total. Same-agent curation/review is not independent human validation, training-data novelty, broad accuracy or runtime proof.

Git campaigns remain **312/1,040 incomplete**, with 728 deferred. Paid benchmark and pilots remain user-deferred, Phase 21 incomplete and Phase 24/15 gates unchanged. Historical paid calls remain two costing $0.071799; this continuation adds zero. No merge, ready-state change, release, outreach or Phase 23 is authorized. After a separately approved regression, complete source assessment and requirement reconciliation, then seek explicit human technical acceptance and deliver accepted closeout to the existing draft PR.
'''
(out/'summary.md').write_text(summary)
url='https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v48-merge-allocation/'
body=summary
for name in ['authorization.json','source-recovery-assessment.json','synthetic-validation.json','evaluation-proposal.json','launcher-binding.json','audit.json']:body=body.replace('('+name+')','('+url+name+')')
(out/'pr-body.md').write_text(body)
heading='## Current v47 sampled timeout: source-only proposal pending'
status=f'''## Current v48 allocation candidate: regression approval pending

The approved single source-only merge optimization is engineering-verified at
**`6e4fd67`**. It avoids constructing unused record fallbacks; **10,944 synthetic
comparisons** preserve environment, complete flow state and inputs. Allocation
checks preserve needed fallbacks. Full local and all 12 hosted suites pass
**2,384 tests / 36 skips**; local combined statement/branch coverage is
**{coverage['percent_covered']:.2f}%**, branch-only **{coverage['percent_branches_covered']:.2f}%**. All **29 normal CI jobs** and docs
pass in **34743452798 / 34743452818**, with exact candidate checkout/package
bindings. Six production requests checked-replay unchanged with zero model calls;
Git runtime/image remains compatible. No new corpus observation or profile ran.

The new **205-observation exposed regression** is prepared, **unapproved and
unexecuted**: 24 four-repository, 94 TypeScript and 87 Python, on 110 inputs and
95 ordered repeat pairs. Bounds are 120-second target, 300-second native/whole
maximum, 15-second cleanup and one 1,150-minute serial local sequence; no retry,
profile, comparator, new repository, target execution or paid call. Exact scope
is in `v48-merge-allocation/evaluation-proposal.json` and `launcher-binding.json`.
The earlier shared source recovery still lacks completed corpus validation, so
both prior-language schedules remain necessary. Synthetic allocation reduction
establishes no native speedup or 300-second completion. The old native timeout
and 204 unstarted closed, sampled timeout and all original fresh failures remain
unchanged. No closed budget is reused and no failed gate is waived.

The audit retains **all 247 requirements**, including 89 original and 158 added
rows. Corrected corpus gates, six historical closure decisions and explicit human
technical acceptance remain unresolved. **Phase 22 remains incomplete.** Git
campaigns stay 312/1,040 incomplete with 728 deferred; paid benchmark/pilots stay
deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge, ready-state
change, release, outreach or Phase 23 is authorized.

'''
oldbinding=read(olddir/'documentation-binding.json')
for name in oldbinding['owning_docs_sha256']:
    path=root/name;text=path.read_text();assert text.count(heading)==1,name
    path.write_text(text.replace(heading,status+'## Historical v47 sampled timeout: source-only proposal pending',1))
write('owning-docs.json',{'sha256':{name:sha(root/name) for name in oldbinding['owning_docs_sha256']}})
print('Preserved239prior rows;247total; updated16owning docs; native proposal remains unapproved.')
