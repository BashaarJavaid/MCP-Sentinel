"""Restore only inventoried absent files from exact candidate Git blobs."""
import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path
root=Path.cwd();out=Path(__file__).resolve().parent
p=json.loads((out/'unexpected-missing-files.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==p['head']=='6e4fd671a97d92f6297dffc900c4dd9e18faad2c'
current=subprocess.check_output(['git','diff','--name-status'],text=True).splitlines()
assert current==p['tracked_changes']
rows=[]
for name,digest in p['missing_head_blobs'].items():
    path=root/name
    assert not path.exists() and not path.is_symlink(),name
    assert all(not parent.is_symlink() for parent in path.parents if parent!=Path('/'))
    data=subprocess.check_output(['git','show',p['head']+':'+name])
    assert hashlib.sha256(data).hexdigest()==digest
    mode=subprocess.check_output(['git','ls-tree',p['head'],'--',name],text=True).split()[0]
    assert mode in {'100644','100755'}
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as stream:stream.write(data)
    path.chmod(0o755 if mode=='100755' else 0o644)
    assert hashlib.sha256(path.read_bytes()).hexdigest()==digest
    rows.append({'path':name,'sha256':digest,'mode':mode})
assert not subprocess.check_output(['git','diff','HEAD'])
receipt={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'head':p['head'],'restored':rows,'existing_files_overwritten':0,'index_or_head_changed':False,'cause':'Unconfirmed inference: installed macOS tmp_cleaner is scheduled at hour0 and removes older/tmp content. Affected directorymtime was00:01; system log had no retained entries. User was asked whether deletion was intentional; no reply had arrived before exact missing-only recovery.','failed_run':'v48-full-suite:2383passed,36skips,1worker InfrastructureError because sentinel.workspaces was missing. Its incomplete source/coverage state is not an accepted engineering pass.','next':'Restore/check missing sealed evidence, run the implicated worker tests, then a new complete local suite with unchanged candidate. No corpus or profile observation.'}
with (out/'tracked-restoration.json').open('x') as stream:json.dump(receipt,stream,indent=2);stream.write('\n')
print('Restored',len(rows),'absent tracked files from exact candidate blobs; no existing file overwritten.')
