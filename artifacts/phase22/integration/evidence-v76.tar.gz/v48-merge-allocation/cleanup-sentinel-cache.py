"""Prune only exact cache IDs whose descriptions identify Sentinel wheel builds."""
import json,os,subprocess
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent
raw=Path('/Users/bashaarjavaid/Library/Containers/com.docker.docker/Data/vms/0/data/Docker.raw')
def run(*args):return subprocess.check_output(['docker',*args],text=True)
def cache():return {r['ID']:r for r in (json.loads(s) for s in run('buildx','du','--format','{{json .}}').splitlines())}
before=cache();selected={key:r for key,r in before.items() if 'sentinel' in r.get('Description','').lower()}
assert len(selected)==6 and all(r['Reclaimable'] and not r['Mutable'] for r in selected.values())
expected={'rc0mh187v8ce60p8v8965bsni','s857df8tggx87t8x2pxm2s9mo','hva1gamdwoms33yoqei8wn45y','o8jt8u9ny33m0e88rhpo7sfht','saixwxlwwfhm4aafg0t1k47qf','t98bj5uese43fmun0szgwbk85'}
assert set(selected)==expected
containers=run('ps','-aq','--no-trunc');volumes=run('volume','ls','-q')
keep=json.loads((out/'docker-cleanup-before.json').read_text())['keep']
packet={'recorded_at':datetime.now(timezone.utc).isoformat(),'selected':selected,'commands':[],'scope':'Exact six unused Sentinel wheel cache IDs only; broad builder prune was rejected and not executed.','raw_allocated_bytes_before':raw.stat().st_blocks*512,'paid_calls':0,'corpus_observations':0}
(out/'sentinel-cache-cleanup-started.json').write_text(json.dumps(packet,indent=2)+'\n')
# Delete the wheel installation results before their COPY input records.
order=sorted(selected,key=lambda k:selected[k]['Description'].startswith('[3/4] COPY'))
for identity in order:
    observed=[json.loads(s) for s in run('buildx','du','--filter','id='+identity,'--format','{{json .}}').splitlines()]
    assert len(observed)==1 and observed[0]['ID']==identity and observed[0]['Reclaimable']
    command=['buildx','prune','--force','--filter','id='+identity]
    packet['commands'].append({'command':['docker',*command],'stdout':run(*command)})
after=cache();removed=set(before)-set(after)
assert removed<=expected and not set(selected)&set(after),(removed,set(selected)&set(after))
assert run('ps','-aq','--no-trunc')==containers and run('volume','ls','-q')==volumes
for image in keep:assert run('image','inspect','--format','{{.Id}}',image).strip()==image
packet.update(passed=True,removed_ids=sorted(removed),unselected_cache_records_preserved=True,runtime_images_containers_volumes_preserved=True,docker_summary_after=run('system','df'),raw_allocated_bytes_after=raw.stat().st_blocks*512,host_available_bytes_after=os.statvfs(out).f_bavail*os.statvfs(out).f_frsize)
with (out/'sentinel-cache-cleanup.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Removed only6Sentinel wheel cache records; all other cache records and runtime images preserved.')
print(packet['docker_summary_after'])
