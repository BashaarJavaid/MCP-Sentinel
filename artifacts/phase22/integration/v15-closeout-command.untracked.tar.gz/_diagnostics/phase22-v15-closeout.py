import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=read('v15-merge-assessment.json');v=read('v15-source-verification.json');seal=read('evidence-v44.json');p=read('v14-closeout-audit/packet.json')
p.update(source=a['scanner']['revision'],scanner_identity=a['scanner'],workflow_delivery=v['executed_engineering_source'],recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_diagnostic=a,prior_audit={'path':'artifacts/phase22/integration/v14-closeout-audit/packet.json','sha256':sha(b/'v14-closeout-audit/packet.json')},current_verification={'path':'artifacts/phase22/integration/v15-source-verification.json','sha256':sha(b/'v15-source-verification.json'),'actual_executed_engineering_source':v['executed_engineering_source'],'new_full_suite_or_hosted_run':False},next_merge_diagnostic_approved=True,next_combine_proposal_approved=False,current_source_fresh_evaluation_approved=False,new_paid_calls=0,phase22_complete=False,technical_acceptance_requested=False,technical_acceptance_received=False)
p['current_source_and_test_files']=v['source_and_test_files_sha256'];p['owning_document_binding']='Current final owning-document hashes are bound after this update in v15-final-documentation-binding.json. Native/profile and actual executed engineering identities remain distinct.'
for row in p['requirements']:
 row['evidence']=list(dict.fromkeys(row['evidence']+['artifacts/phase22/integration/v15-source-verification.json']))
 row['current_verification']='All code/test/workflow/package inputs equal actual engineering source592a9cd. Retained test results keep that execution source; no new full suite is claimed.'
 if row['id'] in ['R63','R64','R65','R69','R85','R86']:row['evidence']+=['artifacts/phase22/integration/v15-merge-assessment.json'];row['latest_diagnostic']='One approved instrumented Meta operator input completed88.533s (90.084s outer measure), full ordered baseline match, four final worker snapshots, zero optimizations/paid calls. Scope stopped; Linux/fresh/acceptance gates remain unmet.'
 if row['id']=='R79':row['evidence']+=['artifacts/phase22/integration/evidence-v44.json']
 if row['id']=='R82':row['evidence']+=['artifacts/phase22/integration/v15-delivery-verification.json']
for i,title,evidence in [('AUTH','Exact single-profile approval and immutable bindings',['v15-merge-authorization.json']),('DIAG','One completed bounded diagnostic with original production logic',['v15-merge-assessment.json']),('SEMANTICS','Synthetic state checks, ordered report match and native/SARIF validation',['v15-instrumentation-selfcheck-final/packet.json','v15-source-verification.json']),('REUSE','Unchanged source and source-bound reuse of full engineering/runtime evidence',['v15-source-verification.json']),('DELIVERY','Closed scope, sealed evidence and consolidated draft delivery',['evidence-v44.json','v15-delivery-verification.json'])]:
 p['additional_scope_requirements'].append({'id':'V15-'+i,'requirement':title,'disposition':'passed','evidence':evidence})
p['additional_scope_dispositions']=dict(collections.Counter(r['disposition'] for r in p['additional_scope_requirements']));assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==12
p['references_sha256'].update({'artifacts/phase22/integration/'+n:sha(b/n) for n in ['v15-merge-authorization.json','v15-merge-assessment.json','v15-source-verification.json','v15-next-combine-proposal.json','v15-combine-source-review.json','evidence-v44.json']})
out=b/'v15-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
summary='''The user's “okay go ahead” approved the single merge diagnostic in
`v14-next-merge-diagnostic-proposal.json`; `v15-merge-authorization.json` records
that decision. The sole Meta operator profile completed in **88.533s**
(**90.084s** including measurement setup/finalization), below 120 seconds.
All four workers have final snapshots. Its full ordered report matches the
retained native baseline after only established volatile exclusions; native JSON
and SARIF validate. The revised synthetic control passes 24 state comparisons.
The initial control-coverage assertion and documentation-binding check failures
are preserved with their corrections. No scanner code changed or optimization
was attempted. The one-profile budget is closed; zero paid calls.

Shared multi-branch value processing accounts for **17.8–21.3 instrumented
CPU-seconds** per active worker. About **85% of 19.01 million key visits** reuse
existing values. Those counts do not imply that reuse consumes 85% of the time:
the block also includes nested combining, lookups, equality and instrumentation.
URL pre-processing adds 3.79 CPU-seconds. Timings overlap where explicitly marked
and include instrumentation overhead; this is not a native performance gain.
See `v15-merge-assessment.json` and `v15-combine-source-review.json`.

Code/test/workflow/package inputs at measured `77ea21f` equal verified `592a9cd`.
The existing local and 12 hosted suites each retain 2,183 passed/36 skipped,
29 normal jobs and docs passed, production replay and Git compatibility, all at
their actual executed source. No repeated full suite or new hosted pass is
claimed. All three exposed SSRF gates remain source-compatible at `2ac39aa`.

The next `v15-next-combine-proposal.json` is **unapproved**: one counter profile,
one conditional shortcut using the existing two-value combination, up to
12 native performance observations and 30 conditional exposed regressions,
120 seconds each, zero paid calls. Its diagnostic threshold must pass before
any optimization; unused maxima close on failure. No new measurement is inferred.
Full Linux timing, fresh evaluation and final human acceptance remain unmet.
Phase 22 remains incomplete; pilots/full paid benchmark stay deferred, Phase 21
incomplete and Phase 24/15 unchanged. No merge, release, outreach or next phase.
'''
paths=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']
for name in paths:
 f=root/name;s=f.read_text()
 if name=='AGENTS.md':needle='## Current phase\n\n';assert s.count(needle)==1;s=s.replace(needle,needle+summary+'\n### Historical v14 verification at `592a9cd`\n\n',1)
 else:
  level='###' if name=='ROADMAP.md' else '##';needle=level+' Current verification at `592a9cd`';assert s.count(needle)==1;s=s.replace(needle,level+' Current v15 diagnostic at `77ea21f`\n\n'+summary+'\n'+level+' Historical v14 verification at `592a9cd`',1)
 f.write_text(s)
f=b/'requirements.md';s=f.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current 89-row audit at `592a9cd`','## Historical v14 89-row audit at `592a9cd`',1)
text='''\n## Current v15 source-bound audit\n\nAll 89 original rows remain mapped in `v15-closeout-audit/packet.json`:
**70 passed, 2 explicitly user-deferred, 17 unresolved**. The five new v15 scope
requirements pass. The seven v14 additions retain six passed and one unresolved
performance-retention requirement: **11 passed and 1 unresolved** across all
12 additional rows. Executed engineering results remain at `592a9cd`; the new
single profile is measured at `77ea21f` on identical scanner bytes.
No full timing pass, fresh result or human acceptance is inferred.\n\n| ID | Requirement | Disposition |\n| --- | --- | --- |\n'''
for row in p['additional_scope_requirements']:
 if row['id'].startswith('V15-'):text+='| '+row['id']+' | '+row['requirement']+' | **passed** |\n'
f.write_text(title+'\n'+text+rest)
index=f'''Batch 44 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every new member and all 43 prior archive hashes are verified.
Restore after batches 1–43 in separate staging using `evidence-v44.json`; existing
destinations must match identical bytes or a recorded previous hash. Stop on
unexpected conflicts. This batch retains the one profile, source-bound comparison,
synthetic control and check failures/corrections, exact approval, helpers and
unapproved next proposal. Final audit/docs/delivery bindings are tracked directly
after the seal.\n\n'''
f=b/'README.md';s=f.read_text().replace('batches 1–43 and closeout audit','batches 1–44 and closeout audit',1);s=s.replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text(f.read_text().rstrip()+'\n\n### Evidence batch 44\n\n'+index)
body=(b/'v14-closeout-draft-body.md').read_text().split('\n\n',1)[0]+'\n\n'+summary+'\n[Current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v15-closeout-audit/packet.json), [diagnostic](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v15-merge-assessment.json), [next conditional proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v15-next-combine-proposal.json), and [evidence batches 1–44](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nThis docs/evidence-only delivery uses the authorized CI-skip convention after proving tested inputs unchanged. Final docs are validated locally; no new hosted code pass is claimed.\n'
f=b/'v15-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(p['dispositions'],p['additional_scope_dispositions'])
