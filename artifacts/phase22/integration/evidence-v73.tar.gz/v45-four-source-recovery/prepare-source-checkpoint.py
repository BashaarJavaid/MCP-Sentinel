"""Preserve source-stage provenance and update current status; no corpus execution."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
git = lambda *args: subprocess.check_output(["git", *args], text=True).strip()
old = json.loads((BASE / "v44-four-fresh-evaluation/documentation-binding.json").read_text())
assert git("rev-parse", "HEAD") == "88814ad34f1a9e253fca25f00cbf13e4a0f9dd40"
assert git("branch", "--show-current") == "phase22/integration"
assert not git("diff", "--cached", "--name-only")
for path, digest in {**old['user_files_sha256'], **old['review_packet_sha256']}.items():
    assert sha(ROOT / path) == digest, path
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', '-C', str(main), 'rev-parse', 'HEAD'], text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', '-C', str(main), 'status', '--porcelain'], text=True).strip()
heading = '## Current four-repository result: failed fresh gates, decision pending'
status = '''## Current v45 source recovery: engineering verification pending

The user approved the focused source-only recovery proposal by replying
`continue`. Shared startup, import, path-return and guard corrections are now
implemented with scanner-owned synthetic controls. Full engineering verification,
a frozen corrected scanner and a separately approved exposed-regression proposal
remain before any new corpus observations. **No new corpus observation or paid
call has occurred.** No technical acceptance or limitation waiver is inferred.
The original 24 observations and all four failed fresh gates at `2e0efb2` remain
unchanged. Earlier engineering and evaluation passes retain their actual source
bindings; they are not current-code passes for this correction.
**Phase 22 remains incomplete.** Git remains 312/1,040 incomplete, paid benchmark
and pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23 is authorized.

'''
for path in old['owning_docs_sha256']:
    file = ROOT / path
    text = file.read_text()
    assert text.count(heading) == 1, path
    file.write_text(text.replace(heading, status + '## Historical v44 four-repository result: failed fresh gates, recovery proposed', 1))

files = git('diff', '--name-only', '--', 'src', 'tests', 'docs/rules.md', 'CHANGELOG.md').splitlines()
files.append('tests/test_flow_recovery.py')
packet = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'stage': 'source corrections implemented; full engineering verification pending',
    'baseline_delivery': git('rev-parse', 'HEAD'),
    'authorization': str((OUT / 'authorization.json').relative_to(ROOT)),
    'authorization_sha256': sha(OUT / 'authorization.json'),
    'first_frozen_assessment_sha256': sha(BASE / 'v44-four-fresh-evaluation/assessment.json'),
    'source_files_sha256': {name: sha(ROOT / name) for name in files},
    'synthetic_checks': {
        'class_module_and_typescript_controls': 'v45-class-module-effects.json: 284 passed',
        'path_and_reconstruction_controls': 'v45-final-synthetic-controls.json: 191 passed at its earlier snapshot',
        'collection_length_controls': 'v45-collection-length-controls.json: nine passed at its snapshot',
        'shared_flow_controls': 'v45-flow-recovery-expanded.json: 783 passed at its earlier snapshot',
    },
    'historical_expectation_correction': 'Four previously quiet Python cases guarded a resolved copy but used the original path. Those remain visible candidates; new resolved-copy qualification records the earlier check without proving equivalence, current working-directory behavior or physical containment.',
    'loop_scope': 'Only break-free unconditional loops with known path calls and intact local array operations; loop-carried locals are widened, return alternatives retained and termination unresolved. Arbitrary calls, replacement, break, continue, nested loops and closures are excluded.',
    'protected_user_files_sha256': old['user_files_sha256'],
    'new_corpus_observations': 0, 'paid_calls': 0, 'target_execution': False,
    'technical_acceptance_received': False, 'phase22_complete': False,
}
with (OUT / 'source-checkpoint.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
with (OUT / 'source-checkpoint.md').open('x') as stream:
    stream.write('''# Phase 22 source recovery checkpoint

The approved recovery changes shared source flow for actual imported-class startup,
checked TypeScript record returns and nonempty operator-root collections; narrowly
summarized canonicalization loops; available optional Python imports and local
external-import identity; and resolved-path identity and reconstruction evidence.
Unknown mutation, escape, discarded checks and unsupported control flow retain
their conservative outcomes. The reconstructed Python write remains a candidate.

All original four-repository measurements remain at `2e0efb2`: 24 completed,
12 equal ordered pairs and four failed fresh gates. These source corrections are
exposed work, not a fresh evaluation success. Every failed synthetic/engineering
attempt remains in its unique wrapper snapshot and receipt.

Full engineering verification is pending. No new corpus observation, paid call,
target execution, comparator, profile or replacement repository is authorized here.
A separate exact regression proposal follows only after verification and freeze.
Technical acceptance and final closeout remain separate pending checkpoints.
''')
print('Source checkpoint preserved; 15 current-status sections updated; protected state verified.')
