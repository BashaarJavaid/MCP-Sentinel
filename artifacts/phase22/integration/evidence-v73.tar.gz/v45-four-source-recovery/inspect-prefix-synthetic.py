"""Inspect guard states on the scanner-owned synthetic test only."""
import json,sys
from pathlib import Path
from tempfile import TemporaryDirectory
root=Path.cwd();sys.path[:0]=[str(root/'src'),str(root)]
from sentinel.static.typescript_path_flow import TypeScriptPathFlow
from tests.test_flow_recovery import test_checked_record_preserves_lexical_component_boundary
original=TypeScriptPathFlow.apply_facts
rows=[]
def inspect(self,facts,env):
    original(self,facts,env)
    rows.append({'facts':sorted(facts or []),'boundaries':{k:[v.key,w.key] for k,(v,w) in self.boundaries.items()},'state':{k:repr(v) for k,v in env.items() if k.startswith('#guard:')},'conditions':{k:repr(v) for k,v in self.conditions.items()}})
TypeScriptPathFlow.apply_facts=inspect
try:
    with TemporaryDirectory() as tmp:test_checked_record_preserves_lexical_component_boundary(Path(tmp))
except AssertionError:pass
with Path(__file__).with_suffix('.json').open('x') as f:json.dump(rows,f,indent=2)
print(json.dumps(rows,indent=2))
