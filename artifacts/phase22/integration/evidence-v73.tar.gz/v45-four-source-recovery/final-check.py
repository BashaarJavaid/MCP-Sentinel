"""Verify the complete recovery/proposal checkpoint without executing an input."""
import hashlib
import importlib.util
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
proposal = read(OUT/'evaluation-proposal.json')
audit = read(OUT/'audit.json')
old = read(BASE/'v44-four-fresh-evaluation/audit.json')
local = read(OUT/'local-checks.json')
quality = read(BASE/'v45-candidate-quality/packet.json')
hosted = read(BASE/'v45-candidate-quality-audit/packet.json')
binding = read(BASE/'v44-four-fresh-evaluation/documentation-binding.json')
assert audit['requirements'] == old['requirements']
assert len(audit['requirements']) == 89 and len(audit['additional_scope_requirements']) == 138
for before, after in zip(old['additional_scope_requirements'], audit['additional_scope_requirements'][:131], strict=True):
    if before['id'] in {'V44-DELIVERY', 'V44-RECOVERY-DECISION'}:
        assert after['previous_row'] == before and after['disposition'] == 'passed'
    else:
        assert after == before
assert not audit['acceptance_packet_ready'] and not audit['technical_acceptance_received'] and not audit['phase22_complete']
assert not audit['regression_approved'] and not audit['regression_executed']
assert quality['engineering_passed'] and quality['source'] == local['candidate'] == proposal['scanner']['revision']
assert len(hosted['quality']) == 12 and all(r['passed'] == 2380 and r['skipped'] == 36 for r in hosted['quality'])
assert len(hosted['actual_checkouts']) == 29
assert sum(j['conclusion'] == 'success' for j in quality['runs']['ci']['jobs']) == 29
assert local['states'] == {'passed': 2380, 'skipped': 36}
fixed = Path(proposal['frozen_checkout'])
for name, digest in local['candidate_engineering_files_sha256'].items():
    assert sha(ROOT/name) == digest == sha(fixed/name), name
assert not subprocess.check_output(['git', 'diff', 'HEAD'], cwd=fixed)
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=fixed)
for name, digest in read(OUT/'prior-row-preservation.json')['referenced_evidence_sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in binding['review_packet_sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in binding['user_files_sha256'].items():
    assert sha(ROOT/name) == digest, name
assert set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()) == set(binding['user_files_sha256'])
assert not subprocess.check_output(['git', 'diff', '--cached'])
changed = set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], text=True).splitlines())
assert changed == set(binding['owning_docs_sha256'])
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=main, text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=main)
subprocess.run(['git', 'merge-base', '--is-ancestor', '8b6b0ddf1d6f6cf5a8da3ab9421471865b801455', 'HEAD'], check=True)
assert read(OUT/'final-distributions.json')['README_sha256'] == sha(ROOT/'README.md')
assert read(OUT/'final-distributions.json')['wheel_product_schema_fixture_members_byte_identical_to_hosted']
assert read(OUT/'compatibility.json')['six_exact_fingerprints_and_full_requests_unchanged']
assert read(OUT/'demo-validation.json')['native_and_sarif_valid']
original = read(BASE/'v44-four-fresh-evaluation/assessment.json')
assert original['repository_gates_passed'] == 0 and original['entire_ordered_repeat_pairs_equal'] == 12
assert original['budget']['remaining'] == 0 and original['budget']['closed']
assert sha(BASE/'v44-four-fresh-evaluation/assessment.json') == 'f895435b935290a69c82ae7a7bc3f0216b31766a201ef72eca7dcade308d52da'
assert not (OUT/'evaluation-authorization.json').exists()
assert not (OUT/'execution-consumed.json').exists()
assert not (BASE/'v46-four-source-regression').exists()
spec = importlib.util.spec_from_file_location('final_runner_check', OUT/'evaluate.py')
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
assert runner.verify() == proposal
assert len(proposal['order']) == 205 and sum(r['batch'] == 'repeat' for r in proposal['order']) == 95
assert sum(len(g['input_ids']) for g in proposal['groups'].values()) == 110
launcher = read(OUT/'launcher-binding.json')
assert launcher['proposal_sha256'] == sha(OUT/'evaluation-proposal.json')
assert launcher['launcher_sha256'] == sha(OUT/'launch.py')
assert launcher['sequence_maximum_seconds'] == 69000
checks = {}
for label in ['v45-full-suite', 'v45-retain-candidate-quality', 'v45-hosted-quality-audit', 'v45-freeze',
              'v45-regression-proposal-import-path', 'v45-frozen-source-validation', 'v45-proposal-boundaries',
              'v45-supervisor-boundaries', 'v45-launcher-approval-boundary', 'v45-final-docs', 'v45-final-build',
              'v45-final-distribution-bytes', 'v45-owned-work']:
    path = BASE/(label+'.json')
    assert read(path)['exit_code'] == 0, label
    checks[label] = sha(path)
owned = read(OUT/'owned-work.json')
assert not owned['owned_processes'] and not owned['managed_container_ids'] and not owned['sentinel_named_container_ids']
provenance = read(OUT/'command-provenance.json')
assert len(provenance['failed_checks']) == 21
record = {'passed': True, 'recorded_at': datetime.now(timezone.utc).isoformat(), 'scanner': proposal['scanner'],
          'checks_sha256': checks, 'original_requirements': 89, 'additional_requirements': 138,
          'prior_rows_retained': 220, 'engineering_files_verified': 302, 'prior_evidence_files_reverified': 300,
          'protected_user_files': 8, 'main_and_parent_ancestry_preserved': True,
          'proposed_observations': 205, 'proposed_input_records': 110, 'proposed_ordered_pairs': 95,
          'proposal_sha256': sha(OUT/'evaluation-proposal.json'), 'launcher_binding_sha256': sha(OUT/'launcher-binding.json'),
          'new_current_source_corpus_observations': 0, 'paid_calls': 0,
          'first_frozen_four_gates_unchanged': True, 'acceptance_packet_ready': False,
          'technical_acceptance_received': False, 'phase22_complete': False,
          'remaining': 'Verify the next seal and existing draft delivery, then obtain separate exact evaluation approval. Actual regression/source assessment, explicit technical acceptance and final accepted closeout follow separately.'}
with (OUT/'final-checks.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print('Complete227-row source/quality/proposal consistency passes; zero new observations and no acceptance.')
