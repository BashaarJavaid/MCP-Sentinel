"""Retain every failed engineering check and its specific correction."""
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
groups = [
    (['initial-synthetic'], 'The initial test imported a nonexistent PythonURLFlow name. Corrected to existing URLFlow; this collection failure is not scanner evidence.', ['baseline-four']),
    (['baseline-synthetic'], 'The first runnable test version omitted the URLFlow deadline. Corrected the synthetic harness; its three other reproduction failures remain recorded.', ['baseline-four']),
    (['baseline-four'], 'All four legitimate synthetic reproductions failed on the prior source: imported startup, checked record qualification, local pathlib and available optional HTTPX. These are scanner-owned controls, not new corpus observations.', ['four-repros-first', 'class-module-effects']),
    (['prefix-synthetic', 'boundary-facts-synthetic'], 'Root normalization gave equality/prefix branches different keys, and checked record merging lost the common fact. Added target-bound lexical facts and all-alternative propagation; no raw-prefix or physical-safety suppression.', ['ts-startup-record-controls', 'class-module-effects']),
    (['typescript-two'], 'Selecting the entry module alone did not provide the imported class value. Reused the defining module initialization/value path; later escape controls tightened it further.', ['typescript-import-value', 'class-module-effects']),
    (['import-home-controls'], 'Resolved and original paths shared an identity, incorrectly suppressing the reconstructed-original sink. Resolution now has a distinct identity and copy checks only qualify the original-path finding.', ['resolved-idempotence-check', 'copy-proof-controls', 'final-synthetic-controls']),
    (['resolved-identity-controls'], 'Distinct resolution exposed six prior expectations. Two repeated resolutions of an already resolved value needed identity preservation and were restored. Four cases actually checked a copy and used the original; their unsafe quiet expectations were tightened and renamed where applicable. Original tests/diffs remain retained.', ['resolved-idempotence-check', 'final-synthetic-controls']),
    (['optional-client-guard-synthetic'], 'Client recovery worked but the successful ip_address result was not known non-None, losing the literal branch. Marking only the bound stdlib successful result non-None preserves existing literal guard scope.', ['ip-constructor-presence', 'class-module-effects']),
    (['canonical-loop-baseline'], 'The generic unsupported infinite loop discarded all returns. The narrow path-operation summary widens state, preserves every return and leaves termination and physical containment unresolved.', ['widened-loop-first', 'class-module-effects']),
    (['import-alias-mutation-check'], 'Escaping paths.Path did not invalidate its later constructor lookup. The canonical callee identity is now checked for unknown effects, including aliases and reimports.', ['import-escaped-constructor', 'class-module-effects']),
    (['path-loop-proof-check'], 'The bounded read-only call proof initially excluded the AST Spread operator used for an intact local array. Added only that known-array spread path; arbitrary effects and loop control remain unsupported.', ['path-loop-spread-check', 'class-module-effects']),
    (['root-cardinality-baseline', 'root-cardinality-first', 'map-cardinality-snapshot', 'zero-length-comparison'], 'Nonempty fallback/length facts were absent; the first map propagation read state after callback invalidation. Snapshotting cardinality before the callback fixed that part. The zero comparison then needed the actual JavaScript numeric AST form (Float as well as Int), not string-literal parsing. Empty/filter/flatMap/find/mutated alternatives remain negative controls.', ['numeric-zero-cardinality', 'collection-length-controls', 'class-module-effects']),
    (['exported-class-escape-baseline'], 'A class escaped in its defining module was still modeled intact when imported. Initializing that module and retrieving its actual class binding preserves the escape/replacement effects.', ['class-module-effects']),
    (['lint-first', 'lint-second'], 'Removed an unused import, formatted/split long synthetic strings and sorted imports. Both failing lint reports and intermediate source snapshots remain preserved.', ['lint-third', 'candidate-lint', 'format-check']),
]
judgments = {}
for labels, reason, corrected in groups:
    for label in labels:
        assert label not in judgments
        judgments[label] = {'assessment': reason, 'corrected_checks': ['v45-'+n for n in corrected]}
rows = []
for path in sorted(BASE.glob('v45-*.json')):
    record = json.loads(path.read_text())
    if 'exit_code' not in record or record['exit_code'] == 0:
        continue
    label = path.stem.removeprefix('v45-')
    assert label in judgments, ('Unassessed failure', label)
    row = {'label': path.stem, 'exit_code': record['exit_code'],
           'command': record['command'], 'source': record['source_commit'],
           'diff_sha256': record['diff_sha256'], 'receipt_sha256': sha(path),
           'log_sha256': sha(BASE/record['log']), **judgments[label]}
    row['corrected_check_receipts_sha256'] = {}
    for name in row['corrected_checks']:
        target = BASE/(name+'.json')
        result = json.loads(target.read_text())
        # baseline-four is an intentional failure used to correct harness validity.
        assert result['exit_code'] == 0 or name == 'v45-baseline-four'
        row['corrected_check_receipts_sha256'][name] = sha(target)
    rows.append(row)
assert {r['label'].removeprefix('v45-') for r in rows} == set(judgments)
packet = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'rows': rows,
          'qualification': 'Synthetic baseline failures and intermediate engineering corrections are preserved at their exact snapshots. No failed result is relabeled as a pass; later checks supersede implementation readiness only. No corpus, diagnostic profile, target repository execution or model call occurred.',
          'additional_provenance': [
              'v45-demo-native-schema invoked a module without a CLI entry point and therefore only imported it; its exit0 is not native report validation evidence. v45-demo-validation calls validate_report_data and validate_sarif_data directly and checks the retained20/20 attempt invariants. The separate SARIF module has a CLI and did validate its file.',
              'The startup-forwarding-guards synthetic source initially omitted await on fs.promises.realpath. The corrected awaited source has its own startup-forwarding-awaited receipt and is the retained relevant proof; the original receipt is not presented as final asynchronous correctness evidence.',
              'Synthetic AST inspections retained in inspect-*-synthetic and inspect-cardinality-v2 files explain normalization keys, imported startup, Spread and length cardinality. They analyze scanner-owned test strings only.',
              'A commentary total of777 for flow-recovery-expanded was corrected to the actual783 passing tests; its log is authoritative.',
              'A read-only lookup for v43-four-fresh-preparation/evaluate-v2.py returned missing; rg located the actual runner.py, which was then inspected. This was a file lookup, not an execution attempt.',
          ], 'new_corpus_observations': 0, 'paid_calls': 0}
with (OUT/'check-failure-assessment.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
print('Retained and assessed', len(rows), 'failed checks with exact source and correction receipts.')
