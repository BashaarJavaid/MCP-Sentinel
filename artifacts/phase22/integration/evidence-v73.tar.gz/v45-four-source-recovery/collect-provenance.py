"""Bind retained command receipts, helper sources and all known failed checks."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
rows = []
for path in sorted(BASE.glob('v45-*.json')):
    record = json.loads(path.read_text())
    if 'exit_code' not in record:
        continue
    patch = path.with_suffix('.patch')
    archive = BASE/record['untracked_source_archive']
    assert sha(patch) == record['diff_sha256']
    assert sha(archive) == record['untracked_source_sha256']
    rows.append({'receipt': path.name, 'receipt_sha256': sha(path), 'log_sha256': sha(BASE/record['log']),
                 'command': record['command'], 'source': record['source_commit'], 'exit_code': record['exit_code'],
                 'patch_sha256': sha(patch), 'untracked_source_archive_sha256': sha(archive)})
failed = {r['receipt'].removesuffix('.json') for r in rows if r['exit_code'] != 0}
assessed = {r['label'] for r in json.loads((OUT/'check-failure-assessment.json').read_text())['rows']}
assert failed == assessed | {'v45-regression-proposal', 'v45-final-distribution-verification'}
packet = {'commands': rows, 'failed_checks': sorted(failed),
          'failure_assessments_sha256': {n: sha(OUT/n) for n in ['check-failure-assessment.json', 'preparation-correction.json', 'distribution-check-correction.json']},
          'helper_sources_sha256': {p.name: sha(p) for p in sorted(OUT.glob('*.py'))},
          'qualification': 'Receipts preserve actual commands, cwd/environment, revisions, source patches, untracked source and outcomes. Earlier successful checks retain their own snapshots. Subsequent final-check/seal/delivery receipts follow this collector and are retained separately; no circular self-binding claim.',
          'read_only_lookup_notes': ['A lookup for v43-four-fresh-preparation/evaluate-v2.py found no file; rg located runner.py.', 'A lookup for v44-four-fresh-evaluation/launch.py found no file; rg located v43-four-fresh-preparation/launch.py. Neither lookup launched any evaluation.'],
          'normal_ci': 'Required hosted CI uses pinned8824014 for ordinary historical reproduction; its reports do not measure the corrected scanner. No current-source corpus observation, extra paid call or target-repository execution occurred.',
          'phase22_complete': False}
with (OUT/'command-provenance.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
print('Bound', len(rows), 'completed command receipts and', len(failed), 'assessed failures.')
