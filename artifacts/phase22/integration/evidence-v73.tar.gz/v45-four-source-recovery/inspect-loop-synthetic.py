"""Inspect only the scanner-owned loop reproduction."""
import json, sys
from pathlib import Path
from tempfile import TemporaryDirectory
root = Path.cwd()
sys.path[:0] = [str(root / 'src'), str(root)]
from sentinel.static.typescript_path_flow import TypeScriptPathFlow
from sentinel.static.typescript_discovery import walk, name_of
from tests.test_flow_recovery import test_infinite_canonicalization_loop_keeps_all_return_alternatives
original = TypeScriptPathFlow.path_loop
rows = []
def inspect(self, file, body, env):
    row = {'result': original(self, file, body, env), 'arrays': [name for name, value in env.items() if value.key in self.arrays], 'calls': []}
    for node in walk(body):
        if 'Call' in node:
            callee = node['Call'][0]
            symbol = self.program.resolve_node(file, callee)
            row['calls'].append({'name': name_of(callee), 'external': symbol.external if symbol else None, 'special': repr(callee.get('Special'))})
    rows.append(row)
    return row['result']
TypeScriptPathFlow.path_loop = inspect
try:
    with TemporaryDirectory() as tmp:
        test_infinite_canonicalization_loop_keeps_all_return_alternatives(Path(tmp), 'path.resolve(input)')
except AssertionError:
    pass
with Path(__file__).with_suffix('.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
print(json.dumps(rows, indent=2))
