"""Bind source recovery to synthetic controls without running corpus analysis."""
import ast
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/private/tmp/mcp-phase22-options')
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
HEAD = '17b4784363f35096a13d33913e98967b24cbad14'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'diff', 'HEAD'], cwd=ROOT)
original = read(BASE/'v44-four-fresh-evaluation/source-diagnosis.json')
assert len(original['rows']) == 4
code = ['src/sentinel/static/'+p for p in ['discovery.py', 'path_flow.py', 'engine.py', 'rules/sent015.py', 'typescript_path_flow.py', 'typescript_registration_flow.py']]
controls = {}
tree = ast.parse((ROOT/'tests/test_flow_recovery.py').read_text())
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        controls[node.name] = {'path': 'tests/test_flow_recovery.py', 'start_line': node.lineno, 'end_line': node.end_lineno}
rows = [
    {'case_id': 'faf-read-root',
     'source_recovery': 'The existing module-startup path now considers New expressions resolving to included classes. Imported class values come from initialization of their defining module, including its recorded replacement/escape effects. Existing instance forwarding reaches scanner-owned dictionary/switch/record/Promise.race read controls. No target module is imported or executed.',
     'guard_recovery': 'The unconditional path-operation loop is widened once and every return alternative retained. Only the listed intact path calls and local array operations qualify; arbitrary effects, breaks and nested loops remain unsupported. A canonical fallback retains lexical normalization; a raw-input fallback does not. Operator root arrays require actual nonempty cardinality or a checked length branch before fallback; filter, flatMap and find cannot borrow map cardinality.',
     'controls': ['test_imported_class_constructed_by_actual_startup', 'test_imported_constructor_requires_actual_intact_startup', 'test_startup_dictionary_forwarding_and_checked_read', 'test_infinite_canonicalization_loop_keeps_all_return_alternatives', 'test_operator_root_fallback_requires_nonempty_collection', 'test_path_loop_summary_rejects_unproven_effects'],
     'limits': 'The loop summary proves neither termination nor physical identity. Lexical-only containment keeps a physical-gap candidate. Actual FAF detection/guard support and all newly reachable tool paths remain unmeasured at this candidate.'},
    {'case_id': 'no-bash-write-prefix',
     'source_recovery': 'Equality and separator-prefix alternatives share a target-bound lexical fact even when repeated normalization calls give operator roots different symbolic identities. Checked record returns preserve the alternatives only when every tainted alternative has the fact; ignored flags, changed records and raw prefixes remain conservative.',
     'guard_recovery': 'A component-bounded lexical check qualifies the existing finding as a remaining physical-containment gap. It does not establish symlink/race safety or suppress the candidate. The common fact requires a canonical non-caller root and canonical target.',
     'controls': ['test_checked_record_preserves_lexical_component_boundary', 'test_compound_record_guard_is_checked_and_unmodified'],
     'limits': 'The original vulnerable after-prefix explanation defect and four original fixed/control false-alert occurrences remain in frozen reports. Current actual report text and support require a separately approved exposed measurement.'},
    {'case_id': 'lightning-discover-linklocal',
     'source_recovery': 'A single module try-import with an ImportError-to-None fallback creates a maybe-None external identity. Only the established available branch narrows it, including propagation into included helper calls. Shadowed ImportError, global writes, member mutation and escaped module identities are excluded. Existing client construction and request logic then apply.',
     'guard_recovery': 'A successful bound stdlib ip_address result is non-None, preserving the literal-address branch and existing URL qualification. Synthetic checks require the actual caller URL, terminal rejection and an intact import/client. DNS failure paths remain unresolved.',
     'controls': ['test_available_optional_httpx_import_reaches_actual_request', 'test_optional_import_requires_available_unmodified_branch', 'test_optional_global_availability_reaches_included_helpers', 'test_optional_client_retains_literal_guard_and_dns_limit'],
     'limits': 'The supported scope is initial literal IPv4 rejection, not destination/DNS/redirect safety. Optional dependency availability is a source prerequisite. Actual Lightning reports remain unmeasured at this candidate.'},
    {'case_id': 'engram-export-home',
     'source_recovery': 'Function-local external imports use actual import declarations and canonical namespace/class identities through the existing mutable value flow. Included local modules take precedence, and alias replacement, namespace/member mutation, escape and reimport after mutation are checked. Bound pathlib.Path and Path.home return path objects without importing pathlib from the target.',
     'guard_recovery': 'Resolution produces a distinct identity from the original path. A relative_to guard on the resolved copy cannot suppress a sink using the reconstructed original. The finding can retain an explicit resolved-copy qualification only for the checked originating input; derived paths retain every tainted origin and unrelated/replaced inputs lose the qualification.',
     'controls': ['test_function_local_pathlib_import_reaches_actual_write', 'test_local_import_identity_requires_intact_value', 'test_local_import_aliases_retain_namespace_mutations', 'test_home_guard_does_not_protect_reconstructed_original', 'test_manifest_reconstruction_keeps_only_initial_copy_evidence'],
     'limits': 'Stable operator home, environment, cwd and ordinary filesystem assumptions are source prerequisites. A resolved-copy qualifier expressly leaves equivalence and containment at use unestablished, including after cwd change. Four older test expectations that suppressed original-path sinks were tightened; their original source is preserved. Actual Engram manifest reports remain unmeasured at this candidate.'},
]
for row in rows:
    assert row['case_id'] in {r['case_id'] for r in original['rows']}
    row['controls'] = {name: controls[name] for name in row['controls']}
    row['actual_corpus_status'] = 'No new observation; original first-frozen gate failed.'
checks = {}
for label in ['v45-class-module-effects', 'v45-final-synthetic-controls', 'v45-flow-recovery-expanded', 'v45-copy-proof-controls', 'v45-collection-length-controls', 'v45-candidate-lint', 'v45-candidate-mypy', 'v45-format-check']:
    path = BASE/(label+'.json')
    record = read(path)
    assert record['exit_code'] == 0
    checks[label] = {'receipt_sha256': sha(path), 'log_sha256': sha(BASE/record['log']), 'source': record['source_commit'], 'diff_sha256': record['diff_sha256'], 'qualification': 'Exact recorded source snapshot; earlier controls are not relabeled as a full final suite.'}
packet = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'candidate': HEAD,
          'authorization_sha256': sha(OUT/'authorization.json'),
          'original_diagnosis_sha256': sha(BASE/'v44-four-fresh-evaluation/source-diagnosis.json'),
          'original_assessment_sha256': sha(BASE/'v44-four-fresh-evaluation/assessment.json'),
          'source_and_test_files_sha256': {n: sha(ROOT/n) for n in code+['tests/test_flow_recovery.py', 'tests/test_containment.py', 'docs/rules.md']},
          'rows': rows, 'synthetic_checks': checks,
          'reviewer': 'Same implementation agent; no independent human validation.',
          'full_engineering': 'Pending; this source review does not freeze or pass the candidate.',
          'compatibility_required': 'Both shared Python and TypeScript paths changed. Prior 87 Python observations at8c62567 and94 TypeScript observations at2e0efb2 are historical references, not proof of current-source compatibility. The four new repositories also require separately approved exposed regression. Preserve whole25+45+45 historical Linux timing sources and never pool language subsets into a new whole batch.',
          'new_corpus_observations': 0, 'paid_calls': 0, 'technical_acceptance_received': False, 'phase22_complete': False}
with (OUT/'source-recovery-assessment.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
print('Bound four source corrections and their synthetic controls; no corpus observation or gate claim.')
