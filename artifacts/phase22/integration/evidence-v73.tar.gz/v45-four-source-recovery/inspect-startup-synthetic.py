"""Inspect scanner-owned startup reproduction; never a corpus observation."""
import json
import sys
from pathlib import Path
from tempfile import TemporaryDirectory

root = Path.cwd()
sys.path[:0] = [str(root / 'src'), str(root)]
from sentinel.static.typescript_registration_flow import RegistrationFlow
from sentinel.static.typescript_discovery import walk
from tests.test_flow_recovery import test_imported_class_constructed_by_actual_startup

original = RegistrationFlow.initialize
rows = []
def inspect(self, initializer):
    result = original(self, initializer)
    rows.append({'file': initializer.file.relative_path,
                 'found': repr(self.found), 'warnings': repr(self.state.warnings),
                 'classes': repr(self.classes), 'instances': repr(self.instances),
                 'constructors': [repr(self.program.resolve_node(initializer.file, node['New'][1].get('t', {}).get('TyExpr', {}))) for node in walk(initializer.node) if 'New' in node]})
    return result
RegistrationFlow.initialize = inspect
try:
    with TemporaryDirectory() as tmp:
        test_imported_class_constructed_by_actual_startup(Path(tmp))
except AssertionError:
    pass
with Path(__file__).with_suffix('.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
print(json.dumps(rows, indent=2))
