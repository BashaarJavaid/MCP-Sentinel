"""Commit only the approved recovery, its status and source checkpoint."""
import datetime
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
git = lambda *args: subprocess.check_output(['git', *args], text=True).strip()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
baseline = '88814ad34f1a9e253fca25f00cbf13e4a0f9dd40'
assert git('rev-parse', 'HEAD') == baseline
assert git('branch', '--show-current') == 'phase22/integration'
assert not git('diff', '--cached', '--name-only')
old = json.loads((BASE / 'v44-four-fresh-evaluation/documentation-binding.json').read_text())
for name, digest in old['user_files_sha256'].items():
    assert sha(ROOT / name) == digest
    assert not git('ls-files', '--', name)
allowed = set(old['owning_docs_sha256']) | {
    'CHANGELOG.md', 'src/sentinel/static/discovery.py',
    'src/sentinel/static/engine.py', 'src/sentinel/static/path_flow.py',
    'src/sentinel/static/rules/sent015.py',
    'src/sentinel/static/typescript_path_flow.py',
    'src/sentinel/static/typescript_registration_flow.py',
    'tests/test_containment.py',
}
assert set(git('diff', '--name-only').splitlines()) == allowed
for label in ('v45-candidate-lint', 'v45-candidate-mypy'):
    check = json.loads((BASE / (label + '.json')).read_text())
    assert check['exit_code'] == 0
    assert check['diff_sha256'] == hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD'])).hexdigest()
files = sorted(allowed | {'tests/test_flow_recovery.py'})
before = {name: sha(ROOT / name) for name in files}
subprocess.run(['git', 'add', '--', *files], check=True)
checkpoint = [str((OUT / name).relative_to(ROOT)) for name in ('authorization.json', 'source-checkpoint.json', 'source-checkpoint.md')]
subprocess.run(['git', 'add', '-f', '--', *checkpoint], check=True)
assert set(git('diff', '--cached', '--name-only').splitlines()) == set(files + checkpoint)
subprocess.run(['git', 'diff', '--cached', '--check'], check=True)
subprocess.run(['git', 'commit', '-m', 'Recover source-bound startup, imports and path guard flow'], check=True)
assert not git('diff', '--name-only')
assert {name: sha(ROOT / name) for name in files} == before
packet = {
    'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source': git('rev-parse', 'HEAD'), 'parent': baseline,
    'files_sha256': {name: sha(ROOT / name) for name in files + checkpoint},
    'full_engineering': 'pending', 'new_corpus_observations': 0, 'paid_calls': 0,
    'phase22_complete': False, 'technical_acceptance_received': False,
}
with (OUT / 'candidate-commit.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
print(packet['source'])
