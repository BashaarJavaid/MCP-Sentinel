"""Reconcile every prior requirement and the verified source-only recovery stage."""
import copy
import hashlib
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

old = read(BASE/'v44-four-fresh-evaluation/audit.json')
proposal = read(OUT/'evaluation-proposal.json')
local = read(OUT/'local-checks.json')
quality = read(BASE/'v45-candidate-quality/packet.json')
assert quality['engineering_passed'] and quality['source'] == proposal['scanner']['revision']
assert read(OUT/'frozen-source-validation.json')['new_corpus_observations'] == 0
assert not (OUT/'evaluation-authorization.json').exists()
assert not (OUT/'execution-consumed.json').exists()
prior = read(BASE/'v43-four-fresh-preparation/prior-requirement-verification.json')
for name, digest in prior['referenced_evidence_sha256'].items():
    assert sha(ROOT/name) == digest, name
rows = copy.deepcopy(old['additional_scope_requirements'])
assert len(old['requirements']) == 89 and len(rows) == 131
updates = {'V44-DELIVERY': BASE/'v44-four-fresh-evaluation/delivery-verification.json',
           'V44-RECOVERY-DECISION': OUT/'authorization.json'}
for row in rows:
    if row['id'] in updates:
        row['previous_row'] = copy.deepcopy(row)
        row['disposition'] = 'passed'
        row['evidence'] = [str(updates[row['id']].relative_to(ROOT))]
        row['assessment'] = 'The actual v44 delivery or explicit source-only continue approval is bound by this receipt. This does not accept failed fresh gates or authorize a new corpus observation.'
new = [
    ('V45-AUTH', 'Bind explicit source-only recovery approval and preserve all closed observation budgets', 'passed', ['authorization.json']),
    ('V45-SOURCE', 'Correct the four source-established shared startup/import/guard/value gaps with conservative synthetic controls', 'passed', ['source-recovery-assessment.json', 'check-failure-assessment.json']),
    ('V45-ENGINEERING', 'Verify the actual corrected candidate with full local/hosted quality, packaging, zero-call replay and runtime bindings', 'passed', ['local-checks.json', 'checkout-binding.json', 'compatibility.json', 'candidate-distributions.json']),
    ('V45-PREPARATION', 'Freeze the verified scanner and prepare exact justified exposed/affected-compatibility scope without executing it', 'passed', ['freeze.json', 'evaluation-proposal.json', 'scoring-rubric.json', 'frozen-source-validation.json']),
    ('V45-REGRESSION', 'Obtain exact separate approval and execute only the bound exposed/compatibility sequence with closed budget', 'unresolved', ['evaluation-proposal.json']),
    ('V45-ASSESSMENT', 'Source-assess all new outcomes, prior report deltas and actual guard/sink support while preserving original failed gates', 'unresolved', ['scoring-rubric.json']),
    ('V45-DELIVERY', 'Seal the recovery evidence and verify concrete proposal delivery to existing draft PR37', 'unresolved', []),
]
for identity, requirement, disposition, evidence in new:
    rows.append({'id': identity, 'requirement': requirement, 'disposition': disposition,
                 'evidence': [str((OUT/n).relative_to(ROOT)) for n in evidence],
                 'assessment': 'Source recovery and engineering are distinct from unapproved exposed observations, the unchanged first-frozen failures, explicit human technical acceptance and subsequent closeout.'})
assert len(rows) == 138
assert len({r['id'] for r in old['requirements']+rows}) == 227
preservation = {'prior_audit_sha256': sha(BASE/'v44-four-fresh-evaluation/audit.json'),
                'rows': {r['id']: hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']},
                'updated_rows': list(updates), 'retained_prior_rows': 220,
                'referenced_evidence_sha256': prior['referenced_evidence_sha256']}
write('prior-row-preservation.json', preservation)
audit = {'recorded_at': datetime.now(timezone.utc).isoformat(), 'source': proposal['scanner']['revision'],
         'scanner_identity': proposal['scanner'], 'requirements': copy.deepcopy(old['requirements']),
         'additional_scope_requirements': rows,
         'dispositions': dict(Counter(r['disposition'] for r in old['requirements'])),
         'additional_scope_dispositions': dict(Counter(r['disposition'] for r in rows)),
         'prior_audit': {'path': 'artifacts/phase22/integration/v44-four-fresh-evaluation/audit.json', 'sha256': sha(BASE/'v44-four-fresh-evaluation/audit.json')},
         'historical_v44_status_fields': {k: old[k] for k in ['four_repository_prepared', 'four_repository_approved', 'four_repository_executed', 'four_repository_gate_passed', 'current_continuation_corpus_observations', 'budget_closed', 'remaining', 'acceptance_packet_ready', 'technical_acceptance_received', 'phase22_complete']},
         'current_evidence': {n: sha(OUT/n) for n in ['authorization.json', 'source-recovery-assessment.json', 'local-checks.json', 'compatibility.json', 'evaluation-proposal.json', 'scoring-rubric.json', 'prior-row-preservation.json']},
         'hosted_quality': {'path': 'artifacts/phase22/integration/v45-candidate-quality/packet.json', 'sha256': sha(BASE/'v45-candidate-quality/packet.json')},
         'source_recovery_approved': True, 'engineering_passed': True, 'regression_prepared': True,
         'regression_approved': False, 'regression_executed': False, 'proposed_native_observations': 205,
         'current_source_corpus_observations': 0, 'new_paid_calls': 0, 'corpus_target_executions': 0,
         'first_frozen_four_repository_gates_passed': 0, 'first_frozen_observations_unchanged': 24,
         'acceptance_packet_ready': False, 'technical_acceptance_requested': False,
         'technical_acceptance_received': False, 'phase22_complete': False,
         'current_requirement_interpretations': copy.deepcopy(old['current_requirement_interpretations']),
         'status': 'Verified source recovery, frozen scanner and unapproved205-observation exposed/compatibility proposal. The original four fresh gates remain failed. Human technical acceptance and verified closeout remain pending.'}
for identity in ['R66', 'R88']:
    audit['current_requirement_interpretations'][identity] = 'All original held-out/fresh failures remain at their actual sources, including24complete four-repository observations and four failed gates at2e0efb2. Source-only recovery is approved and engineering passes at17b4784. No corrected-scanner corpus observation has occurred; the205-observation proposal requires separate approval. Later passes are exposed regression; no fresh failure or historical closure proposal is accepted now.'
audit['current_requirement_interpretations']['R84'] = 'Explicit human technical acceptance and subsequent verified closeout remain pending. Source-recovery approval and any future evaluation approval are not acceptance. Paid benchmark/pilots and the incomplete Git remainder are user-deferred; Phase21 remains incomplete and Phase24/15 unchanged.'
write('audit.json', audit)
summary = f'''# Four-source recovery and proposed exposed regression

**Source recovery is verified at `{proposal['scanner']['revision']}`. The proposed 205-observation regression is unapproved and unexecuted. Phase 22 remains incomplete.**

The user's `continue` decision binds [source-only recovery](authorization.json), not corpus execution or technical acceptance. [Source assessment](source-recovery-assessment.json) links the four corrections to scanner-owned controls. Imported TypeScript class startup now observes defining-module replacement/escape effects; checked compound path returns retain component boundaries. Python local imports and available optional HTTPX branches retain actual external identities. A resolved-copy check qualifies a reconstructed-path finding without suppressing it or claiming containment at use. Narrow path loops keep termination and physical-containment uncertainty visible.

Full local and all twelve Linux/macOS/Windows × Python 3.10–3.13 suites pass **2,380 tests / 36 skips**. Local combined statement-and-branch coverage is **89.98%**, with **85.85% branch-only coverage**. All **29 normal CI jobs** pass in [34737757018](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34737757018), and [docs 34737757049](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34737757049) pass. The actual hosted merge checkout is `0511e6a57741ac6152922c809c3e0ad72fee0f7f`, whose complete tree equals the candidate. Ruff, formatting, configured strict mypy, lock/schema/notices, offline artifacts, dependency audit, strict docs, distributions, installed-wheel matrix, Docker, isolation and hooks are source-bound. All six actual production requests regenerate and checked-replay with unchanged fingerprints/request hashes and **zero paid calls**. The owned Docker fixture completes 20/20 attempts with 14 findings and valid native/SARIF reports. Existing Git runtime/image bindings remain unchanged; no Git campaign ran.

[Local checks](local-checks.json) bind 302 engineering files. [Failure assessment](check-failure-assessment.json) retains all 19 failed synthetic/lint/intermediate checks and their corrections, including four tightened old expectations that checked a resolved copy but used the original path. Earlier checkpoints retain their actual pre-final snapshots; they are not relabeled as final full-suite evidence. Hosted normal historical reproduction jobs retain their pinned `8824014` scanner; they are not current-source corpus observations.

One later [proposal-preparation import failure](preparation-correction.json) stopped before producing a rubric/proposal or observing any source. Its original helper and failed receipt are preserved; the corrected import-path preparation, frozen source validation and runner checks pass without any corpus observation.

The [exact proposal](evaluation-proposal.json), SHA-256 `{sha(OUT/'evaluation-proposal.json')}`, requests **one serial local macOS sequence: 205 rules-only observations on 110 exposed input records, with 95 entire ordered repeat pairs**. It adds no repository or mutation and retains the original effective configurations and labels. The 15 Python development inputs run once, as in the prior schedule; every other input runs twice.

| Scope | Observations | Input records | Ordered repeat pairs |
| --- | ---: | ---: | ---: |
| Four exposed corrections: FAF, no-bash, Lightning, Engram | 24 | 12 | 12 |
| Prior TypeScript: memory-keeper, four SSRF families, development and historical subsets | 94 | 47 | 47 |
| Prior Python: DDG, development and historical subsets | 87 | 51 | 36 |
| Total | 205 | 110 | 95 |

The first 24 observations retain the original whole twelve-input first/repeat order, then the prior TypeScript and Python schedules follow. Bounds are **120 seconds as target, 300 seconds maximum per whole/native input, 15 seconds cleanup, and 1,150 minutes maximum for the sequence** (internal stop at 1,149). Stop and close every unused observation on infrastructure, identity, execution, time, schema, cleanup or ordered-repeat failure. Detection/coverage failures remain results for source assessment after the other authorized inputs are collected. There is no tuning, retry, profile, comparator, target execution, replacement or paid call. Historical source-freeze receipts establish unchanged input provenance; all their observation budgets remain closed. A new exact authorization is required before the runner can execute.

The [prospective rubric](scoring-rubric.json) preserves every original named condition, actual caller/sink, label and source prerequisite. It states how accurate lexical/physical and resolved-copy qualifications are assessed under the frozen ordinary-file assumptions. Qualifiers remain raw findings and do not prove runtime safety. Engram's reconstructed-path equivalence remains explicitly unestablished; Lightning's private/link-local literal evidence establishes no DNS/redirect safety. Unsupported silence fails negative-path support. Every four-repository report item and every change on the earlier inputs must be source-assessed; stale finding identities are not silently accepted.

**Original four-repository first-frozen results at `2e0efb2` remain unchanged:** 24 complete observations, 12 equal ordered pairs, all within 120 seconds; all four gates failed. FAF, Lightning and Engram missed the named vulnerable sink. No-bash detected its vulnerable overwrite but falsely alerted on both negatives in each pass. Quiet negatives lacked supported guard/sink coverage. All 236 findings, 46,486 diagnostics and 270 surfaces remain retained and assessed. A later corrected pass is exposed regression, never a new fresh success or independent human validation.

The [full audit](audit.json) retains all **89 original and 131 prior additional rows**, adding seven recovery requirements for **227 total**. Source recovery and engineering do not accept R66/R88, the six historical failed-attempt closure proposals, the four failed fresh gates or R84 human acceptance. The original held-out result remains ten completed, ten unsupported and five incomplete, with zero hits among four completed vulnerable inputs out of ten vulnerable inputs total. Memory-keeper's original fresh discrimination failure, DDG's initially unsupported fixed send and manifest TypeScript-label error despite actual Python configuration, Lighthouse misses, earlier failed optimization/stopped attempts and all later exposed passes retain their real sources. The historical 70-warning backlog remains separate.

Earlier whole 25 development reuse and 45+45 historical Linux timing/condition passes remain bound to `1f3f72f`, including the Meta operator erratum. Language subsets are never pooled into a new whole original batch. Prior Python87 at `8c62567` and TypeScript94 at `2e0efb2` are comparison references; changed shared code prevents claiming their old unchanged-source compatibility proof at this scanner.

Git campaigns remain **312/1,040 incomplete**, with 728 deferred. Paid benchmark and pilots remain user-deferred, Phase 21 incomplete, and Phase 24/15 gates unchanged. Same-agent curation/review is not independent human validation, training-data novelty, broad accuracy or runtime safety proof. No merge, ready-state change, release, outreach or Phase 23 is authorized. After exact evaluation approval, continue through measured results, complete source assessment, separate explicit technical acceptance and verified closeout to the same draft PR.
'''
with (OUT/'summary.md').open('x') as stream:
    stream.write(summary)
url = 'https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v45-four-source-recovery/'
body = summary
for name in ['authorization.json', 'source-recovery-assessment.json', 'local-checks.json', 'check-failure-assessment.json', 'preparation-correction.json', 'evaluation-proposal.json', 'scoring-rubric.json', 'audit.json']:
    body = body.replace('('+name+')', '('+url+name+')')
with (OUT/'pr-body.md').open('x') as stream:
    stream.write(body)
for name in read(BASE/'v44-four-fresh-evaluation/documentation-binding.json')['owning_docs_sha256']:
    path = ROOT/name
    text = path.read_text()
    start = text.index('## Current v45 source recovery: engineering verification pending')
    end = text.index('\n## ', start+4)
    link = url+'summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md', path.parent)
    status = f'''## Current v45 source recovery: verified, regression approval pending

Source recovery at `17b4784` passes **2,380 tests / 36 skips** locally and in all
12 hosted suites; all 29 normal CI jobs and docs pass. Local combined branch-enabled
coverage is 89.98% (branch-only 85.85%). Packaging, isolation and six exact zero-call
production replays are verified. The [review packet]({link}) binds the corrected
scanner and an **unapproved 205-observation exposed/compatibility proposal**:
24 four-repository + 94 prior TypeScript + 87 prior Python observations, 110 inputs,
95 ordered pairs; 120-second target, 300-second maximum, one 1,150-minute sequence.
**No corrected-scanner corpus observation or paid call has occurred.** Original
24 first-frozen observations and all four failed fresh gates at `2e0efb2` remain
unchanged. Later passes would be exposed regression. Accurate lexical/physical and
resolved-copy qualifiers retain their source prerequisites and unresolved safety.
The audit retains all 227 requirements; no historical failure or limitation is
accepted. **Phase 22 remains incomplete** pending separate evaluation approval,
source assessment, explicit technical acceptance and verified closeout. Git stays
312/1,040 incomplete, paid benchmark/pilots deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.
'''
    path.write_text(text[:start]+status+text[end:])
print('Reconciled227 audit rows and15 owning docs; proposal unapproved, all original failures preserved.')
