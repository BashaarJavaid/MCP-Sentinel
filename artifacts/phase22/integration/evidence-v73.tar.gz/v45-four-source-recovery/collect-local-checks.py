"""Retain completed local engineering with exact source, coverage and request bindings."""
import hashlib
import importlib.metadata
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
HEAD = '17b4784363f35096a13d33913e98967b24cbad14'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'diff', 'HEAD'])
suite = ET.parse(BASE/'v45-full-suite-junit.xml').getroot()
states = Counter('failed' if node.find('failure') is not None or node.find('error') is not None else 'skipped' if node.find('skipped') is not None else 'passed' for node in suite.iter('testcase'))
assert states == {'passed': 2380, 'skipped': 36}
coverage = read(BASE/'v45-full-suite-coverage.json')
assert coverage['meta']['branch_coverage']
assert coverage['totals']['percent_covered'] >= 80
assert coverage['totals']['percent_branches_covered'] >= 80
labels = ['candidate-lint', 'candidate-mypy', 'format-check', 'full-suite', 'lock', 'schema',
          'notices', 'artifacts', 'docs', 'build', 'candidate-distributions', 'runtime-requirements',
          'dependency-audit', 'production-capture', 'runtime-reuse', 'demo-validation',
          'supervisor-boundaries', 'source-recovery-assessment', 'check-failure-assessment']
checks = {}
for label in labels:
    path = BASE/('v45-'+label+'.json')
    row = read(path)
    assert row['exit_code'] == 0
    patch = BASE/('v45-'+label+'.patch')
    assert sha(patch) == row['diff_sha256']
    checks['v45-'+label] = {'command': row['command'], 'source_commit': row['source_commit'],
        'receipt_sha256': sha(path), 'log_sha256': sha(BASE/row['log']), 'diff_sha256': sha(patch)}
old = read(BASE/'v44-four-fresh-evaluation/compatible-reuse.json')
paths = set(old['source_files_sha256']) | {'tests/test_flow_recovery.py'}
sources = {n: sha(ROOT/n) for n in sorted(paths)}
changed = {n: {'previous_sha256': old['source_files_sha256'].get(n), 'candidate_sha256': h}
           for n, h in sources.items() if old['source_files_sha256'].get(n) != h}
for name in paths:
    assert subprocess.check_output(['git', 'show', HEAD+':'+name]) == (ROOT/name).read_bytes(), name
replay = read(BASE/'v45-production-capture-revalidation/packet.json')
assert replay['source'] == HEAD and replay['model_calls'] == 0
assert len(replay['requests']) == 6 and all(r['accepted'] for r in replay['requests'])
packet = {'candidate': HEAD, 'states': dict(states), 'coverage_totals': coverage['totals'],
          'coverage_metric': '89.97540535616687 is the configured combined statement/branch coverage total. Branch-only coverage is85.85204375359815; both exceed80. Hosted legacy branch_coverage_percent names the combined branch-enabled metric.',
          'junit_sha256': sha(BASE/'v45-full-suite-junit.xml'), 'coverage_sha256': sha(BASE/'v45-full-suite-coverage.json'),
          'checks': checks, 'candidate_engineering_files_sha256': sources, 'changes_from_prior_engineering': changed,
          'precommit_lint_mypy_binding': 'The lint/mypy receipts at88814ad contain the exact candidate patch before commit; candidate-commit.json verifies that patch identity and file hashes before committing17b4784. Configured hosted checks bind the actual committed candidate separately.',
          'candidate_commit_receipt_sha256': sha(OUT/'candidate-commit.json'),
          'python': sys.version, 'packages': {name: importlib.metadata.version(name) for name in ['semgrep', 'mcp', 'pytest', 'pydantic']},
          'runtime_binding_sha256': sha(OUT/'compatibility.json'), 'production_replay_sha256': sha(BASE/'v45-production-capture-revalidation/packet.json'),
          'hosted_engineering': 'Pending separate retained matrix/job/log/package audit; no hosted pass inferred here.',
          'new_corpus_observations': 0, 'paid_calls': 0, 'technical_acceptance_received': False, 'phase22_complete': False}
with (OUT/'local-checks.json').open('x') as stream:
    json.dump(packet, stream, indent=2)
    stream.write('\n')
print('Bound2380passing tests,36skips,', len(sources), 'engineering files and6zero-call requests.')
