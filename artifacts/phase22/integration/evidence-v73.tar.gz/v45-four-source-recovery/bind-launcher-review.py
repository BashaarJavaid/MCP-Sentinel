"""Add the concrete outer supervisor binding to the unsealed review packet."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
sha = lambda name: hashlib.sha256((OUT/name).read_bytes()).hexdigest()
binding = json.loads((OUT/'launcher-binding.json').read_text())
assert binding['proposal_sha256'] == sha('evaluation-proposal.json')
assert binding['launcher_sha256'] == sha('launch.py')
for name in ['summary.md', 'pr-body.md']:
    path = OUT/name
    text = path.read_text()
    assert 'launcher-binding.json' not in text
    target = 'launcher-binding.json' if name == 'summary.md' else 'https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v45-four-source-recovery/launcher-binding.json'
    paragraph = f"\nThe [concrete launcher binding]({target}), SHA-256 `{sha('launcher-binding.json')}`, implements the existing 1,150-minute outer limit without changing the proposal's scope. The new evaluation approval must bind both this launcher packet and the exact proposal. Missing approval is verified to fail before creating output or consuming a launch token.\n"
    marker = '\nThe [prospective rubric]'
    assert marker in text
    path.write_text(text.replace(marker, paragraph+marker, 1))
path = OUT/'audit.json'
audit = json.loads(path.read_text())
audit['current_evidence']['launcher-binding.json'] = sha('launcher-binding.json')
row = next(r for r in audit['additional_scope_requirements'] if r['id'] == 'V45-PREPARATION')
row['evidence'].append('artifacts/phase22/integration/v45-four-source-recovery/launcher-binding.json')
path.write_text(json.dumps(audit, indent=2)+'\n')
print('Bound the existing outer deadline and missing-approval check in the review packet; no scope change.')
