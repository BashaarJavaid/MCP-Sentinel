"""Inspect the scanner-owned root fallback reproduction only."""
import json, sys
from pathlib import Path
from tempfile import TemporaryDirectory
root = Path.cwd()
sys.path[:0] = [str(root / 'src'), str(root)]
from sentinel.static.typescript_path_flow import TypeScriptPathFlow
from tests.test_flow_recovery import test_operator_root_fallback_requires_nonempty_collection
original = TypeScriptPathFlow.nonempty
rows = []
def inspect(self, value, env):
    result = original(self, value, env)
    rows.append({'result': result, 'key': value.key, 'flag': value.collection_nonempty,
                 'invalid': value.key in self.invalidated_objects,
                 'variants': repr(self.array_items(value, env)),
                 'names': [name for name, current in env.items() if current.key == value.key],
                 'guards': [name for name, current in env.items() if name.startswith('#guard:') and current.contained]})
    return result
TypeScriptPathFlow.nonempty = inspect
try:
    with TemporaryDirectory() as tmp:
        test_operator_root_fallback_requires_nonempty_collection(Path(tmp), "[path.resolve('/srv/unit')]", '', True)
except AssertionError:
    pass
with Path(__file__).with_suffix('.json').open('x') as stream:
    json.dump(rows, stream, indent=2)
print(json.dumps(rows, indent=2))
