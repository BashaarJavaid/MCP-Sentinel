# Proposed correction for the DDG fixed-path coverage gap

Status: source-only design in response to “how can we fix this?” No scanner changes,
scans, target executions or paid calls. The delivered v33 result and pending
acceptance packet remain unchanged; this document approves no new evaluation.

## Source-established gaps

- `src/sentinel/static/rules/sent015.py:619-647` recognizes direct HTTP methods,
  but not HTTPX `build_request` followed by `send`. The fixed source uses these at
  `fetch.py:129/135` and reports them unresolved.
- Its `facts`, `literals` and `restricted` helpers do not establish this upstream
  network-list/`any` rejection and pinning flow. Adding `send` alone cannot prove
  that the fixed guard is effective. In particular, the existing six negative IP
  flags must not be promoted to a guarantee that shared address space is blocked.
- `sent016.py:383` also has an explicit direct-method list. Any shared request-object
  representation must preserve its credential analysis and conservative unknown
  mutation behavior; this correction must not silently imply broader send coverage.

## Smallest sufficient implementation

1. Model source-established HTTPX request construction and execution using existing
   value/member/alias tracking. Carry the actual destination into `send`, preserve
   caller provenance through the pinned-URL transformation, and invalidate facts
   after request URL replacement, method rebinding or unknown mutation. Do not
   trust method names on arbitrary objects or treat `build_request` as execution.
2. Recognize the explicit literal network-membership rejection and its boolean
   helper/early-exit path. Bind any safety qualification to the same URL and
   address class rejected before dispatch. Preserve uncertainty about DNS,
   redirects, unknown callbacks and broader destinations. Prefer a narrow,
   source-backed CGNAT qualification over a blanket “safe URL” conclusion.
3. Add focused synthetic regression controls using the same build_request/send
   path: correct block, absent block, wrong network, wrong checked URL, swallowed
   rejection, replaced request URL and rebound client methods. The decisive pair
   differs only in the CGNAT guard: fixed rejection is recognized; removing it
   restores the candidate at the same supported send sink. Warnings or an absent
   finding due to lost coverage do not satisfy this test.
4. Run applicable engineering checks, freeze the corrected scanner, then prepare
   an exact separately approvable exposed-regression proposal. It must bind the
   five retained DDG inputs, additional guard-sensitivity controls if included,
   repeat/condition/schema/coverage checks, timing, environment, budget and stop
   conditions. Do not spend the closed v32/v33 observation budget or invent a new
   scanner hash before implementation. Revalidate affected prior source evidence.

## Completion criterion

The fixed HTTP request is actually analyzed, its initial CGNAT rejection has
source-bound detector evidence, and loss/bypass of that guard produces a candidate
on the same request path. Both original vulnerable variants remain detected;
fixed/control condition results repeat correctly. All residual unsupported flows
remain disclosed, and whole-server safety is not claimed.

All work can use deterministic offline analysis with zero paid model calls.
The original f85a90f fresh-source result remains immutable. A subsequent DDG
measurement is an exposed regression, not another unseen-repository success.
