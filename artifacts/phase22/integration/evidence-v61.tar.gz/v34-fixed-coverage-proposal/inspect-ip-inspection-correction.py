"""Synthetic diagnostic of narrow builtin IP type inspection; no product mutation."""
import ast
from pathlib import Path
from tempfile import TemporaryDirectory
from tests.test_ssrf import test_returned_ip_error_checks_the_mapped_address_of_the_requested_url
from sentinel.static.rules.sent015 import URLFlow, UNKNOWN_VALUE
original=URLFlow.call

def controlled(self,symbol,node,env):
 if self.external(symbol,node.func,env) in {'isinstance','builtins.isinstance'} and len(node.args)==2 and not node.keywords and isinstance(node.args[0],ast.Name) and self.external(symbol,node.args[1],env) in {'ipaddress.IPv4Address','ipaddress.IPv6Address'}:
  value=self.expression(symbol,node.args[0],env)
  if self.parts.get(value.key,('',''))[1]=='ip' and self.address_intact(value,env):return UNKNOWN_VALUE
 return original(self,symbol,node,env)
URLFlow.call=controlled
for checked in ['url','other']:
 with TemporaryDirectory() as tmp:
  test_returned_ip_error_checks_the_mapped_address_of_the_requested_url(Path(tmp),checked)
  print('Synthetic mapped-address control passes:',checked)
