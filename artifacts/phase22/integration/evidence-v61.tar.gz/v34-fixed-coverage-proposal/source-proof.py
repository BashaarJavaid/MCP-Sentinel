"""Check unaffected TypeScript paths and frozen input configuration, without scanning."""
import ast
import hashlib
import itertools
import json
import subprocess
from pathlib import Path

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],text=True)
old='f85a90f';new='5b5016e'
changed=git('diff','--name-only',old,new,'--','src').splitlines()
assert set(changed)=={'src/sentinel/static/engine.py','src/sentinel/static/rules/sent015.py','src/sentinel/static/path_flow.py'}
def tree(rev,path):return ast.parse(git('show',rev+':'+path))
def defs(t):return {n.name:ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=[defs(tree(v,'src/sentinel/static/path_flow.py')) for v in [old,new]]
assert a.keys()==b.keys() and [k for k in a if a[k]!=b[k]]==['PathFlow']
a,b=[defs(tree(v,'src/sentinel/static/rules/sent015.py')) for v in [old,new]]
assert a.keys()==b.keys() and [k for k in a if a[k]!=b[k]]==['restricted','URLFlow']
assert a['TypeScriptURLFlow']==b['TypeScriptURLFlow'] and a['detect']==b['detect']
assert not git('diff',old,new,'--','src/sentinel/static/typescript_path_flow.py','src/sentinel/static/typescript_discovery.py','src/sentinel/static/typescript_registration_flow.py','src/sentinel/static/traversal.py','src/sentinel/static/model.py','src/sentinel/static/coverage.py','src/sentinel/static/workers.py')
t=tree(new,'src/sentinel/static/typescript_path_flow.py');cls=next(n for n in t.body if isinstance(n,ast.ClassDef) and n.name=='TypeScriptPathFlow');assert cls.bases==[]
assert 'if language is not TargetLanguage.TYPESCRIPT and path.suffix == ".py":' in (ROOT/'src/sentinel/static/traversal.py').read_text()
ts=next(n for n in tree(new,'src/sentinel/static/rules/sent015.py').body if isinstance(n,ast.ClassDef) and n.name=='TypeScriptURLFlow')
constants={n.value for n in ast.walk(ts) if isinstance(n,ast.Constant) and isinstance(n.value,str)}
assert not any(x.startswith('not:is_') or x=='cgnat-ipv4' for x in constants)
# URL facts are internal enumerated facts, never target-controlled strings. The TS
# producer enumerates the six names below; the other constructor emits scheme/host.
admissible=['scheme','host','literal-ipv4','loopback-ipv4','loopback-ipv4-default','linklocal-ipv4']
for n in admissible:assert n in constants
# Evaluate only scanner-owned pure restriction helpers, never target source.
funcs=[]
for rev in [old,new]:
 module=tree(rev,'src/sentinel/static/rules/sent015.py');nodes=[n for n in module.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='IP_CHECKS' for x in n.targets) or isinstance(n,ast.FunctionDef) and n.name=='restricted']
 namespace={};exec(compile(ast.Module(body=nodes,type_ignores=[]),'<scanner restriction control>','exec'),namespace);funcs.append(namespace['restricted'])
for bits in itertools.product([False,True],repeat=6):
 checks=frozenset(n for n,on in zip(admissible,bits) if on);assert funcs[0](checks)==funcs[1](checks)
configs=[]
p=json.loads((BASE/'v30-compatibility-proposal/evaluation-proposal.json').read_text())
for group,g in p['groups'].items():
 for id,row in g['inputs'].items():
  path=ROOT/row['configuration'];assert sha(path)==row['configuration_sha256']
  assert json.loads(path.read_text())['language']=='typescript'
  configs.append({'group':group,'input_id':id,'configuration_sha256':sha(path)})
lighthouse=json.loads((BASE/'v29-loopback-fix/evaluation-proposal.json').read_text())
path=ROOT/lighthouse['configuration_path'];cfg=json.loads(path.read_text())
for id,row in cfg.items():
 assert row['configuration']['language']=='typescript';configs.append({'group':'lighthouse','input_id':id,'configuration_sha256':row['sha256']})
assert len(configs)==44
# The only new engine description branch is selected by cgnat-ipv4, emitted only
# by PythonURLFlow. All prior TS captures and descriptions retain their text.
engine_diff=git('diff',old,new,'--','src/sentinel/static/engine.py')
assert 'cgnat-ipv4' in engine_diff
frozen=Path(json.loads((OUT/'freeze.json').read_text())['frozen_checkout'])
assert not subprocess.check_output(['git','status','--porcelain'],cwd=frozen)
assert not git('diff',new,'--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile')
result={'source_only':True,'from_scanner':old,'to_scanner':new,'changed_product_files':changed,'shared_value_helpers_unchanged':True,'typescript_class_and_dispatch_unchanged':True,'typescript_runtime_does_not_inherit_python_PathFlow':True,'typescript_inputs_disable_python_collection':True,'admissible_typescript_guard_facts':admissible,'all64_guard_fact_combinations_equal':True,'new_engine_branch':'cgnat-ipv4 emitted only by Python URLFlow; never a TS capture','retained_typescript_inputs':configs,'retained_measurements':'54-observation compatibility and10-observation Lighthouse packets atf85a90f; no new measurements or performance claim.','frozen_checkout_clean':True,'corpus_observations':0,'paid_calls':0,'limitation':'The46 Python development/historical inputs and five DDG inputs require separately approved current-scanner measurements. Historical whole-batch timing stays at1f3f72f.'}
path=OUT/'source-proof.json';assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n');print('44 TS input records retain source-compatible paths;64 internal fact combinations agree; zero scans.')
