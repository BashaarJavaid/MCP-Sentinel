from pathlib import Path
p=Path('src/sentinel/static/rules/sent015.py');s=p.read_text();s=s.replace('"host" in checks or checks >= IP_CHECKS or "is_global" in checks','"host" in checks\n        or (checks >= IP_CHECKS and "cgnat-ipv4" in checks)\n        or "is_global" in checks')
s=s.replace('self.parts: dict[str, tuple[str, str]] = {}','self.parts: dict[str, tuple[str, str]] = {}\n        self.networks: dict[str, ipaddress.IPv4Network | ipaddress.IPv6Network] = {}\n        self.requests: set[str] = set()',1)
s=s.replace('self.parts[result.key] = (self.parts[receiver.key][0], node.attr)','''self.parts[result.key] = (self.parts[receiver.key][0], node.attr)
                if "cgnat-ipv4" in receiver.url_checks and node.attr == "scheme":
                    # Qualification of the initially checked URL, not the new
                    # authority produced by later URL reconstruction.
                    result = replace(result, url_checks=frozenset({"cgnat-ipv4"}))''',1)
marker='    def call(self, symbol: Symbol, node: ast.Call, env: dict[str, Value]) -> Value:\n'
pos=s.index(marker)
s=s[:pos]+'''    def network_rejection(
        self, symbol: Symbol, node: ast.Call, env: dict[str, Value]
    ) -> Value | None:
        """Recognize bounded, unfiltered membership over source-known networks."""
        if len(node.args) != 1 or node.keywords:
            return None
        expression = node.args[0]
        if not (
            isinstance(expression, ast.GeneratorExp)
            and len(expression.generators) == 1
            and isinstance(expression.elt, ast.Compare)
            and len(expression.elt.ops) == 1
            and isinstance(expression.elt.ops[0], ast.In)
        ):
            return None
        generator = expression.generators[0]
        if (
            generator.is_async
            or generator.ifs
            or not isinstance(generator.target, ast.Name)
            or not isinstance(expression.elt.comparators[0], ast.Name)
            or expression.elt.comparators[0].id != generator.target.id
        ):
            return None
        items = self.sequence_elements(
            self.expression(symbol, generator.iter, env), env
        )
        if not items:
            return None
        blocked = []
        for item in items:
            network = self.networks.get(item.key)
            if (
                network is None
                or "#member:unknown:" + item.key in env
                or any(marker in env for marker in self.members.get(item.key, {}).values())
            ):
                return None
            blocked.append(network)
        ip = self.expression(symbol, expression.elt.left, env)
        origin, part = self.parts.get(ip.key, ("", ""))
        if part != "ip":
            return None
        value = Value(key=_key("network-membership", origin, *map(str, blocked)))
        shared = ipaddress.ip_network("100.64.0.0/10")
        checks = frozenset({(origin, "cgnat-ipv4")}) if any(
            network.version == 4 and shared.subnet_of(network) for network in blocked
        ) else frozenset()
        self.predicates[value.key] = (checks, frozenset())
        return value

'''+s[pos:]
pos=s.index('        if receiver.key in self.ip_lists:',s.index(marker))
s=s[:pos]+'''        if external in {"any", "builtins.any"}:
            membership = self.network_rejection(symbol, node, env)
            if membership is not None:
                return membership
        if external == "ipaddress.ip_network" and len(node.args) == 1 and not node.keywords:
            literal = member_label(self.expression(symbol, node.args[0], env))
            if isinstance(literal, str):
                try:
                    network = ipaddress.ip_network(literal)
                except ValueError:
                    pass
                else:
                    value = Value(key=_key("ip-network", symbol.file.relative_path,
                                           str(node.lineno), *self.call_sites))
                    self.networks[value.key] = network
                    self.record_keys.add(value.key)
                    return value
        if external == "urllib.parse.urlunparse" and len(node.args) == 1 and not node.keywords:
            sequence = self.expression(symbol, node.args[0], env)
            parts = self.sequence_elements(sequence, env)
            if parts is not None and len(parts) == 6:
                value = replace(combine(list(parts)), key=_key("rebuilt-url", sequence.key),
                                url_checks=frozenset())
                # Only the scheme from the checked parsed URL carries the initial
                # literal rejection; arbitrary string formatting does not.
                if self.parts.get(parts[0].key, ("", ""))[1] == "scheme":
                    value = replace(value, url_checks=parts[0].url_checks & {"cgnat-ipv4"})
                return value
        if self.parts.get(receiver.key, ("", ""))[1] == "hostname" and not node.keywords:
            if (method == "lower" and not node.args) or (
                method == "rstrip" and len(node.args) == 1
                and isinstance(node.args[0], ast.Constant) and node.args[0].value == "."
            ):
                return receiver
'''+s[pos:]
pos=s.index('        service_request = client and service in {',s.index(marker))
s=s[:pos]+'''        if client and service in {"httpx.Client", "httpx.AsyncClient"}:
            if method == "build_request":
                arguments = [self.expression(symbol, arg, env) for arg in node.args]
                keywords = {kw.arg: self.expression(symbol, kw.value, env) for kw in node.keywords}
                if (
                    len(arguments) <= 2 and None not in keywords
                    and not any(isinstance(arg, ast.Starred) for arg in node.args)
                    and not (arguments and "method" in keywords)
                    and not (len(arguments) == 2 and "url" in keywords)
                    and (arguments or "method" in keywords)
                    and (len(arguments) == 2 or "url" in keywords)
                ):
                    url = keywords.get("url", arguments[1] if len(arguments) == 2 else UNKNOWN_VALUE)
                    request = Value(key=_key("httpx-request", symbol.file.relative_path,
                                             str(node.lineno), str(node.col_offset), *self.call_sites))
                    self.requests.add(request.key)
                    self.record_keys.add(request.key)
                    env[self.member_key(request, "url")] = url
                    return self.aggregate(request, env)
            if method == "send":
                arguments = [self.expression(symbol, arg, env) for arg in node.args]
                keywords = {kw.arg: self.expression(symbol, kw.value, env) for kw in node.keywords}
                if (
                    len(arguments) <= 1 and None not in keywords
                    and not any(isinstance(arg, ast.Starred) for arg in node.args)
                    and not (arguments and "request" in keywords)
                ):
                    request = keywords.get("request", arguments[0] if arguments else UNKNOWN_VALUE)
                    if request.key in self.requests:
                        url = self.member(request, "url", env)
                        self.url_sink(symbol, node, url, name)
                        if "#member:unknown:" + request.key in env or url.maybe_missing:
                            self.unresolved(symbol, node, "request URL state is unresolved")
                        return UNKNOWN_VALUE
'''+s[pos:]
s=s.replace('"sink_name": name,\n                        "flow_locations": json.dumps(','''"sink_name": name,
                        **({"url_guard_scope": "cgnat-ipv4"}
                           if "cgnat-ipv4" in url.url_checks else {}),
                        "flow_locations": json.dumps(''',1)
p.write_text(s)
p=Path('src/sentinel/static/engine.py');s=p.read_text().replace('            else definition.description\n','''            else "The source rejects initial literal IPv4 destinations in shared "
            "address space (100.64.0.0/10) for the checked caller URL before this "
            "request. This candidate does not allege that initial shared-space "
            "bypass. Other destinations, subsequent URL transformations, DNS, "
            "redirects and IPv6 protection remain unestablished."
            if match.captures.get("url_guard_scope") == "cgnat-ipv4"
            else definition.description
''',1);p.write_text(s)
