"""Diagnose the failing synthetic IP inspection control; never reads corpus targets."""
import ast
from pathlib import Path
from tempfile import TemporaryDirectory
from tests.test_ssrf import test_returned_ip_error_checks_the_mapped_address_of_the_requested_url
from sentinel.static.rules.sent015 import URLFlow
original=URLFlow.call

def traced(self,symbol,node,env):
 name=ast.unparse(node.func)
 before={k for k in env if k.startswith('#member:unknown:')}
 value=original(self,symbol,node,env)
 after={k for k in env if k.startswith('#member:unknown:')}
 if after-before:print('NEW UNKNOWN MUTATION',name,sorted(after-before),flush=True)
 return value
URLFlow.call=traced
with TemporaryDirectory() as tmp:
 try:test_returned_ip_error_checks_the_mapped_address_of_the_requested_url(Path(tmp),'url')
 except AssertionError:print('Reproduced mapped-address inspection failure')
 else:raise AssertionError('Failure did not reproduce')
