from pathlib import Path
from tempfile import TemporaryDirectory
from tests.test_ssrf_prepared_requests import report,PREFIX,GUARD
from sentinel.static.rules.sent015 import URLFlow
oldassign=URLFlow.assign
oldfunction=URLFlow.function
def assign(self,target,value,env):
 oldassign(self,target,value,env)
 import ast
 if isinstance(target,ast.Attribute): print('ASSIGN',ast.unparse(target),[(k,v.key[:8]) for k,v in env.items() if k.startswith('#member:')], self.globals)
def function(self,symbol,bindings):
 print('FUNCTION',symbol.name,[(k,v.key[:8]) for k,v in bindings.items() if k.startswith('#member:')])
 return oldfunction(self,symbol,bindings)
URLFlow.assign=assign
URLFlow.function=function
old=URLFlow.network_rejection
def debug(self,symbol,node,env):
 print('NETWORKS',[(k[:8],str(v),self.members.get(k),{m:env[m] for m in self.members.get(k,{}).values() if m in env}) for k,v in self.networks.items()])
 print('MEMBERS',[(k,v) for k,v in env.items() if k.startswith('#member:') and v.sources])
 return old(self,symbol,node,env)
URLFlow.network_rejection=debug
with TemporaryDirectory() as d:
 report(Path(d),PREFIX+GUARD+'''@mcp.tool()
def fetch(url: str, other: str):
    BLOCKED[1].network_address = other
    validate(url)
    client = httpx.Client()
    request = client.build_request("GET", url)
    return client.send(request)
''')
