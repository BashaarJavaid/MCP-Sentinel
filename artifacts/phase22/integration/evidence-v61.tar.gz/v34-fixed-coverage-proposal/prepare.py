"""Prepare the exposed correction and Python compatibility packet; no scanner runs."""
import hashlib
import json
import shutil
import tempfile
from pathlib import Path

from scripts.phase20_corpus import validate as historical, materialize
from scripts.phase22_corpus import frozen
from scripts.phase20_measurements import load_configuration, LLM
from scripts.phase20_scoring import candidate_identity

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
freeze=read(OUT/'freeze.json');groups={};files={};order=[]
def bind(p):
 name=p.relative_to(ROOT).as_posix();files[name]=sha(p);return name
for group in ['ddg','development','historical']:
 approval=BASE/'v32-fresh-v6/evaluation-authorization.json' if group=='ddg' else ROOT/'artifacts/phase22/authorization.json' if group=='development' else None
 manifest=historical() if group=='historical' else frozen(approval_path=approval)
 manifest_path=ROOT/'tests/evals/phase20/manifest.yaml' if group=='historical' else ROOT/read(approval)['corpus']['manifest']
 if group=='ddg':
  ids=[i.id for i in manifest.inputs[-5:]]
  report_root=BASE/'v33-fresh-v6/raw'
  assessment_path=BASE/'v33-fresh-v6/assessment.json';scored={}
 else:
  ids=[i.id for i in manifest.inputs if i.language=='python' and (group=='historical' or i.split=='development')]
  report_root=BASE/('v22-final-hosted/artifacts/phase22-refresh-historical_first' if group=='historical' else 'v21-sequence-hosted/artifacts/phase22-full-development')
  assessment_path=BASE/('v22-refresh-v1/condition-assessment.json' if group=='historical' else 'v21-full-linux-v1/development-condition-assessment.json')
  scored={r['input_id']:r for r in read(assessment_path)['assessments']}
 bind(assessment_path);bind(manifest_path)
 if approval:bind(approval)
 selected=[i for i in manifest.inputs if i.id in ids];assert [i.id for i in selected]==ids
 target=OUT/'references'/group;target.mkdir(parents=True,exist_ok=False);rows={};snapshots={s.revision:s for s in manifest.snapshots}
 for item in selected:
  pattern=f'*rules-first*/{item.id}/report.json' if group=='ddg' else f'*/{item.id}/report.json'
  paths=list(report_root.glob(pattern));assert len(paths)==1,(group,item.id,paths)
  source=paths[0];report=read(source);ref=target/(item.id+'.json');shutil.copyfile(source,ref)
  config=source.parent/'configuration.json';dest=target/(item.id+'-configuration.json');shutil.copyfile(config,dest)
  with tempfile.TemporaryDirectory(prefix='phase22-v34-source-only-') as tmp:
   source_root=materialize(item,snapshots[item.snapshot],Path(tmp).resolve()/'source',manifest.packet)
   c=load_configuration(source_root,environ={},static_only=True,cli_overrides={'rules_only':True,'ignore_paths':['.phase20/**'],'max_findings_per_scan':500},llm_cli_overrides={'model':LLM.model,'reasoning_effort':'medium','retries':0,'max_concurrency':1,'cache_enabled':False})
   payload={'scanner':c.scanner.model_dump(mode='json'),'target':c.target.model_dump(mode='json') if c.target else None,'static_only':c.static_only,'language':c.language.value}
   assert payload==read(dest),(group,item.id,'configuration changed')
  a=None
  if group!='ddg':
   match=scored[item.id].get('matches',scored[item.id].get('matched_keys'))
   assert match is not None
   a={'candidate_identity':candidate_identity(report['findings']),'matches':match,'rationale':'Retained original named-condition assessment applies automatically only if entire ordered findings equal the reference; changed outputs require individual source assessment. Preserve the two approved raw Meta operator erratum alerts, never relabel valid negatives.'}
  rows[item.id]={'input':item.model_dump(mode='json'),'reference_report':bind(ref),'reference_original':source.relative_to(ROOT).as_posix(),'configuration':bind(dest),'configuration_sha256':sha(dest),'assessment':a,'source_only_materialization_configuration_verified':True}
 groups[group]={'manifest':bind(manifest_path),'manifest_sha256':sha(manifest_path),'source_freeze_approval':bind(approval) if approval else None,'input_ids':ids,'inputs':rows,'assessment_path':bind(assessment_path)}
 for batch in (['first','repeat'] if group in {'ddg','historical'} else ['compatibility']):
  order.extend({'group':group,'batch':batch,'input_id':i} for i in ids)
assert len(order)==87 and len(groups['development']['input_ids'])==15 and len(groups['historical']['input_ids'])==31
for p in [OUT/'evaluate.py',OUT/'scoring-rubric.json',OUT/'freeze.json',OUT/'implementation-authorization.json',BASE/'v32-fresh-v6/runner.py',BASE/'v20-linux-diagnostic-v1/runner.py']:bind(p)
p={'status':'prepared_not_approved','scanner':freeze['scanner'],'frozen_checkout':freeze['frozen_checkout'],'lock_sha256':freeze['harness_and_lock_sha256']['uv.lock'],'purpose':'Demonstrate actual DDG prepared-request sink coverage and narrow initial CGNAT guard recognition, then revalidate all affected Python development/historical inputs after shared Python flow corrections.','runner':bind(OUT/'evaluate.py'),'execution':'One serial local macOS sequence in immutable5b5016e using the existing locked Python3.12 environment; no overlapping owned heavy work. This is exposed regression and partial compatibility, not a new whole-batch Linux timing result.','bounds':{'native_observations':87,'local_sequences':1,'hosted_dispatches':0,'normal_target_seconds':120,'native_and_whole_input_maximum_seconds':300,'cleanup_maximum_seconds_per_input':15,'sequence_maximum_minutes':480,'retries':0,'profiles':0,'comparators':0,'paid_calls':0,'target_execution':False},'groups':groups,'order':order,'files_sha256':files,'volatile_exclusions':read(BASE/'v13-exposed-assessment/packet.json')['volatile_fields'],'gate':'All87 observations complete and schemas/identity/configuration/cleanup pass. All36 entire ordered repeats agree. Detection and coverage must satisfy scoring-rubric.json after individual source assessment; raw completion alone is not a gate pass.','stop':'First execution, timeout, identity, configuration, schema, cleanup or entire ordered-repeat failure closes every unstarted observation. Detection/coverage changes remain measured outcomes and do not abort collection or authorize tuning/retry. Finish after87; no resumption. Do not start without315seconds remaining.','reuse':'TypeScript implementation and admissible guard facts retain source-compatible behavior as documented in source-proof.json, including the54-observation compatibility and10-observation Lighthouse results atf85a90f. Historical whole25+45+45 timing remains at1f3f72f; do not pool old TypeScript with new Python as a new whole batch.','guard_controls':'The committed synthetic same-path controls demonstrate guard presence/removal/bypass and invalidation. This proposal measures the five unchanged complete upstream DDG corpus records twice; it adds no altered upstream counterfactual sources. Actual fixed-input send/guard evidence is mandatory under the rubric.','corpus_authorization':'Old receipts bind only immutable source/configuration; all old budgets remain closed. A new exact evaluation-authorization.json must bind this proposal, scanner, order, bounds and rubric before any observation.','exposure':'All inputs exposed before correction. Original f85a90f DDG fresh result and all earlier misses/failures remain immutable; no new unseen-source success is claimed.','not_authorized':['Paid calls','Corpus target execution','Another fresh corpus','Profiles or retries','Technical acceptance','Merge/release/outreach/Phase23'],'phase22_complete':False}
path=OUT/'evaluation-proposal.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print('Prepared87 observations and51 source-only materializations; zero scans.')
