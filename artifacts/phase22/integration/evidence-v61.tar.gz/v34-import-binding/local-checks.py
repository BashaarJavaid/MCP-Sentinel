"""Bind completed local checks and full-suite source without relabeling older runs."""
import hashlib,json,subprocess,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['v34-import-full-suite','v34-import-lint','v34-import-format','v34-import-final-mypy','v34-lock','v34-import-schema','v34-import-notices','v34-import-artifacts','v34-import-production-capture-corrected','v34-import-binding-affected']
checks=[]
for label in labels:
 path=BASE/(label+'.json');m=json.loads(path.read_text());assert m['exit_code']==0,label
 checks.append({'label':label,'source':m['source_commit'],'command':m['command'],'exit_code':m['exit_code'],'metadata_sha256':sha(path),'log_sha256':sha(BASE/m['log'])})
control=json.loads((BASE/'v34-import-binding-affected.json').read_text())
assert hashlib.sha256(subprocess.check_output(['git','diff',control['source_commit'],'a50e9b7'])).hexdigest()==control['diff_sha256']
m=json.loads((BASE/'v34-import-full-suite.json').read_text());assert m['source_commit']=='8a3db5885981f511b58eb484550229c15d11bca0'
assert (BASE/'v34-import-full-suite.patch').read_bytes()==b''
counts=Counter('skipped' if c.find('skipped') is not None else 'failed' if c.find('failure') is not None or c.find('error') is not None else 'passed' for c in ET.parse(BASE/'v34-import-full-suite-junit.xml').iter('testcase'))
assert counts=={'passed':2280,'skipped':36}
coverage=json.loads((BASE/'v34-import-full-suite-coverage.json').read_text())['totals']['percent_covered'];assert coverage>=80
inputs=['src','tests','scripts','schemas','pyproject.toml','uv.lock','action.yml','.github','Makefile','LICENSE','CHANGELOG.md']
assert not subprocess.check_output(['git','diff','a50e9b7','--',*inputs])
paths=subprocess.check_output(['git','ls-tree','-r','--name-only',m['source_commit'],'--',*inputs],text=True).splitlines()
for n in paths:assert not (ROOT/n).is_symlink(),n
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard','src','tests','scripts'])
source={'corrected_scanner':'a50e9b7754a69042394306d5207b428f965d8e1d','actual_full_suite_source':m['source_commit'],'current_product_tests_equal_tested_source':True,'verified_inputs':inputs,'file_sha256':{n:sha(ROOT/n) for n in paths},'full_suite_metadata_sha256':sha(BASE/'v34-import-full-suite.json'),'full_suite_empty_patch_sha256':sha(BASE/'v34-import-full-suite.patch'),'qualification':'Full suite completed against committed8a3db58 with no product/test changes, equal correcteda50e9b7. README status-only documentation changes after verification have separate final distribution/source bindings; hosted artifacts retain exact8a3db58.'}
for name,obj in [('local-source-binding.json',source),('local-checks.json',{'scanner':source['corrected_scanner'],'checks':checks,'full_suite':dict(counts,branch_coverage_percent=coverage),'new_paid_calls':0,'lock_reuse':'v34-lock ran at5b5016e with identical uv.lock/pyproject and tooling; current hosted lock check is separate.'})]:
 p=OUT/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n')
print(dict(counts),coverage,'bound to committed8a3db58/correcteda50e9b7')
