"""Bind unchanged source preparation to the import-identity correction; no scans."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v34-fixed-coverage-final'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((OLD/'evaluation-proposal.json').read_text());f=json.loads((OUT/'freeze.json').read_text())
assert p['status']=='prepared_not_approved' and not (OLD/'evaluation-authorization.json').exists()
for name,digest in p['files_sha256'].items():assert sha(ROOT/name)==digest,name
for name in ['evaluate.py','scoring-rubric.json']:shutil.copyfile(OLD/name,OUT/name)
p['files_sha256']={n:d for n,d in p['files_sha256'].items() if not n.startswith(str(OLD.relative_to(ROOT))+'/')}
for name in ['evaluate.py','scoring-rubric.json','freeze.json','prepare.py','source-proof.py']:
 q=OUT/name;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
p.update(scanner=f['scanner'],frozen_checkout=f['frozen_checkout'],runner=str((OUT/'evaluate.py').relative_to(ROOT)))
p['execution']=p['execution'].replace('2624578','a50e9b7')
p['superseded_unapproved_proposal']={'path':str((OLD/'evaluation-proposal.json').relative_to(ROOT)),'sha256':sha(OLD/'evaluation-proposal.json'),'reason':'After the2277-test full pass, a local ipaddress module control exposed false stdlib identity. Corrected a50e9b7 uses the existing program resolver and adds three controls. Both prior proposals remain unapproved and unexecuted.'}
p.pop('prepared_command',None);p.pop('prepared_command_cwd',None)
path=OUT/'evaluation-proposal.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n')
print('Rebound unchanged87-observation scope to a50e9b7; zero scans.')
