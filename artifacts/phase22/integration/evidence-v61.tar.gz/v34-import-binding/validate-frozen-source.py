"""Validate frozen manifest/source identities without running a scanner."""
import hashlib,json,subprocess,sys
from pathlib import Path
ROOT=Path('/private/tmp/mcp-phase22-options');OUT=Path(__file__).resolve().parent
p=json.loads((OUT/'evaluation-proposal.json').read_text());frozen=Path(p['frozen_checkout'])
sys.path[:0]=[str(frozen),str(frozen/'src')]
from scripts.phase20_corpus import validate
from scripts.phase22_corpus import frozen as source_freeze
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for group,g in p['groups'].items():
 assert sha(frozen/g['manifest'])==g['manifest_sha256']
 m=validate(root=frozen) if group=='historical' else source_freeze(approval_path=frozen/g['source_freeze_approval'],root=frozen)
 selected=[i for i in m.inputs if i.id in g['input_ids']]
 assert [i.id for i in selected]==g['input_ids']
 for i in selected:
  row=g['inputs'][i.id];assert i.model_dump(mode='json')==row['input']
  assert sha(ROOT/row['configuration'])==row['configuration_sha256']
 rows[group]={'selected':len(selected),'whole_manifest_validated':len(m.inputs),'source_freeze_receipt':g['source_freeze_approval']}
assert not subprocess.check_output(['git','status','--porcelain'],cwd=frozen)
q={'scanner':p['scanner'],'groups':rows,'clean_frozen_checkout':True,'corpus_observations':0,'paid_calls':0,'extra_staging_required':False,'configuration_basis':'All51 materialized configurations verified during originalv34 preparation; exact records, scanner configuration implementation and retained configuration hashes are unchanged.'}
assert not subprocess.check_output(['git','diff','5b5016e','a50e9b7','--','src/sentinel/config.py','scripts/phase20_measurements.py','scripts/phase20_corpus.py','scripts/phase22_corpus.py'],cwd=ROOT)
path=OUT/'frozen-source-validation.json';assert not path.exists();path.write_text(json.dumps(q,indent=2)+'\n');print(rows,'zero scans')
