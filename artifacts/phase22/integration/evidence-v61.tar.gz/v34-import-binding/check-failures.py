"""Retain unsuccessful engineering checks and their corrections as source-bound history."""
import hashlib,json
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for path in sorted(BASE.glob('v34-*.json')):
 m=json.loads(path.read_text())
 if 'command' in m and 'exit_code' in m:
  rows.append({'metadata':path.name,'metadata_sha256':sha(path),'exit_code':m['exit_code'],'source':m.get('source_commit'),'log':m.get('log'),'log_sha256':sha(BASE/m['log']) if m.get('log') else None})
assert any(r['metadata']=='v34-full-suite.json' and r['exit_code']==1 for r in rows)
assert any(r['metadata']=='v34-final-full-suite.json' and r['exit_code']==2 for r in rows)
assert any(r['metadata']=='v34-recovered-full-suite.json' and r['exit_code']==0 for r in rows)
explanations={
 'v34-prepared-initial':'Two controls found global network-descendant mutation lost through helpers and replaced HTTPX constructor trusted. Shared state propagation and external receiver checks corrected.',
 'v34-affected-initial':'Four failures: old six-flag IP fixtures assumed CGNAT rejection; computed receivers evaluated twice. Corrected unsafe guard assumptions and reused cached receiver evaluation. Original fixtures/patches retained.',
 'v34-mypy-initial':'Five type-check errors corrected: IPv4/IPv6 network narrowing, prepared-request local name and StaticEvidence assertions.',
 'v34-lint-initial/v34-lint':'Line length and nested-condition style corrected; original logs retained.',
 'v34-full-suite':'Complete initial5b5016e run: one mapped-address guard failure,2269 passed,36 skipped. Tracking IP objects exposed builtin isinstance as unknown mutation. Narrow known stdlib type inspection correction retains guard; unknown/replaced classes still invalidate.',
 'v34-ip-inspection-controls':'One new control exposed direct module-level imported class replacement. Source-known module attribute writes now invalidate imported identities; seven added controls all pass in the corrected final suite.',
 'v34-proposal-preparation':'Initial helper invocation omitted repository root from sys.path; corrected source-only invocation passed with no scanner execution.',
 'v34-final-full-suite':'Interrupted after one atomic-output test failure and361 passes during concurrent disk exhaustion. Exit2 and partial result retained; no full-suite or exact CLI-error claim. Recovered control and full unchanged-source suite pass.',
 'worktree_creation':'Ordinary2624578 checkout failed exit128 with No space left on device and was automatically removed by Git. Byte-verified immutable archives were deduplicated and full corrected checkout created using native copy-on-write clones; both frozen trees remain content-identical.',
 'process_filter':'First read-only process filter found none because macOS executable is capitalized Python; it sent no signal. Exact verified owned pytest PID was subsequently interrupted once.',
 'atomic_output_diagnostic':'Original output was text old, so JSON diagnostic failed; raw bytes retained as.txt, demonstrating no partial overwrite.',
 'v34-local-ip-module-control':'After2624578 passed2277 tests, a local ipaddress.py source control showed imported-module identity was falsely treated as stdlib. Corrected a50e9b7 delegates external resolution to the existing PythonProgram resolver; local module/package and modified builtin controls pass. Original failed control and superseded full pass remain retained.',
 'v34-import-production-capture':'Output-directory argument repeated its repository-relative prefix. FileNotFoundError occurred before any replay or target start. Corrected basename invocation passes all six zero-call production requests.',
 'superseded_262_ci':'Run34666908684 completed28 normal jobs successfully, one normal job cancelled, four optional corpus jobs skipped. Corrected a50 delivery triggered normal concurrency cancellation; this is not a complete matrix pass.',
 'initial_ci':'Run34666053199 retained17 successful,5 failed,7 cancelled and4 skipped jobs. Remaining jobs were cancelled by normal PR concurrency on corrected delivery. Some cancelled jobs also retained the known failure before interruption; partial counts are not complete results.'}
p={'checks':rows,'failure_and_correction_explanations':explanations,'initial_ci_disposition_sha256':sha(BASE/'v34-fixed-coverage-final/initial-ci-disposition.json'),'disk_recovery_sha256':sha(BASE/'v34-fixed-coverage-final/disk-recovery.json'),'disk_failure_assessment_sha256':sha(BASE/'v34-fixed-coverage-final/disk-failure-assessment.json'),'all_old_scanner_and_corpus_results_unchanged':True,'new_corpus_observations':0,'new_paid_calls':0,'superseded_262_ci_disposition_sha256':sha(OUT/'superseded-262-ci-disposition.json'),'superseded_262_ci_packet_sha256':sha(BASE/'v34-final-quality/packet.json'),'final_a50_ci_packet_sha256':sha(BASE/'v34-import-quality/packet.json'),'qualification':'Engineering/source-only checks are distinct from the still-unapproved87-observation corpus regression. No failed run is relabeled as passing.'}
path=OUT/'check-failure-assessment.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print('Retained',len(rows),'versioned check receipts and all failure dispositions')
