"""Verify the delivered existing draft without dispatching any evaluation."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
raw=subprocess.check_output(['gh','pr','view','37','--json',fields]);pr=json.loads(raw)
path=OUT/'delivery-readback.json';assert not path.exists();path.write_bytes(raw)
assert pr['headRefOid']==head and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning' and pr['isDraft'] and pr['state']=='OPEN'
assert pr['body']==(OUT/'pr-body.md').read_text()
parent=json.loads(subprocess.check_output(['gh','pr','view','36','--json','headRefOid,state,isDraft']));assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455'
binding=json.loads((OUT/'documentation-binding.json').read_text())
for n,d in binding['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
for n,d in binding['review_packet_sha256'].items():assert sha(OUT/n)==d,n
assert not subprocess.check_output(['git','diff',binding['tested_workflow'],'--',*binding['byte_identical_quality_inputs']])
assert not subprocess.check_output(['git','diff','HEAD']) and not subprocess.check_output(['git','diff','--cached'])
protected=binding['user_files_sha256'];assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],text=True).splitlines())==set(protected)
for n,d in protected.items():assert sha(ROOT/n)==d,n
for folder,row in binding['worktrees'].items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=folder,text=True).strip()==row['revision']
 assert not subprocess.check_output(['git','diff','HEAD'],cwd=folder)
 if folder.endswith('frozen-f85a90f'):
  staged=binding['authorized_staged_frozen_artifacts_sha256'];assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=folder,text=True).splitlines())==set(staged)
  for n,d in staged.items():assert sha(Path(folder)/n)==d,n
 else:assert not subprocess.check_output(['git','status','--porcelain'],cwd=folder)
for folder,row in json.loads((OUT/'older-frozen-source-bindings.json').read_text()).items():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=folder,text=True).strip()==row['revision']
 assert not subprocess.check_output(['git','diff','HEAD'],cwd=folder)
 assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=folder,text=True).splitlines())==set(row['existing_untracked_files_sha256'])
 for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
p={'recorded_at':datetime.now(timezone.utc).isoformat(),'delivered_revision':head,'readback_sha256':hashlib.sha256(raw).hexdigest(),'parent':parent,'documentation_binding_sha256':sha(OUT/'documentation-binding.json'),'product_tests_workflow_equal_tested_source':True,'new_paid_calls':0,'new_corpus_observations':0,'proposed_native_observations':87,'evaluation_approved':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Ignored post-delivery receipt; not claimed inside the preceding commit or seal61. Existing draft remains open and draft; no evaluation dispatch.'}
path=OUT/'delivery-verification.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print('Verified delivered draft',pr['url'],head)
