"""Retain final documentation/package checks and supplement the complete audit."""
import hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
labels=['v34-final-docs','v34-final-distributions','v34-final-distributions-corrected','v34-final-distribution-binding','v34-final-distribution-binding-corrected']
checks=[]
for label in labels:
 path=BASE/(label+'.json');m=json.loads(path.read_text());expected=1 if label in ['v34-final-distributions','v34-final-distribution-binding'] else 0;assert m['exit_code']==expected,label
 checks.append({'metadata':path.name,'sha256':sha(path),'exit_code':m['exit_code'],'command':m['command'],'source':m['source_commit'],'log_sha256':sha(BASE/m['log'])})
new=next((OUT/'distributions').glob('*.whl'));old=next((BASE/'v34-import-quality/artifacts/ci/portunusmcp-sentinel-dist').glob('*.whl'))
with zipfile.ZipFile(old) as a,zipfile.ZipFile(new) as z:
 assert set(a.namelist())==set(z.namelist())
 changed=[n for n in z.namelist() if not n.endswith('/') and a.read(n)!=z.read(n)]
 meta=next(n for n in changed if n.endswith('/METADATA'));assert set(changed)=={meta,meta.rsplit('/',1)[0]+'/RECORD'}
 old_readme=subprocess.check_output(['git','show','8a3db58:README.md']);assert a.read(meta).count(old_readme)==1
 assert z.read(meta)==a.read(meta).replace(old_readme,(ROOT/'README.md').read_bytes())
q={'checks':checks,'final_package_source_binding_sha256':sha(OUT/'final-distributions.json'),'wheel_metadata_changes':changed,'METADATA_exactly_old_with_current_README_substitution':True,'failure_assessments':{'v34-final-distributions':'--no-isolation failed before building because hatchling was absent from the main environment. Standard uv build --offline succeeded using cached build dependencies. No network or target dependency installation.','v34-final-distribution-binding':'Verifier initially treated uv-generated .gitignore as an archive. Preserved original helper; corrected helper accepts only the exact one-byte asterisk metadata file. Both final distributions pass exact hosted source bindings.'},'new_corpus_observations':0,'new_paid_calls':0,'technical_acceptance_received':False}
path=OUT/'final-verification.json';assert not path.exists();path.write_text(json.dumps(q,indent=2)+'\n')
audit=OUT/'audit.json';prior=OUT/'audit-before-final-verification.json';assert not prior.exists();shutil.copyfile(audit,prior);p=json.loads(audit.read_text());ref=str(path.relative_to(ROOT))
p['references_sha256'][ref]=sha(path);p['final_verification_sha256']=sha(path)
for row in p['requirements']:
 if row['id'] in {'R71','R72','R79','R80','R81','R82'}:row['evidence'].append(ref)
audit.write_text(json.dumps(p,indent=2)+'\n');print('Final docs/package checks bound; only README metadata and RECORD differ; all failures retained.')
