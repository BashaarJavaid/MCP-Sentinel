"""Publish actual engineering and exact pending evaluation status to owning docs."""
import json
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
local=json.loads((OUT/'local-checks.json').read_text());audit=json.loads((OUT/'audit.json').read_text());assert not audit['acceptance_packet_ready']
assert json.loads((BASE/'v34-import-quality/packet.json').read_text())['engineering_passed']
cov=local['full_suite']['branch_coverage_percent']
text=f'''The DDG fixed-request correction is implemented at **`a50e9b7`**. SENT-015
follows source-established HTTPX `build_request` → `send`, retaining a narrow
initial shared-space (`100.64.0.0/10`) rejection qualification on the same caller
URL. Removing/bypassing the guard or replacing/escaping the request loses that
qualification in synthetic controls. Known IP type inspection preserves valid
facts; local module/package shadows, replaced classes/imported attributes and
unknown mutation stay conservative.
The old six negative IP flags alone no longer establish CGNAT rejection. Broader
destinations, subsequent transformations, DNS, redirects and IPv6 remain unproven.

Current engineering passes at **`8a3db58`**: **2,280 tests / 36 skips** locally
and in all **12 supported hosted suites**, **{cov:.2f}%** local branch coverage,
all **29 normal CI jobs** and docs. Ruff/format/strict mypy, lock/schema/notices,
offline artifacts, installed-wheel/Docker/isolation/hooks and exact package-source
checks pass. All **six production requests regenerate and replay with zero paid
calls**. The initial candidate's full-suite failure, failed/cancelled CI jobs,
additional replacement control, disk exhaustion and interrupted verification are
retained, including the local-module identity failure after the earlier full pass.
The final import-binding correction passes a new full suite and hosted matrix.

**Actual corrected DDG coverage is not yet evaluated.** The exact proposal at
`artifacts/phase22/integration/v34-import-binding/evaluation-proposal.json`
requires separate approval: **87 native observations**, one serial local macOS
sequence, **zero comparator runs, retries, profiles, paid calls or corpus target
executions**. The five unchanged DDG inputs run twice (10), 15 Python development
inputs once, and 31 Python historical inputs twice (62). The target is 120 seconds,
the uniform native/whole-input maximum 300 seconds, cleanup at most 15 seconds,
and sequence maximum 480 minutes. Execution/identity/schema/cleanup/timing/repeat
failure closes all unused observations; detector outcomes are retained for source
assessment. No old budget is reopened.

The gate requires actual fixed-source `send` coverage with initial CGNAT rejection
evidence, both vulnerable detections per DDG batch, unchanged Python named
conditions and **36 entire ordered repeats**. Source-sensitive synthetic controls
are separate engineering evidence. All changed findings and diagnostics require
source assessment. Preserve the two nominal fixed Meta operator erratum inputs,
each with its retained two matched keys, separately from the seven valid Python
development negatives. The unchanged TypeScript paths support reuse of the prior
54-observation compatibility and ten-observation Lighthouse results at `f85a90f`.
Historical whole 25 + 45 + 45 Linux timing remains measured at `1f3f72f`; these
partial checks will not be pooled into a new whole-batch result.

The original **DDG fresh detection at `f85a90f` remains immutable**: two correlated
vulnerable hits in each native batch, zero matching negative alerts and five
ordered repeats; fixed request/guard recognition was unresolved. The correction
follows source exposure and is an exposed regression, not another unseen success.
Original Lighthouse fresh misses, original held-out misses and all earlier failed
attempts remain preserved. Git campaigns stay **312/1,040 incomplete**, as requested.
Paid benchmark/pilots remain deferred; Phase 21 incomplete and Phase 24/15 unchanged.

The current audit accounts for **89 original requirements** (69 passed, two
user-deferred, 18 pending current-source regression/acceptance) and **94 added
rows** (87 passed, five historical proposed limitations, two unresolved). The
pending original rows converge on this regression and its assessments. **Phase 22
remains incomplete** until the actual remaining gates, explicit human technical
acceptance and verified final closeout delivery. No merge, ready-state, release,
outreach or Phase 23 is authorized.
'''
(OUT/'summary.md').write_text('# Phase 22 corrected fixed-request coverage: evaluation pending\n\n'+text)
old=(OUT/'candidate-status.md').read_text();note='## Current v34 correction and regression approval checkpoint\n\n'+text+'\n'
previous=json.loads((BASE/'v33-fresh-v6/documentation-binding.json').read_text())
for name in previous['owning_docs_sha256']:
 p=ROOT/name;s=p.read_text();assert s.count(old)==1,name;p.write_text(s.replace(old,note))
readme=ROOT/'artifacts/phase22/integration/README.md'
s=readme.read_text().replace('# Integration evidence, batches 1–58 and closeout audit','# Integration evidence, batches 1–61 and closeout audit',1);marker=note;assert s.count(marker)==1
links='Review [current engineering summary](v34-import-binding/summary.md), [89 + 94 row audit](v34-import-binding/audit.json), [exact unapproved regression proposal](v34-import-binding/evaluation-proposal.json) and [scoring rubric](v34-import-binding/scoring-rubric.json). Restore seal 61 after seals 1–60, verifying all archive/member hashes in numeric order. Earlier readiness proposals remain historical and were not accepted.\n\n'
readme.write_text(s.replace(marker,marker+links))
body='# Phase 22: prepared-request correction verified; exact regression pending\n\n'+text+'\nReview the final `v34-import-binding/` summary, audit, source proof, freeze, scoring rubric and exact evaluation proposal under `artifacts/phase22/integration/`. Seal61 retains the new engineering/failure/preparation records after all60 preceding seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626907\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34668626916\n'
(OUT/'pr-body.md').write_text(body)
print('Updated14 owning docs and prepared exact regression draft body; no acceptance inferred.')
