"""Freeze completed source-only preparation checks into the approval packet."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
path=OUT/'evaluation-proposal.json';p=json.loads(path.read_text());old=OUT/'evaluation-proposal-before-final-binding.json';assert not old.exists();shutil.copyfile(path,old)
assert not (OUT/'evaluation-authorization.json').exists()
for n in ['source-proof.json','frozen-source-validation.json','compatibility.json','supervisor-check/selfcheck.json','finalize-proposal.py']:
 q=OUT/n;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
for n in ['v34-final-proposal-preparation.json','v34-final-source-proof.json','v34-final-runner-boundaries.json','v34-final-supervisor-boundaries.json','v34-final-runtime-compatibility.json']:
 q=BASE/n;assert json.loads(q.read_text())['exit_code']==0;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
p['prepared_command']=['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(OUT/'evaluate.py'),'run',str(BASE/'v35-ddg-regression/raw')]
p['prepared_command_cwd']=p['frozen_checkout']
p['launch_precondition']='Before the single invocation, record an exact new approval, ensure all owned engineering/corpus work and containers are finished, use the unchanged existing locked Python3.12 environment, retain launch argv/exit/log and actual machine load/topology/memory, and verify no execution-consumed receipt exists. Runner requires approved scope and enforces one-use budget. No approval is inferred here.'
p['expected_condition_counts']={'ddg_per_batch':{'vulnerable':2,'valid_negatives':3},'development_once':{'vulnerable':6,'valid_negatives':7,'nominal_fixed_erratum_inputs':2,'historical_matched_keys_per_erratum_input':2},'historical_per_batch':{'vulnerable':14,'valid_negatives':17},'entire_ordered_repeats':36}
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
path.write_text(json.dumps(p,indent=2)+'\n');print('Final87-observation proposal SHA256',sha(path),'unapproved,unexecuted.')
