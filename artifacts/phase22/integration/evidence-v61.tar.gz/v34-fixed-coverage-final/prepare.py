"""Bind the corrected scanner to the already validated87-observation source plan."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v34-fixed-coverage-proposal'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((OLD/'evaluation-proposal.json').read_text());freeze=json.loads((OUT/'freeze.json').read_text())
assert p['status']=='prepared_not_approved' and not (OLD/'evaluation-authorization.json').exists()
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
s=(OLD/'evaluate.py').read_text().replace('"condition_passed": False, "ordered_findings_equal": False','"condition_passed": None, "ordered_findings_equal": False')
s=s.replace('assert not condition({"findings": []}, r, a, "vulnerable", set())["condition_passed"]','assert condition({"findings": []}, r, a, "vulnerable", set())["condition_passed"] is None')
s=s.replace('assert not condition({"findings": [{**f, "description": "changed"}]}, r, a, "vulnerable", set())["condition_passed"]','assert condition({"findings": [{**f, "description": "changed"}]}, r, a, "vulnerable", set())["condition_passed"] is None')
(OUT/'evaluate.py').write_text(s)
rubric=json.loads((OLD/'scoring-rubric.json').read_text())
rubric['python_compatibility']['development']='All15 Python development inputs once:6 vulnerable conditions detected,0 matching alerts on7 valid negatives, and retained raw matching results on the2 nominal fixed Meta operator inputs under their approved erratum. Each of those2 input cases has2 historical matched candidate keys; preserve raw findings and keys without relabeling the sources.'
(OUT/'scoring-rubric.json').write_text(json.dumps(rubric,indent=2)+'\n')
s=(OLD/'source-proof.py').read_text().replace("new='5b5016e'","new='2624578'")
(OUT/'source-proof.py').write_text(s)
p.update(scanner=freeze['scanner'],frozen_checkout=freeze['frozen_checkout'],lock_sha256=freeze['harness_and_lock_sha256']['uv.lock'],runner=str((OUT/'evaluate.py').relative_to(ROOT)))
p['execution']=p['execution'].replace('immutable5b5016e','immutable2624578')
p['superseded_unapproved_proposal']={'path':str((OLD/'evaluation-proposal.json').relative_to(ROOT)),'sha256':sha(OLD/'evaluation-proposal.json'),'reason':'Initial5b5016e full suite exposed an IP inspection regression. Corrected2624578 and seven additional controls replace that unapproved candidate. Neither proposal has run.'}
for name in ['evaluate.py','scoring-rubric.json','freeze.json']:
 p['files_sha256'].pop(str((OLD/name).relative_to(ROOT)))
 p['files_sha256'][str((OUT/name).relative_to(ROOT))]=sha(OUT/name)
for path in [OUT/'prepare.py',OUT/'source-proof.py',BASE/'v22-refresh-disposition-corrected.json']:
 p['files_sha256'][str(path.relative_to(ROOT))]=sha(path)
path=OUT/'evaluation-proposal.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n')
print('Bound corrected2624578 to87 proposed observations; zero scans.')
