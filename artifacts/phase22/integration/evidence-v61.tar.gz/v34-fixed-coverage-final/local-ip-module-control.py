"""Source-only synthetic control for a repository module shadowing ipaddress."""
from pathlib import Path
from tempfile import TemporaryDirectory
from tests.test_ssrf_prepared_requests import PREFIX,GUARD,report
with TemporaryDirectory() as tmp:
 root=Path(tmp)
 (root/'ipaddress.py').write_text('def ip_network(value):\n    return ()\ndef ip_address(value):\n    return value\n')
 result=report(root,PREFIX+GUARD+'''@mcp.tool()
def fetch(url: str):
    validate(url)
    client = httpx.Client()
    request = client.build_request("GET", url)
    return client.send(request)
''')
 print('finding count',len(result.findings))
 for finding in result.findings:print(finding.description)
 assert len(result.findings)==1
 assert '100.64.0.0/10' not in result.findings[0].description
