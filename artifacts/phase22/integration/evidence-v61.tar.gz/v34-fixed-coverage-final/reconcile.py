"""Reconcile all89 original and88 prior added requirements at actual final source."""
import copy,hashlib,json,xml.etree.ElementTree as ET
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=json.loads((BASE/'v33-fresh-v6/audit.json').read_text());p=copy.deepcopy(old)
proposal=json.loads((OUT/'evaluation-proposal.json').read_text())
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
quality=json.loads((BASE/'v34-final-quality-audit/packet.json').read_text())
assert len(quality['quality'])==12 and all(q['passed']==2277 and q['skipped']==36 for q in quality['quality'])
assert json.loads((BASE/'v34-recovered-full-suite.json').read_text())['exit_code']==0
assert json.loads((OUT/'local-source-binding.json').read_text())['current_product_tests_equal_tested_source']
counts=defaultdict(Counter)
for c in ET.parse(BASE/'v34-recovered-full-suite-junit.xml').iter('testcase'):
 state='skipped' if c.find('skipped') is not None else 'failed' if c.find('failure') is not None or c.find('error') is not None else 'passed'
 counts[c.attrib['classname'].replace('.','/')+'.py'][state]+=1
assert sum(c['passed'] for c in counts.values())==2277 and sum(c['skipped'] for c in counts.values())==36 and not any(c['failed'] for c in counts.values())
refs=['v34-final-quality/packet.json','v34-final-quality-audit/packet.json','v34-recovered-full-suite.json','v34-recovered-full-suite-junit.xml','v34-recovered-full-suite-coverage.json','v34-fixed-coverage-final/local-source-binding.json','v34-fixed-coverage-final/local-checks.json','v34-fixed-coverage-final/compatibility.json','v34-fixed-coverage-final/source-proof.json','v34-fixed-coverage-final/freeze.json','v34-fixed-coverage-final/evaluation-proposal.json','v34-fixed-coverage-final/scoring-rubric.json','v34-fixed-coverage-final/check-failure-assessment.json','v34-fixed-coverage-proposal/implementation-authorization.json']
common='Corrected2624578 passes current engineering at66c47af. Synthetic guard-sensitive prepared-request controls pass; actual corrected DDG and affected Python compatibility remain unapproved and unmeasured in the exact87-observation proposal. Originalf85a90f fresh detection remains immutable and its fixed-path limitation is not accepted. TypeScript results retain source-compatible reuse. Git312/1040 stays incomplete; Phase22 acceptance and closeout remain pending.'
pending={*(f'R{i:02}' for i in range(18,27)),'R33','R35','R36','R63','R64','R65','R67','R69'}
for row in p['requirements']:
 prior=next(r for r in old['requirements'] if r['id']==row['id'])
 row['prior_requirement_record_sha256']=hashlib.sha256(json.dumps(prior,sort_keys=True).encode()).hexdigest()
 row['historical_assessment']={'audit':'v33-fresh-v6/audit.json','text':prior['assessment'],'disposition':prior['disposition']}
 row['interpretation']=common
 row['evidence'].extend('artifacts/phase22/integration/'+n for n in refs)
 row['current_tests']={n:dict(counts[n]) for n in row.get('source_and_test_files',[]) if n in counts}
 if row['id'] in pending:
  row['disposition']='unresolved'
  row['assessment']='Prior measured result remains passed at its recorded scanner. Current Python flow/guard implementation changed, so final current-source acceptance requires the separately proposed87-observation DDG/Python compatibility sequence and source assessments. No old budget is reopened, no old result is relabeled, and old plus new partial observations will not be presented as a new whole25/45 Linux batch.'
 elif row['id'] in {'R66','R88'}:
  row['assessment']='The first-frozenf85a90f DDG repository result remains the actual fresh detection evidence: two correlated vulnerable hits per native batch, zero matching negatives, five ordered repeats, all15 observations assessed. The later2624578 correction follows source exposure and cannot be called fresh. The fixed sink/guard coverage requirement is separately pending inV33-FIXED-COVERAGE/V34-REGRESSION; no limitation or technical acceptance is inferred.'
 elif row['id'] in {'R71','R72','R73','R74'}:
  row['assessment']='Final corrected2624578 passes2277 tests/36 skips locally and in all12 supported hosted suites at66c47af, above80% branch coverage; all29 normal CI jobs and docs pass. Current Ruff/format/mypy/lock/schema/notices/offline artifacts, exact package-source checks, installed-wheel/Docker/isolation/hooks and six zero-call production replays are source-bound. Initial failed/partial checks and disk recovery remain retained.'
 elif row['id']=='R84':
  row['assessment']='User requested a correction instead of accepting the fixed-path limitation. Current-source regression approval, successful measured/source-assessed disposition, explicit final human technical acceptance and verified closeout delivery remain. Pilots remain explicitly deferred.'
 elif row['id'] in {'R62','R83'}:
  row['assessment']='Current owning docs distinguish verified engineering from an unapproved87-observation exposed regression, retain all original fresh/heldout failures and incompleteGit/paid/pilot scopes, and supersede the unacceptedv33 readiness proposal. No Phase22 completion is claimed.'
for row in p['additional_scope_requirements']:
 if row['id']=='V33-FIXED-COVERAGE':
  row['historical_v33_assessment']=copy.deepcopy(row)
  row['disposition']='unresolved';row['assessment']='User asked to fix the coverage gap and approved source-plan implementation. Prepared-request sink and narrow initial CGNAT qualification pass synthetic controls at2624578; actual fixed DDG send/guard evidence is mandatory in the unapproved87-observation regression. The earlier limitation was never accepted.'
for id,requirement,status in [
 ('V34-AUTH','Implement the approved source-only correction without spending a new evaluation or paid budget','passed'),
 ('V34-CORRECTION','Model HTTPX prepared request execution and source-bound initial shared-space rejection with mutation/rebinding/guard-sensitivity controls','passed'),
 ('V34-ENGINEERING','Verify corrected product/source/packages/replays and supported normal CI after preserving failed candidates','passed'),
 ('V34-PREPARATION','Freeze corrected scanner and prepare exact source/configuration/repeat/timing/stop-bound87-observation proposal','passed'),
 ('V34-RETENTION','Preserve initial rule/control/CI failures, disk exhaustion, interrupted suite and all prior evidence','passed'),
 ('V34-REGRESSION','After separate exact approval, establish actual DDG fixed send/guard coverage and all affected Python compatibility outcomes','unresolved')]:
 p['additional_scope_requirements'].append({'id':id,'requirement':requirement,'disposition':status,'assessment':common,'evidence':['artifacts/phase22/integration/'+n for n in refs]})
p['prior_audit']={'path':'v33-fresh-v6/audit.json','sha256':sha(BASE/'v33-fresh-v6/audit.json')}
p['historical_v33_current_source_status']={k:old[k] for k in ['scanner_identity','current_source_corpus_runs','current_source_native_observations','current_source_comparator_observations','current_exposed_gate_passed','current_compatibility_passed','acceptance_packet_ready']}
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='66c47af7055c97d71e22b74660516c75e5d59d55',workflow_tested_source='66c47af7055c97d71e22b74660516c75e5d59d55',scanner_identity=proposal['scanner'],current_tests_by_file=dict(counts),current_source_corpus_runs=0,current_source_native_observations=0,current_source_comparator_observations=0,current_exposed_evaluation_approved=False,current_exposed_evaluation_executed=False,current_exposed_gate_passed=None,current_compatibility_passed=None,current_compatibility_observations_this_continuation=0,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,new_paid_calls=0,status=common,per_file_test_counts_basis='Completedv34-recovered-full-suite JUnit at66c47af, with scanner and tests identical2624578.',owning_document_binding='Finalv34 documentation/delivery bindings follow current owning-doc edits.')
p['full_sequence_status_basis']='Historical whole25 reuse and45+45 repeat remain passed at1f3f72f. TypeScript compatibility atf85a90f retains source-compatible reuse; Python compatibility at2624578 is not yet measured. No new pooled whole-batch timing claim.'
p['fresh_evaluation_status_basis']='Original DDG first-frozen detection remains measured and assessed atf85a90f. Correction2624578 is exposed and unevaluated; actual fixed-path coverage remains pending.'
p['historical_source_and_test_file_bindings']={'source':old['source'],'files':old['current_source_and_test_files'],'earlier':old['historical_source_and_test_file_bindings']}
names=set(old['current_source_and_test_files'])|{'src/sentinel/static/path_flow.py','src/sentinel/static/rules/sent015.py','src/sentinel/static/engine.py','tests/test_ssrf.py','tests/test_ssrf_prepared_requests.py'}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in sorted(names)}
p['references_sha256'].update({'artifacts/phase22/integration/'+n:sha(BASE/n) for n in refs})
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==94
assert p['dispositions']=={'passed':69,'explicitly user-deferred':2,'unresolved':18}
assert p['additional_scope_dispositions']=={'passed':87,'proposed documented limitation awaiting decision':5,'unresolved':2}
path=OUT/'audit.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print(p['dispositions'],p['additional_scope_dispositions'])
