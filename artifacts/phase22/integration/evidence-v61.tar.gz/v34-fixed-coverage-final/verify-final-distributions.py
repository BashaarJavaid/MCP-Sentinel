"""Verify final docs-aware distributions while reusing byte-identical hosted code tests."""
import hashlib,json,subprocess,tarfile,zipfile
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
assert not subprocess.check_output(['git','diff','66c47af','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile','LICENSE','CHANGELOG.md'])
tracked=set(subprocess.check_output(['git','ls-tree','-r','--name-only','HEAD'],text=True).splitlines())
hosted=list((BASE/'v34-final-quality/artifacts/ci/portunusmcp-sentinel-dist').glob('*.whl'));assert len(hosted)==1
with zipfile.ZipFile(hosted[0]) as z:hosted_code={n:z.read(n) for n in z.namelist() if n.startswith('sentinel/') and not n.endswith('/')}
rows=[]
for path in sorted((OUT/'distributions').iterdir()):
 if path.suffix=='.whl':
  with zipfile.ZipFile(path) as z:
   assert z.testzip() is None;members={n:z.read(n) for n in z.namelist() if not n.endswith('/')}
  assert {n:d for n,d in members.items() if n.startswith('sentinel/')}==hosted_code
  mapping={}
  for n in members:
   if n.startswith('sentinel/_fixtures/'):mapping[n]='tests/fixtures/'+n.removeprefix('sentinel/_fixtures/')
   elif n.startswith('sentinel/_schemas/'):mapping[n]='schemas/'+n.removeprefix('sentinel/_schemas/')
   elif n.startswith('sentinel/'):mapping[n]='src/'+n
 else:
  assert path.name.endswith('.tar.gz')
  with tarfile.open(path) as t:
   assert not any(m.issym() or m.islnk() for m in t.getmembers());members={m.name:t.extractfile(m).read() for m in t if m.isfile()}
  mapping={n:n.split('/',1)[1] for n in members if n.split('/',1)[1] in tracked}
 checked=[]
 for n,source in mapping.items():
  assert (ROOT/source).read_bytes()==members[n],(path.name,n)
  if source!='README.md':assert subprocess.check_output(['git','show','66c47af:'+source])==members[n]
  checked.append({'member':n,'source_path':source,'sha256':sha(members[n]),'binding':'current status-only documentation' if source=='README.md' else 'exact hosted66c47af Git blob'})
 assert any(x['source_path']=='src/sentinel/static/rules/sent015.py' for x in checked)
 rows.append({'path':str(path.relative_to(ROOT)),'sha256':sha(path.read_bytes()),'source_members':checked,'metadata_members':[n for n in members if n not in mapping]})
assert len(rows)==2
p={'hosted_source':'66c47af7055c97d71e22b74660516c75e5d59d55','scanner':'2624578c381ae47df5b424e2c91f47a9cb362793','README_sha256':sha((ROOT/'README.md').read_bytes()),'distributions':rows,'wheel_product_schema_fixture_members_byte_identical_to_hosted':True,'qualification':'Final README status documentation changes package long-description metadata only. Newly built wheel/sdist source members match current files; every non-README source member equals its tested66c47af Git blob. Hosted installed-wheel matrix, Docker and isolation results retain actual66c47af artifacts; no new hosted run is claimed for docs-only delivery.'}
path=OUT/'final-distributions.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print('Verified final wheel/sdist source members and exact hosted code/schema/fixture bytes.')
