"""A parameter property must not bypass existing prototype-assignment rejection."""
import sys,tempfile
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root/'src'),str(root)]
from tests.test_typescript_classes import test_imported_class_receiver_and_replacement
with tempfile.TemporaryDirectory(prefix='v71-prototype-property-') as temp:
 test_imported_class_receiver_and_replacement(Path(temp),
  "constructor(private __proto__: any) {} save(p) { return fs.writeFileSync(p, 'data'); }",
  "new Writer({save: unknown}).save(args.path)",0)
print('Prototype mutation remains unsupported.')
