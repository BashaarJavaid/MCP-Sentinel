"""Deliver the authorized candidate to the same draft for ordinary engineering."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
run = lambda *args: subprocess.check_output(args, cwd=ROOT, text=True)
head = json.loads((OUT / 'candidate-commit.json').read_text())['source']
assert run('git', 'rev-parse', 'HEAD').strip() == head
assert not run('git', 'diff', 'HEAD')
pr = json.loads(run('gh', 'api', 'repos/BashaarJavaid/MCP-Sentinel/pulls/37'))
assert pr['head']['sha'] == '93fb7a58718b585ac916356d6bca1a191069032f'
assert pr['draft'] and pr['state'] == 'open' and pr['base']['ref'] == 'phase22/description-poisoning'
assert pr['body'] == (OUT.parent / 'v70-uncapped-four-results/pr-body-delivery.md').read_text()
with (OUT / 'candidate-pre-pr37.json').open('x') as f:
    json.dump({k:pr[k] for k in ('state','draft','title','body','head','base')}, f, indent=2)
body = f'''Candidate `{head}` corrects two source-established support gaps under the already-authorized Phase 22 recovery contract: ordinary TypeScript constructor parameter properties now retain bound arguments/defaults on the actual receiver, and Python initial URL guard evidence survives only proved trailing-slash/path-suffix derivation. Receiver replacement/escape, ambiguous field-initializer ordering, wrong/caught guards, hostname fallbacks, formatting and authority changes remain conservative. No timeout or performance-cache change is included.

The source candidate passes 104 focused class/URL cases and 119 discovery/worker checks, including complete ordered rule-state equality, source-node identity across pickle and serial/parallel results. A further nonempty-discovery assertion passes for both cold/warm parameter-property cases. Ruff, format and whole-scope strict mypy pass. Full local engineering, six zero-call production request replays and the hosted matrix are pending/in progress. Initial five synthetic failures, the targeted-suite coverage configuration failure and the URL helper-normalization regression remain retained with their corrections.

The completed uncapped experiment at earlier scanner `4145d35` remains immutable: 24/24 observations, 12/12 entire ordered pairs equal, cleanup passed, zero budget remaining. FAF took 2212.22–2341.48 seconds per input; other inputs took 6.28–10.72 seconds. No-bash/Engram narrowly passed; FAF missed its named sink and Lightning fixed/safe qualifier gates failed. Those outcomes do not establish this corrected candidate's behavior. The normal 1800-second shared deadline remains unchanged. Prior Python/TypeScript regression is still unexecuted at current source; another exact numerical proposal requires separate approval.

All 399 requirements, original first-frozen failures, six unaccepted historical closure proposals and source-bound earlier outcomes remain. No new corpus observation, profile, comparator, target execution, performance attempt or paid call occurred. The v68 literal-serialization optimization stays unapproved/unimplemented. Phase 22 remains incomplete pending current-source gates, explicit human technical acceptance and accepted closeout. Git stays 312/1,040 incomplete with 728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete, Phase 24/15 unchanged. This PR remains OPEN DRAFT on its existing base; no merge, ready-state change, release, outreach or Phase 23.
'''
metadata = {'title':'Phase 22: constructor and URL guard corrections; engineering in progress','body':body}
with (OUT / 'candidate-metadata-update.json').open('x') as f:
    json.dump(metadata, f, indent=2)
with (OUT / 'candidate-pr-body.md').open('x') as f:
    f.write(body)
print(run('git','push','https://github.com/BashaarJavaid/MCP-Sentinel.git','HEAD:refs/heads/phase22/integration'))
response = json.loads(run('gh','api','--method','PATCH','repos/BashaarJavaid/MCP-Sentinel/pulls/37','--input',str(OUT/'candidate-metadata-update.json')))
with (OUT / 'candidate-patch-response.json').open('x') as f:
    json.dump({k:response[k] for k in ('state','draft','title','body','head','base')},f,indent=2)
pr = json.loads(run('gh','api','repos/BashaarJavaid/MCP-Sentinel/pulls/37'))
remote = json.loads(run('gh','api','repos/BashaarJavaid/MCP-Sentinel/git/ref/heads/phase22/integration'))
verified = pr['head']['sha'] == remote['object']['sha'] == head and pr['title'] == metadata['title'] and pr['body'] == body and pr['draft'] and pr['state'] == 'open' and pr['base']['ref'] == 'phase22/description-poisoning'
with (OUT / 'candidate-delivery.json').open('x') as f:
    json.dump({'passed':verified,'head':head,'recorded_at':datetime.now(timezone.utc).isoformat(),'pr':{k:pr[k] for k in ('state','draft','title','body')},'body_sha256':hashlib.sha256(body.encode()).hexdigest(),'paid_calls':0,'engineering':'pending'},f,indent=2)
assert verified, 'Readback stale: resolve by reads, never repeat this writer.'
print('Candidate draft delivery verified.')
