"""Publish the completed exposed gate and next exact unapproved checkpoint."""
from pathlib import Path
import json
ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
assert json.loads((OUT/'assessment.json').read_text())['condition_gate_passed']
common='''The approved Lighthouse regression **passes all 10 observations** at scanner
**`f85a90f`**, workflow **`75142f0`**, run
[34648036083](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34648036083).
Both whole five-input batches detect both correlated vulnerable variants and retain
the required narrow IPv4 link-local rejection qualifier on both fixed variants and
the public control. Broader SSRF candidates remain visible. All five entire ordered
reports repeat equally after only the established 11 volatile exclusions.
Whole-input times are **11.992–14.300 seconds**, all within the 120-second target
and 300-second maximum. JSON/SARIF and owned process cleanup validate.
**Ten observations and one dispatch consumed; zero budget remains.**
All **10 findings, 974 warnings, 624 unresolved-flow occurrences and 20 unresolved
surfaces** are individually source-assessed, with zero unassessed entries.
Dispatch remains incompletely resolved; this is no runtime proof or complete coverage.

This is an **exposed regression pass**. The original independent-source evaluation
at `1f3f72f` remains 15 completed observations with **0/2 vulnerable hits per native
batch and comparator**. The stopped `6db3858` vulnerable miss and `4a2359d` fixed
qualification failure retain their closed nine- and seven-observation remainders.
No earlier failure is replaced, and no fresh generalization or independent human
review is claimed. The original held-out result remains 10 completed, 10 unsupported
and five incomplete, with zero hits among four completed vulnerable inputs out of
ten vulnerable inputs total.

Product, test, package and workflow bytes still equal verified `439c3fe`: local and
all 12 hosted suites pass **2,242 tests / 36 skips**, local branch coverage **89.76%**,
all **29 normal CI jobs** and docs pass. Packaging, installed-wheel/Docker/isolation,
Ruff/format/strict mypy, lock/schema/notices/offline artifacts and six production
request replays retain their actual source bindings. **Zero additional paid calls.**
Git runtime/image remain unchanged; 13 campaigns are incomplete, **312/1,040** tested.

The next exact proposal is **unapproved**:
`artifacts/phase22/integration/v30-compatibility-proposal/evaluation-proposal.json`.
It requests **54 serial local macOS rules-only observations** at immutable `f85a90f`:
three earlier exposed SSRF families twice each (30), followed by the 10 development
and 14 historical TypeScript inputs once (24). Bounds are 120 seconds as target,
300 seconds per whole input, 15 seconds cleanup, one 300-minute sequence, zero
retries, profiles, comparators, target executions or paid calls. Stop at the first
incomplete, late, identity/schema/cleanup, ordered-finding/condition or repeat failure;
close every unstarted observation. Every other report delta requires source assessment.
No new compatibility observation has run. Source-only AST/configuration checks bind
unchanged Python analysis for the other 15 development and 31 historical inputs.
The accepted whole 25 + 45 + 45 Linux timing/condition results retain measured scanner
`1f3f72f`; partial compatibility observations will not be called a new whole batch.

The audit contains **89 original rows: 82 passed, two user-deferred, five unresolved**,
and **81 added rows: 75 passed, six unresolved**, including closed historical failed
gates. Earlier TypeScript compatibility, the explicit disposition of fresh-result
limitations and final human technical acceptance remain open. **Phase 22 remains
incomplete.** Pilots and the full paid benchmark remain deferred; Phase 21 is
incomplete and Phase 24/15 gates are unchanged. No merge, release, outreach or Phase 23.
'''
names=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','docs/phase22-timeout-policy.md','docs/phase22-corpus-review.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/requirements.md','artifacts/phase22/integration/progress.md']
for name in names:
 p=ROOT/name;s=p.read_text();level='###' if name=='ROADMAP.md' else '##'
 marker=level+' Current loopback qualification correction and regression checkpoint\n'
 assert s.count(marker)==1
 s=s.replace(marker,level+' Current Lighthouse regression pass and compatibility checkpoint\n\n'+common+'\n'+level+' Historical v29 loopback qualification checkpoint\n',1)
 if name.endswith('integration/README.md'):
  s=s.replace('batches 1–56','batches 1–57',1)
  marker=level+' Current Lighthouse regression pass and compatibility checkpoint\n\n'
  s=s.replace(marker,marker+'Review the [current summary](v30-lighthouse-regression/summary.md), [89 + 81 row audit](v30-lighthouse-regression/audit.json), [passed evaluation](v30-lighthouse-regression/assessment.json) and [exact unapproved compatibility proposal](v30-compatibility-proposal/evaluation-proposal.json). Restore seal 57 after seals 1–56 using the existing numeric-order procedure; verify all archive/member hashes.\n\n',1)
 p.write_text(s)
p=ROOT/'ARCHITECTURE.md';s=p.read_text().replace('another corpus evaluation is unapproved. This is not broad IPv6 protection.', 'the approved Lighthouse repeat gate passes all ten observations at `f85a90f`\n(run 34648036083). This is not broad IPv6 protection. Earlier TypeScript compatibility\nnow has a separate, unapproved 54-observation local proposal; final acceptance remains open.');p.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 Lighthouse regression result and compatibility checkpoint\n\n'+common+'\nEvidence seals 1–57 preserve raw reports, source assessments, approvals and earlier failures. Final documentation/delivery bindings are supplemental.\n')
(OUT/'pr-body.md').write_text('Phase 22 adds bounded security source analysis and ordered runtime campaigns. Technical acceptance remains open.\n\n'+common+'\nReview `artifacts/phase22/integration/v30-lighthouse-regression/summary.md`, its complete audit and the exact compatibility proposal. Evidence seals 1–57 preserve actual source-bound results and all earlier closed budgets.\n')
print('Updated current status, preserved prior checkpoint, prepared draft body.')
