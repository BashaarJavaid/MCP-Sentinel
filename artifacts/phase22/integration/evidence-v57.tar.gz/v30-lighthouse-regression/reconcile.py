"""Reconcile the successful approved run while retaining all historical gates."""
import copy
import hashlib
import json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((OUT/'assessment.json').read_text());assert a['condition_gate_passed'] and a['budget']['native_completed']==10
proof=BASE/'v30-compatibility-proposal/source-proof.json';assert json.loads(proof.read_text())['corpus_observations']==0
old=json.loads((BASE/'v29-loopback-fix/audit.json').read_text());p=copy.deepcopy(old)
common='Currentf85a90f exposed Lighthouse gate passes all10 observations in two whole5-input batches:2 correlated vulnerable hits and0 narrow-condition alerts on3 qualified negatives per batch;all5 ordered repeats agree. All10 findings,974 warnings,624 unresolved flows and20 unresolved surfaces source-assessed. Original fresh1f3f72f misses and both stopped corrective runs remain unchanged. Earlier TypeScript compatibility needs the exact unapproved54-observation proposal;fresh-result disposition and final human acceptance remain open.'
refs=['v30-lighthouse-regression/assessment.json','v30-lighthouse-regression/source-assessment.json','v30-lighthouse-regression/retained-source-deltas.json','v30-lighthouse-regression/validation.json','v29-loopback-fix/evaluation-authorization.json','v30-compatibility-proposal/evaluation-proposal.json','v30-compatibility-proposal/source-proof.json']
for r in p['requirements']:
 r['historical_assessment']={'audit':'v29-loopback-fix/audit.json','text':r['assessment']}
 r['interpretation']=common;r['evidence'].extend('artifacts/phase22/integration/'+n for n in refs)
 if r['id'] in {'R66','R88','R62','R83'}:r['assessment']=common
 if r['id'] in {'R87','R89'}:r['assessment']='Prior exposed five-input repeat gates remain passed at2ac39aa and source-compatible through1f3f72f. Currentf85a90f changes shared TypeScript analysis;the concrete54-observation compatibility proposal includes30 new observations across all3 earlier exposed families and24 affected development/historical TypeScript inputs. No new compatibility measurement or waiver is inferred.'
 if r['id'] in {'R63','R64','R65'}:r['assessment']+=' The accepted whole-batch results remain at1f3f72f. Source-only AST/configuration proof establishes unchanged Python paths for15 development and31 historical inputs. The proposed24 TypeScript compatibility observations do not constitute a new whole-batch timing pass.'
for r in p['additional_scope_requirements']:
 if r['id']=='V29-REGRESSION':r.update(disposition='passed',assessment=common,evidence=['artifacts/phase22/integration/'+n for n in refs])
for ident,requirement in [('V30-AUTH','Record exact approved decision and consume the single ten-observation dispatch'),('V30-DISPOSITION','Validate and individually source-assess successful complete discrimination/repeat gate without replacing original misses'),('V30-COMPAT-PREP','Prepare minimal source-bound54-observation compatibility scope and justify Python reuse without executing new observations')]:
 p['additional_scope_requirements'].append({'id':ident,'requirement':requirement,'disposition':'passed','evidence':['artifacts/phase22/integration/'+n for n in refs]})
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='75142f053ab5017ebd0a7f0953994ee9f7c14dd8',scanner_identity=a['scanner'],latest_measured_scanner=a['scanner'],current_source_corpus_runs=10,current_exposed_evaluation_approved=True,current_exposed_evaluation_executed=True,current_exposed_gate_passed=True,prior_scanner_regression_observations_this_continuation=0,status=common,prior_audit={'path':'v29-loopback-fix/audit.json','sha256':sha(BASE/'v29-loopback-fix/audit.json')},owning_document_binding='Final v30 documentation/delivery binding is authoritative after final owning-doc edits.',new_paid_calls=0,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False)
p['references_sha256'].update({n:sha(BASE/n) for n in refs})
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==81
assert p['dispositions']=={'passed':82,'explicitly user-deferred':2,'unresolved':5}
assert p['additional_scope_dispositions']=={'passed':75,'unresolved':6}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in old['current_source_and_test_files']}
path=OUT/'audit.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print(p['dispositions'],p['additional_scope_dispositions'])
