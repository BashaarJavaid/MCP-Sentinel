"""Prepare source-bound compatibility inputs; never execute a scanner."""
import hashlib
import json
import shutil
from pathlib import Path

from scripts.phase20_corpus import validate as historical
from scripts.phase22_corpus import frozen
from scripts.phase20_scoring import candidate_identity

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
old=read(BASE/'v29-loopback-fix/evaluation-proposal.json')
groups={}; files={}; order=[]
def bind(p):
 name=p.relative_to(ROOT).as_posix();files[name]=sha(p);return name
for group,version,approval_name in [('searxng','v3','authorization-7555a9d.json'),('fetchmcp','v2','authorization-62987a6.json'),('openwebsearch','v1','authorization.json'),('development',None,'authorization.json'),('historical',None,None)]:
 approval=(ROOT/'artifacts/phase22'/('corpus-replacement-'+version)/approval_name if version else ROOT/'artifacts/phase22/authorization.json') if approval_name else None
 manifest=historical() if group=='historical' else frozen(approval_path=approval)
 if version:
  manifest_path=ROOT/read(approval)['corpus']['manifest']
  report_root=BASE/f'v13-exposed-{group}-rules-first'
  ids=[o['input_id'] for o in read(report_root/'results.json')['outcomes']]
  assessment_path=BASE/('v13-searxng-assessment/packet.json' if group=='searxng' else 'v13-exposed-assessment/packet.json')
  a=read(assessment_path)['runs'];run=a['first'] if 'first' in a else a[group+'-first']
  scored={r['input_id']:r for r in run['rows']}
 else:
  manifest_path=ROOT/('tests/evals/phase20/manifest.yaml' if group=='historical' else 'artifacts/phase22/corpus-review/manifest.json')
  ids=[i.id for i in manifest.inputs if i.language=='typescript' and (group=='historical' or i.split=='development')]
  report_root=BASE/('v22-final-hosted/artifacts/phase22-refresh-historical_first' if group=='historical' else 'v21-sequence-hosted/artifacts/phase22-full-development')
  assessment_path=BASE/('v22-refresh-v1/condition-assessment.json' if group=='historical' else 'v21-full-linux-v1/development-condition-assessment.json')
  scored={r['input_id']:r for r in read(assessment_path)['assessments']}
 bind(assessment_path);bind(manifest_path)
 if approval:bind(approval)
 selected=[i for i in manifest.inputs if i.id in ids];assert [i.id for i in selected]==ids
 target=OUT/'references'/group;target.mkdir(parents=True,exist_ok=False)
 rows={}
 for item in selected:
  paths=list(report_root.glob(f'*/{item.id}/report.json')) if not version else [report_root/item.id/'report.json']
  assert len(paths)==1,(group,item.id,paths)
  source=paths[0];report=read(source);ref=target/(item.id+'.json');shutil.copyfile(source,ref)
  config=source.parent/'configuration.json';dest=target/(item.id+'-configuration.json');shutil.copyfile(config,dest)
  match=scored[item.id].get('matches',scored[item.id].get('matched_keys'))
  assert bool(match)==(item.label=='vulnerable')
  rows[item.id]={'input':item.model_dump(mode='json'),'reference_report':bind(ref),'reference_original':source.relative_to(ROOT).as_posix(),'configuration':bind(dest),'configuration_sha256':sha(dest),'assessment':{'candidate_identity':candidate_identity(report['findings']),'matches':match,'rationale':'Reuse the unchanged named-condition judgment only when the entire ordered finding list equals this frozen source-assessed reference. Every other report delta remains separately reviewable.'}}
 groups[group]={'manifest':manifest_path.relative_to(ROOT).as_posix(),'manifest_sha256':sha(manifest_path),'source_freeze_approval':approval.relative_to(ROOT).as_posix() if approval else None,'input_ids':ids,'inputs':rows,'assessment_path':assessment_path.relative_to(ROOT).as_posix()}
 for batch in (['first','repeat'] if version else ['compatibility']):
  order.extend({'group':group,'batch':batch,'input_id':i} for i in ids)
assert len(order)==54 and len(groups['development']['input_ids'])==10 and len(groups['historical']['input_ids'])==14
for p in [OUT/'evaluate.py',BASE/'v23-fresh-v5/runner.py',BASE/'v20-linux-diagnostic-v1/runner.py']:bind(p)
proposal={'status':'prepared_not_approved','scanner':old['scanner'],'lock_sha256':old['lock_sha256'],'purpose':'Restore current-source compatibility of three earlier exposed SSRF families and check all24 affected historical/development TypeScript inputs, preserving the accepted whole-batch Linux timing evidence at1f3f72f.','runner':(OUT/'evaluate.py').relative_to(ROOT).as_posix(),'execution':'One serial local macOS sequence in an immutablef85a90f checkout using the existing locked environment; no overlapping owned heavy work. Prior2ac39aa exposed results were local macOS. This does not claim a new whole-batch Linux timing pass.','bounds':{'native_observations':54,'local_sequences':1,'hosted_dispatches':0,'normal_target_seconds':120,'native_and_whole_input_maximum_seconds':300,'cleanup_maximum_seconds_per_input':15,'sequence_maximum_minutes':300,'retries':0,'profiles':0,'comparators':0,'paid_calls':0,'target_execution':False},'groups':groups,'order':order,'files_sha256':files,'volatile_exclusions':read(BASE/'v13-exposed-assessment/packet.json')['volatile_fields'],'gate':'Each observation completes with valid JSON/SARIF, unchanged entire ordered findings against its individually source-assessed reference, unchanged condition keys and the same named-condition outcome. The three exposed families each run all5 inputs twice with2 vulnerable hits and0 matching alerts on3 negatives per batch; all15 entire ordered repeats must agree after the established11 volatile exclusions. Coverage/warning and other non-finding changes against old sources require individual post-run source assessment before final compatibility is claimed.','stop':'Stop on first incomplete, late, identity/configuration/schema/cleanup/finding-condition change or ordered-repeat failure. Retain attempted/partial records and close every unstarted observation. No assessment tuning, source changes, retries or resumption under this budget.','reuse':'The15 Python development and31 Python historical inputs retain their original source-bound results: changed Python module bodies are confined to TypeScript classes and a report branch reachable only from a TypeScript url_guard_scope capture. Shared Python analysis code is unchanged; exact AST/source proof is retained separately. Original whole25+45+45 timing/conditions stay measured at1f3f72f; old Python plus new TypeScript observations will never be called a new whole batch.','corpus_authorization':'Old corpus receipts bind immutable source/configuration only. A new exact evaluation-authorization.json must approve this proposal and its entire order before any observation; old budgets remain closed. Harness result metadata retains its original source-freeze receipt; the supervising packet binds the new execution approval.','exposure':'All sources are already exposed; these are regression/compatibility observations. No fresh generalization or independent human review claim.','not_authorized':['Paid calls','Target execution','Another fresh corpus','Full historical timing rerun','Final technical acceptance','Merge/release/outreach/Phase23'],'phase22_complete':False}
path=OUT/'evaluation-proposal.json';assert not path.exists();path.write_text(json.dumps(proposal,indent=2)+'\n');print('Prepared54 observations,',len(files),'bound files; zero scans.')
