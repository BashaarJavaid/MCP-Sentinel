"""Check Python reuse and immutable runner inputs using source only."""
import ast
import hashlib
import importlib.util
import json
import subprocess
from pathlib import Path

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],text=True)
old='1f3f72f';new='f85a90f'
changed=git('diff','--name-only',old,new,'--','src').splitlines()
assert set(changed)=={'src/sentinel/static/engine.py','src/sentinel/static/rules/sent015.py','src/sentinel/static/typescript_discovery.py','src/sentinel/static/typescript_path_flow.py','src/sentinel/static/typescript_registration_flow.py'}
path='src/sentinel/static/rules/sent015.py'
a,b=[ast.parse(git('show',rev+':'+path)) for rev in [old,new]]
def defs(tree):return {n.name:ast.dump(n,include_attributes=False) for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
x,y=defs(a),defs(b)
assert x.keys()==y.keys() and [k for k in x if x[k]!=y[k]]==['TypeScriptURLFlow']
assert x['URLFlow']==y['URLFlow'] and x['detect']==y['detect']
# The only import change adds the existing TypeScript walk helper; Python never calls it.
imports=lambda t:[ast.dump(n,include_attributes=False) for n in t.body if isinstance(n,(ast.Import,ast.ImportFrom))]
assert set(imports(b))-set(imports(a))=={ast.dump(ast.parse('from sentinel.static.typescript_discovery import TypeScriptSymbol, name_of, walk').body[0],include_attributes=False)}
assert set(imports(a))-set(imports(b))=={ast.dump(ast.parse('from sentinel.static.typescript_discovery import TypeScriptSymbol, name_of').body[0],include_attributes=False)}
for p in ['src/sentinel/static/traversal.py','src/sentinel/static/model.py','src/sentinel/static/coverage.py','src/sentinel/static/workers.py']:
 assert git('show',old+':'+p)==git('show',new+':'+p)
assert 'elif language is not TargetLanguage.PYTHON and _is_typescript_source(path)' in (ROOT/'src/sentinel/static/traversal.py').read_text()
assert 'if context.files.typescript_files:' in (ROOT/path).read_text()
# Every production of the new report capture is inside the TypeScript class.
lines=(ROOT/path).read_text().splitlines();cls=next(n for n in b.body if isinstance(n,ast.ClassDef) and n.name=='TypeScriptURLFlow')
producers=[i for i,line in enumerate(lines,1) if '"url_guard_scope"' in line]
assert producers and all(cls.lineno<=i<=cls.end_lineno for i in producers)
configs=json.loads((BASE/'v21-full-linux-v1/configurations.json').read_text())
proposal=json.loads((OUT/'evaluation-proposal.json').read_text())
from scripts.phase22_corpus import frozen
from scripts.phase20_corpus import validate
rows={}
for group,manifest in [('development',frozen()),('historical',validate())]:
 items=[i for i in manifest.inputs if i.language=='python' and (group=='historical' or i.split=='development')]
 assert len(items)==(15 if group=='development' else 31)
 for item in items:assert configs[item.id]['configuration']['language']=='python'
 rows[group]=[{'input_id':i.id,'snapshot':i.snapshot,'configuration_sha256':configs[i.id]['sha256']} for i in items]
assert not git('diff','439c3fe','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','action.yml','.github','Makefile','README.md','LICENSE','CHANGELOG.md')
frozen_root=Path('/private/tmp/mcp-phase22-frozen-f85a90f')
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=frozen_root,text=True).strip()==proposal['scanner']['revision']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=frozen_root)
spec=importlib.util.spec_from_file_location('compat',OUT/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
m.verify();m.selfcheck()
assert json.loads((OUT/'supervisor-check/selfcheck.json').read_text())['passed']
result={'source_only':True,'scanner':proposal['scanner'],'changed_product_files':changed,'unchanged_python_class_and_dispatch':True,'import_change':'Adds existing TypeScript walk helper; consumed only by TypeScriptURLFlow','typescript_source_collection_disabled_for_python':True,'new_capture_producers':producers,'python_inputs':rows,'engineering_inputs_equal_tested_439c3fe':True,'frozen_checkout_clean':str(frozen_root),'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'runner_sha256':sha(OUT/'evaluate.py'),'supervisor_controls_sha256':sha(OUT/'supervisor-check/selfcheck.json'),'corpus_observations':0,'paid_calls':0,'limitation':'Source compatibility of Python execution paths, not a new timing measurement. All TypeScript inputs require the separately proposed observations. Original full-batch timing remains measured at1f3f72f.'}
p=OUT/'source-proof.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('46 Python inputs retain source-compatible analysis;54 TypeScript observations prepared,zero executed.')
