"""Bind unaffected Python measurements to unchanged source; no corpus execution."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],text=True)
old='8c6256725f0948ee593eb4b73e90baf6f7b0d76a';new='2e0efb268b733a14d7eca87555fdd87f134ba78c'
assert git('rev-parse','HEAD').strip()==new
assert git('diff','--name-only',old,new,'--','src').splitlines()==['src/sentinel/static/typescript_path_flow.py']
assert set(git('diff','--name-only',old,new,'--','src','tests','scripts','schemas','uv.lock','pyproject.toml','.github','action.yml','Makefile').splitlines())=={'src/sentinel/static/typescript_path_flow.py','tests/test_typescript_containment.py','tests/test_ssrf.py'}
proposal=json.loads((BASE/'v37-ddg-trace/evaluation-proposal.json').read_text());rows=[]
for group,g in proposal['groups'].items():
 for name in g['input_ids']:
  x=g['inputs'][name];c=ROOT/x['configuration'];config=json.loads(c.read_text())
  assert sha(c)==x['configuration_sha256'] and config['language']=='python' and config['static_only'] and config['scanner']['scanner']['rules_only']
  assert x['input']['language'].lower()=='python'
  rows.append({'group':group,'input_id':name,'configuration':x['configuration'],'configuration_sha256':sha(c)})
assert len(rows)==51
p={'source_only':True,'from_scanner':old,'to_scanner':new,'changed_product_files':['src/sentinel/static/typescript_path_flow.py'],'python_engine_and_flow_bytes_unchanged':True,'python_inputs_select_python_only':True,'retained_python_inputs':rows,'retained_measurements':'v38 actual8c62567:87 observations (five DDG twice,15 development once,31 historical twice). Source-compatible reuse, not new execution or a pooled whole-corpus timing claim.','prior_assessment_sha256':sha(BASE/'v38-guard-regression/assessment.json'),'typescript_compatibility':'Shared TypeScript path, shell, option, URL, credential and registration analysis changes. All44 prior TypeScript input records plus3v7 originals require a separately approved current-source regression.','new_corpus_observations':0,'paid_calls':0}
with (OUT/'source-proof.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('51 Python-only input bindings unchanged;87 retained observations keep actual8c62567 identity. TypeScript needs separate regression.')
