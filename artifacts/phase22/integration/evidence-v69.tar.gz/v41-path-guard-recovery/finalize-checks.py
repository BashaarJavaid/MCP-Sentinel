"""Bind completed engineering to the corrected freeze before evaluation approval."""
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head='2e0efb268b733a14d7eca87555fdd87f134ba78c';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
labels=['v41-full-suite','v41-final-lint','v41-final-format','v41-final-mypy','v41-lock','v41-schema','v41-notices','v41-artifacts','v41-production-capture','v41-runtime-compatibility','v41-source-proof-final','v41-source-assessment','v41-frozen-source-validation','v41-runner-boundaries','v41-supervisor-boundaries','v41-registration-controls-corrected','v41-checkout-binding']
checks=[]
for label in labels:
 path=BASE/(label+'.json');r=read(path);assert r['exit_code']==0,label
 checks.append({'label':label,'metadata_sha256':sha(path),'log_sha256':sha(BASE/r['log']),'source':r['source_commit'],'patch_sha256':r['diff_sha256'],'command':r['command']})
assert read(BASE/'v41-full-suite.json')['source_commit']==head and not (BASE/'v41-full-suite.patch').read_bytes()
counts=Counter();by_file={}
for c in ET.parse(BASE/'v41-full-suite-junit.xml').iter('testcase'):
 state='skipped' if c.find('skipped') is not None else 'failed' if c.find('failure') is not None or c.find('error') is not None else 'passed';counts[state]+=1
 parts=c.attrib['classname'].split('.')
 while not (ROOT/('/'.join(parts)+'.py')).exists():parts.pop();assert parts
 by_file.setdefault('/'.join(parts)+'.py',Counter())[state]+=1
assert counts=={'passed':2317,'skipped':36},counts
coverage=read(BASE/'v41-full-suite-coverage.json')['totals']['percent_covered'];assert coverage>=80
quality=read(BASE/'v41-final-quality/packet.json');assert quality['engineering_passed'] and quality['source']==head
audit=read(BASE/'v41-final-quality-audit/packet.json');assert len(audit['quality'])==12 and all(r['passed']==2317 and r['skipped']==36 for r in audit['quality'])
files=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','src','tests','scripts','schemas','pyproject.toml','uv.lock','action.yml','.github','Makefile','LICENSE','CHANGELOG.md'],text=True).splitlines()
for n in files:assert subprocess.check_output(['git','show',head+':'+n])==(ROOT/n).read_bytes(),n
record={'scanner':read(OUT/'freeze.json')['scanner'],'actual_tested_source':head,'checks':checks,'full_suite':dict(counts,branch_coverage_percent=coverage),'tests_by_file':by_file,'source_files_sha256':{n:sha(ROOT/n) for n in files},'quality_packet_sha256':sha(BASE/'v41-final-quality/packet.json'),'quality_audit_sha256':sha(BASE/'v41-final-quality-audit/packet.json'),'six_production_requests_replayed':True,'production_replay_source':'12fbdf50525cc090ad4ac5ebf101e042f45525c2','production_source_bytes_equal_tested_candidate':True,'paid_calls':0,'current_source_corpus_observations':0,'normal_ci_historical_reproductions':'Pinned8824014 reproductions are ordinary historical verification, not new corrected-scanner measurements.'}
with (OUT/'local-checks.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
failures=[
 ('v41-synthetic-before','Both guarded initialization forms wrongly alert; direct/local root controls pass. Root cause established before implementation.'),
 ('v41-security-controls','Initial candidate missed explicit eval and require AST special-node invalidation; corrected and all33 then-selected controls passed.'),
 ('v41-catch-shadow-control','Catch parameter named process was not treated as a shadow; PatId rejection added, retained34-control full suite passes.'),
 ('v41-lint','One synthetic source string exceeded line length; split literal only.'),
 ('v41-affected-controls','1172pass,1fail: existing before-process.exit case expected a reachable handler. Proven unconditional termination prevents registration; assertion updated to require no tool/match. Other11 effect/placement cases unchanged.'),
 ('v41-registration-controls','Initial assertion edit matched the preceding similar test block, leaving the intended case unchanged. Moved to exact named test before committing; corrected12 cases pass.'),
 ('v41-freeze-checkout','Sandbox denied creation of shared Git worktree metadata before checkout; authorized escalation created and verified the immutable tree.'),
 ('v41-source-proof','Overstrict assertion required manifest language to equal effective scanner language. Five old DDG metadata fields say typescript, while all10 actual observations use python.'),
 ('v41-source-proof-corrected','Case-normalization did not resolve the genuine metadata discrepancy. Original helpers retained; final proof records both fields and verifies all87 actual Python configurations.'),
]
record={'failed_checks':[{'label':label,'metadata_sha256':sha(BASE/(label+'.json')),'log_sha256':sha(BASE/(label+'.log')),'assessment':why} for label,why in failures],'initial_hosted':{'source':'12fbdf50525cc090ad4ac5ebf101e042f45525c2','ci':34712538629,'ci_conclusion':read(BASE/'v41-quality/packet.json')['runs']['ci']['conclusion'],'docs':34712538626,'retained_packet_sha256':sha(BASE/'v41-quality/packet.json'),'reason':'Superseded by committed corrected registration assertion; workflow concurrency cancelled remaining initial jobs. No initial full hosted pass is claimed.'},'initial_source_and_all_evidence_retained':True,'implementation_cycles':1,'current_scanner_observations':0,'paid_calls':0}
with (OUT/'check-failure-assessment.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
path=OUT/'evaluation-proposal.json';p=read(path);shutil.copyfile(path,OUT/'evaluation-proposal-before-final-binding.json')
for n in ['validate-frozen-source.py','frozen-source-validation.json','compatibility.json','supervisor-check/selfcheck.json','finalize-checks.py','local-checks.json','check-failure-assessment.json','diagnosis.json','python-reuse-execution-binding.json']:
 q=OUT/n;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
for n in ['v41-final-quality/packet.json','v41-final-quality-audit/packet.json',*[x+'.json' for x in labels]]:
 q=BASE/n;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
path.write_text(json.dumps(p,indent=2)+'\n')
print('All2317tests/36skips local and12hosted suites pass; unapproved94-observation proposal:',sha(path))
