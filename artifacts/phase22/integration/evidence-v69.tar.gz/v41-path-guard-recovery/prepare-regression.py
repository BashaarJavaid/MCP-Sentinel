"""Prepare one unapproved repeat of every affected TypeScript input; no scans."""
import copy,hashlib,json
from pathlib import Path
from scripts.phase22_corpus import Manifest
from scripts.phase20_scoring import candidate_identity
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
prior=read(BASE/'v30-compatibility-proposal/evaluation-proposal.json');freeze=read(OUT/'freeze.json');groups=copy.deepcopy(prior['groups']);refs=read(BASE/'v31-compatibility/raw/packet.json')
files={}
def bind(p):
 files[str(p.relative_to(ROOT))]=sha(p)
for group,g in groups.items():
 for name,x in g['inputs'].items():
  row=next(r for r in refs['attempts'] if r['group']==group and r['input_id']==name)
  ref=BASE/'v31-compatibility/raw'/row['directory']/name/'report.json'
  assert candidate_identity(read(ref)['findings'])==x['assessment']['candidate_identity']
  x['reference_report']=str(ref.relative_to(ROOT));x['configuration']=str(ref.with_name('configuration.json').relative_to(ROOT))
  assert sha(ROOT/x['configuration'])==x['configuration_sha256']
lighthouse=read(BASE/'v29-loopback-fix/evaluation-proposal.json');v7=read(BASE/'v39-fresh-v7/evaluation-proposal.json')
for group,manifest,approval,ids,raw in [
 ('memorykeeper',v7['manifest']['path'],'artifacts/phase22/integration/v39-fresh-v7/evaluation-authorization.json',v7['input_order'],BASE/'v40-fresh-v7/raw'),
 ('lighthouse',lighthouse['corpus']['manifest'],'artifacts/phase22/integration/v29-loopback-fix/evaluation-authorization.json',lighthouse['corpus']['input_ids'],BASE/'v30-lighthouse-regression/hosted/artifacts/phase22-lighthouse-regression')]:
 m=Manifest.model_validate_json((ROOT/manifest).read_text());selected=[i for i in m.inputs if i.id in ids];assert [i.id for i in selected]==ids
 g={'manifest':manifest,'manifest_sha256':sha(ROOT/manifest),'source_freeze_approval':approval,'input_ids':ids,'inputs':{}}
 for item in selected:
  reports=sorted(p for p in raw.rglob('report.json') if p.parent.name==item.id and 'first' in p.parent.parent.name);assert len(reports)==1,item.id
  ref=reports[0];config=ref.with_name('configuration.json');assert read(config)['language']=='typescript'
  g['inputs'][item.id]={'input':item.model_dump(mode='json'),'reference_report':str(ref.relative_to(ROOT)),'configuration':str(config.relative_to(ROOT)),'configuration_sha256':sha(config),'assessment':None}
 groups[group]=g
# Put the six exposed repair observations first, then all44 prior TS inputs twice.
groups={k:groups[k] for k in ['memorykeeper','searxng','fetchmcp','openwebsearch','lighthouse','development','historical']}
order=[{'group':k,'batch':batch,'input_id':i} for k,g in groups.items() for batch in ['first','repeat'] for i in g['input_ids']]
assert len(order)==94 and sum(len(g['input_ids']) for g in groups.values())==47
for g in groups.values():
 bind(ROOT/g['manifest'])
 if g['source_freeze_approval']:bind(ROOT/g['source_freeze_approval'])
 for x in g['inputs'].values():
  bind(ROOT/x['reference_report']);bind(ROOT/x['configuration'])
  assert read(ROOT/x['configuration'])['language']=='typescript'
for n in ['v31-compatibility/assessment.json','v31-compatibility/source-assessment.json','v30-lighthouse-regression/assessment.json','v40-fresh-v7/assessment.json','v40-fresh-v7/finding-source-assessment.json','v39-fresh-v7/runner.py','v32-fresh-v6/runner.py','v20-linux-diagnostic-v1/runner.py']:
 bind(BASE/n)
for name in ['freeze.json','source-proof.json','prepare-regression.py','evaluate.py','scoring-rubric.json']:bind(OUT/name)
proposal={'status':'prepared_not_approved','scanner':freeze['scanner'],'lock_sha256':freeze['harness_and_lock_sha256']['uv.lock'],'frozen_checkout':freeze['frozen_checkout'],'purpose':'Verify the exposed memory-keeper canonical import guard correction and every affected TypeScript corpus input. Reuse byte-bound Python measurements; preserve all original fresh outcomes.','runner':str((OUT/'evaluate.py').relative_to(ROOT)),'execution':'One local serial macOS sequence using the existing locked environment; no hosted evaluation dispatch or larger runner.','bounds':{'native_observations':94,'local_sequences':1,'hosted_dispatches':0,'normal_target_seconds':120,'native_and_whole_input_maximum_seconds':300,'cleanup_maximum_seconds_per_input':15,'sequence_maximum_minutes':520,'nominal_input_minutes':470,'retries':0,'profiles':0,'comparators':0,'paid_calls':0,'target_execution':False,'new_repositories':0},'groups':groups,'order':order,'files_sha256':files,'volatile_exclusions':prior['volatile_exclusions'],'witnesses':{'lighthouse':lighthouse['witnesses'],'memorykeeper':{i:{'label':groups['memorykeeper']['inputs'][i]['input']['label'],'path':'src/index.ts','sink_line':1724 if i.endswith('vulnerable') else 1849,'rule_id':'SENT-012'} for i in v7['input_order']}},'gate':'All47 entire ordered report repeats must agree after only the established11 volatile exclusions. Each v7batch must detect the original vulnerable import and have zero matching fixed/safe read alerts, with source-established actual read/guard support rather than unsupported silence. Preserve all prior TypeScript condition requirements and narrower SSRF qualifiers. Assess every finding, warning, unresolved flow, surface and change against bound original reports. Runtime safety and named dispatch are not inferred.','stop':'Stop on the first incomplete, late, schema/identity/cleanup failure, report repeat mismatch or v7 named-read condition failure. Close all unstarted observations. Other source/coverage changes are retained for complete source assessment after this one sequence; they cannot silently pass. No tuning, source/label/deadline change, retry or extra observation.','reuse':'51 Python-only effective configurations retain the87 actual8c62567 observations by byte-bound unchanged Python paths. Historical whole45+45 and25 development executions keep their actual1f3f72f sources; these47-input repeats are not pooled into a new whole original corpus batch.','exposure':'All47 input records are exposed. A later pass is regression, never replacement of first-frozenv7:one vulnerable hit and two matching false alerts per batch at8c62567.','following_checkpoint':'Final source assessments and requirement reconciliation, then explicit human Phase22 technical acceptance if actual gates are ready. No acceptance is inferred from evaluation approval.','not_authorized':['paid calls','target execution or dependencies','new repository','merge/release/ready/outreach','Phase23'],'phase22_complete':False}
with (OUT/'evaluation-proposal.json').open('x') as f:json.dump(proposal,f,indent=2);f.write('\n')
print('Prepared94 native observations on47 exposed TypeScript input records; no approval or execution.')
