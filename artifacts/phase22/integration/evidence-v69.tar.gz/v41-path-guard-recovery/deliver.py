"""Deliver verified source correction and unapproved regression to existing draft37."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
old=read(BASE/'v40-fresh-v7/documentation-binding.json');tested='2e0efb268b733a14d7eca87555fdd87f134ba78c'
assert run(['git','rev-parse','HEAD']).strip()==tested and run(['git','branch','--show-current']).strip()=='phase22/integration'
assert not run(['git','diff','--cached'])
fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
pr=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'pre-delivery-pr37.json',pr)
assert pr['headRefOid']==tested and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(BASE/'v40-fresh-v7/pr-body.md').read_text()
parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,state,isDraft']));write(OUT/'pre-delivery-pr36.json',parent)
assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455';run(['git','merge-base','--is-ancestor',parent['headRefOid'],'HEAD'])
checks=read(OUT/'local-checks.json');inputs=list(checks['source_files_sha256']);assert not run(['git','diff',tested,'--',*inputs])
protected=old['user_files_sha256'];stage=read(BASE/'v39-fresh-v7/staging-verification.json')
def verify_protected():
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision']
  assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 folder=stage['frozen_checkout'];assert run(['git','rev-parse','HEAD'],folder).strip()=='8c6256725f0948ee593eb4b73e90baf6f7b0d76a' and not run(['git','diff','HEAD'],folder)
 assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(stage['existing_untracked_files_sha256'])
 for n,d in stage['staged_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 fixed=Path(read(OUT/'freeze.json')['frozen_checkout']);assert run(['git','rev-parse','HEAD'],fixed).strip()==tested and not run(['git','status','--porcelain'],fixed)
 for n,d in read(OUT/'frozen-source-validation.json')['source_receipts_staged'].items():assert sha(fixed/n)==d,n
verify_protected()
proposal=read(OUT/'evaluation-proposal.json');audit=read(OUT/'audit.json')
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==115
assert audit['dispositions']=={'passed':77,'explicitly user-deferred':2,'unresolved':10}
assert audit['additional_scope_dispositions']=={'passed':108,'proposed documented limitation awaiting decision':5,'unresolved':2}
assert read(OUT/'authorization.json')['approved'] and checks['full_suite']['passed']==2317
assert audit['current_continuation_corpus_observations']==0 and not audit['current_source_typescript_regression_executed']
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
for n,d in audit['current_source_and_test_files'].items():assert sha(ROOT/n)==d,n
for label in ['v41-docs','v41-build','v41-distributions','v41-finalize-checks']:
 assert read(BASE/(label+'.json'))['exit_code']==0,label
assert read(OUT/'owned-work.json')['owned_processes']==[]
for n,d in proposal['files_sha256'].items():assert sha(ROOT/n)==d,n
seal=read(BASE/'evidence-v69.json');assert sha(BASE/seal['archive'])==seal['sha256']
for r in seal['files']:assert sha(BASE/r['path'])==r['sha256'],r['path']
dist=read(OUT/'final-distributions.json');assert sha(ROOT/'README.md')==dist['README_sha256']
for r in dist['distributions']:assert sha(ROOT/r['path'])==r['sha256']
docs=list(old['owning_docs_sha256']);refs=['audit.json','summary.md','pr-body.md','authorization.json','evaluation-proposal.json','diagnosis.json','local-checks.json','source-proof.json','python-reuse-execution-binding.json','check-failure-assessment.json','final-distributions.json','deliver.py','freeze.json','frozen-source-validation.json']
worktrees={**old['worktrees'],read(OUT/'freeze.json')['frozen_checkout']:{'revision':tested,'classification':'new immutable scanner with hash-bound ignored source-freeze provenance receipts'}}
b={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':tested,'tested_workflow':tested,'scanner':proposal['scanner'],'byte_identical_quality_inputs':inputs,'owning_docs_sha256':{n:sha(ROOT/n) for n in docs},'review_packet_sha256':{n:sha(OUT/n) for n in refs},'user_files_sha256':protected,'worktrees':worktrees,'authorized_staged_frozen_artifacts_sha256':old['authorized_staged_frozen_artifacts_sha256'],'new_frozen_staging_verification':{'path':'v41-path-guard-recovery/frozen-source-validation.json','sha256':sha(OUT/'frozen-source-validation.json')},'prior_v39_staging_verification':{'path':'v39-fresh-v7/staging-verification.json','sha256':sha(BASE/'v39-fresh-v7/staging-verification.json')},'evidence_seal':{'path':seal['archive'],'sha256':seal['sha256'],'members':len(seal['files'])},'source_correction_approved':True,'engineering_passed':True,'evaluation_approved':False,'evaluation_executed':False,'new_native_observations':0,'proposed_native_observations':94,'first_frozen_fresh_discrimination_passed':False,'new_paid_calls':0,'technical_acceptance_requested':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Post-seal binding directly tracked. Product/tests/workflows equal tested2e0efb2. Final docs and package metadata separately checked. Original8c62567 fresh result retained; new exposed TypeScript regression unapproved. No current-source corpus pass, paid call or technical acceptance.'}
write(OUT/'documentation-binding.json',b)
paths=sorted(docs);extra=[str(p.relative_to(ROOT)) for p in [BASE/'evidence-v69.json',BASE/'evidence-v69.tar.gz',OUT/'documentation-binding.json']]
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','add','-f','--',*extra],check=True)
assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths+extra)
subprocess.run(['git','commit','-m','Deliver verified import-root correction and exposed regression proposal [skip ci]'],check=True)
subprocess.run(['git','push','origin','phase22/integration'],check=True)
subprocess.run(['gh','pr','edit','37','--title','Phase 22: import-root correction; exposed regression pending','--body-file',str(OUT/'pr-body.md')],check=True)
head=run(['git','rev-parse','HEAD']).strip();readbacks=[]
for attempt in range(5):
 pr=json.loads(run(['gh','pr','view','37','--json',fields]));readbacks.append(pr)
 if pr['headRefOid']==head and pr['body']==(OUT/'pr-body.md').read_text():break
 time.sleep(2)
write(OUT/'delivery-readback-history.json',readbacks);write(OUT/'delivery-readback.json',pr)
assert pr['headRefOid']==head and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning' and pr['body']==(OUT/'pr-body.md').read_text()
assert json.loads(run(['gh','pr','view','36','--json','headRefOid']))['headRefOid']==parent['headRefOid']
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached']);verify_protected()
for n,d in b['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
write(OUT/'delivery-verification.json',{'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-readback.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':0,'evaluation_approved':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Supplemental ignored post-delivery receipt; sealed evidence and delivered commit remain immutable.'})
print('Verified existing OPEN draft delivery',head,pr['url'])
