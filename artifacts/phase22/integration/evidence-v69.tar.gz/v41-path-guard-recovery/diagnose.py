"""Inspect only the minimal synthetic regression, never corpus or target code."""
import ast,json,tempfile,time
from pathlib import Path
from sentinel.static.model import RuleRunState,TypeScriptSourceFile
from sentinel.static.typescript_discovery import TypeScriptProgram
from sentinel.static.typescript_path_flow import TypeScriptPathFlow,analyze
root=Path.cwd();out=Path(__file__).resolve().parent
module=ast.parse((root/'tests/test_typescript_containment.py').read_text());fun=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='test_checked_import_after_canonical_root_initialization');assign=fun.body[0];source=assign.value.func.value.value
rows=[]
for name,s in [('try-throw',source.replace('FAILURE','throw new Error();')),('try-exit',source.replace('FAILURE','process.exit(1);')),('constant-root',source.replace("let root: string;\ntry { root = fs.realpathSync('/allowed'); }\ncatch { FAILURE }","const root = fs.realpathSync('/allowed');")),('local-root',source.replace("let root: string;\ntry { root = fs.realpathSync('/allowed'); }\ncatch { FAILURE }",'').replace('function checked(input: string): string {',"function checked(input: string): string {\nconst root = fs.realpathSync('/allowed');"))]:
 with tempfile.TemporaryDirectory(prefix='phase22-v41-synthetic-') as temp:
  p=Path(temp)/'server.ts';p.write_text(s);program=TypeScriptProgram((TypeScriptSourceFile(p,p.name,s),),deadline=time.monotonic()+15);state=RuleRunState();events=[]
  class Trace(TypeScriptPathFlow):
   def guard(self,value,env,truth):
    super().guard(value,env,truth);events.append({'kind':'guard','truth':truth,'facts':repr(self.condition(value)),'env':{k:repr(v) for k,v in env.items() if k in {'root','resolved','safe','inside'}},'boundaries':repr(self.boundaries)})
   def path_sink(self,file,node,env,value,name,**kwargs):
    events.append({'kind':'sink','value':repr(value),'globals':{str(k):repr(v) for k,v in self.globals.items() if k[1]=='root'}});super().path_sink(file,node,env,value,name,**kwargs)
  analyze(program,state,flow=Trace(program,state));rows.append({'case':name,'synthetic_source':s,'findings':[m.snippet for m in state.matches],'tools':[{'name':t.name,'factory':repr(t.factory)} for t in program.tools()],'events':events});print(name,len(state.matches))
with (out/'synthetic-diagnosis.json').open('x') as f:json.dump({'corpus_observations':0,'target_execution':False,'rows':rows},f,indent=2)
