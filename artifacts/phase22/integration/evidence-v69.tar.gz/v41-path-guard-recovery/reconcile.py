"""Reconcile source correction, verification and remaining exact evaluation gate."""
import copy,hashlib,json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v40-fresh-v7'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
checks=read(OUT/'local-checks.json');proposal=read(OUT/'evaluation-proposal.json');oldbinding=read(OLD/'documentation-binding.json')
assert checks['full_suite']['passed']==2317 and checks['full_suite']['skipped']==36
pending={'R22','R26','R27','R28','R65','R87','R89'}
text=f'''The approved focused source correction is implemented and engineering-verified at
**`2e0efb2`**, source SHA-256 **`{proposal['scanner']['source_sha256']}`**.
A single assignment to an initially uninitialized TypeScript module variable was
being discarded as rebinding. That lost the canonical filesystem root before the
checked import return reached the read. Synthetic reproductions failed with both
throwing and terminating startup catches; direct-constant and local-root controls
already passed. The shared analysis now reuses existing branch semantics for this
narrow initialization and recognizes stable, unshadowed Node `process.exit` as
terminal. Later writes, caller-controlled roots, ineffective prefixes, replaced
reads, eval, escaping/rebound process and nonterminating branches stay conservative.

The correction adds **34 synthetic security cases**. An existing SSRF regression
now explicitly requires no reachable tool after unconditional startup termination;
its other 11 effect/placement cases retain their checks. The initial affected run
was **1,172 passed / one failed** on that changed expectation. Initial eval/require
AST controls, catch-parameter shadowing, lint/assertion placement and source-binding
helper failures are preserved with corrections. Initial CI **34712538629** was
superseded and cancelled; its completed documentation and retained artifacts are
not represented as a full pass.

Final local and all **12 hosted suites pass 2,317 tests, with 36 skips**; local
branch coverage is **{checks['full_suite']['branch_coverage_percent']:.2f}%**. Final CI
**34712751779** passes all **29 normal jobs**, and documentation **34712751789**
passes. The complete hosted merge tree equals tested `2e0efb2`. Ruff, formatting,
strict mypy, lock, schemas, notices, generated artifacts, wheel/source distribution
bindings and ordinary installed-wheel, Docker replay and isolation checks pass.
Six production request replays used **zero model calls** at product-identical
`12fbdf5`; Git runtime components and the approved image remain byte-bound.
**Git campaigns remain incomplete at 312/1,040**, as the user requested.

**No new corpus observation, comparator, profile, repository or paid call occurred.**
The immutable source is `/private/tmp/mcp-phase22-frozen-2e0efb2`. Complete corpus
source archives, configurations and old source-freeze receipts validate without
execution. These receipts establish provenance; they do not reopen old budgets.
All 87 actual `8c62567` Python regression observations remain source-compatible:
the 51 effective input configurations select Python and its analysis bytes did
not change. The five original DDG manifest records incorrectly say TypeScript;
all ten executed DDG observations used the hash-bound Python configuration. That
metadata error and both fields are now explicit; original bytes/results are retained.

The next **unapproved** proposal is
`artifacts/phase22/integration/v41-path-guard-recovery/evaluation-proposal.json`:
**94 native observations**, one serial local sequence, **47 exposed TypeScript
input records each twice**. The three original memory-keeper inputs run first
(six observations), followed by the 44 prior TypeScript records: three SSRF
families, Lighthouse, ten development and 14 historical inputs. Every input keeps
the **120-second target / 300-second native and whole-input maximum**, with at most
15 seconds cleanup; the sequence ceiling is **520 minutes** (470 nominal input
minutes). There are zero comparators, retries, profiles, target executions, paid
calls or new repositories. Stop on an import-condition failure, incomplete/late
result, identity/schema/cleanup failure or ordered-repeat mismatch and close all
unstarted observations. Other changed findings/coverage require source assessment.
All 47 entire ordered repeats and existing condition/qualifier gates are required.
The actual fixed guard and supported read must be assessed; silence alone is not
proof of support. This is exposed regression, not another fresh-source evaluation.

The original memory-keeper first-frozen result at **`8c62567` remains unchanged**:
**six complete observations**, three entire ordered repeats, **one vulnerable hit
and two matching fixed/control false alerts per batch**. The maximum whole input
was **98.448156 seconds**. The fixed read was supported, but its guard and named
MCP dispatch were not established. Broader export and Git-message candidates and
the upstream test-secret false positive remain visible. A synthetic repair is not
a passing re-evaluation. The repository was absent from eight prior manifests and
100 prior effective trees, but was curated and assessed by the same implementation
agent after freeze; no independent human or training-data novelty claim is made.

Original DDG first-frozen detection, later narrow initial-URL qualification, all
Lighthouse/SSRF original misses and exposed passes remain attached to their actual
sources. The original held-out baseline remains 10 completed, 10 unsupported and
five incomplete, with zero hits among four completed vulnerable inputs out of ten
vulnerable inputs total. The historical whole 45+45 Linux timing/condition passes
and explicitly reused whole 25 development batch retain actual `1f3f72f`; partial
language subsets are never pooled into new whole-batch execution. Original timing
failures, errata, failed experiments and closed budgets remain preserved.

The audit accounts for **all 89 original requirements: 77 passed, two user-deferred,
ten unresolved**. R66/R88 retain the fresh discrimination failure and R84 awaits
explicit human acceptance; seven affected TypeScript condition requirements now
explicitly await verification of the changed source. This does not erase their
historical passes. All **115 added rows** are retained: 108 passed, five historical
closure proposals awaiting decision, and two unresolved evaluation criteria.
**Phase 22 remains incomplete; technical acceptance is not requested.** The exact
regression requires separate approval under the continuation prompt. Paid benchmark
and pilots stay deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23 is authorized.
'''
old='## Current v40 fresh detection and failed discrimination checkpoint\n\n'+(OLD/'summary.md').read_text().split('\n\n',1)[1]+'\n'
new='## Current v41 source correction and pending exposed regression\n\n'+text+'\n'
for n,d in oldbinding['owning_docs_sha256'].items():
 path=ROOT/n;assert sha(path)==d,n;s=path.read_text()
 if n=='artifacts/phase22/corpus-replacement-v7/README.md':
  assert s=='# Replacement v7: first-frozen evaluation result\n\n'+(OLD/'summary.md').read_text().split('\n\n',1)[1];path.write_text('# Replacement v7: source correction; exposed regression pending\n\n'+text)
 else:
  assert s.count(old)==1,n;path.write_text(s.replace(old,new))
path=ROOT/'docs/rules.md';s=path.read_text();anchor='The TypeScript interpreter also follows the documented\n';assert s.count(anchor)==1
s=s.replace(anchor,'A TypeScript module root assigned once inside a top-level `try` can retain its\ncanonical path when failure branches throw or call a proven global `process.exit`.\nThis narrow proof excludes finally blocks, nested declarations, later writes,\ndestructuring/loop rebinding and direct eval. Shadowed, replaced or escaped\n`process` and unknown termination stay conservative. Code after proven process\ntermination does not register a reachable handler. This is source reasoning,\nnot a runtime filesystem or race-safety guarantee.\n\n'+anchor);path.write_text(s)
path=BASE/'README.md';s=path.read_text().replace('batches 1–68','batches 1–69',1);start=s.index('Review the [first-frozen evaluation]');end=s.index('\n',start);s=s[:start]+'Review the [source correction](v41-path-guard-recovery/diagnosis.json), [89 + 115 row audit](v41-path-guard-recovery/audit.json) and [unapproved 94-observation regression proposal](v41-path-guard-recovery/evaluation-proposal.json). Restore seal 69 after seals 1–68, verifying every archive/member hash. First-frozen false positives remain preserved; technical acceptance is pending.'+s[end:];path.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 source correction and pending exposed regression\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: canonical import-root correction; regression pending\n\n'+text+'\nEvidence: `artifacts/phase22/integration/v41-path-guard-recovery/`, seal69 after all68 earlier seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34712751779\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34712751789\n')
p=copy.deepcopy(read(OLD/'audit.json'));common='Focused source correction and engineering pass at2e0efb2;0new corpus observations. Originalv7 first-frozen discrimination failure at8c62567 preserved. Exact94-observation exposed TypeScript regression unapproved; Python87 retained observations source-compatible. No technical acceptance.'
for r in p['requirements']:
 r['historical_v40_assessment']={k:r[k] for k in ['assessment','disposition','interpretation']};r['interpretation']=common
 if r['id'] in pending:
  r['disposition']='unresolved';r['assessment']='Historical measured pass retained; current-source TypeScript condition verification pending the exact94-observation proposal after shared path/registration analysis changed.'
 elif r['id'] in {'R66','R88','R84'}:r['assessment']=common
 elif r['id'] in {'R37','R71','R72','R73','R74'}:r['assessment']='Current2e0efb2 local and12hosted suites pass2317tests36skips; full engineering/distribution/source bindings in local-checks.json. Original failed/cancelled checks preserved.'
 elif r['id'] in {'R62','R83'}:r['assessment']='Owning docs distinguish synthetic correction and engineering pass from pending actual TypeScript regression, originalfreshfalsepositives and explicit acceptance.'
for id,requirement,disposition in [('V41-SOURCE','Execute the approved focused source correction with security controls and preserved original failures','passed'),('V41-ENGINEERING','Verify and freeze corrected source with required zero-paid engineering and reuse bindings','passed'),('V41-EXPOSED','Execute separately approved current-source TypeScript regression and assess every outcome','unresolved')]:
 p['additional_scope_requirements'].append({'id':id,'requirement':requirement,'disposition':disposition,'assessment':common,'evidence':['artifacts/phase22/integration/v41-path-guard-recovery/'+n for n in ['authorization.json','diagnosis.json','local-checks.json','freeze.json','evaluation-proposal.json']]})
p['prior_audit']={'path':'v40-fresh-v7/audit.json','sha256':sha(OLD/'audit.json')}
p['historical_v40_status_fields']={k:p.get(k) for k in ['status','current_source_corpus_runs','current_source_native_observations','current_continuation_corpus_observations','fresh_evaluation_status_basis']}
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),status=common,current_scanner=proposal['scanner'],current_source_corpus_runs=0,current_source_native_observations=0,current_continuation_corpus_observations=0,current_compatibility_observations_this_continuation=0,source_correction_approved=True,source_correction_engineering_passed=True,current_source_typescript_regression_approved=False,current_source_typescript_regression_executed=False,proposed_exposed_observations=94,current_source_observation_interpretation='No current2e0efb2 corpus observations. Prior87Python8c62567 observations are reused by exactsource/configuration binding; previous TS results retain their measured revisions and need the new proposed regression.',acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,owning_document_binding='Finalv41 binding follows docs/package checks andseal69.',fresh_evaluation_status_basis=common)
keys=['source','scanner_identity','workflow_tested_source','current_tests_by_file','per_file_test_counts_basis','full_sequence_status_basis','current_exposed_evaluation_approved','current_exposed_evaluation_executed','current_exposed_gate_passed','current_compatibility_passed','runner_preparation_final','final_verification_sha256','source_only_recovery_checkpoint','diagnostic_proposed_observations','diagnostic_approved','diagnostic_executed','diagnostic_passed','corrected_scanner_proposed_observations','corrected_scanner_evaluation_approved','corrected_scanner_evaluation_executed','current_fixed_guard_recognition_established','final_documentation_source_files']
p['historical_v40_current_fields']={k:p.get(k) for k in keys}
p.update(source=proposal['scanner']['revision'],scanner_identity=proposal['scanner'],workflow_tested_source=proposal['scanner']['revision'],current_tests_by_file=checks['tests_by_file'],per_file_test_counts_basis='Actualv41-full-suite-junit.xml at2e0efb2;2317passed36skipped.',full_sequence_status_basis='Original whole25 reuse and45+45 Linux gates retain actual1f3f72f. Python87observations at8c62567 remain source-compatible; changed TypeScript inputs need the proposed94-observation regression. No pooled whole-batch execution.',current_exposed_evaluation_approved=False,current_exposed_evaluation_executed=False,current_exposed_gate_passed=None,current_compatibility_passed=None,runner_preparation_final={'passed':True,'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'runner_sha256':sha(OUT/'evaluate.py'),'corpus_observations':0},final_verification_sha256=sha(OUT/'local-checks.json'),source_only_recovery_checkpoint=True,diagnostic_proposed_observations=0,diagnostic_approved=False,diagnostic_executed=False,diagnostic_passed=None,corrected_scanner_proposed_observations=94,corrected_scanner_evaluation_approved=False,corrected_scanner_evaluation_executed=False,current_fixed_guard_recognition_established=None,final_documentation_source_files={n:sha(ROOT/n) for n in oldbinding['owning_docs_sha256']})
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==115
assert p['dispositions']=={'passed':77,'unresolved':10,'explicitly user-deferred':2};assert p['additional_scope_dispositions']=={'passed':108,'proposed documented limitation awaiting decision':5,'unresolved':2}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in p['current_source_and_test_files']}
p['references_sha256'].update({str((OUT/n).relative_to(ROOT)):sha(OUT/n) for n in ['diagnosis.json','local-checks.json','evaluation-proposal.json','summary.md','source-proof.json','python-reuse-execution-binding.json']})
with (OUT/'audit.json').open('x') as f:json.dump(p,f,indent=2);f.write('\n')
print('89+115rows reconciled; source correction verified, TypeScript regression unapproved.')
