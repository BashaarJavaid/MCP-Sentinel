"""Retain every requirement and correct the failed diagnostic preparation claim."""
import copy,hashlib,json,os
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3];OLD=BASE/'v49-allocation-regression'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
a=read(OUT/'assessment.json');old=read(OLD/'audit.json');rows=copy.deepcopy(old['additional_scope_requirements'])
assert a['profile_attempts']==1 and a['valid_current_source_profiles']==0 and a['budget_closed']
for row in rows:
    if row['id']=='V49-DELIVERY':
        row['previous_row']=copy.deepcopy(row);row.update(disposition='passed',evidence=['artifacts/phase22/integration/v49-allocation-regression/delivery-verification.json'],assessment='Exact2933d39draft readback passed. This does not validate the stale sampler import binding.')
    if row['id']=='V49-DIAGNOSTIC-PREPARATION':
        row['previous_row']=copy.deepcopy(row);row.update(disposition='unresolved',evidence=['artifacts/phase22/integration/v50-faf-allocation-sampling/assessment.json','artifacts/phase22/integration/v50-faf-allocation-sampling/source-correction.json'],assessment='The historical hash/synthetic checks passed but failed to establish the actual subprocess scanner identity. The proposed sampler retained17b4784instead of6e4fd67. The invalid interrupted attempt is closed. Corrected identity checks are prepared; current-source profile execution requires a new decision. Historical preparation is not silently relabeled as sound.')
new=[('V50-AUTH','Bind the actual single-profile user approval and preserve its exact stale sampler bytes','passed',['../v49-allocation-regression/diagnostic-authorization.json','assessment.json']),('V50-STOP','Stop the invalid attempt, preserve all output and close its one-use budget','passed',['assessment.json','budget-closed.json','owned-work.json']),('V50-SOURCE','Correct the diagnostic import binding and reject a wrong-root counterexample before sampling or target snapshot access','passed',['source-correction.json','sampler-selfcheck/packet.json']),('V50-PREPARATION','Prepare the corrected exact one-profile proposal with missing-approval checks and zero further input executions','passed',['diagnostic-proposal.json','../v50-diagnostic-boundary.json']),('V50-PROFILE-GATE','Obtain a valid current-source diagnostic or explicit disposition of the invalid profile attempt','unresolved',['assessment.json']),('V50-DELIVERY','Seal the invalid profile and corrected proposal; verify existing draft delivery','unresolved',[])]
for identity,requirement,disposition,evidence in new:rows.append({'id':identity,'requirement':requirement,'disposition':disposition,'evidence':[str((OUT/n).resolve().relative_to(ROOT)) for n in evidence],'assessment':'One invalid interrupted attempt; no report or worker sample snapshot; zero remaining. Corrected proposal unapproved; no performance, detection, compatibility or human acceptance inferred.'})
assert len(old['requirements'])==89 and len(rows)==170 and len({r['id'] for r in old['requirements']+rows})==259
audit=copy.deepcopy(old);audit['historical_v49_status_fields']={k:copy.deepcopy(v) for k,v in old.items() if k not in ['requirements','additional_scope_requirements'] and not k.startswith('historical_')}
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(),additional_scope_requirements=rows,additional_scope_dispositions=dict(Counter(r['disposition'] for r in rows)),prior_audit={'path':str((OLD/'audit.json').relative_to(ROOT)),'sha256':sha(OLD/'audit.json')},diagnostic_approved=True,diagnostic_executed=True,diagnostic_attempts=1,diagnostic_completed_inputs=0,diagnostic_budget_closed=True,diagnostic_remaining=0,valid_current_source_profiles=0,current_diagnostic_prepared=True,current_diagnostic_approved=False,current_diagnostic_executed=False,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,new_paid_calls=0,status='Approved profile stopped on discovery of stale worker import root; invalid interrupted attempt, no report or snapshot, budget closed. Diagnostic-only correction and wrong-root guard verified; new single300-second profile prepared but unapproved/unexecuted. No scanner optimization or corpus retry.')
audit['current_evidence']={n:sha(OUT/n) for n in ['assessment.json','source-correction.json','sampler-selfcheck/packet.json','diagnostic-proposal.json','owned-work.json']}
write('audit.json',audit)
write('prior-row-preservation.json',{'prior_audit_sha256':sha(OLD/'audit.json'),'retained_prior_rows':253,'updated_rows':['V49-DELIVERY','V49-DIAGNOSTIC-PREPARATION'],'rows':{r['id']:hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']}})
summary=f'''# Invalid profile stopped; corrected worker binding prepared

**The single approved profile was stopped after discovering a stale sampler import root. One invalid interrupted attempt, no report or worker sample snapshot, zero remaining budget. Phase 22 remains incomplete.**

The exact `approved` decision binds the [proposal and authorization](../v49-allocation-regression/diagnostic-authorization.json) delivered at `2933d39`. The parent harness used frozen `6e4fd67`, but the reused sampler still inserted `/private/tmp/mcp-phase22-frozen-17b4784` into its worker import path. This was an agent preparation error. Parent scanner hashes and file-hash validation did not establish subprocess import identity; the synthetic check omitted that assertion. The prior V49-DIAGNOSTIC-PREPARATION pass is explicitly corrected to unresolved with its full previous row retained.

The owned supervisor received SIGTERM immediately after discovery. Its existing finally block reaped owned children, and the diagnostic finally closed the budget. The subsequent [process/container inventory](owned-work.json) is empty. The harness retained `incomplete`, `reason: null` and **27,097 ms** within its narrower interval. SystemExit bypassed the post-supervise execution receipt, so **no exact whole-input or cleanup duration is available**. This was an intentional identity-failure stop, not a measured 300-second timeout. No worker startup receipt or sample exists, so actual worker progress is unknown. Findings, warnings, coverage, vulnerable detection and negative discrimination remain unknown. [Assessment](assessment.json) preserves the original sampler, commands, log, configuration and source-bound parent result.

The [diagnostic-only correction](source-correction.json) sets the intended frozen root and checks actual worker/flow module paths plus full revision/source/harness identity **before timer setup or target snapshot deserialization**. Parent preflight runs that check in an isolated subprocess before consuming a launch token. Each real worker would retain its own startup identity receipt. A deliberately stale-root counterexample is rejected; six synthetic vectors retain equal values and unchanged scanner methods, valid sample/frame accounting and restored signal/timer state. The [synthetic check](sampler-selfcheck/packet.json) and missing-approval boundary pass with **zero additional input executions**. Product source is unchanged; no optimization occurred.

The [new exact proposal](diagnostic-proposal.json), SHA-256 `{sha(OUT/'diagnostic-proposal.json')}`, is **unapproved and unexecuted**. It requests one FAF vulnerable rules-only input at frozen `6e4fd67`: 120-second target, **300-second whole-input maximum**, 15-second cleanup, 100 Hz CPU sampling per worker and 15-second partial snapshots. Identity-check overhead remains inside that same limit. Bounds are **zero retries, optimization attempts, comparators, paid calls, target execution or resource/deadline changes**. This is a new one-use budget, never a reopening of the invalid attempt or the 204 closed native observations. Missing or mismatched worker receipts invalidate attribution. Sampling/GIL/native-code bias, unsampled parent stages, snapshot overhead and partial coverage remain limitations; no sample share promises a speedup.

The prior native regression at `6e4fd67` remains one FAF timeout at 300.004111 seconds, no report and 204 unstarted closed; its cleanup passed. The earlier `17b4784` native timeout and v47 sampled timeout with four partial snapshots remain unchanged. The allocation candidate retains 10,944 equal synthetic cases and its measured synthetic allocation accounting, but no native completion or speedup. Engineering remains **2,384 tests / 36 skips locally and in all 12 hosted suites**, 29 normal CI jobs and docs passed in [34743452798](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452798) / [34743452818](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452818). Combined statement/branch coverage is 89.98%, branch-only 85.85%. All 302 engineering files, six zero-call production replays, owned Docker fixture result and Git image/runtime bindings retain tested `6e4fd67`; docs/package verification is separate from hosted code tests. Restored files and the verified 3.704 GiB Docker cleanup remain preserved.

The [audit](audit.json) retains all **259 requirements: 89 original and 170 added**. Original dispositions remain 84 passed, two user-deferred, two proposed limitations and one human-acceptance unresolved. Six historical closure proposals remain unaccepted. All four first-frozen repository gates at `2e0efb2` still fail; subsequent corrections are exposed. Prior TS94 at `2e0efb2`, Python87 at `8c62567`, whole development25 reuse and historical45+45 at `1f3f72f` retain their actual source bindings and Meta operator erratum. Original memory-keeper false alerts, DDG's unsupported fixed send and wrong TypeScript metadata despite actual Python configuration, Lighthouse misses, and held-out10 completed/10 unsupported/5 incomplete with zero hits among four completed vulnerable out of ten vulnerable total remain unchanged. Same-agent review is not independent human validation, broad accuracy, training novelty or runtime safety proof.

Git stays **312/1,040 incomplete**, 728 deferred. Paid benchmark and pilots remain deferred, Phase 21 incomplete and Phase 24/15 unchanged. Explicit human technical acceptance and verified final closeout remain pending. No merge, ready-state, release, outreach or Phase 23 is authorized.
'''
with (OUT/'summary.md').open('x') as f:f.write(summary)
url='https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/'
body=summary.replace('(../v49-allocation-regression/','('+url+'v49-allocation-regression/')
for name in ['owned-work.json','assessment.json','source-correction.json','sampler-selfcheck/packet.json','diagnostic-proposal.json','audit.json']:body=body.replace('('+name+')','('+url+'v50-faf-allocation-sampling/'+name+')')
with (OUT/'pr-body.md').open('x') as f:f.write(body)
docs=list(read(OLD/'documentation-binding.json')['owning_docs_sha256']);assert len(docs)==16
for name in docs:
    path=ROOT/name;text=path.read_text().replace('## Current v49','## Historical v49',1);first,rest=text.split('\n',1)
    link=url+'v50-faf-allocation-sampling/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md',path.parent)
    status=f'''## Current v50 profile binding failure: stopped and closed

The approved single profile was deliberately stopped when the reused sampler's
worker import root was found to be `17b4784` instead of approved `6e4fd67`.
**One invalid interrupted attempt, no report or sample snapshot, zero remaining.**
Cleanup inventory is empty. Parent identity does not prove worker identity;
V49-DIAGNOSTIC-PREPARATION is corrected to unresolved with its prior row preserved.
The [review packet]({link}) retains this agent preparation error and the diagnostic-only
correction: actual worker/flow imports and full scanner identity checked before
sampling or target snapshot access, with a stale-root rejection control.
A new **single 300-second profile is unapproved and unexecuted**; no retry,
optimization or paid call is authorized. Prior native timeouts and all four
first-frozen failures remain unchanged. Product retains tested `6e4fd67`:
2,384 tests / 36 skips locally and in all 12 hosted suites; 29 normal jobs and
docs passed, combined coverage 89.98%, branch-only 85.85%. All 259 requirements
remain. **Phase 22 is incomplete**; human acceptance is separate. Git stays
312/1,040 incomplete; paid benchmark/pilots deferred, Phase 21 incomplete and
Phase 24/15 unchanged. No merge, ready-state, release, outreach or Phase 23.

'''
    path.write_text(first+'\n\n'+status+rest)
write('owning-docs.json',{'sha256':{name:sha(ROOT/name) for name in docs}})
print('Retained259requirements; corrected stale preparation claim; updated16owning docs. No new input execution.')
