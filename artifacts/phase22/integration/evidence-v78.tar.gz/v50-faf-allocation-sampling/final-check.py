"""Verify closed invalid attempt, corrected diagnostic guards and unchanged product."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v49-allocation-regression'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
checks=['v50-owned-cleanup','v50-corrected-sampler-check','v50-assessment-preparation','v50-diagnostic-boundary','v50-reconciliation','v50-final-docs','v50-final-build','v50-final-distributions']
for n in checks:assert read(BASE/(n+'.json'))['exit_code']==0,n
engineering=read(BASE/'v48-merge-allocation/local-checks.json')['candidate_engineering_files_sha256'];assert len(engineering)==302
for n,d in engineering.items():assert sha(ROOT/n)==sha(Path('/private/tmp/mcp-phase22-frozen-6e4fd67')/n)==d,n
binding=read(OLD/'documentation-binding.json')
for n,d in binding['user_files_sha256'].items():assert sha(ROOT/n)==d,n
for n,d in read(OUT/'owning-docs.json')['sha256'].items():assert sha(ROOT/n)==d,n
prior=read(BASE/'v45-four-source-recovery/prior-row-preservation.json')['referenced_evidence_sha256']
for n,d in prior.items():assert sha(ROOT/n)==d,n
proposal=read(OUT/'diagnostic-proposal.json')
for n,d in proposal['files_sha256'].items():assert sha(ROOT/n)==d,n
assert proposal['bounds']['total_input_executions']==1 and proposal['bounds']['optimization_attempts']==0 and proposal['bounds']['retries']==0
assert not (OUT/'diagnostic-authorization.json').exists() and not (OUT/'diagnostic-consumed.json').exists() and not (BASE/'v51-faf-bound-sampling').exists()
a=read(OUT/'assessment.json');assert a['budget_closed'] and a['remaining']==0 and a['sample_snapshots']==0 and not a['profile_gate_passed']
audit=read(OUT/'audit.json');assert audit['requirements']==read(OLD/'audit.json')['requirements'] and len(audit['additional_scope_requirements'])==170
assert next(r for r in audit['additional_scope_requirements'] if r['id']=='V49-DIAGNOSTIC-PREPARATION')['disposition']=='unresolved'
assert not audit['technical_acceptance_received'] and not audit['phase22_complete']
assert read(OUT/'final-distributions.json')['wheel_product_schema_fixture_members_byte_identical_to_hosted']
assert not subprocess.check_output(['git','diff','6e4fd67','--','src','tests','scripts','schemas','.github','uv.lock','pyproject.toml','CHANGELOG.md'])
subprocess.run(['git','diff','--check'],check=True)
subprocess.run(['git','merge-base','--is-ancestor','8b6b0ddf1d6f6cf5a8da3ab9421471865b801455','HEAD'],check=True)
main=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel');assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=main,text=True).strip()=='4cd57593b2585b9ee05c0f175930e6a0d76d362a';assert not subprocess.check_output(['git','status','--porcelain'],cwd=main)
write('check-failure-assessment.json',{'profile_failure':'Stale worker import root in agent-authored sampler. Parent/preflight hash checks passed but did not prove worker identity; deliberately stopped and invalidated. Full failure source assessment retained.','scanner_product_failure_observed':False,'ordinary_checks':'All new correction, synthetic rejection, missing-approval, docs and package checks passed. The wrong-root subprocess failure is an expected negative control.','profile_retries':0,'paid_calls':0})
write('command-provenance.json',{'wrapper_commands':{n:read(BASE/(n+'.json')) for n in checks},'direct_commands':[{'command':['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(OLD/'authorize-diagnostic.py')],'exit_code':0,'evidence':'v49-allocation-regression/diagnostic-preflight.json'},{'command':['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(OLD/'diagnostic.py')],'exit_code':1,'console':'supervisor termination','evidence':'v50-faf-allocation-sampling/assessment.json'},{'action':'Selected the sole owned parent whose command ended in the exact diagnostic.py path and sent SIGTERM to PID82270; existing supervisor finally performed cleanup.','exit_code':0}],'failure_assessment_sha256':sha(OUT/'check-failure-assessment.json'),'paid_calls':0})
write('final-checks.json',{'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':proposal['scanner'],'engineering_files_verified':302,'prior_evidence_files_verified':len(prior),'requirements':259,'protected_user_files':8,'owning_docs':16,'main_and_parent_preserved':True,'checks_sha256':{n:sha(BASE/(n+'.json')) for n in checks},'diagnostic_proposal_sha256':sha(OUT/'diagnostic-proposal.json'),'invalid_profile_attempts':1,'valid_current_source_profiles':0,'corrected_profile_executions':0,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False})
print('Final checks pass:259requirements,302unchanged engineering files,invalid attempt closed,corrected profile unexecuted.')
