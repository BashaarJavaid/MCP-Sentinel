import json, traceback
from pathlib import Path
from sentinel.static.rules.sent015 import TypeScriptURLFlow as Flow
from sentinel.static.typescript_path_flow import TypeScriptPathFlow
OUT=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v13-searxng-fixed-trace')
stream=(OUT/'events.jsonl').open('x')
originals={name:getattr(Flow,name) for name in ['function','invalidate','call','exit_facts','member']}
def facts(env):return sorted(k for k,v in env.items() if k.startswith('#guard:') and v.contained)
def val(v):return {'key':v.key,'sources':sorted(v.sources),'url_checks':sorted(v.url_checks)}
def emit(kind,**data):stream.write(json.dumps({'kind':kind,**data},default=str)+'\n');stream.flush()
def loc(self,file,node):
 r=self.program.source_range(node,file);return f'{file.relative_path}:{r.start_line}'
def function(self,symbol,args,captured=None):
 site=loc(self,symbol.file,symbol.node)
 emit('enter',site=site,args=[val(v) for v in args],facts=facts(captured or {}))
 try:
  result=originals['function'](self,symbol,args,captured)
  emit('exit',site=site,result=val(result),condition=self.conditions.get(result.key),effects=self.function_effects)
  return result
 except BaseException as e:emit('error',site=site,error=repr(e));raise
def invalidate(self,value):
 if value.key not in self.invalidated_objects:
  emit('invalidate',value=val(value),process=value.key==self.process.key,environment=value.key==self.environment.key,stack=traceback.format_stack(limit=7))
 return originals['invalidate'](self,value)
def call(self,file,node,env):
 before=facts(env);result=originals['call'](self,file,node,env);after=facts(env)
 if before!=after or file.relative_path.endswith(('http-security.ts','url-reader.ts')):
  emit('call',site=loc(self,file,node),text=self.program.text(file,node)[:300],before=before,after=after,result=val(result),condition=self.conditions.get(result.key))
 return result
def exit_facts(self,exits):
 result=originals['exit_facts'](self,exits)
 if any(facts(e) for e in exits):emit('exit_facts',branches=[facts(e) for e in exits],result=result)
 return result
def member(self,value,name,env):
 result=originals['member'](self,value,name,env)
 if value.key in {self.process.key,self.environment.key}:emit('environment_member',parent=val(value),name=name,result=val(result),invalidated=sorted(self.invalidated_objects & {self.process.key,self.environment.key}))
 return result
for name in originals:setattr(Flow,name,globals()[name])
