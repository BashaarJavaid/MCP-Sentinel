import sys,os,json,runpy,time,hashlib
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root),str(root/'src')]
for k in list(os.environ):
 if k.startswith(('OPENAI_','SENTINEL_')):os.environ.pop(k)
from scripts.phase22_corpus import frozen
from scripts.phase20_measurements import measure,scanner_identity
from sentinel.static import workers
from sentinel.llm.semantic_reviewer import OpenAITransport
async def forbidden(*a,**kw):raise AssertionError('paid calls forbidden')
OpenAITransport.create=forbidden
out=root/'artifacts/phase22/integration/v13-searxng-fixed-trace';out.mkdir()
identity=scanner_identity();receipt=root/'artifacts/phase22/integration/v13-continuation-authorization.json'
assert identity==json.loads(receipt.read_text())['starting_scanner']
approval=root/'artifacts/phase22/corpus-replacement-v3/authorization-7555a9d.json';m=frozen(approval_path=approval);selected=[i for i in m.inputs if i.id=='searxng-default-loopback-fixed'];assert len(selected)==1
(out/'attempt.json').write_text(json.dumps({'input_id':selected[0].id,'attempt':1,'kind':'instrumented_native','deadline_seconds':120,'authorization_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'scanner':identity,'paid_calls':0,'target_execution':False},indent=2)+'\n')
# Both entry routes keep production discovery, dispatch, values and effects unchanged.
# Native worker selection is unchanged; only SENT-015 emits identity/fact events.
workers.WORKER=Path('/private/tmp/phase22-v13-trace-worker.py')
# The source exceeds the native worker threshold. Do not install duplicate parent hooks.
start=time.monotonic()
result=measure(m.model_copy(update={'inputs':selected}),'rules',out/'measurement',phase22_approval=approval)
(out/'execution.json').write_text(json.dumps({'wall_seconds':time.monotonic()-start,'outcomes':result['outcomes'],'scanner_after':scanner_identity()},indent=2)+'\n')
print(result['outcomes'])
