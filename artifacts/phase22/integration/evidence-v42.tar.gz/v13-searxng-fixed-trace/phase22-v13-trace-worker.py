import sys,runpy
sys.path[:0]=['/private/tmp/mcp-phase22-options/src','/private/tmp/mcp-phase22-options']
if sys.argv[-1]=='SENT-015':runpy.run_path('/private/tmp/phase22-v13-trace-hooks.py')
from sentinel.static import workers
workers._worker()
