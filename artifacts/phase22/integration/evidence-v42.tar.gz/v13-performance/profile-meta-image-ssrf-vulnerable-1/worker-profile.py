"""Counter-only diagnostic; production replacement always executes unchanged."""
import collections, json, sys, threading
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root/'src'),str(root)]
from sentinel.static import workers,path_flow
from sentinel.static.rules import sent015,sent016
out=Path(__file__).resolve().parent
counts=collections.Counter();stop=threading.Event();original=path_flow.replace

def counted(value, /, **changes):
 if isinstance(value,path_flow.Value):
  frame=sys._getframe(1);key=(Path(frame.f_code.co_filename).name,frame.f_code.co_name,frame.f_lineno,','.join(sorted(changes)))
  counts[(*key,'calls')]+=1
  if all(getattr(value,k)==v for k,v in changes.items()):counts[(*key,'no_op')]+=1
 return original(value,**changes)
for module in (path_flow,sent015,sent016):module.replace=counted

def snapshot():
 rows={}
 for (*site,kind),count in list(counts.items()):
  key=tuple(site);rows.setdefault(key,{'file':site[0],'function':site[1],'line':site[2],'fields':site[3],'calls':0,'no_op':0})[kind]=count
 (out/(sys.argv[-1]+'-replacement-counts.json')).write_text(json.dumps(sorted(rows.values(),key=lambda r:r['no_op'],reverse=True),indent=2)+'\n')
def snapshots():
 while not stop.wait(15):snapshot()
thread=threading.Thread(target=snapshots,daemon=True);thread.start()
try:workers._worker()
finally:stop.set();thread.join();snapshot()
