"""Launch the exact approved evaluator once, retaining preflight and actual exit."""
import hashlib,json,os,platform,subprocess,sys,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/private/tmp/mcp-phase22-options');OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v39-fresh-v7'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
p=json.loads((ASSETS/'evaluation-proposal.json').read_text());a=json.loads((ASSETS/'evaluation-authorization.json').read_text());frozen=Path(p['frozen_checkout'])
assert a['approved'] and a['user_decision']=='approved' and a['proposal_sha256']==sha(ASSETS/'evaluation-proposal.json')
assert not (ASSETS/'execution-consumed.json').exists() and not (OUT/'raw').exists()
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()=='de7cb94c3a115e1da9e6a360f55b7bc616361359'
assert not subprocess.check_output(['git','diff','HEAD'],cwd=ROOT)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=frozen,text=True).strip()==p['scanner']['revision']
stage=json.loads((ASSETS/'staging-verification.json').read_text())
assert not subprocess.check_output(['git','diff','HEAD'],cwd=frozen)
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=frozen,text=True).splitlines())==set(stage['existing_untracked_files_sha256'])
for n,d in stage['staged_files_sha256'].items():assert sha(frozen/n)==d,n
protected=json.loads((ASSETS/'documentation-binding.json').read_text())['user_files_sha256']
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())==set(protected)
for n,d in protected.items():assert sha(ROOT/n)==d,n
rows={}
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines():
 parts=line.strip().split(None,2)
 if len(parts)==3:rows[int(parts[0])]={'parent':int(parts[1]),'command':parts[2]}
ancestors=set();pid=os.getpid()
while pid in rows and pid not in ancestors:ancestors.add(pid);pid=rows[pid]['parent']
markers=['v40-fresh-v7/', 'v39-fresh-v7/', 'v38-guard-regression/', 'v37-ddg-trace/', 'v36-guard-recovery/', 'phase22-check.py','v34-import-binding/','v34-fixed-coverage-final/','v35-ddg-regression/']
owned=[{'pid':pid,**r} for pid,r in rows.items() if pid not in ancestors and any(m in r['command'] for m in markers)]
containers=subprocess.check_output(['docker','ps','-aq','--filter','label=com.securemcp.sentinel=true'],text=True).splitlines()
named=subprocess.check_output(['docker','ps','-aq','--filter','name=sentinel'],text=True).splitlines()
assert not owned and not containers and not named,(owned,containers,named)
env={k:v for k,v in os.environ.items() if not k.startswith(('OPENAI_','SENTINEL_'))}
env['PATH']='/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin:'+env['PATH']
code="import sys,runpy;from pathlib import Path;sys.path[:0]=[str(Path.cwd()/'src'),str(Path.cwd())];m=runpy.run_path(sys.argv[1]);m['check_identity']();print('Exact frozen source, configuration and approval identities verified; zero scans.')"
pre=subprocess.run([sys.executable,'-I','-c',code,str(ASSETS/'runner.py')],cwd=frozen,env=env,capture_output=True,text=True)
(OUT/'source-preflight.log').write_text(pre.stdout+pre.stderr);assert pre.returncode==0,pre.stderr
stat=os.statvfs(OUT)
write('preflight.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'approval_sha256':sha(ASSETS/'evaluation-authorization.json'),'python':sys.version,'platform':platform.platform(),'cpu_count':os.cpu_count(),'topology':subprocess.check_output(['sysctl','hw.physicalcpu','hw.logicalcpu','hw.memsize'],text=True),'load_average':os.getloadavg(),'memory':subprocess.check_output(['vm_stat'],text=True),'disk_free_bytes':stat.f_bavail*stat.f_frsize,'owned_processes':owned,'owned_containers':containers,'named_containers':named,'source_preflight_exit':pre.returncode,'source_preflight_log_sha256':sha(OUT/'source-preflight.log'),'protected_user_files_sha256':protected,'corpus_observations':0,'paid_calls':0})
command=[sys.executable,'-I',str(ASSETS/'runner.py'),'run',str(OUT/'raw')]
write('launch.json',{'command':command,'cwd':str(frozen),'started_at':datetime.now(timezone.utc).isoformat(),'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'approval_sha256':sha(ASSETS/'evaluation-authorization.json'),'credentials_removed':True,'preflight_sha256':sha(OUT/'preflight.json'),'launch_helper_sha256':sha(Path(__file__))})
start=time.monotonic()
with (OUT/'execution.log').open('x') as log:
 result=subprocess.run(command,cwd=frozen,env=env,stdout=log,stderr=subprocess.STDOUT)
write('exit.json',{'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'completed_at':datetime.now(timezone.utc).isoformat(),'log_sha256':sha(OUT/'execution.log'),'qualification':'Actual single invocation result; no retry or inferred detection pass.'})
print('Approved sequence exited',result.returncode,flush=True)
sys.exit(result.returncode)
