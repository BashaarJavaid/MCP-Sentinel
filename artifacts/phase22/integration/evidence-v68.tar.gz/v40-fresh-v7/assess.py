"""Validate and source-adjudicate the immutable first-frozen v7 outputs."""
import hashlib,importlib.util,json,os,re
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
from scripts.phase22_corpus import frozen,input_files
from scripts.phase20_scoring import candidate_identity,score,metrics
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v39-fresh-v7';RAW=OUT/'raw'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
spec=importlib.util.spec_from_file_location('v7_runner',ASSETS/'runner.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
p=runner.verify_packet();os.chdir(p['frozen_checkout']);runner.approved();os.chdir(ROOT)
packet=read(RAW/'packet.json');end=read(OUT/'exit.json');inventory=read(OUT/'inventory.json');configs=read(ROOT/p['configuration']['path'])
assert end['exit_code']==0 and end['elapsed_seconds']<2400 and end['log_sha256']==sha(OUT/'execution.log')
assert packet['budget_closed'] and packet['passed'] and packet['execution_gate_passed'] and len(packet['attempts'])==6 and packet['unstarted']==[]
assert packet['model_calls']==0 and not packet['target_execution']
assert packet['scanner']==p['scanner'] and packet['runner_revision']=='de7cb94c3a115e1da9e6a360f55b7bc616361359'
assert packet['proposal_sha256']==sha(ASSETS/'evaluation-proposal.json') and packet['approval_sha256']==sha(ASSETS/'evaluation-authorization.json') and packet['binding_sha256']==sha(ASSETS/'binding.json')
for n,d in packet['files_sha256'].items():assert sha(RAW/n)==d,n
manifest=frozen(approval_path=ASSETS/'evaluation-authorization.json');snap={s.revision:s for s in manifest.snapshots};inputs={i.id:i for i in manifest.inputs if i.id in p['input_order']}
source={i.snapshot:input_files(i,snap[i.snapshot],ROOT) for i in inputs.values()}
assert [(a['batch'],a['input_id']) for a in packet['attempts']]==[(b,i) for b in p['batch_order'] for i in p['input_order']]
assert len(inventory['rows'])==6
contexts=inventory['contexts'];context_assessment={}
for key,c in contexts.items():
 path=c['path'];data=source[c['snapshot']][path];assert hashlib.sha256(data).hexdigest()==c['source_sha256'];lines=data.decode().splitlines()
 test='/__tests__/' in path or '/test-helpers/' in path
 if 'binding' in c:
  symbol=c['binding'];base=c['base_identifier'];occ=c['base_identifier_occurrence_lines'];assert occ and all(base in lines[n-1] for n in occ)
  if symbol=='tools/list metadata':explanation='ListToolsRequestSchema advertises allTools.filter(tool => enabledTools.has(tool.name)); runtime profile filtering prevents full static metadata/dispatch resolution. The source lists context_import, but the scanner surface remains unresolved.'
  elif symbol=='dynamic tool description':explanation='Tool-profile source stores tool-name arrays and dynamic profile data; the diagnostic is a metadata-resolution limit, not an identified malicious instruction. It does not negate the separate source-reviewed context_import registration.'
  elif test:explanation=f'The unresolved symbol {symbol!r} occurs in retained upstream test/helper source at the indexed base-identifier lines. Tests use Jest globals, mocks and server/database helpers. They were scanned as source but never executed; test binding uncertainty is not a production exploit or a passing regression result.'
  elif base in {'process','console','Buffer','Promise','Date','JSON','Math','Object','Array','Set','Map','Error','String','Number','RegExp','parseInt','parseFloat','isNaN','undefined'}:explanation=f'The unresolved {symbol!r} is a language/Node global or member at the indexed source occurrences. Source prerequisites assume ordinary Node startup; the report has not established this binding or its effects. In particular process.exit failure branches and operator environment roots must not be silently assumed understood by the detector.'
  else:explanation=f'The unresolved {symbol!r} is indexed to exact occurrences of its base identifier {base!r} in {path}. Imported helpers, local variables and instance/data members remain statically unresolved. These source bindings are retained as coverage limits; their calls/effects are not declared safe, malicious or executed from this warning alone.'
  context_assessment[key]={'source':c,'assessment':explanation,'disposition':'Retained source-bound binding/metadata limitation; no automatic suppression or safety conclusion.'}
 else:
  n=c['line'];text=lines[n-1];scope='module initialization, declarations or shared helper'
  if path=='src/index.ts':
   listing=next(i+1 for i,t in enumerate(lines) if 'setRequestHandler(ListToolsRequestSchema' in t)
   dispatch=next(i+1 for i,t in enumerate(lines) if 'setRequestHandler(CallToolRequestSchema' in t)
   cases=[(i+1,m.group(1)) for i,t in enumerate(lines[:min(n,listing-1)]) if (m:=re.match(r"    case '([^']+)':",t))]
   if n>=listing:scope='profile-filtered tool metadata and stdio startup'
   elif n>=dispatch:scope=cases[-1][1] if cases else 'CallToolRequestSchema profile gating/dispatch'
   elif 92<=n<=133 and 'resolveConfinedImportPath' in '\n'.join(lines[85:98]):scope='resolveConfinedImportPath'
  else:scope=path.removesuffix('.ts')+' shared implementation'
  if scope=='resolveConfinedImportPath':explanation='The fixed helper resolves against the canonical operator exports root, realpaths/stats the candidate, requires equality or separator-bounded containment, rejects nonregular/oversized files and returns the checked resolved path. Metadata calls precede boundary rejection; the scored operation is subsequent file-content reading. Unresolved stats and startup/root bindings remain genuine analysis limits; the scanner still reports the guarded read.'
  elif scope=='context_import':explanation='This is the scored import handler. Vulnerable source passes caller filePath directly to readFileSync at1724. Fixed source calls resolveConfinedImportPath at1837, returns on rejection, then reads safePath at1849. Later JSON/schema, database and response operations do not retroactively authorize an outside read. Source containment is established only under frozen ordinary-filesystem prerequisites; current fixed-path guard recognition fails.'
  elif scope=='context_export':explanation='Separate export handler selects an existing session, gathers database rows, constructs an export name from its first8identifier characters and writes it under tmpdir (vulnerable) or exportsDir (fixed). Its path alert is not the named import-read condition. Caller/session/database identity and filename assumptions need separate review; no additional exploit or broad export-safety proof is claimed.'
  elif scope=='context_git_commit':explanation='Separate Git commit tool obtains a stored session working_directory, stages dot and passes caller message as the first simple-git commit argument. The report treats this as an option-position concern; source alone does not establish the dependency argument expansion or a confirmed option exploit. This remains an unmatched unconfirmed candidate, outside import confinement; no Git command ran.'
  elif test:explanation='Retained upstream test source uses fixtures, Jest and controlled process/filesystem scaffolding. No upstream test, process or filesystem action was executed. A source warning here does not establish production behavior or successful runtime protection.'
  elif path.endswith('channels.ts'):explanation='Channel helpers transform Git-branch/session names using whitespace, character normalization and truncation. These operations name database channels; they are not the context_import file-content boundary. Their unresolved calls remain visible.'
  elif path.endswith('token-limits.ts'):explanation='Shared response/token-budget helpers estimate serialized sizes, validate configured limits and bound result counts. These operations do not enforce the import-directory boundary; unresolved data, callbacks and arithmetic remain coverage limitations.'
  elif 'repositories/' in path or any(path.endswith(x) for x in ['database.ts','migrations.ts','retention.ts','migrationHealthCheck.ts']):explanation='Source implements local SQLite repository, migration or retention state, including instance inheritance and prepared query calls. The scanner leaves the identified construct unresolved. Database semantics and cross-session authorization are not certified, and this is not an independent import-read condition finding.'
  elif scope.startswith('context_'):explanation=f'The exact statement belongs to the separate {scope} switch arm. Its model/helper/database, collection or response operation is retained as unresolved; it does not itself establish the named context_import read or its directory guard. Possible issues in this other tool remain unconfirmed rather than silently accepted as safe.'
  else:explanation=f'The exact source statement in {scope} concerns initialization, shared model/helper/SDK behavior or metadata. The scanner leaves its call, binding or control effect unresolved. No independent exploit, complete call graph or safety conclusion is inferred; the scored import flow is assessed separately.'
  context_assessment[key]={'source':c,'scope':scope,'statement':text,'assessment':explanation,'disposition':'Retained source-bound unresolved behavior or finding context; no target execution.'}
rows=[];findings=[];diagnostics=[];surfaces=[];first={}
for a,inv in zip(packet['attempts'],inventory['rows'],strict=True):
 assert a['input_id']==inv['input_id'];i=inputs[a['input_id']];folder=RAW/a['directory'];rp=folder/i.id/'report.json';report=read(rp);result=read(folder/'results.json');runner.completed(a['timing'])
 assert a['state']=='completed' and result['scanner']==p['scanner'] and result['outcomes']==[a['outcome']] and result['model_calls']==0 and result['requests']=={}
 assert result['manifest_sha256']==p['manifest']['sha256'] and result['authorization_sha256']==packet['approval_sha256']
 assert sha(rp)==inv['report_sha256']==a['outcome']['report_sha256'];assert sha(rp.parent/'configuration.json')==configs[i.id]['sha256']==a['outcome']['configuration_sha256']
 validate_report_data(report);validate_sarif_data(read(rp.with_suffix('.sarif')));assert report['analysisComplete'] and report['executionSuccessful']
 canonical=runner.supervisor.clean(report,runner.EXCLUDED)
 if a['batch']=='rules-first':first[i.id]=canonical
 else:assert canonical==first[i.id] and a['ordered_repeat_equal']
 matches=[]
 for frow in inv['findings']:
  f=frow['finding'];loc=f['location'];line=loc['range']['start_line'];path=loc['path'];matched=f['rule_id']=='SENT-012' and path=='src/index.ts' and line in {1724,1849}
  if matched:
   assert 'without enforced containment' in f['description'] and 'readFileSync' in f['evidence']['snippet'];matches.append(f['dedup_key'])
   if i.label=='vulnerable':
    assert line==1724 and f['dedup_key']=='6834debb7cb64c8be935c18e7775bcb8beb739ea63dcdd8de3837730f6d8a6fb';explanation='The registered CallToolRequestSchema handler takes request.params.arguments; context_import destructures filePath at1721 and directly reads it at1724. The report includes dispatch372 and the actual read, so the broad containment candidate includes the frozen sibling path. Surface dispatch remains unresolved, but source binds this exact tool/caller/read. Correct narrow candidate hit; not runtime proof.'
   else:
    assert line==1849 and f['dedup_key']=='95cec91e2517a516fa0ee4f72645dc7f7622de2f0a2028200a020b7b81b17581';explanation='Matching false alert on the named condition. Fixed helper92-132 rejects outside paths using canonical equality or exportsDirReal + path.sep prefix at116; handler1837 returns on any thrown rejection before read1849. For the safe control the input is inside exports. The finding nevertheless asserts no enforced containment at that actual read and does not qualify recognized fixed protection. It cannot be excluded merely because source is labeled fixed.'
  elif f['rule_id']=='SENT-012':
   assert path=='src/index.ts' and line in {1665,1766};explanation='Unmatched export-write suspicion, not the context_import read. Source context_export selects an existing session before interpolating its first8identifier characters in a filename. Fixed changes only the output root to exportsDir. No separate session-identity/filename exploit is established under this import-only condition; broader export behavior remains unconfirmed.'
  elif f['rule_id']=='SENT-014':
   assert path=='src/index.ts' and line in {1468,1569};explanation='Unmatched simple-git commit-message concern. Source passes message as the API first argument after git.add(dot); this is not an explicit raw argv array. Dependency command expansion is not proven by the retained server source, so option injection remains unconfirmed. No command was executed; the import condition does not score this alert.'
  else:
   assert f['rule_id']=='SENT-005' and path=='src/__tests__/e2e/import-path-confinement.test.ts' and line==36;explanation='Unmatched synthetic-secret false positive: the new upstream security test explicitly seeds a victim JSON fixture with an EXAMPLEKEY marker and tests its non-disclosure. This is retained test data, not evidence of a live exposed credential. The raw finding remains redacted; no credential was used and upstream tests were not run.'
  findings.append({'batch':a['batch'],'input_id':i.id,'report_sha256':sha(rp),'finding':f,'context':frow['source'],'matches_condition':matched,'assessment':explanation,'disposition':'Scored candidate hit' if matched and i.label=='vulnerable' else 'Scored matching negative false alert' if matched else 'Source-assessed unmatched candidate'})
 for d in inv['diagnostics']:
  assert d['source'] in context_assessment;diagnostics.append({'batch':a['batch'],'input_id':i.id,'report_sha256':sha(rp),**d,'assessment_context':d['source'],'disposition':'Retained coverage limitation; see exact indexed source and assessment.'})
 for index,s in enumerate(inv['coverage']['surfaces']):
  assert s['status']=='unresolved' and s['name'] is None and any(x['code']=='ambiguous_dispatch' for x in s['reasons']);surfaces.append({'batch':a['batch'],'input_id':i.id,'index':index,'surface':s,'source_sha256':hashlib.sha256(source[i.snapshot]['src/index.ts']).hexdigest(),'assessment':'Official SDK Server registers CallToolRequestSchema with switch(toolName), while ListToolsRequestSchema returns an allTools array filtered by enabledTools. Source includes context_import in full/standard profiles; detector retains one unnamed unresolved dispatch surface. Findings can bind the source-reviewed import flow, but complete named tool/schema/dispatch coverage is not established.'})
 adjudication={'candidate_identity':candidate_identity(report['findings']),'matches':matches,'rationale':'Every candidate individually adjudicated against exact source and frozen rubric. Fixed/control import-read assertions match the condition and count as false alarms; unresolved dispatch is reported separately.'}
 row={'batch':a['batch'],'input_id':i.id,'label':i.label,'snapshot':i.snapshot,'tree_sha256':i.tree_sha256,'report_sha256':sha(rp),'sarif_sha256':sha(rp.with_suffix('.sarif')),'outcome':a['outcome'],'native_seconds':a['native_seconds'],'whole_seconds':a['timing']['elapsed_seconds'],'timing_class':a['timing_class'],'timing':a['timing'],'ordered_repeat_equal':a.get('ordered_repeat_equal'),'finding_count':len(report['findings']),'warning_count':len(report['warnings']),'unresolved_flow_count':len(inv['coverage']['unresolved_flows']),'surface_count':len(inv['coverage']['surfaces']),'coverage':inv['coverage'],'rule_outcomes':report['static_analysis']['rule_outcomes'],'condition_assessment':adjudication}
 row.update(score(label=i.label,state='completed',findings=report['findings'],assessment=adjudication));rows.append(row)
ms={b:metrics([r for r in rows if r['batch']==b]) for b in p['batch_order']}
for b in ms:assert ms[b]['candidate']['completed_detections']==1 and ms[b]['false_alarm_conditions']==2 and ms[b]['states']=={'completed':3}
assert len(findings)==22 and len(surfaces)==6 and len(first)==3
write('source-context-assessment.json',{'contexts':context_assessment,'count':len(context_assessment),'unmapped':0,'qualification':'Every reported diagnostic is mapped to exact source bytes and concrete statement/base-identifier locations, with retained scope and unresolved effects. This is source adjudication of limitations, not execution, a complete dependency proof or a claim that the scanner resolved these symbols.'})
write('finding-source-assessment.json',{'rows':findings,'count':len(findings),'unassessed':0})
write('diagnostic-source-assessment.json',{'rows':diagnostics,'count':len(diagnostics),'by_kind':dict(Counter(d['kind'] for d in diagnostics)),'unmapped':0,'context_packet_sha256':sha(OUT/'source-context-assessment.json')})
write('surface-source-assessment.json',{'rows':surfaces,'count':len(surfaces),'unassessed':0,'total_possible_surfaces':'unknown in all6reports'})
write('assessment.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'execution_checks_passed':True,'source_assessment_complete':True,'fresh_detection_gate_passed':False,'vulnerable_detection_passed':True,'negative_discrimination_passed':False,'fixed_sink_supported':True,'fixed_guard_recognition_established':False,'named_dispatch_resolved':False,'limitation_accepted':False,'technical_acceptance_received':False,'phase22_complete':False,'scanner':packet['scanner'],'runner_revision':packet['runner_revision'],'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'authorization_sha256':sha(ASSETS/'evaluation-authorization.json'),'rubric_sha256':sha(ASSETS/'scoring-rubric.json'),'raw_packet_sha256':sha(RAW/'packet.json'),'launch_sha256':sha(OUT/'launch.json'),'exit_sha256':sha(OUT/'exit.json'),'budget':{'native_consumed':6,'comparator_consumed':0,'unstarted':0,'remaining':0,'closed':True,'dispatches':0,'paid_calls':0,'target_executions':0,'retries':0},'native_within120':sum(r['timing_class']=='completed_within_target' for r in rows),'native_extended':sum(r['timing_class']=='completed_using_extended_time' for r in rows),'max_whole_native_seconds':max(r['whole_seconds'] for r in rows),'max_native_seconds':max(r['native_seconds'] for r in rows),'sequence_seconds':end['elapsed_seconds'],'entire_ordered_repeat_equal':3,'batch_metrics':ms,'rows':rows,'finding_count':len(findings),'diagnostic_count':len(diagnostics),'surface_count':len(surfaces),'assessment_files_sha256':{n:sha(OUT/n) for n in ['source-context-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json']},'product_implication':'The first-frozen scanner detects the vulnerable import path in a previously unused repository but also flags the actual protected read on fixed and safe sources. It cannot reliably distinguish the fix under the prospectively frozen criterion. The fixed sink is supported; guard recognition and named dispatch remain unresolved. A correction requires a separate exposure/disposition decision; no miss/false alert is relabeled or accepted automatically.','source_exposure':'One project-unused repository and one narrow vulnerability, source curated and adjudicated by the same agent after8c62567freeze. Repeats are not independent discoveries. No training-data novelty, independent human review, runtime proof or broad accuracy claim.'})
print('All6 complete; vulnerable1/1per batch; matching false alerts2/2negatives per batch;3wholeorderedrepeats. Detection/discrimination gate FAILS.')
