"""Reconcile the completed failed-discrimination result without accepting or tuning it."""
import copy,hashlib,json,subprocess
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ASSETS=BASE/'v39-fresh-v7'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
a=read(OUT/'assessment.json');assert a['execution_checks_passed'] and a['source_assessment_complete'] and not a['fresh_detection_gate_passed']
b=read(ASSETS/'documentation-binding.json');assert not subprocess.check_output(['git','diff','8c62567','--',*b['byte_identical_quality_inputs']])
source_review={'scanner':a['scanner'],'observations':{'supported_fixed_sink':'SENT-012 emits at actual fixed readFileSync(safePath)1849, with canonical root and caller locations; this is not missing sink support.','actual_source_guard':'Fixed resolveConfinedImportPath92-132 uses realpath on root/candidate and equality OR separator-bounded prefix116; rejected paths throw and handler1837 catches/returns before1849.','unresolved_startup_and_dispatch':'Retained diagnostics cannot resolve process.exit and profile-filtered tool metadata; one unnamed ambiguous dispatch surface remains.','existing_model':'typescript_path_flow.py already models realpath, equality, separator prefixes, boolean facts, throw and try branches. Boundary facts require a canonical base; catch branches that are not modeled as terminal can merge unchecked initialization state.','hypothesis_not_execution_proof':'Investigate loss of the canonical root/guard across startup try/catch and process.exit, then boolean guard propagation and exact checked-return identity. Source review suggests these boundaries; no trace, synthetic reproduction or correction has run on the new source.'},'files_sha256':{n:sha(ROOT/n) for n in ['src/sentinel/static/typescript_path_flow.py','src/sentinel/static/typescript_registration_flow.py','src/sentinel/static/typescript_modules.py','src/sentinel/static/rules/sent012.py']},'native_observations_after_budget':0,'paid_calls':0}
write('scanner-source-review.json',source_review)
proposal={'recorded_at':datetime.now(timezone.utc).isoformat(),'status':'proposed_not_approved','decision_requested':'Approve one focused source-only correction cycle for the exposed TypeScript import-guard false positive, with synthetic security regressions and required engineering verification. Zero new corpus observations, profiles, comparator runs, target executions or paid calls. Prepare a new frozen exact exposed-regression proposal after the correction; do not execute it without its separate approval.','failed_gate':{'assessment_sha256':sha(OUT/'assessment.json'),'scanner':a['scanner'],'vulnerable_hits_per_batch':1,'matching_negative_alerts_per_batch':2,'batches':2,'first_frozen_result_retained':True,'limitation_accepted':False},'scope':['Reproduce the canonical-root/checked-return loss using minimal synthetic sources, including ordinary unshadowed Node termination and try/catch behavior where relevant.','Correct the shared cause only after the reproduction establishes it; preserve conservative handling of shadowed/rebound process or exit, unknown callbacks, ineffective prefix checks, caller-controlled roots, replaced values and other branches. Do not suppress this repository, rule, line, warning or broad source class.','Add meaningful positive/negative security regressions; run affected checks and all required current-source engineering, package/schema/docs/replay/hosted checks under existing zero-paid contracts. Retain failures and source identities.','Freeze the corrected source and prepare exact bounded exposed-regression/compatibility inputs and budgets. This source is now exposed; no future result may replace the8c62567 first-frozen outcome.','Keep unrelated export, Git-message and test-secret candidates visible. Their broader correction is outside this focused cycle; retain named-dispatch uncertainty unless directly addressed with proven safety controls.'], 'bounds':{'implementation_cycles':1,'corpus_native_observations':0,'comparator_observations':0,'profiles':0,'target_execution':False,'target_dependency_installation':False,'paid_calls':0,'new_repositories':0},'stop':'If focused synthetic proof cannot establish a safe shared correction, retain the unresolved failure and deliver the source diagnosis. No speculative repeated optimization, live trace, corpus retry, deadline change or new-source replacement.','technical_acceptance':False,'phase22_complete':False,'source_review_sha256':sha(OUT/'scanner-source-review.json')}
write('recovery-proposal.json',proposal)
text=f'''The approved additional fresh-repository evaluation **completed all six
observations**, but **fails fixed/control discrimination** at frozen scanner
**`8c62567`**. In each three-input batch, Sentinel detects the **one vulnerable
`context_import` file read**, and also emits **matching false alerts on both
negative inputs** (fixed and safe). All **three entire ordered report repeats
agree** after only the established 11 volatile exclusions. This demonstrates
first-frozen vulnerable detection on another project-unused repository, but it
is not a passing vulnerable/fixed discrimination result.

All six inputs completed within the **120-second target**. Maximum native time
was **{a['max_native_seconds']:.3f} seconds**; maximum whole-input time was
**{a['max_whole_native_seconds']:.6f} seconds**, below the uniform **300-second maximum**.
The single serial macOS sequence took **{a['sequence_seconds']:.3f} seconds**.
Native JSON/SARIF, source/configuration identities and process cleanup validate.
The **six-observation budget is closed**, with zero unused observations, retries,
profiles, comparators, target executions or paid calls.

The repository is **`mkreyman/mcp-memory-keeper`**: complete vulnerable
**`dd53a8f` (0.12.2)** and fixed **`84f6dfa` (0.13.0)** upstream trees, the latter
compared against its direct first parent. It was selected only after `8c62567`
freeze and is absent from all eight earlier corpus manifests and 100 unique
prior effective trees. The same implementation agent curated and assessed it;
this is one repository and one vulnerability, not independent human review,
training-data novelty or six independent discoveries. The 45 old manifest records
and two format-required mutation records were not evaluated.

The vulnerable source directly reads caller `filePath` at `src/index.ts:1724`.
The fixed source calls `resolveConfinedImportPath`, checks canonical equality or
`exportsDirReal + path.sep` containment, returns on rejection, then reads the checked
`safePath` at line 1849. The frozen sibling `exports-backup` path is rejected before
reading; the safe control lies inside `exports`. Sentinel supports the actual
fixed read but still asserts missing containment. **Fixed guard recognition fails**;
this is a matching false positive, not an unsupported-sink silence. All six reports
also retain one unnamed **unresolved MCP dispatch surface**, so complete named
metadata/dispatch coverage is not established. No runtime protection proof is claimed.

All **22 findings**, **{a['diagnostic_count']:,} warning/unresolved-flow occurrences** and
**six surfaces** are indexed to exact source evidence and assessed. Broader export
and Git-message candidates remain unmatched and unconfirmed; the added secret
finding is upstream test fixture data. The diagnostic assessment retains binding,
callback, class and metadata limitations without treating them as resolved or safe.
An initial inventory helper incorrectly treated a synthetic metadata diagnostic
label as a literal source token; its failure and corrected catalog binding are
preserved. No report, source, label, rubric or scanner changed, and no scan repeated.

The proposed next step is **one focused source-only correction cycle**, in
`artifacts/phase22/integration/v40-fresh-v7/recovery-proposal.json`: establish the
shared guard/root-state cause using synthetic controls, implement only a supported
fix, run required engineering checks, freeze the new source and prepare a separate
exact exposed-regression proposal. It authorizes no work until approved and requests
**zero new corpus scans, profiles, comparators, target executions or paid calls**.
The original result remains immutable; a later fix is exposed regression. Source
inspection suggests checking canonical-root propagation across startup try/catch
and termination, but no root-cause execution proof or repair has occurred.

Prior **87/87 exposed regression at `8c62567` remains passed**, with 36 whole
ordered repeats, DDG two vulnerable hits per batch, zero matching negatives and
six actual fixed/control sends carrying the narrow direct-route initial 100.64/10
qualification. Python development and both 31-input historical batches retain
actual passes. Original fresh DDG at `f85a90f` remains 10 native + five Semgrep,
two correlated native hits per batch, zero matching negatives, five ordered
repeats and Semgrep 0/2; its original fixed-coverage gap and later exposed fix
remain distinguished. Original Lighthouse misses, failed `a50e9b7` regression,
all closed experiments and the original held-out result (10 completed,
10 unsupported, five incomplete; 0/4 completed vulnerable hits out of 10 total
vulnerable inputs) remain unchanged.

Historical whole Linux timing retains `1f3f72f`: both whole 45-input batches pass
with 20 hits and zero matching alerts on 25 negatives each, and the whole 25-input
development batch is reused under the explicit amendment. Current Python and
compatible TypeScript subsets are not pooled into new whole-batch execution.
Product/tests/workflows remain identical to tested `8c62567`: local and all 12
hosted suites retain **2,283 passed / 36 skipped**, **89.91% local branch coverage**,
29 normal CI jobs and docs passed. Final status docs/package metadata are checked
separately; six zero-call production replays and runtime/image compatibility retain
source bindings. **Git campaigns stay incomplete at 312/1,040**, as requested.

The audit retains **89 original rows: 84 passed, two user-deferred, three unresolved
(R66/R88 for this failed fresh discrimination checkpoint, R84 for human acceptance)**.
All **112 added rows** remain: 106 passed, five proposed historical closure
limitations, one unresolved evaluation criterion. Passing execution/source
assessment does not turn the failed criterion into a pass. **Phase 22 remains
incomplete; technical acceptance is not requested.** The correction and any later
exact measurements need their recorded decisions. Paid benchmark and pilots stay
deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge, ready-state change,
release, outreach or Phase 23 is authorized.
'''
old='## Current v39 additional fresh-repository preparation checkpoint\n\n'+(ASSETS/'summary.md').read_text().split('\n\n',1)[1]+'\n'
new='## Current v40 fresh detection and failed discrimination checkpoint\n\n'+text+'\n'
for n,d in b['owning_docs_sha256'].items():
 path=ROOT/n;assert sha(path)==d,n;s=path.read_text()
 if n=='artifacts/phase22/corpus-replacement-v7/README.md':
  assert s=='# Replacement v7: memory-keeper source-only preparation\n\n'+(ASSETS/'summary.md').read_text().split('\n\n',1)[1];path.write_text('# Replacement v7: first-frozen evaluation result\n\n'+text)
 else:assert s.count(old)==1,n;path.write_text(s.replace(old,new))
path=BASE/'README.md';s=path.read_text().replace('batches 1–67','batches 1–68',1);start=s.index('Review the [new six-observation proposal]');end=s.index('\n',start);s=s[:start]+'Review the [first-frozen evaluation](v40-fresh-v7/assessment.json), [89 + 112 row audit](v40-fresh-v7/audit.json) and [unapproved focused correction proposal](v40-fresh-v7/recovery-proposal.json). Restore seal 68 after seals 1–67, verifying every archive/member hash. Vulnerable detection passes, fixed/control discrimination fails; technical acceptance remains pending.'+s[end:];path.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 fresh detection and failed discrimination\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: fresh vulnerable detection; fixed/control false positives\n\n'+text+'\nEvidence: `artifacts/phase22/integration/v40-fresh-v7/`, seal68 after all67 earlier seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303579\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303580\n')
p=copy.deepcopy(read(ASSETS/'audit.json'));common='Approvedv40 six-native first-frozen8c62567 evaluation completes with3whole ordered repeats; vulnerable1/1per batch detected, both negatives falsely alerted each batch. Fixed sink supported, guard and named dispatch unresolved. Budget closed; proposed source-only correction unapproved; no paid/target execution. Priorv38 and all historical evidence preserved.'
for r in p['requirements']:
 r['historical_v39_assessment']={k:r[k] for k in ['assessment','disposition','interpretation']};r['interpretation']=common
 if r['id'] in {'R66','R88'}:r['assessment']=common
 elif r['id']=='R84':r['assessment']='Technical acceptance is not ready or requested: fresh negative discrimination failed. User must explicitly dispose of the measured limitation/correction; no automatic waiver. Historical five closure proposals, paid/pilot deferrals and subsequent closeout requirements remain.'
 elif r['id'] in {'R62','R83'}:r['assessment']='Owning docs distinguish completed execution, successful fresh vulnerable detection, failed fixed/control discrimination, unresolved metadata and pending correction/acceptance. Historical passes/failures remain source-bound.'
for r in p['additional_scope_requirements']:
 if r['id']=='V39-EVALUATION':r['historical_v39_assessment']=r['assessment'];r['assessment']=common;r['evidence']+=['artifacts/phase22/integration/v40-fresh-v7/assessment.json']
for id,req in [('V40-EXECUTION','Execute the exact approved six-native first-frozen sequence with schema/identity/repeat/cleanup and closed budgets'),('V40-ASSESSMENT','Source-assess every result and retain first-frozen failure without tuning or accepting a limitation')]:p['additional_scope_requirements'].append({'id':id,'requirement':req,'disposition':'passed','assessment':common,'evidence':['artifacts/phase22/integration/v40-fresh-v7/'+n for n in ['assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json']]+['artifacts/phase22/integration/v39-fresh-v7/evaluation-authorization.json']})
p['prior_audit']={'path':'v39-fresh-v7/audit.json','sha256':sha(ASSETS/'audit.json')};p['historical_v39_status_fields']={k:p[k] for k in ['status','current_continuation_corpus_observations','fresh_evaluation_status_basis']}
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),status=common,current_source_corpus_runs=93,current_source_native_observations=93,current_continuation_corpus_observations=6,current_compatibility_observations_this_continuation=0,additional_fresh_evaluation_approved=True,additional_fresh_evaluation_executed=True,additional_fresh_evaluation_native_observations=6,additional_fresh_vulnerable_detection_passed=True,additional_fresh_negative_discrimination_passed=False,additional_fresh_fixed_guard_recognition_established=False,additional_fresh_named_dispatch_resolved=False,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,owning_document_binding='Finalv40 binding follows affected docs/package checks and seal68.',fresh_evaluation_status_basis=common,current_source_observation_interpretation='93 total actual8c62567 observations: prior87exposed regression plus current6first-frozenv7. These are separate scopes, not a new pooled batch. Prior current_fixed_guard_recognition_established refers only to passed DDG scope; v7fixed guard fails.')
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==112
assert p['dispositions']=={'passed':84,'unresolved':3,'explicitly user-deferred':2};assert p['additional_scope_dispositions']=={'passed':106,'proposed documented limitation awaiting decision':5,'unresolved':1}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in p['current_source_and_test_files']}
p['references_sha256'].update({str((OUT/n).relative_to(ROOT)):sha(OUT/n) for n in ['assessment.json','recovery-proposal.json','scanner-source-review.json','summary.md']})
write('audit.json',p);print('All89+112 rows reconciled; failed discrimination preserved, correction unapproved.')
