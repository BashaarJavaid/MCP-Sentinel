"""Read retained reports only; no detector or target invocation."""
import hashlib,json,re
from pathlib import Path
from scripts.phase22_corpus import frozen,input_files
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v39-fresh-v7'
proposal=json.loads((ASSETS/'evaluation-proposal.json').read_text())
m=frozen(approval_path=ASSETS/'evaluation-authorization.json');snap={s.revision:s for s in m.snapshots}
inputs={i.id:i for i in m.inputs if i.id in proposal['input_order']}
rows=[];contexts={}
for p in sorted((OUT/'raw').glob('*/*/report.json')):
 report=json.loads(p.read_text());item=inputs[p.parent.name];files=input_files(item,snap[item.snapshot],ROOT)
 def at(path,line):
  key=f'{item.snapshot}:{path}:{line}'
  if key not in contexts:
   lines=files[path].decode().splitlines();assert 0<line<=len(lines)
   contexts[key]={'snapshot':item.snapshot,'path':path,'line':line,'source_sha256':hashlib.sha256(files[path]).hexdigest(),'lines':[f'{n+1}: {lines[n]}' for n in range(max(0,line-8),min(len(lines),line+8))]}
  return key
 coverage=report['static_analysis']['coverage'];findings=[];diagnostics=[]
 for f in report['findings']:
  loc=f['location'];findings.append({'finding':f,'source':at(loc['path'],loc['range']['start_line'])})
 for kind,entries in [('warning',report['warnings']),('unresolved_flow',coverage['unresolved_flows'])]:
  for index,d in enumerate(entries):
   match=re.match(r'(SENT-\d+) at (.+):(\d+): (.+)',d['message'])
   binding=re.fullmatch(r"(.+): cannot resolve TypeScript binding '(.+)'",d['message']) if not match else None
   if binding:
    path,symbol=binding.groups();lines=files[path].decode().splitlines();base={'tools/list metadata':'ListToolsRequestSchema','dynamic tool description':'ALL_TOOL_NAMES'}.get(symbol,symbol.split('.')[0]);occurrences=[n+1 for n,t in enumerate(lines) if re.search(r'(?<![\w$])'+re.escape(base)+r'(?![\w$])',t)];assert occurrences,(path,symbol)
    key=f'{item.snapshot}:{path}:binding:{symbol}';contexts[key]={'snapshot':item.snapshot,'path':path,'binding':symbol,'base_identifier':base,'source_sha256':hashlib.sha256(files[path]).hexdigest(),'base_identifier_occurrence_lines':occurrences,'first_occurrence_excerpt':[f'{n+1}: {lines[n]}' for n in range(max(0,occurrences[0]-3),min(len(lines),occurrences[0]+3))] }
   else:assert match,d
   diagnostics.append({'kind':kind,'index':index,'diagnostic':d,'source':at(match[2],int(match[3])) if match else key})
 rows.append({'report':str(p.relative_to(ROOT)),'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_id':item.id,'label':item.label,'findings':findings,'diagnostics':diagnostics,'coverage':coverage,'rule_outcomes':report['static_analysis']['rule_outcomes']})
with (OUT/'inventory.json').open('x') as f:json.dump({'rows':rows,'contexts':contexts},f,indent=2);f.write('\n')
print([(r['input_id'],len(r['findings']),len(r['diagnostics']),len(r['coverage']['surfaces'])) for r in rows]);print('Unique source contexts',len(contexts))
