import sys,json,collections,threading,time
from pathlib import Path
sys.path.insert(0,'/private/tmp/mcp-phase22-options/src')
from sentinel.static import workers,path_flow
out=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v11-traversal-profile');rule=sys.argv[-1];original=path_flow.PathFlow.function;counts=collections.Counter();signatures=set();sources=collections.Counter();stop=threading.Event()
def counted(self,symbol,bindings):
 before=bindings.copy()
 signature=(self,symbol.node,tuple(self.call_sites),frozenset(self.active),tuple(sorted(bindings.items())))
 repeated=signature in signatures;signatures.add(signature)
 source=(symbol.file.relative_path,symbol.name,getattr(symbol.node,'lineno',0));sources[source]+=1
 sizes={k:len(v) for k,v in vars(self).items() if isinstance(v,(dict,set,list))}
 counts['helper_calls']+=1;counts['repeated_source_context_bindings']+=repeated
 try:return original(self,symbol,bindings)
 finally:
  changed=bindings!=before
  side_changed=any(len(getattr(self,k))!=v for k,v in sizes.items())
  counts['changed_bindings']+=changed;counts['changed_side_table_sizes']+=side_changed
  counts['repeated_with_changed_bindings']+=repeated and changed
  counts['repeated_with_changed_side_table_sizes']+=repeated and side_changed
path_flow.PathFlow.function=counted
def snapshot():
 data={'counts':dict(counts),'unique_signatures':len(signatures),'source_calls':[{'path':k[0],'name':k[1],'line':k[2],'calls':v} for k,v in sources.most_common(30)],'caveat':'No reusable result proved: side table sizes omit contents and current caller state; only aggregate counts and source names retained.'}
 (out/(rule+'-counts.json')).write_text(json.dumps(data,indent=2))
def snapshots():
 while not stop.wait(15):snapshot()
thread=threading.Thread(target=snapshots,daemon=True);thread.start()
try:workers._worker()
finally:stop.set();thread.join();snapshot()
