"""Validate retained four-repository output only; never invoke a scanner."""
import hashlib
import importlib.util
import json
import os
import sys
from pathlib import Path

OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];ASSETS=OUT.parent/'v43-four-fresh-preparation';RAW=OUT/'raw'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
p=read(ASSETS/'evaluation-proposal.json');frozen=Path(p['frozen_checkout'])
os.chdir(frozen);sys.path[:0]=[str(frozen/'src'),str(frozen)]
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data
from scripts.phase22_corpus import frozen as load_frozen
spec=importlib.util.spec_from_file_location('four_runner',ASSETS/'runner.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);r.approved()
packet=read(RAW/'packet.json');execution=read(OUT/'execution.json');launch=read(OUT/'launch.json');consumed=read(ASSETS/'execution-consumed.json')
assert packet['budget_closed'] and packet['remaining_observation_budget']==0
assert packet['scanner']==p['scanner'] and packet['runner_revision']=='84f89a7308ffdf209981f1791e3fa06f16bf3c18'
for key,path in [('proposal_sha256',ASSETS/'evaluation-proposal.json'),('approval_sha256',ASSETS/'evaluation-authorization.json'),('binding_sha256',ASSETS/'binding.json')]:assert packet[key]==sha(path)
assert packet['model_calls']==0 and not packet['target_execution']
assert consumed['budget_consumed'] and consumed['proposal_sha256']==packet['proposal_sha256'] and consumed['approval_sha256']==packet['approval_sha256']
assert consumed['output']==str(RAW)
timing=execution['timing'];assert timing['cleanup_verified'] and not timing['timed_out'] and not timing['remaining_group_killed'] and timing['elapsed_seconds']<=9000
assert launch['cwd']==str(frozen) and launch['command'][-1]==str(RAW)
order=[{'batch':b,'input_id':i} for b in p['batch_order'] for i in p['input_order']]
assert packet['unstarted']==order[len(packet['attempts']):]
for name,digest in packet['files_sha256'].items():assert sha(RAW/name)==digest,name
cases={i:c for c in p['repositories'] for i in c['input_ids']};inputs={};configs={}
for c in p['repositories']:
    m=load_frozen(approval_path=ASSETS/'authorizations'/(c['id']+'.json'))
    inputs.update({i.id:i for i in m.inputs if i.id in c['input_ids']});configs.update(read(ROOT/c['configuration']['path']))
rows=[];first={};repeat=0
for a,expected in zip(packet['attempts'],order):
    assert all(a[k]==v for k,v in expected.items())
    row=dict(a);folder=RAW/a['directory'];path=folder/a['input_id']/'report.json';c=cases[a['input_id']];item=inputs[a['input_id']]
    row.update(repository=c['repository'],language=c['language'],label=item.label,snapshot=item.snapshot,tree_sha256=item.tree_sha256)
    if a['state']=='completed':
        r.completed(a['timing']);result=read(folder/'results.json');report=read(path)
        assert result['scanner']==p['scanner'] and result['manifest_sha256']==c['manifest']['sha256']
        assert result['authorization_sha256']==sha(ASSETS/'authorizations'/(c['id']+'.json'))
        assert result['outcomes']==[a['outcome']] and result['model_calls']==0 and not result['requests']
        assert sha(path)==a['outcome']['report_sha256']
        assert sha(path.parent/'configuration.json')==configs[item.id]['sha256']==a['outcome']['configuration_sha256']
        validate_report_data(report);validate_sarif_data(read(path.with_suffix('.sarif')))
        assert report['analysisComplete'] and report['executionSuccessful'] and report['static_analysis']['duration_ms']<=300000
        canonical=r.supervisor.clean(report,r.EXCLUDED)
        if a['batch']=='rules-first':first[item.id]=canonical
        else:
            assert canonical==first[item.id] and a['ordered_repeat_equal'];repeat+=1
        row.update(report_sha256=sha(path),sarif_sha256=sha(path.with_suffix('.sarif')),finding_count=len(report['findings']),warning_count=len(report['warnings']),coverage=report['static_analysis']['coverage'],rule_outcomes=report['static_analysis']['rule_outcomes'])
    rows.append(row)
if packet['passed']:
    assert timing['returncode']==0 and len(rows)==24 and all(a['state']=='completed' for a in rows) and repeat==12
else:assert timing['returncode']!=0 and packet['stop_reason']
write('validation.json',{'validation_passed':True,'execution_gate_passed':packet['passed'],'stop_reason':packet.get('stop_reason'),'scanner':p['scanner'],'raw_packet_sha256':sha(RAW/'packet.json'),'execution_sha256':sha(OUT/'execution.json'),'validator_sha256':sha(Path(__file__)),'attempts':rows,'repeat_pairs_equal':repeat,'unstarted_closed':packet['unstarted'],'remaining':0,'budget_closed':True,'source_assessment_pending':True,'paid_calls':0})
print(f'Validated {len(rows)} attempts; {repeat} ordered repeats; execution gate {packet["passed"]}.')
