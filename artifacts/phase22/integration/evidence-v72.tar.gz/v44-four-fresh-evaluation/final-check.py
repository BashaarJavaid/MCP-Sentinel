"""Final evidence consistency, preservation and affected-check verification."""
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];BASE=OUT.parent;PREP=BASE/'v43-four-fresh-preparation'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(OUT/'assessment.json');old=read(PREP/'audit.json');audit=read(OUT/'audit.json');compat=read(OUT/'compatible-reuse.json');binding=read(PREP/'documentation-binding.json')
assert audit['requirements']==old['requirements'] and audit['additional_scope_requirements'][:115]==old['additional_scope_requirements'][:115]
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==131
assert not audit['acceptance_packet_ready'] and not audit['technical_acceptance_received'] and not audit['phase22_complete']
for name,digest in compat['source_files_sha256'].items():assert sha(ROOT/name)==digest,name
prior=read(PREP/'prior-requirement-verification.json')
for name,digest in prior['referenced_evidence_sha256'].items():assert sha(ROOT/name)==digest,name
for name,digest in binding['user_files_sha256'].items():assert sha(ROOT/name)==digest,name
assert set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())==set(binding['user_files_sha256'])
assert not subprocess.check_output(['git','diff','--name-only','--','src','tests','scripts','schemas','.github','uv.lock','pyproject.toml','action.yml','Makefile'],cwd=ROOT)
checks={}
for label in ['v44-docs','v44-build-cache-access','v44-distribution-verification']:
    path=BASE/(label+'.json');d=read(path);assert d['exit_code']==0
    checks[label]={'path':str(path.relative_to(ROOT)),'sha256':sha(path),'exit_code':0}
assert read(OUT/'final-distributions.json')['README_sha256']==sha(ROOT/'README.md')
assert read(BASE/'v44-build.json')['exit_code']==2
v=read(OUT/'validation.json');inv=read(OUT/'inventory.json');fs=read(OUT/'finding-source-assessment.json');ds=read(OUT/'diagnostic-source-assessment.json');ss=read(OUT/'surface-source-assessment.json');cs=read(OUT/'source-context-assessment.json')
assert len(v['attempts'])==len(a['rows'])==len(inv['rows'])==24
assert len(fs['rows'])==a['finding_count']==236 and len(ds['rows'])==a['diagnostic_count']==46486 and len(ss['rows'])==a['surface_count']==270
assert len(cs['contexts'])==4314 and cs['unassessed']==fs['unassessed']==ds['unmapped']==ss['unassessed']==0
for name,digest in a['assessment_files_sha256'].items():assert sha(OUT/name)==digest
for row in inv['rows']:
    assert sha(ROOT/row['report'])==row['report_sha256']
    f=[r for r in fs['rows'] if (r['batch'],r['input_id'])==(row['batch'],row['input_id'])];d=[r for r in ds['rows'] if (r['batch'],r['input_id'])==(row['batch'],row['input_id'])];s=[r for r in ss['rows'] if (r['batch'],r['input_id'])==(row['batch'],row['input_id'])]
    assert [r['finding'] for r in f]==[r['finding'] for r in row['findings']]
    assert [(r['kind'],r['index'],r['diagnostic']) for r in d]==[(r['kind'],r['index'],r['diagnostic']) for r in row['diagnostics']]
    assert [r['surface'] for r in s]==[r['surface'] for r in row['surfaces']]
assert a['repository_gates_passed']==0 and not a['fresh_detection_gate_passed']
assert a['budget']['remaining']==0 and a['budget']['closed'] and a['budget']['paid_calls']==0
assert a['within120']==24 and a['extended']==0 and a['entire_ordered_repeat_pairs_equal']==12
spec=importlib.util.spec_from_file_location('four_runner_final',PREP/'runner.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);p=r.verify_packet();frozen=Path(p['frozen_checkout']);os.chdir(frozen);sys.path[:0]=[str(frozen/'src'),str(frozen)]
for case in p['repositories']:r.check_identity(case['input_ids'][0])
for name,digest in read(PREP/'staging-files.json').items():assert sha(frozen/name)==digest,name
owned=read(OUT/'owned-work.json');assert not owned['owned_processes'] and not owned['managed_container_ids'] and not owned['sentinel_named_container_ids']
result={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'checks':checks,'scanner':p['scanner'],'source_inputs_verified':len(compat['source_files_sha256']),'prior_evidence_files_reverified':len(prior['referenced_evidence_sha256']),'original_and_earlier_added_rows_unchanged':204,'full_audit_rows':220,'protected_user_files':8,'staged_input_files_verified':len(read(PREP/'staging-files.json')),'all_report_occurrences_and_assessments_match':True,'execution_gate_passed':True,'fresh_repository_gates_passed':0,'remaining_observation_budget':0,'paid_calls':0,'failed_checks_preserved':['inventory-path-correction.json','diagnosis-range-correction.json','reconciliation-path-correction.json','../v44-build.json'],'build_cache_resolution':'Initial offline build stopped at sandbox cache access before build; authorized cache access succeeds in v44-build-cache-access. No dependency upgrade, target or paid work.','acceptance_packet_ready':False,'technical_acceptance_received':False,'phase22_complete':False,'required_remaining':'User decision on focused recovery or explicit failed-gate scope disposition, then separate technical acceptance and verified closeout; current outcome delivery verified after commit.'}
with (OUT/'final-checks.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Final consistency checks pass;220audit rows preserved; failed fresh gate remains unresolved.')
