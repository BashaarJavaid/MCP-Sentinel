"""Bind final docs/packets after the numbered seal; no remote mutations."""
import hashlib
import json
import subprocess
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;PREP=BASE/'v43-four-fresh-preparation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
old=read(PREP/'documentation-binding.json');seal=read(BASE/'evidence-v72.json');assert sha(BASE/seal['archive'])==seal['sha256']
path=BASE/'README.md';text=path.read_text().replace('batches 1–71','batches 1–72',1)
block=f'''\n## Evaluation evidence seal 72

[Seal 72](evidence-v72.json) retains {len(seal['files']):,} members
({sum(r['bytes'] for r in seal['files']):,} raw bytes), archive SHA-256
`{seal['sha256']}`. It includes all24observations, exact approvals, complete raw
reports/logs, source assessments, the failed-gate recovery proposal,220-row audit,
current checks and supplemental v43 delivery receipts. All71prior archives and
every member were verified; no sealed historical file was changed.
Restore after seals1–71 in numeric order into separate safe staging; reject unsafe
paths/symlinks and verify archive/member hashes before extraction. Existing files
must match identical bytes or an explicit recorded previous hash; stop on conflicts.
Current owning docs and post-seal bindings are directly tracked. The delivery
readback will be a supplemental post-commit receipt, outside the commit it verifies.
Phase22 remains incomplete; this seal records four failed fresh gates, not acceptance.
'''
for before,after in [('all24observations','all 24 observations'),('proposal,220-row','proposal, 220-row'),('All71prior','All 71 prior'),('seals1–71','seals 1–71'),('Phase22','Phase 22')]:block=block.replace(before,after)
assert '## Evaluation evidence seal 72' not in text
first,rest=text.split('\n',1);path.write_text(first+'\n'+block+rest)
worktrees=subprocess.check_output(['git','worktree','list','--porcelain'],text=True)
def parse(s):
    return {b.splitlines()[0].removeprefix('worktree '):next(l[5:] for l in b.splitlines() if l.startswith('HEAD ')) for b in s.strip().split('\n\n')}
prior=parse(old['worktrees']);current=parse(worktrees)
for name,head in prior.items():assert current[name]==('84f89a7308ffdf209981f1791e3fa06f16bf3c18' if name==str(ROOT) else head),(name,current[name],head)
for name,digest in old['user_files_sha256'].items():assert sha(ROOT/name)==digest,name
review_names=['summary.md','audit.json','assessment.json','validation.json','source-diagnosis.json','recovery-proposal.json','compatible-reuse.json','final-checks.json','final-distributions.json','pr-body.md','command-provenance.json']
review={str((OUT/n).relative_to(ROOT)):sha(OUT/n) for n in review_names}
for path in [PREP/'evaluation-authorization.json',PREP/'binding.json',PREP/'execution-consumed.json',PREP/'approved-preflight.json',PREP/'approved-owned-work.json',PREP/'approved-remote-preflight.json',*sorted((PREP/'authorizations').glob('*.json'))]:review[str(path.relative_to(ROOT))]=sha(path)
result={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':'84f89a7308ffdf209981f1791e3fa06f16bf3c18','measured_scanner':read(PREP/'evaluation-proposal.json')['scanner'],'tested_workflow':old['tested_workflow'],'owning_docs_sha256':{n:sha(ROOT/n) for n in old['owning_docs_sha256']},'review_packet_sha256':review,'corpus_files_sha256':{},'user_files_sha256':old['user_files_sha256'],'worktrees':worktrees,'evidence_seal':{'index':'artifacts/phase22/integration/evidence-v72.json','index_sha256':sha(BASE/'evidence-v72.json'),'archive_sha256':seal['sha256']},'proposal_sha256':sha(PREP/'evaluation-proposal.json'),'recovery_proposal_sha256':sha(OUT/'recovery-proposal.json'),'new_native_observations':24,'new_paid_calls':0,'target_execution':False,'four_repository_gates_passed':0,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Current docs and directly tracked review packet are bound after seal72. Prior v43 receipts are included in seal72. Future remote delivery receipt follows the commit and is supplemental; no circular self-sealing claim.'}
with (OUT/'documentation-binding.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print('Final docs,source/evidence identities and protected worktrees bound after seal72.')
