"""Reconcile the completed failed fresh gate without accepting a limitation."""
import copy
import hashlib
import json
import os
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;PREP=BASE/'v43-four-fresh-preparation'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();read=lambda p:json.loads(p.read_text())
def write(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
a=read(OUT/'assessment.json');old=read(PREP/'audit.json');p=read(PREP/'evaluation-proposal.json');compat=read(PREP/'compatible-reuse.json')
for name,digest in compat['source_files_sha256'].items():assert sha(ROOT/name)==digest,name
for name,digest in compat['retained_evidence_sha256'].items():assert sha(ROOT/name)==digest,name
compat['current_validation_sha256']=sha(OUT/'validation.json');compat['current_assessment_sha256']=sha(OUT/'assessment.json');compat['qualification']+=' New24-observation four-repository scope retains frozen2e0efb2; none of the failed fresh gates is corrected or waived. No new engineering suite or hosted code pass.'
write('compatible-reuse.json',compat)
added=copy.deepcopy(old['additional_scope_requirements']);updates={
'V43-PREPARATION-DELIVERY':[str((PREP/'delivery-verification.json').relative_to(ROOT))],
'V43-APPROVAL':[str((PREP/'evaluation-authorization.json').relative_to(ROOT)),str((PREP/'binding.json').relative_to(ROOT))],
'V43-EVALUATION':[str((OUT/'validation.json').relative_to(ROOT)),str((OUT/'execution.json').relative_to(ROOT))],
'V43-ASSESSMENT':[str((OUT/'assessment.json').relative_to(ROOT))]}
for row in added:
    if row['id'] in updates:
        row['previous_disposition']=row['disposition'];row['disposition']='passed';row['evidence']=updates[row['id']];row['assessment']='Actual delivered preparation, exact user approval, completed24-observation execution or exhaustive source assessment is verified by the bound evidence. Passing the process requirement does not turn any failed repository detection gate into a pass.'
new=[('V44-EXECUTION','Validate24complete first-frozen observations,12entire ordered repeats,all bounds/schemas/identities/cleanup and closed zero-call budget','passed',['validation.json','execution.json']),('V44-SOURCE','Source-assess every finding,warning,unresolved flow and surface plus actual named sink/guard support','passed',['assessment.json','source-context-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json']),('V44-FOUR-GATE','Establish all four requested fresh vulnerable/fixed/safe gates or obtain explicit user disposition of their actual failures','unresolved',['assessment.json','source-diagnosis.json','recovery-proposal.json']),('V44-COMPATIBILITY','Verify all retained original/additional scope and unchanged current engineering/source bindings','passed',['compatible-reuse.json']),('V44-RECOVERY-DECISION','Obtain explicit decision on focused source-only recovery or documented failed-gate scope; no automatic waiver,correction,scan or replacement','unresolved',['recovery-proposal.json']),('V44-DELIVERY','Complete affected checks,new evidence seal and verified existing draft delivery of completed outcomes and next decision','unresolved',[])]
for id,requirement,status,evidence in new:added.append({'id':id,'requirement':requirement,'disposition':status,'evidence':[str((OUT/n).relative_to(ROOT)) for n in evidence],'assessment':'Four first-frozen repository gates fail and remain unresolved. Execution/assessment/compatibility passes are separately bound; technical acceptance and closeout have not occurred.'})
assert len(old['requirements'])==89 and len(added)==131
rows=old['requirements']+old['additional_scope_requirements'];preservation={r['id']:hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in rows}
write('prior-row-preservation.json',{'prior_audit_sha256':sha(PREP/'audit.json'),'rows':preservation,'original89_and_prior115_unchanged':True,'v43_rows_updated_only_for_actual_decisions_and_evidence':list(updates),'scope_rows_retained':214})
audit={'recorded_at':datetime.now(timezone.utc).isoformat(),'source':p['scanner']['revision'],'scanner_identity':p['scanner'],'requirements':copy.deepcopy(old['requirements']),'additional_scope_requirements':added,'dispositions':dict(Counter(r['disposition'] for r in old['requirements'])),'additional_scope_dispositions':dict(Counter(r['disposition'] for r in added)),'historical_v43_status_fields':{k:v for k,v in old.items() if k not in {'requirements','additional_scope_requirements'}},'prior_audit':{'path':str((PREP/'audit.json').relative_to(ROOT)),'sha256':sha(PREP/'audit.json')},'current_evidence':{n:sha(OUT/n) for n in ['assessment.json','validation.json','source-diagnosis.json','recovery-proposal.json','compatible-reuse.json','prior-row-preservation.json']},'four_repository_prepared':True,'four_repository_approved':True,'four_repository_executed':True,'four_repository_gate_passed':False,'current_continuation_corpus_observations':24,'new_paid_calls':0,'target_executions':0,'budget_closed':True,'remaining':0,'acceptance_packet_ready':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'phase22_complete':False,'current_requirement_interpretations':copy.deepcopy(old['current_requirement_interpretations']),'status':'Approved four-repository collection completes24/24 with12ordered pairs; all4repository gates fail after source assessment. Focused source-only recovery proposal requires actual user decision. No limitation is accepted and technical acceptance readiness is false.'}
for id in ['R66','R88']:audit['current_requirement_interpretations'][id]='Original heldout/fresh failures and later exposed corrections remain source-bound. New four-repository first-frozen result: one named vulnerable candidate hit per pass, three misses, no-bash two matching negative alerts per pass, no supported correctly guarded negative case. All four gates fail; explicit disposition/recovery and final technical acceptance remain unresolved.'
audit['current_requirement_interpretations']['R84']='Explicit human technical acceptance remains unresolved and is not requested while the four failed fresh gates await a decision. Paid benchmark/pilots are user-deferred; incomplete Git312/1040 remains deferred. No merge/release/Phase23.'
write('audit.json',audit)
summary='''# Four-repository first-frozen evaluation result

**All 24 observations complete and all 12 entire ordered report pairs agree. All four fresh repository gates fail. Phase 22 remains incomplete.**

The user's exact “approved.” decision binds the [delivered proposal](../v43-four-fresh-preparation/evaluation-proposal.json), SHA-256 `f14463b709be246621cf82c08d01978dafea72bc0c1defb5f6044de53ed1d983`, at preparation delivery `84f89a7308ffdf209981f1791e3fa06f16bf3c18`. [Authorization](../v43-four-fresh-preparation/evaluation-authorization.json) and four per-manifest receipts bind one serial local macOS sequence, frozen scanner `2e0efb268b733a14d7eca87555fdd87f134ba78c`, source SHA-256 `0eac8832012e213744d752c6c33a0ba6a2e378f6230e273030f5043f00cf6ebb`, unchanged harness/lock, twelve original vulnerable/fixed/safe records twice. Approval did not include technical acceptance.

| Repository / actual language | Named vulnerable hits per pass | Matching fixed/safe alerts per pass | Actual named sink / fixed guard support | Repeats | Gate |
| --- | --- | --- | --- | --- | --- |
| Wolfe-Jam/faf-mcp / TypeScript | 0/1 | 0/2 | No tool surfaces; named read and fixed guard unsupported | 3/3 equal | Fail |
| RobertBergman/no-bash-mcp / TypeScript | 1/1 | 2/2 | Actual overwrite found; fixed guard recognition fails; unnamed dispatch unresolved | 3/3 equal | Fail |
| refined-element/lightning-enable-mcp Python member / Python | 0/1 | 0/2 | Tool recognized; actual HTTPX client.get unresolved; fixed guard support unestablished | 3/3 equal | Fail |
| petersimmons1972/engram / Python | 0/1 | 0/2 | Tool recognized; actual manifest write and local Path unresolved | 3/3 equal | Fail |

Every repository completed 6/6 observations. **None of the eight fixed/safe input records establishes supported, correctly guarded discrimination.** Quiet negatives in FAF, Lightning and Engram do not count as successful discrimination. Four repositories are four narrow conditions, not 24 independent discoveries or population accuracy. All complete archives, configurations, illustrative caller values, prerequisites and frozen labels remain unchanged. Safe records use their fixed tree; static analysis is not specialized by the illustrative caller value. Eight format-required mutations and all prior manifest records remain unexecuted in this scope.

| Input | First whole / native seconds | Repeat whole / native seconds | Matching keys first / repeat | Ordered pair |
| --- | --- | --- | --- | --- |
'''
for id in p['input_order']:
    first,repeat=[r for r in a['rows'] if r['input_id']==id]
    summary+=f"| `{id}` | {first['timing']['elapsed_seconds']:.3f} / {first['native_seconds']:.3f} | {repeat['timing']['elapsed_seconds']:.3f} / {repeat['native_seconds']:.3f} | {len(first['matching_keys'])} / {len(repeat['matching_keys'])} | Equal |\n"
summary+='''
All **24/24 observations meet the 120-second target**, with zero extended allowances. Maximum whole input is **51.378262 seconds**, native **45.063 seconds**; the serial sequence took **455.321356 seconds** (7 minutes 35 seconds), within 150 minutes. [Validation](validation.json) checks exact identities, native/SARIF schemas, 300-second whole/native limits, cleanup and all ordered reports after only the established eleven volatile exclusions. **One sequence and 24 observations consumed; zero budget remains.** Zero retries, profiles, comparators, replacements, target executions, dependency installations or paid calls. No owned evaluation work remains.

The [source assessments](assessment.json) bind all **236 findings, 46,486 diagnostic occurrences and 270 surfaces** to exact reports and retained source. There are 4,314 unique source contexts; repeated occurrences share explicit source judgments. Unresolved operations remain unresolved. Recognized surfaces do not imply complete sink coverage, and native reports have no positive per-sink guard trace. FAF has zero surfaces; no-bash has one unnamed unresolved dispatch per report; Lightning and Engram recognize 26 and 18 tool surfaces respectively. Total possible surfaces remains unknown; no coverage percentage is inferred.

No-bash's actual overwrite candidate binds caller, helper and write, but its vulnerable “after-prefix” wording is imprecise: sibling-prefix bypass needs no further path derivation. The report still asserts containment failure and requests component-aware checking, so the candidate is counted with that explanation defect disclosed. Its fixed separator-prefix-or-root guard returns a checked value, yet all four fixed/safe occurrences falsely assert missing containment. Other raw findings remain separately adjudicated: a vulnerable Git shell concern; ordinary ESM project-script/read reachability false positives; a fixed Git `-m` operand false positive; and other filesystem candidates outside the overwrite condition.

Lightning's validation alerts are conditional false positives under ordinary compatible SDK schema validation; its manifest parsing findings do not establish actual tool registration, including mocked test data. Engram's related markdown/directory/README findings remain visible but cannot substitute for the frozen `manifest_path.write_text` sink. Source prerequisites retain PostgreSQL/NullEmbedder and stable filesystem assumptions. No upstream tests or runtime services ran.

[Source diagnosis](source-diagnosis.json) identifies FAF's imported class startup/discovery gap, Lightning's optional HTTPX import identity loss, Engram's function-local pathlib identity gap, and no-bash's failed compound path-guard propagation. The exact no-bash loss point and downstream support after any repair remain to be localized with synthetic controls. **No scanner correction has been made and no failed measurement has been relabeled.** The [focused recovery proposal](recovery-proposal.json) requests a source-only correction/engineering stage for these four gaps, followed by a separate exact exposed-regression/affected-compatibility proposal. It authorizes no new observation, paid call, target execution, comparator, profile or replacement. A documented failed-gate scope decision is an explicit alternative requiring the user's decision; none is accepted now.

The [full audit](audit.json) retains all **89 original and 115 earlier added requirements**, plus all ten preparation rows, and adds six result/decision/delivery rows. Original dispositions remain 84 passed, two user-deferred, two proposed documented limitations and one unresolved human acceptance. The six older proposed failed-attempt closures remain awaiting decision. Execution and assessment requirements pass; the four-repository result and recovery decision remain unresolved. Technical acceptance readiness is false until the actual failed gate is explicitly handled. Subsequent human acceptance and verified closeout remain separate.

All **301 engineering inputs** still equal tested `2e0efb2`; retained local and all twelve hosted suites pass **2,317 tests / 36 skips**, local branch coverage **89.915%**, all **29 normal jobs** in CI `34712751779` and docs `34712751789`. This continuation adds report/source validation and affected docs/package checks, not a new hosted code pass. Six zero-call production replays and existing Git image/runtime bindings remain compatible.

Historical evidence remains unchanged: exposed TypeScript 94/94 and 47 repeats at `2e0efb2`; Python 87 measured at `8c62567`; whole 25 development reuse and 45+45 historical Linux evidence at `1f3f72f`, with the Meta operator erratum. Language subsets are not pooled into a new whole batch. Memorykeeper's original fixed/control false alerts, DDG's initially unsupported fixed send and frozen manifest TypeScript-label error despite actual Python configuration, Lighthouse's original misses, all earlier failed optimizations/stops and their later exposed corrections remain source-bound. Original holdout stays ten completed, ten unsupported and five incomplete, zero hits among four completed vulnerable inputs out of ten vulnerable inputs total. The historical 70-warning backlog remains separate.

Novelty remains relative to recorded project source exposure: nine prior manifests, 104 effective trees and 2,910 retained archives were checked before any scan. Same-owner FAF catalog references and Engram's fork ancestry are disclosed. FAF's actual fix/tag discrepancy and no-bash's MIT declarations without a standalone/full grant text remain visible. Same-agent curation/review is not independent human validation or training-data novelty. These results establish neither broad accuracy nor runtime safety.

Git campaigns remain **312/1,040 incomplete**, with 728 attempts deferred. Paid benchmark and pilots remain user-deferred/nonblocking; Phase 21 remains incomplete and Phase 24/15 gates are unchanged. Historical Phase 22 paid cost remains **$0.071799**; this continuation adds **$0**. No merge, ready-state change, release, outreach or Phase 23 is authorized. After an actual recovery/disposition decision, continue through a separately delivered technical acceptance packet and explicit acceptance, then verified closeout to draft PR #37.
'''
with (OUT/'summary.md').open('x') as f:f.write(summary)
url='https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/'
body=summary
for target in ['../v43-four-fresh-preparation/evaluation-proposal.json','../v43-four-fresh-preparation/evaluation-authorization.json','validation.json','assessment.json','source-diagnosis.json','recovery-proposal.json','audit.json']:
    final=url+(target.removeprefix('../') if target.startswith('../') else 'v44-four-fresh-evaluation/'+target);body=body.replace('('+target+')','('+final+')')
with (OUT/'pr-body.md').open('x') as f:f.write(body)
for name in read(PREP/'documentation-binding.json')['owning_docs_sha256']:
    path=ROOT/name;text=path.read_text();first,rest=text.split('\n',1);link=url+'v44-four-fresh-evaluation/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md',path.parent)
    status=f'''\n## Current four-repository result: failed fresh gates, decision pending

The approved first-frozen batch at `2e0efb2` completes **24/24 observations**;
all **12 entire ordered report pairs agree**, all within120seconds (maximum
51.378262seconds; sequence455.321356seconds). **All four repository gates fail**:
FAF, Lightning's Python member and Engram miss their named vulnerable sinks;
no-bash detects the vulnerable overwrite but falsely alerts on both fixed/safe
inputs per pass. Quiet negatives lack established named-path support.
The [completed review packet]({link}) source-assesses all236findings,
46,486diagnostics and270surfaces and proposes focused source-only recovery.
No correction or limitation waiver is inferred. All24observations are consumed,
zero budget remains, and no extra paid/target/comparator/retry/profile call occurred.
All prior source-bound results and failures remain preserved; product/test/workflow
bytes still equal tested `2e0efb2`. **Phase22 remains incomplete**: actual failed-gate
disposition/recovery, separate explicit technical acceptance and closeout remain.
Git312/1,040 stays incomplete, paid benchmark/pilots deferred, Phase21 incomplete,
Phase24/15 unchanged. No merge, ready-state, release, outreach or Phase23.
'''
    assert '## Current four-repository result:' not in text
    path.write_text(first+'\n'+status+rest.replace('## Current four-repository preparation:','## Historical v43 four-repository preparation:',1))
# Keep frozen corpus/proposal and prior sealed preparation documents untouched.
print('Reconciled full220-row audit,12input/4repository tables and15owning docs; failed gates remain unresolved.')
