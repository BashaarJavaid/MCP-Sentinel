"""Record the actual exact evaluation approval and source-only preflight."""
import hashlib
import importlib.metadata
import importlib.util
import json
import os
import platform
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

assets=Path(__file__).resolve().parent
root=assets.parents[3]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,d):
    with p.open('x') as f: json.dump(d,f,indent=2); f.write('\n')
def git(path,*args): return subprocess.check_output(['git','-C',str(path),*args],text=True).strip()
p=json.loads((assets/'evaluation-proposal.json').read_text())
assert sha(assets/'evaluation-proposal.json')=='f14463b709be246621cf82c08d01978dafea72bc0c1defb5f6044de53ed1d983'
head=git(root,'rev-parse','HEAD'); assert head=='84f89a7308ffdf209981f1791e3fa06f16bf3c18'
assert not (root/p['output']).exists() and not (assets/'execution-consumed.json').exists()
for name,digest in p['files_sha256'].items(): assert sha(root/name)==digest,name
binding=json.loads((assets/'documentation-binding.json').read_text())
for field in ['owning_docs_sha256','user_files_sha256']:
    for name,digest in binding[field].items(): assert sha(root/name)==digest,name
compatible=json.loads((assets/'compatible-reuse.json').read_text())
for name,digest in compatible['source_files_sha256'].items(): assert sha(root/name)==digest,name
frozen=Path(p['frozen_checkout'])
for name,digest in json.loads((assets/'staging-files.json').read_text()).items(): assert sha(frozen/name)==digest,name
assert git(frozen,'rev-parse','HEAD')==p['scanner']['revision']
main=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert git(main,'rev-parse','HEAD')=='4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not git(root,'diff','--name-only') and not git(root,'diff','--cached','--name-only')
versions={n:importlib.metadata.version(n) for n in ['semgrep','mcp','pytest','pydantic']}
assert platform.python_version()=='3.12.13'
assert versions=={'semgrep':'1.176.0','mcp':'1.29.0','pytest':'9.0.3','pydantic':'2.13.4'}
now=datetime.now(timezone.utc).isoformat()
a={'approved':True,'user_decision':'approved.','recorded_at':now,'decision_context':'Direct reply to the final exact 24-observation proposal delivered at84f89a7, proposal SHA f14463b709be246621cf82c08d01978dafea72bc0c1defb5f6044de53ed1d983. Approval is for this evaluation only; separate human technical acceptance remains pending.','delivery_head':head,'proposal_sha256':sha(assets/'evaluation-proposal.json'),'checkpoint_sha256':p['checkpoint']['sha256'],'scanner':p['scanner'],'bounds':p['bounds'],'input_order':p['input_order'],'technical_acceptance_received':False,'phase22_complete':False}
write(assets/'evaluation-authorization.json',a)
(assets/'authorizations').mkdir(exist_ok=False)
for c in p['repositories']:
    write(assets/'authorizations'/(c['id']+'.json'),{'approved':True,'recorded_at':now,'user_decision':a['user_decision'],'parent_authorization_sha256':sha(assets/'evaluation-authorization.json'),'corpus':{'manifest':c['manifest']['path'],'sha256':c['manifest']['sha256'],'freeze_approved':True,'input_ids':c['input_ids'],'treatments':['rules']}})
files=dict(p['files_sha256'])
for path in [assets/'evaluation-proposal.json',assets/'evaluation-authorization.json',*sorted((assets/'authorizations').glob('*.json'))]: files[str(path.relative_to(root))]=sha(path)
write(assets/'binding.json',{'recorded_at':now,'delivery_head':head,'files':files,'technical_acceptance_received':False})
spec=importlib.util.spec_from_file_location('approved_runner',assets/'runner.py')
r=importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
os.chdir(frozen);sys.path[:0]=[str(frozen/'src'),str(frozen)]
for c in p['repositories']: r.check_identity(c['input_ids'][0])
import sentinel
assert str(Path(sentinel.__file__).resolve()).startswith(str(frozen/'src')+'/')
write(assets/'approved-preflight.json',{'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'approval_sha256':sha(assets/'evaluation-authorization.json'),'binding_sha256':sha(assets/'binding.json'),'delivery_head':head,'scanner':p['scanner'],'python':platform.python_version(),'packages':versions,'imported_sentinel':sentinel.__file__,'four_manifest_authorizations_valid':True,'protected_user_files':binding['user_files_sha256'],'engineering_files_verified':len(compatible['source_files_sha256']),'scanner_observations':0,'paid_calls':0})
print('Exact approval recorded; four manifest identities and source-only preflight passed; zero observations so far.')
