## Current v64 parent-and-worker profile: source-only decision pending

The approved single FAF profile at frozen **`1948bf9`** timed out after
**1800.010375 seconds**, retaining **148,764 partial samples**
from **1 verified process snapshot(s): parent**. Cleanup passed;
no report exists and the one-use budget is closed. Parent and worker denominators
are separate. Missing worker snapshots do not prove workers never launched.
Partial shares establish no native speedup, removable-cost fraction or detection.

`v64-shared-discovery-sampling/optimization-proposal.json` prepares **one unapproved
source-only attempt** to avoid redundant If invalidation-accumulator construction.
The original baseline and every per-arm copy, guard, traversal and state update remain.
Complete branch-isolation, alias/state and report equivalence plus full engineering
are required. No implementation, corpus/profile/retry, paid call,
resource change or timeout revision is included. The 1800-second policy remains.

All **358 requirements (89 original + 269 added)** and every earlier failed gate
remain. Product retains tested `1948bf9`: **2,418 tests / 36 skips** locally and in
all 12 hosted suites, 29 normal CI jobs and docs passed. Combined coverage is
90.08%, branch-only 85.92%; six zero-call replays and approved runtime bindings
remain compatible. This continuation adds profile assessment and docs/package checks.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete;
paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state change, release, outreach or Phase 23 is authorized.

