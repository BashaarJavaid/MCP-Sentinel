"""Exercise the prepared supervisor/sequence contract without scanning any target."""
import hashlib,importlib.util,json,subprocess,sys,tempfile
from pathlib import Path
from unittest.mock import patch
from scripts import phase20_measurements as h
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_v7',OUT/'runner.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
proposal=runner.verify_packet();runner.selfcheck();assert not runner.APPROVAL.exists()
with patch.object(runner.Path,'cwd',return_value=Path(proposal['frozen_checkout'])):
 try:runner.approved()
 except FileNotFoundError:pass
 else:raise AssertionError('Missing approval accepted')
with patch.object(runner,'sha',return_value='wrong'):
 try:runner.verify_packet()
 except AssertionError:pass
 else:raise AssertionError('Changed bound bytes accepted')
assert not (OUT/'execution-consumed.json').exists()
assert not subprocess.check_output(['git','diff','8c62567','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile','CHANGELOG.md','LICENSE'])
source=(OUT/'runner.py').read_text()
for text in ['OpenAITransport.create = forbidden','key.startswith(("OPENAI_", "SENTINEL_"))','"-I"','.open("x") as receipt','not parent_packet.get("budget_closed", False)','315 < stop','supervisor.supervise(command','previous[observation["input_id"]] = canonical']:assert text in source,text
synthetic=[]
for corrupt in [False,True]:
 with tempfile.TemporaryDirectory(prefix='phase22-v39-synthetic-') as temp:
  base=Path(temp);assets=base/'assets';assets.mkdir();out=base/'output';out.mkdir()
  for name in ['proposal.json','approval.json','binding.json']:(assets/name).write_text('{"synthetic_only":true,"approved":false}')
  fake={'scanner':{'revision':'synthetic-no-corpus'},'input_order':['synthetic-a','synthetic-b','synthetic-c'],'batch_order':['rules-first','rules-repeat'],'bounds':{'internal_stop_minutes':10}}
  def supervise(command,log,seconds):
   assert seconds==300;folder=Path(command[-1]);item=command[-2];batch=command[-3];(folder/item).mkdir(parents=True)
   report={'static_analysis':{'duration_ms':1},'findings':[item]+(['intentional-mismatch'] if corrupt and batch=='rules-repeat' else []),'warnings':[],'timestamp':batch}
   (folder/item/'report.json').write_text(json.dumps(report));(folder/'results.json').write_text(json.dumps({'outcomes':[{'state':'synthetic-only'}]}));(folder/'validation.json').write_text('{"synthetic_only":true}');log.write_text('No subprocess or scanner invoked; synthetic report only.\n')
   return {'returncode':0,'timed_out':False,'cleanup_verified':True,'remaining_group_killed':False,'elapsed_seconds':0.001,'elapsed_including_cleanup_seconds':0.002}
  with patch.object(runner,'ASSETS',assets),patch.object(runner,'PROPOSAL',assets/'proposal.json'),patch.object(runner,'APPROVAL',assets/'approval.json'),patch.object(runner,'approved',return_value=fake),patch.object(runner,'check_identity',return_value=None),patch.object(runner.supervisor,'selfcheck',return_value=None),patch.object(runner.supervisor,'supervise',side_effect=supervise):
   try:runner.run(out)
   except AssertionError as error:
    assert corrupt and str(error)=='entire ordered report mismatch',str(error)
   else:assert not corrupt
  result=json.loads((out/'packet.json').read_text());assert result['budget_closed']
  if corrupt:assert not result['passed'] and len(result['attempts'])==4 and len(result['unstarted'])==2
  else:assert result['passed'] and len(result['attempts'])==6 and sum(a.get('ordered_repeat_equal',False) for a in result['attempts'])==3
  synthetic.append({'intentional_repeat_mismatch':corrupt,'passed_expected_behavior':True,'attempt_records':len(result['attempts']),'closed_unstarted':len(result['unstarted']),'actual_scanner_calls':0})
packet={'passed':True,'scanner':proposal['scanner'],'preparation_source':h.scanner_identity(),'proposal_sha256':runner.sha(runner.PROPOSAL),'checks':['Missing approval rejected','Bound file drift rejected','300-second deadline/15-second cleanup controls','Entire ordered report sensitivity','Synthetic six-input sequence stores first reports and compares all3repeats','Synthetic first-repeat mismatch closes2unstarted records','Product/test/workflow/lock bytes equal tested8c62567'],'synthetic_sequences':synthetic,'actual_native_observations':0,'actual_comparator_observations':0,'paid_calls':0,'target_execution':False,'files_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'preflight.py',OUT/'runner.py']}}
with (OUT/'preflight.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('Preparation checks pass; no corpus source scanned or executed.')
