"""Publish a source-only checkpoint, preserving all measured historical results."""
import copy, hashlib, json, subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent; BASE=OUT.parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
proposal=read(OUT/'evaluation-proposal.json'); old=read(BASE/'v38-guard-regression/documentation-binding.json')
assert read(OUT/'preflight.json')['passed']
assert read(BASE/'v39-preflight-permitted.json')['exit_code']==0
assert (OUT/'supervisor-checks/selfcheck.json').exists()
for n,d in proposal['files_sha256'].items():assert sha(ROOT/n)==d,n
for n in ['evaluation-authorization.json','binding.json','execution-consumed.json']:assert not (OUT/n).exists()
assert not subprocess.check_output(['git','diff','8c62567','--',*old['byte_identical_quality_inputs']])
staged=read(OUT/'staging-files.json'); frozen=Path(proposal['frozen_checkout'])
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=frozen,text=True).strip()==proposal['scanner']['revision']
assert not subprocess.check_output(['git','diff','HEAD'],cwd=frozen)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=frozen,text=True).splitlines()
assert untracked and all(n.startswith('artifacts/phase22/corpus-replacement-v7/') and n in staged for n in untracked)
for n,d in staged.items():assert sha(frozen/n)==d,n
write(OUT/'staging-verification.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':proposal['scanner'],'frozen_checkout':str(frozen),'tracked_clean':True,'staged_files_sha256':staged,'existing_untracked_files_sha256':{n:sha(frozen/n) for n in untracked},'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'native_observations':0,'paid_calls':0,'target_execution':False})
write(OUT/'preparation-check-disposition.json',{'passed':True,'initial_preflight':'v39-preflight.json','initial_failure':'Read-only sysctl hw.ncpu/hw.memsize denied by filesystem execution sandbox before synthetic sequence. No target or corpus scan started.','corrected_preflight':'v39-preflight-permitted.json','correction':'Same helper rerun with authorized system/process access; no source change.','runner_source_correction':'runner-preparation-correction.json','supervisor_selfcheck':'supervisor-checks/selfcheck.json','native_observations':0,'paid_calls':0,'target_execution':False})
text='''The additional fresh-repository checkpoint is **prepared, unapproved and
unevaluated**. The user's “okay proceed with this” authorizes source preparation;
the exact evaluation remains a separate decision under the original closeout
prompt. Scanner **`8c62567`** was frozen before repository selection and remains
unchanged. A separate staging checkout preserves the original frozen checkout.

The selected independent repository is **`mkreyman/mcp-memory-keeper`** (MIT).
The maintainer's [CVE-2026-54561 advisory](https://github.com/mkreyman/mcp-memory-keeper/security/advisories/GHSA-f7wf-v2vw-mpcx)
documents `context_import` reading arbitrary local files before the 0.13.0 fix.
Complete upstream trees are retained: vulnerable **`dd53a8f` (0.12.2)** and fixed
**`84f6dfa` (0.13.0)**, compared against the fix merge's direct first parent.
The repository is absent from all **eight prior corpus manifests**; neither tree
matches any of **100 unique prior effective trees**, and no source file matches
a prior corpus source file. Curation occurred after scanner freeze by the same
implementation agent. This establishes repository novelty relative to the retained
corpora, not independent human review or training-data novelty.

The named SENT-012 condition is a caller-selected import file outside the
operator-owned exports directory. The vulnerable source reads the supplied path;
the fixed source canonicalizes it and checks equality or a directory-separator
boundary before reading file bytes. A sibling `exports-backup` directory must be
rejected; a file inside `exports` is the safe control. Startup, tool profile,
operator configuration and ordinary readable-file prerequisites are frozen.
The condition excludes symlink races, later parsing/database behavior and broader
filesystem safety. Source inspection is not target execution or runtime proof.

The exact proposal is
`artifacts/phase22/integration/v39-fresh-v7/evaluation-proposal.json`:
**six native rules-only observations**, original vulnerable/fixed/safe inputs
twice, **zero comparators**, one serial local macOS sequence, **120-second target /
300-second native and whole-input maximum**, at most **15 seconds cleanup per
input** and **40 minutes overall** (38-minute internal stop). It allows **zero
retries, profiles, detector changes, target executions, target dependency installs
or paid calls**. First infrastructure, timeout, identity, schema, cleanup or ordered
repeat failure closes the unused budget. Detection misses remain recorded outcomes.

Success requires the one vulnerable condition hit and zero matching alerts on
the two negatives in each batch, three entire ordered repeats, and source
assessment of all findings, warnings, unresolved flows and coverage. Fixed-path
support and guard recognition are reported separately: silence cannot establish
that the scanner understood the fix. Any unresolved fixed-path coverage requires
an explicit disposition before final acceptance. The existing manifest contract
retains 45 earlier records and two paired variable-renaming records; **all 47 are
outside this proposed evaluation**. Six repeats do not represent six independent
repositories or vulnerabilities.

Source/configuration validation and synthetic supervisor/sequence checks pass.
An initial preflight was blocked by sandboxed read-only system topology access;
the unchanged check passed with permitted access. A preparation-only repeat
reference assignment error was corrected and both versions are preserved. No
new corpus scan, comparator observation, target execution or paid call has run.

The prior **87/87 exposed regression pass at `8c62567` remains unchanged**:
36 whole ordered repeats; DDG two vulnerable hits per batch and zero matching
negative alerts; six actual fixed/control sends support initial 100.64.0.0/10
rejection on the direct `web_fetch` route. Python development passes 15/15
(six hits, seven valid negatives, two Meta operator erratum cases each retaining
two raw matched keys). Each 31-input Python historical batch has 14 hits and
zero matching alerts on 17 negatives. 74 observations met 120 seconds; 13 used
extended time; maximum whole-input time was 157.750767 seconds. That budget is
closed. Broader URL protection, other routes, DNS, redirects and IPv6 remain
outside the narrow DDG guard qualification.

Original fresh DDG detection remains measured at `f85a90f`: 10 native and five
Semgrep observations, two correlated vulnerable hits per native batch, zero
matching negative alerts and five whole ordered repeats; Semgrep hit 0/2.
Its original fixed coverage gap is preserved; the later correction is exposed
regression. Original Lighthouse and earlier fresh misses, the failed `a50e9b7`
regression, stopped experiments and all closed budgets remain unchanged. The
original held-out baseline remains 10 completed, 10 unsupported, five incomplete,
with zero hits among four completed vulnerable inputs out of ten vulnerable inputs.

Historical whole Linux timing retains its actual `1f3f72f` source: both 45-input
batches pass with 20 vulnerable hits and zero matching alerts on 25 negatives
each, with all 45 ordered repeats; the whole 25-input development batch is reused
under the user's explicit amendment. Current Python and compatible TypeScript
subsets are not pooled into a new whole execution. Prior exposed TypeScript and
Lighthouse evidence retains its documented `f85a90f` compatibility bindings.

Product, tests and workflows equal tested `8c62567`. Local and all 12 hosted
quality suites retain **2,283 passed / 36 skipped**, **89.91% local branch
coverage**, 29 normal CI jobs and docs passed. Affected documentation and package
metadata are checked separately; no new hosted code pass is claimed. Six zero-call
production replays and Git runtime/image compatibility retain exact source evidence.
**Git coverage remains incomplete at 312/1,040 attempts**, under the user deferral.

The audit retains all **89 original rows: 84 passed, two user-deferred and three
unresolved (R66/R88 for this additional fresh checkpoint, R84 for human acceptance)**.
All **110 added scope rows** remain: 104 passed, five proposed historical closure
dispositions and the new evaluation unresolved. Historical passes stay recorded;
the new test does not erase them. The earlier v38 acceptance proposal has not been
accepted and is postponed pending this additional evaluation and source assessment.
**Phase 22 remains incomplete.** Paid benchmark and pilots remain deferred;
Phase 21 remains incomplete and Phase 24/15 gates are unchanged. No merge,
ready-state change, release, outreach or Phase 23 is authorized.
'''
previous='## Current v38 regression pass and technical acceptance checkpoint\n\n'+(BASE/'v38-guard-regression/summary-final.md').read_text().split('\n\n',1)[1]+'\n'
current='## Current v39 additional fresh-repository preparation checkpoint\n\n'+text+'\n'
for n,d in old['owning_docs_sha256'].items():
 p=ROOT/n;assert sha(p)==d,n;s=p.read_text();assert s.count(previous)==1,n;p.write_text(s.replace(previous,current))
p=BASE/'README.md';s=p.read_text().replace('batches 1–66','batches 1–67',1)
start=s.index('Review [passed exposed regression]');end=s.index('\n',start)
s=s[:start]+'Review the [new six-observation proposal](v39-fresh-v7/evaluation-proposal.json), [89 + 110 row audit](v39-fresh-v7/audit.json), [source preparation](../corpus-replacement-v7/preparation.json) and [preserved exposed regression pass](v38-guard-regression/assessment.json). Restore seal 67 after seals 1–66, verifying every archive and member hash. Exact evaluation approval and final human technical acceptance remain pending.'+s[end:];p.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 additional fresh-repository preparation\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: another fresh repository prepared; evaluation approval pending\n\n'+text+'\nReview `artifacts/phase22/integration/v39-fresh-v7/` and `artifacts/phase22/corpus-replacement-v7/`. Seal 67 preserves preparation evidence after all 66 prior seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303579\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303580\n')
(ROOT/'artifacts/phase22/corpus-replacement-v7/README.md').write_text('# Replacement v7: memory-keeper source-only preparation\n\n'+text)
p=copy.deepcopy(read(BASE/'v38-guard-regression/audit-final.json'))
common='Additional user-requested fresh repository prepared after immutable8c62567 freeze; zero new observations. Priorv38 regression and engineering passes remain unchanged. Exactv39 six-native evaluation and source assessment precede explicit human acceptance.'
for r in p['requirements']:
 r['historical_v38_assessment']={k:r[k] for k in ['assessment','disposition','interpretation']};r['interpretation']=common
 if r['id'] in {'R66','R88'}:
  r['disposition']='unresolved';r['assessment']='Prior DDG fresh detection and corrected exposed fixed coverage retain their passes. The user requested another unseen repository before acceptance; new memory-keeper source preparation is complete, exact6-native evaluation unapproved and unevaluated. No new detection or guard-recognition result exists.'
 elif r['id']=='R84':r['assessment']='Human technical acceptance has not occurred. The user requested another fresh repository; earlier v38 acceptance proposal is postponed pending its exact evaluation, source assessments and renewed acceptance packet. Paid/pilot deferrals persist.'
 elif r['id'] in {'R62','R83'}:r['assessment']='Current documentation separates completedv38 regression from prepared, unapprovedv39 fresh evaluation. All historical outcomes, closed budgets, incompleteGit and deferred paid/pilots remain visible.'
for id,requirement,status in [('V39-PREPARATION','Prepare independent repository sources after scanner freeze; retain novelty, condition and zero-call controls','passed'),('V39-EVALUATION','Obtain exact approval, execute bounded six-native evaluation and source-assess detection plus fixed-path coverage','unresolved')]:
 p['additional_scope_requirements'].append({'id':id,'requirement':requirement,'disposition':status,'assessment':common,'evidence':['artifacts/phase22/integration/v39-fresh-v7/'+n for n in ['scope-and-precuration-freeze.json','evaluation-proposal.json','preflight.json','staging-verification.json','scoring-rubric.json']]})
p['prior_audit']={'path':'v38-guard-regression/audit-final.json','sha256':sha(BASE/'v38-guard-regression/audit-final.json')}
p['historical_v38_status_fields']={k:p[k] for k in ['status','current_continuation_corpus_observations','acceptance_packet_ready','technical_acceptance_requested','fresh_evaluation_status_basis','technical_acceptance_request_history']}
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),status=common,current_continuation_corpus_observations=0,current_compatibility_observations_this_continuation=0,additional_fresh_evaluation_prepared=True,additional_fresh_evaluation_approved=False,additional_fresh_evaluation_executed=False,additional_fresh_evaluation_native_observations=0,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,owning_document_binding='Finalv39 documentation binding follows docs/package checks and seal67.',fresh_evaluation_status_basis=common,technical_acceptance_request_history='Priorv38 proposal not accepted; user requested one additional fresh repository and approved preparation. Exact evaluation remains separate before renewed technical acceptance.')
p['current_source_and_test_files']={n:sha(ROOT/n) for n in p['current_source_and_test_files']}
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==110
assert p['dispositions']=={'passed':84,'unresolved':3,'explicitly user-deferred':2}
assert p['additional_scope_dispositions']=={'passed':104,'proposed documented limitation awaiting decision':5,'unresolved':1}
p['references_sha256'].update({str((OUT/n).relative_to(ROOT)):sha(OUT/n) for n in ['evaluation-proposal.json','preflight.json','staging-verification.json','scoring-rubric.json']})
write(OUT/'audit.json',p)
print('Prepared checkpoint reconciled; exact evaluation and technical acceptance remain pending.')
