"""Retain public source bytes without executing upstream code or installing dependencies."""
import json
import subprocess
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

from scripts.phase20_corpus import archive_files, digest, tree_digest

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = ROOT/'artifacts/phase22/corpus-replacement-v7'
REPO = 'mkreyman/mcp-memory-keeper'
FIX = '84f6dfa692736a34ff36e2d2cf2188b71facf73b'
assert (OUT/'scope-and-precuration-freeze.json').exists()
assert not BASE.exists()
(BASE/'provenance').mkdir(parents=True)
(BASE/'sources').mkdir()
metadata = json.loads((OUT/'candidate-commit.json').read_text())
assert metadata['sha'] == FIX and len(metadata['parents']) in {1,2}
(BASE/'provenance/upstream-fix.json').write_bytes((OUT/'candidate-commit.json').read_bytes())
repository = subprocess.check_output(['gh', 'api', f'repos/{REPO}'])
(BASE/'provenance/repository.json').write_bytes(repository)
info = json.loads(repository)
assert info['full_name'].casefold() == REPO.casefold() and not info['fork']
rows = []
for label, revision in [('vulnerable', metadata['parents'][0]['sha']), ('fixed', FIX)]:
    url = f'https://codeload.github.com/{REPO}/tar.gz/{revision}'
    with urllib.request.urlopen(url, timeout=45) as response:
        data = response.read(32*1024*1024+1)
    assert len(data) <= 32*1024*1024
    files = archive_files(data, strip_root=True)
    assert 'LICENSE' in files
    path = BASE/f'sources/memory-{label}.tar.gz'
    path.write_bytes(data)
    rows.append({'label':label, 'revision':revision, 'url':url, 'archive':str(path.relative_to(ROOT)), 'sha256':digest(data), 'file_count':len(files), 'tree_sha256':tree_digest(files)})
(BASE/'provenance/downloads.json').write_text(json.dumps({'recorded_at':datetime.now(timezone.utc).isoformat(), 'rows':rows, 'source_only':True, 'scans':0, 'paid_calls':0}, indent=2)+'\n')
print(json.dumps(rows,indent=2))
