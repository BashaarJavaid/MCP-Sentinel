"""Deliver the verified source-only proposal to the existing authorized draft."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
old=read(BASE/'v38-guard-regression/documentation-binding.json')
baseline='cb3f2347b2348fac4bff7a7553c581557553dec9';tested='8c6256725f0948ee593eb4b73e90baf6f7b0d76a'
assert run(['git','rev-parse','HEAD']).strip()==baseline
assert run(['git','branch','--show-current']).strip()=='phase22/integration'
assert not run(['git','diff','--cached'])
fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
pr=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'pre-delivery-pr37.json',pr)
assert pr['headRefOid']==baseline and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(BASE/'v38-guard-regression/pr-body-final.md').read_text()
parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,state,isDraft']));write(OUT/'pre-delivery-pr36.json',parent)
assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455';run(['git','merge-base','--is-ancestor',parent['headRefOid'],'HEAD'])
inputs=old['byte_identical_quality_inputs'];assert not run(['git','diff',tested,'--',*inputs])
protected=old['user_files_sha256']
corpus=ROOT/'artifacts/phase22/corpus-replacement-v7'
newfiles=[str(p.relative_to(ROOT)) for p in sorted(corpus.rglob('*')) if p.is_file()]
assert len(newfiles)>20 and not any(p.is_symlink() for p in corpus.rglob('*'))
stage=read(OUT/'staging-verification.json')
def verify_protected(allow_new):
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)| (set(newfiles) if allow_new else set())
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision']
  assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 folder=stage['frozen_checkout'];assert run(['git','rev-parse','HEAD'],folder).strip()==tested and not run(['git','diff','HEAD'],folder)
 assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(stage['existing_untracked_files_sha256'])
 for n,d in stage['staged_files_sha256'].items():assert sha(Path(folder)/n)==d,n
verify_protected(True)
proposal=read(OUT/'evaluation-proposal.json');audit=read(OUT/'audit.json')
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==110
assert audit['dispositions']=={'passed':84,'explicitly user-deferred':2,'unresolved':3}
assert audit['additional_scope_dispositions']=={'passed':104,'proposed documented limitation awaiting decision':5,'unresolved':1}
assert read(OUT/'preflight.json')['passed'] and read(OUT/'supervisor-checks/selfcheck.json')['passed']
assert not audit['additional_fresh_evaluation_executed'] and audit['current_continuation_corpus_observations']==0
for name in ['evaluation-authorization.json','binding.json','execution-consumed.json']:assert not (OUT/name).exists()
for n,d in audit['current_source_and_test_files'].items():assert sha(ROOT/n)==d,n
for label in ['v39-docs','v39-build','v39-distributions','v39-preflight-permitted']:
 assert read(BASE/(label+'.json'))['exit_code']==0,label
assert read(OUT/'owned-work.json')['owned_processes']==[]
for n,d in proposal['files_sha256'].items():assert sha(ROOT/n)==d,n
seal=read(BASE/'evidence-v67.json');assert sha(BASE/seal['archive'])==seal['sha256']
for r in seal['files']:assert sha(BASE/r['path'])==r['sha256'],r['path']
dist=read(OUT/'final-distributions.json');assert sha(ROOT/'README.md')==dist['README_sha256']
for r in dist['distributions']:assert sha(ROOT/r['path'])==r['sha256']
docs=list(old['owning_docs_sha256'])+['artifacts/phase22/corpus-replacement-v7/README.md']
refs=['audit.json','summary.md','pr-body.md','evaluation-proposal.json','preflight.json','preparation-check-disposition.json','runner-preparation-correction.json','staging-verification.json','scoring-rubric.json','final-distributions.json','deliver.py']
b={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':baseline,'tested_workflow':tested,'scanner':proposal['scanner'],'byte_identical_quality_inputs':inputs,'owning_docs_sha256':{n:sha(ROOT/n) for n in docs},'review_packet_sha256':{n:sha(OUT/n) for n in refs},'user_files_sha256':protected,'worktrees':old['worktrees'],'authorized_staged_frozen_artifacts_sha256':old['authorized_staged_frozen_artifacts_sha256'],'new_frozen_staging_verification':{'path':'v39-fresh-v7/staging-verification.json','sha256':sha(OUT/'staging-verification.json')},'new_corpus_files_sha256':{n:sha(ROOT/n) for n in newfiles},'evidence_seal':{'path':seal['archive'],'sha256':seal['sha256'],'members':len(seal['files'])},'source_preparation_approved':True,'evaluation_approved':False,'evaluation_executed':False,'new_native_observations':0,'proposed_native_observations':6,'new_paid_calls':0,'technical_acceptance_requested':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Post-seal binding directly tracked. Final docs and source hashes verified; product/tests/workflows equal tested8c62567. Source-only preparation, no new hosted pass or corpus observation; earlier acceptance proposal postponed until the additional fresh checkpoint.'}
write(OUT/'documentation-binding.json',b)
paths=sorted(set(docs+newfiles));extra=[str(p.relative_to(ROOT)) for p in [BASE/'evidence-v67.json',BASE/'evidence-v67.tar.gz',OUT/'documentation-binding.json']]
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','add','-f','--',*extra],check=True)
assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths+extra)
subprocess.run(['git','commit','-m','Prepare additional fresh MCP evaluation checkpoint [skip ci]'],check=True)
subprocess.run(['git','push','origin','phase22/integration'],check=True)
subprocess.run(['gh','pr','edit','37','--title','Phase 22: another fresh repository prepared; evaluation pending','--body-file',str(OUT/'pr-body.md')],check=True)
head=run(['git','rev-parse','HEAD']).strip();readbacks=[]
for attempt in range(5):
 pr=json.loads(run(['gh','pr','view','37','--json',fields]));readbacks.append(pr)
 if pr['headRefOid']==head and pr['body']==(OUT/'pr-body.md').read_text():break
 time.sleep(2)
write(OUT/'delivery-readback-history.json',readbacks);write(OUT/'delivery-readback.json',pr)
assert pr['headRefOid']==head and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning';assert pr['body']==(OUT/'pr-body.md').read_text()
assert json.loads(run(['gh','pr','view','36','--json','headRefOid']))['headRefOid']==parent['headRefOid']
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached']);verify_protected(False)
for n,d in b['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
write(OUT/'delivery-verification.json',{'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-readback.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':0,'evaluation_approved':False,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Supplemental ignored post-delivery receipt; sealed preparation and delivered commit remain immutable.'})
print('Verified existing OPEN draft delivery',head,pr['url'])
