"""Prepare the exact unchanged87-input-order regression at the corrected freeze."""
import hashlib,json,shutil
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v34-import-binding'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=json.loads((OLD/'evaluation-proposal.json').read_text());f=json.loads((OUT/'freeze.json').read_text())
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
for name in ['evaluate.py','scoring-rubric.json']:shutil.copyfile(OLD/name,OUT/name)
p.update(scanner=f['scanner'],frozen_checkout=f['frozen_checkout'],runner=str((OUT/'evaluate.py').relative_to(ROOT)))
p['purpose']='Verify preserved DDG initial-URL guard qualification on the exact direct caller route, without qualifying the uncertain search-derived sibling; restore narrow private-literal reporting on Meta and revalidate every affected Python input.'
p['execution']=p['execution'].replace('a50e9b7','8c62567')
p.pop('superseded_unapproved_proposal',None)
p['prior_closed_scopes']={'v35':{'proposal_sha256':sha(OLD/'evaluation-proposal.json'),'observations':87,'gate_passed':False,'remaining':0},'v37_diagnostic':{'proposal_sha256':sha(BASE/'v36-guard-recovery/diagnostic-proposal.json'),'observations':1,'diagnostic_passed':True,'remaining':0}}
p['source_assessment_baseline']={'packet':str((BASE/'v35-ddg-regression/raw/packet.json').relative_to(ROOT)),'assessment':str((BASE/'v35-ddg-regression/assessment.json').relative_to(ROOT)),'qualification':'Compare all new findings/diagnostics to the immediately prior whole87 observations as well as retained original condition assessments. Earlier measured false alarms and guard loss are not relabeled.'}
p['guard_controls']='Committed same-path guard sensitivity and the newly failing-before mixed-route/private-literal controls pass. The merge control checks every visit order and staged merge: an unguarded visit cancels only that same route qualification. All source labels, required actual sink and initial caller condition remain unchanged. A global or sibling-route qualification cannot satisfy the direct initial URL gate.'
p['prepared_command']=['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(OUT/'evaluate.py'),'run',str(BASE/'v38-guard-regression/raw')]
p['prepared_command_cwd']=f['frozen_checkout']
for name in ['evaluate.py','scoring-rubric.json','freeze.json','prepare-regression.py','source-proof.py','source-proof.json','diagnostic-assessment.json']:
 q=OUT/name;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
for name in ['raw/packet.json','assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json']:
 q=BASE/'v35-ddg-regression'/name;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
with (OUT/'evaluation-proposal.json').open('x') as file:json.dump(p,file,indent=2);file.write('\n')
print('Prepared87 observations at corrected8c62567; original rubric unchanged; no approval or execution.')
