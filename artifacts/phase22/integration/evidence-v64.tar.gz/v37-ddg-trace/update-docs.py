"""Deliver the measured diagnostic and verified correction without claiming regression success."""
import json
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());local=read(OUT/'local-checks.json');assert local['full_suite']['passed']==2283
coverage=local['full_suite']['branch_coverage_percent']
text=f'''The approved **single DDG diagnostic passes** at frozen **`a50e9b7`**:
**3.967 seconds native / 8.369 seconds whole input**, identical entire ordered
report after the established 11 volatile exclusions, valid JSON/SARIF, complete
trace and verified cleanup. All **1,066 events** were retained, with no dropped
events and all hooks restored. Its **one-observation budget is closed**.

The trace establishes that the direct `web_fetch` caller reaches the actual send
with its initial CGNAT guard recognized. A separate search-derived caller reaches
the same send without that qualification. Whole-location deduplication drops the
recognized direct-route qualification. The broader search-derived uncertainty
remains visible; the trace does not establish complete SSRF protection.

The approved source correction is frozen at **`8c62567`**. It preserves narrow
guard qualifications by analyzed caller route within **one canonical finding per
sink**. Conflicting guarded/unguarded visits to the same route cancel that route's
qualification. Other caller routes, later transformations, DNS, redirects and
broader destination protection remain unresolved. Python scheme plus six-flag
address guards now retain the existing narrow private-literal qualification;
they do not become CGNAT guards or universal SSRF suppression.

Both new reproductions failed before correction. The affected suite passes
**436 tests**. Full local and all **12 hosted quality suites pass 2,283 tests /
36 skips**; local branch coverage is **{coverage:.2f}%**. All **29 normal CI jobs**
and docs pass at actual `8c62567`; package members match Git blobs and all actual
CI checkout trees equal that source. Six exact production requests regenerate and
replay with **zero paid calls**. The abbreviated-revision replay check failure
and corrected runtime receipt are preserved. Existing Git runtime components and
image are unchanged; its **312/1,040 attempts remain incomplete**, as requested.

**No corrected-scanner corpus observation has occurred.** The next exact
**unapproved** proposal is
`artifacts/phase22/integration/v37-ddg-trace/evaluation-proposal.json`:
**87 native observations** at `8c62567` (five DDG inputs twice, 15 Python development
inputs once, 31 Python historical inputs twice), one local serial sequence,
120-second target, **300-second native/whole-input maximum**, 15-second cleanup,
**480-minute sequence maximum**, zero retries, profiles, comparators, target
execution or paid calls. The original rubric, inputs, conditions and **36 entire
ordered repeats** remain mandatory; qualification must cover the exact initial
caller route, never an uncertain sibling. Execution/identity/time/schema/cleanup/
repeat failure closes all unstarted observations. Detection changes require
individual source assessment after collection and confer no repair/retry authority.

The previous **v35 87-observation regression still fails** DDG guard coverage and
Meta compatibility at `a50e9b7`; its 79 target / eight extended completions,
241.846285-second maximum, 36 ordered repeats and every source assessment remain.
Original first-frozen DDG detection at `f85a90f` remains two vulnerable hits per
batch and zero matching negative alerts, with its original fixed-path limitation.
All original misses and exposed corrections remain distinct. TypeScript's prior
54-observation compatibility and ten Lighthouse observations retain compatible
source bindings; whole Linux timing remains at `1f3f72f`. No partial batches are
pooled and no new fresh-source, speedup or runtime protection claim is made.

The audit retains **89 original rows: 84 passed, two user-deferred and three
unresolved (R33, R65, R84)**, plus **106 added rows: 98 passed, five historical
proposed limitations and three unresolved**. Corrected DDG/Meta regression and
explicit human technical acceptance remain. **Phase 22 remains incomplete**;
paid benchmark/pilots stay deferred, Phase 21 incomplete and Phase 24/15 unchanged.
No merge, ready-state, release, outreach or Phase 23 is authorized.
'''
old='## Current v36 source-only investigation and diagnostic checkpoint\n\n'+(BASE/'v36-guard-recovery/summary.md').read_text().split('\n\n',1)[1]+'\n'
new='## Current v37 diagnostic and caller-route correction checkpoint\n\n'+text+'\n'
for name in read(BASE/'v36-guard-recovery/documentation-binding.json')['owning_docs_sha256']:
 p=ROOT/name;s=p.read_text();assert s.count(old)==1,name;p.write_text(s.replace(old,new))
p=BASE/'README.md';s=p.read_text().replace('batches 1–63','batches 1–64',1)
start=s.index('Review [source-only investigation](v36-guard-recovery/assessment.json)');end=s.index('\n',start)
s=s[:start]+'Review [measured diagnostic](v37-ddg-trace/diagnostic-assessment.json), [89 + 106 row audit](v37-ddg-trace/audit.json), [exact unapproved regression](v37-ddg-trace/evaluation-proposal.json) and the unchanged [regression rubric](v37-ddg-trace/scoring-rubric.json). Restore seal 64 after seals 1–63, verifying every archive and member hash. The [v35 failed regression](v35-ddg-regression/assessment.json) remains unchanged.'+s[end:];p.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 diagnostic and caller-route correction\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: caller-route guard correction; exposed regression pending\n\n'+text+'\nReview `artifacts/phase22/integration/v37-ddg-trace/` for the diagnostic assessment, correction/source bindings, verification and exact pending proposal. Seal64 preserves new evidence after all63 preceding seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303579\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34697303580\n')
print('Updated14 owning documents for measured diagnostic and verified correction; regression remains unapproved.')
