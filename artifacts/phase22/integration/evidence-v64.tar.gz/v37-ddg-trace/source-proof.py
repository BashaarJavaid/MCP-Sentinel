"""Bind unaffected TypeScript/runtime paths without executing corpus sources."""
import ast,hashlib,itertools,json,subprocess,sys
from pathlib import Path
from uuid import uuid4
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from sentinel.static import engine
from sentinel.static.model import StaticMatch
from sentinel.finding import SourceRange
from datetime import datetime,timezone
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
git=lambda *args:subprocess.check_output(['git',*args],text=True)
old='a50e9b7754a69042394306d5207b428f965d8e1d';new='8c6256725f0948ee593eb4b73e90baf6f7b0d76a'
assert git('rev-parse','HEAD').strip()==new
assert set(git('diff','--name-only',old,new,'--','src').splitlines())=={'src/sentinel/static/engine.py','src/sentinel/static/rules/sent015.py'}
def defs(source):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(source).body if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
a,b=[defs(git('show',v+':src/sentinel/static/rules/sent015.py')) for v in [old,new]]
assert a.keys()==b.keys() and [k for k in a if a[k]!=b[k]]==['URLFlow']
assert 'url_guard_paths' not in a['TypeScriptURLFlow']
assert not git('diff',old,new,'--','src/sentinel/static/path_flow.py','src/sentinel/static/typescript_path_flow.py','src/sentinel/static/typescript_discovery.py','src/sentinel/static/traversal.py','src/sentinel/static/workers.py','src/sentinel/static/model.py','src/sentinel/static/coverage.py','src/sentinel/config.py','scripts','uv.lock','pyproject.toml')
namespace=dict(vars(engine))
source=ast.parse(git('show',old+':src/sentinel/static/engine.py'))
functions=[n for n in source.body if isinstance(n,ast.FunctionDef) and n.name in {'_deduplicate','_finding_from_match'}]
exec(compile(ast.Module(body=functions,type_ignores=[]),'<retained scanner rendering>','exec'),namespace)
scopes=['','literal-ipv4','loopback-ipv4','loopback-ipv4-default','linklocal-ipv4'];count=0
for left,right in itertools.product(scopes,repeat=2):
 matches=[StaticMatch('SENT-015','server.ts',SourceRange(start_line=10,start_column=1,end_line=10,end_column=20),'fetch(url)',captures={'flow_locations':json.dumps([['server.ts',i]]),**({'url_guard_scope':scope} if scope else {})}) for i,scope in enumerate([left,right],1)]
 before=namespace['_deduplicate'](matches);after=engine._deduplicate(matches);assert before==after
 scan_id=uuid4();now=datetime.now(timezone.utc)
 for f,g in zip(before,after,strict=True):
  x=namespace['_finding_from_match'](f,scan_id,now).model_dump(mode='json');y=engine._finding_from_match(g,scan_id,now).model_dump(mode='json');x.pop('finding_id');y.pop('finding_id');assert x==y
 count+=1
prior=BASE/'v34-import-binding/source-proof.json';record=json.loads(prior.read_text());assert len(record['retained_typescript_inputs'])==44
for row in record['retained_typescript_inputs']:assert row['configuration_sha256']
packet={'source_only':True,'from_scanner':old,'to_scanner':new,'changed_product_files':['src/sentinel/static/engine.py','src/sentinel/static/rules/sent015.py'],'python_shared_flow_unchanged':True,'typescript_class_dispatch_and_restriction_function_unchanged':True,'new_captures_only_produced_by_python':True,'typescript_scope_pair_rendering_comparisons':count,'every_entire_match_and_finding_equal_except_random_finding_id':True,'prior_source_compatibility_sha256':sha(prior),'retained_typescript_inputs':record['retained_typescript_inputs'],'retained_measurements':'Original f85a90f 54-observation TypeScript compatibility and10-observation Lighthouse gate remain source-compatible through a50e9b7. No new measurements or speed claim.','corpus_observations':0,'paid_calls':0,'qualification':'Python DDG and all46 Python development/historical input records need a separate exact current-source regression decision. Original first-frozen DDG and whole Linux timing retain actual measured sources.'}
with (OUT/'source-proof.json').open('x') as f:json.dump(packet,f,indent=2);f.write('\n')
print('25 TypeScript scope-pair comparisons agree; unchanged TypeScript paths bound; zero corpus observations.')
