"""Bind completed engineering and unchanged regression conditions before approval."""
import hashlib,json,shutil,subprocess,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head='8c6256725f0948ee593eb4b73e90baf6f7b0d76a';assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==head
labels=['v37-full-suite','v37-lint','v37-format','v37-mypy','v37-lock','v37-schema','v37-notices','v37-artifacts','v37-production-capture-corrected','v37-affected-controls','v37-source-proof','v37-frozen-source-validation','v37-runner-boundaries','v37-runtime-compatibility-corrected']
checks=[]
for name in labels:
 f=BASE/(name+'.json');a=read(f);assert a['exit_code']==0,name;checks.append({'label':name,'metadata_sha256':sha(f),'log_sha256':sha(BASE/a['log']),'source':a['source_commit'],'command':a['command']})
full=read(BASE/'v37-full-suite.json');assert full['source_commit']==head and (BASE/'v37-full-suite.patch').read_bytes()==b''
counts=Counter();by_file={}
for c in ET.parse(BASE/'v37-full-suite-junit.xml').iter('testcase'):
 state='skipped' if c.find('skipped') is not None else 'failed' if c.find('failure') is not None or c.find('error') is not None else 'passed';counts[state]+=1
 parts=c.attrib['classname'].split('.')
 while not (ROOT/('/'.join(parts)+'.py')).exists():parts.pop();assert parts
 name='/'.join(parts)+'.py';by_file.setdefault(name,Counter())[state]+=1
assert counts=={'passed':2283,'skipped':36}
coverage=read(BASE/'v37-full-suite-coverage.json')['totals']['percent_covered'];assert coverage>=80
quality=read(BASE/'v37-quality/packet.json');assert quality['engineering_passed'] and quality['source']==head
audit=read(BASE/'v37-quality-audit/packet.json');assert len(audit['quality'])==12 and all(r['passed']==2283 and r['skipped']==36 for r in audit['quality'])
assert read(OUT/'compatibility.json')['scanner']==head
files=subprocess.check_output(['git','ls-tree','-r','--name-only',head,'--','src','tests','scripts','schemas','pyproject.toml','uv.lock','action.yml','.github','Makefile','LICENSE','CHANGELOG.md'],text=True).splitlines()
for n in files:assert subprocess.check_output(['git','show',head+':'+n])==(ROOT/n).read_bytes(),n
record={'scanner':read(OUT/'freeze.json')['scanner'],'actual_tested_source':head,'checks':checks,'full_suite':dict(counts,branch_coverage_percent=coverage),'tests_by_file':by_file,'source_files_sha256':{n:sha(ROOT/n) for n in files},'quality_packet_sha256':sha(BASE/'v37-quality/packet.json'),'quality_audit_sha256':sha(BASE/'v37-quality-audit/packet.json'),'six_production_requests_replayed':True,'paid_calls':0,'historical_evaluation_binding':'Pinned normal-CI reproductions retain8824014; no corrected8c62567 corpus observation yet.'}
with (OUT/'local-checks.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
failure={'expected_reproductions':{'receipt':'v37-root-controls-before.json','result':'Both mixed-route DDG qualifier and Meta private-literal qualifier assertions failed before source correction.'},'verification_corrections':[{'initial':'v37-production-capture.json','failure':'Abbreviated commit argument did not match exact40-character HEAD; assertion stopped before request construction or Docker execution.','corrected':'v37-production-capture-corrected.json','corrected_result':'Six exact production requests regenerate/replay; zero paid calls.'},{'initial':'compatibility-initial.json','failure':'Copied receipt contained a malformed scanner revision; actual component/image/request checks passed.','corrected':'compatibility.json','corrected_result':'Read-only checks repeated and exact corrected scanner hash verified.'}],'all_initial_files_retained':True,'diagnostic_failures':0,'additional_corpus_observations':0,'paid_calls':0}
with (OUT/'check-failure-assessment.json').open('x') as f:json.dump(failure,f,indent=2);f.write('\n')
path=OUT/'evaluation-proposal.json';p=read(path);shutil.copyfile(path,OUT/'evaluation-proposal-before-final-binding.json')
for name in ['validate-frozen-source.py','frozen-source-validation.json','compatibility.json','supervisor-check/selfcheck.json','finalize-preparation.py','local-checks.json','check-failure-assessment.json']:
 q=OUT/name;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
for name in ['v37-quality/packet.json','v37-quality-audit/packet.json',*[label+'.json' for label in labels]]:
 q=BASE/name;p['files_sha256'][str(q.relative_to(ROOT))]=sha(q)
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
assert sha(OUT/'scoring-rubric.json')==sha(BASE/'v34-import-binding/scoring-rubric.json')
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
path.write_text(json.dumps(p,indent=2)+'\n')
print('Local/hosted2283 passed36 skipped; exact87-observation proposal unapproved:',sha(path))
