"""Create and verify a complete immutable scanner checkout using COW artifacts."""
import datetime,hashlib,json,os,subprocess,sys
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
fixed=Path('/private/tmp/mcp-phase22-frozen-8c62567');revision='8c6256725f0948ee593eb4b73e90baf6f7b0d76a';assert not fixed.exists()
subprocess.run(['git','worktree','add','--no-checkout','--detach',str(fixed),revision],check=True)
subprocess.run(['/bin/cp','-cR','/private/tmp/mcp-phase22-frozen-a50e9b7/artifacts',str(fixed/'artifacts')],check=True)
subprocess.run(['git','checkout','HEAD','--','.',':!artifacts'],cwd=fixed,check=True)
changed=subprocess.check_output(['git','diff','--name-only','a50e9b7',revision,'--','artifacts'],text=True).splitlines()
if changed:subprocess.run(['git','checkout','HEAD','--',*changed],cwd=fixed,check=True)
subprocess.run(['git','reset','--mixed','HEAD'],cwd=fixed,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=fixed)
env={**os.environ,'PYTHONPATH':'src:.'}
identity=json.loads(subprocess.check_output([sys.executable,'-c','import json;from scripts.phase20_measurements import scanner_identity;print(json.dumps(scanner_identity()))'],cwd=fixed,env=env,text=True))
assert identity['revision']==revision
p={'scanner':identity,'frozen_checkout':str(fixed),'tracked_clean':True,'untracked_clean':True,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'harness_and_lock_sha256':{n:hashlib.sha256((fixed/n).read_bytes()).hexdigest() for n in ['uv.lock','scripts/phase20_corpus.py','scripts/phase22_corpus.py','scripts/phase20_measurements.py','scripts/phase20_scoring.py']},'source_exposure':'All DDG/compatibility inputs exposed before correction; original f85a90f fresh result unchanged.','storage':'Complete clean Git tree with copy-on-write artifact clones; source and tests checked out at actual8c62567.','new_corpus_observations':0,'paid_calls':0}
path=OUT/'freeze.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(identity))
