"""Verify unchanged engineering, complete stopped-budget evidence and final docs."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OLD = BASE/'v45-four-source-recovery'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

checks = ['v46-output-validation', 'v46-sampler-synthetic', 'v46-owned-cleanup', 'v46-assessment-preparation', 'v46-diagnostic-boundary', 'v46-reconciliation', 'v46-final-docs', 'v46-final-build-cached', 'v46-final-distributions']
for name in checks:
    assert read(BASE/(name+'.json'))['exit_code'] == 0, name
assert read(BASE/'v46-final-build.json')['exit_code'] == 1
engineering = read(OLD/'local-checks.json')['candidate_engineering_files_sha256']
assert len(engineering) == 302
for name, digest in engineering.items():
    assert sha(ROOT/name) == digest, name
    assert sha(Path('/private/tmp/mcp-phase22-frozen-17b4784')/name) == digest, name
binding = read(OLD/'documentation-binding.json')
for name, digest in binding['user_files_sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in read(OUT/'owning-docs.json')['sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in read(OLD/'prior-row-preservation.json')['referenced_evidence_sha256'].items():
    assert sha(ROOT/name) == digest, name
proposal = read(OUT/'diagnostic-proposal.json')
for name, digest in proposal['files_sha256'].items():
    assert sha(ROOT/name) == digest, name
assert not (OUT/'diagnostic-authorization.json').exists()
assert not (OUT/'diagnostic-consumed.json').exists()
assert not (BASE/'v47-faf-sampling').exists()
assert read(OUT/'assessment.json')['budget']['unstarted_closed'] == 204
assert read(OUT/'final-distributions.json')['wheel_product_schema_fixture_members_byte_identical_to_hosted']
audit = read(OUT/'audit.json')
assert len(audit['requirements']) == 89 and len(audit['additional_scope_requirements']) == 144
assert audit['requirements'] == read(OLD/'audit.json')['requirements']
assert not audit['technical_acceptance_received'] and not audit['phase22_complete']
assert not subprocess.check_output(['git', 'diff', '17b4784', '--', 'src', 'tests', 'scripts', 'schemas', '.github', 'uv.lock', 'pyproject.toml', 'CHANGELOG.md'])
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', '8b6b0ddf1d6f6cf5a8da3ab9421471865b801455', 'HEAD'], check=True)
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=main, text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=main)
provenance = {'wrapper_commands': {n: read(BASE/(n+'.json')) for n in checks+['v46-final-build']},
    'direct_commands': [
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'authorize-regression.py')], 'exit_code': 0, 'evidence': 'v45-four-source-recovery/execution-preflight.json', 'console': 'Exact205-observation approval recorded; frozen source and one-use launcher preflight passed. Zero observations started.'},
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'launch.py')], 'exit_code': 1, 'evidence': 'v46-four-source-regression/execution.json', 'console': 'No direct stdout; child output retained in sequence.log and raw input log.'}],
    'failure_assessment': 'The actual corpus attempt timed out and its budget closed. The separate first package command failed before producing a distribution; build-command-correction.json binds the successful established offline command. No other executed check failed.',
    'paid_calls': 0, 'retry_observations': 0}
write('command-provenance.json', provenance)
write('final-checks.json', {'passed': True, 'recorded_at': datetime.now(timezone.utc).isoformat(),
    'scanner': read(OLD/'freeze.json')['scanner'], 'engineering_files_verified': 302, 'prior_evidence_files_verified': len(read(OLD/'prior-row-preservation.json')['referenced_evidence_sha256']),
    'requirements': 233, 'protected_user_files': 8, 'owning_docs': 16, 'main_and_parent_preserved': True,
    'checks_sha256': {n: sha(BASE/(n+'.json')) for n in checks}, 'diagnostic_proposal_sha256': sha(OUT/'diagnostic-proposal.json'),
    'corpus_budget': read(OUT/'assessment.json')['budget'], 'diagnostic_executions': 0, 'paid_calls': 0,
    'technical_acceptance_received': False, 'phase22_complete': False})
print('Final checks passed:302engineering files,233requirements,16docs,closed205budget and unexecuted diagnostic.')
