import datetime,hashlib,json,subprocess
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');base=root/'artifacts/phase22/integration';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args):return subprocess.check_output(args,cwd=root,text=True)
def write(name,data):
 p=base/name;assert not p.exists(),name;p.write_text(json.dumps(data,indent=2)+'\n');return p
measured='2ac39aa9331818fd7e3a86c8323ee8307522c98c';hosted='592a9cd016537d827589567bf9be310d4e757c75'
starting='77ea21fa1f8c52f1f1ab11eba4d1cc8f2c24c7ef'
assert run(['git','rev-parse','HEAD']).strip()==starting
assert not run(['git','diff',hosted,starting,'--','src','tests','scripts','.github','schemas','Makefile','pyproject.toml','uv.lock','action.yml','README.md','LICENSE','CHANGELOG.md','THIRD_PARTY_NOTICES.md','.pre-commit-hooks.yaml','.python-version','.gitattributes','demo','sentinel.toml'])
inputs=['src','tests','scripts','.github','schemas','Makefile','pyproject.toml','uv.lock','action.yml','README.md','LICENSE','CHANGELOG.md','THIRD_PARTY_NOTICES.md','.pre-commit-hooks.yaml','.python-version','.gitattributes','demo','sentinel.toml']
native_inputs=['src','scripts','schemas','.github','uv.lock','pyproject.toml','action.yml','tests/fixtures']
assert not run(['git','diff',measured,hosted,'--',*native_inputs])
assert not run(['git','diff','HEAD','--',*inputs])
for label in ['v15-verification-final-command','v15-closeout-command','v15-final-docs-corrected-check']:
 assert json.loads((base/(label+'.json')).read_text())['exit_code']==0,label
host=json.loads((base/'v14-hosted-final/packet.json').read_text());assert host['engineering_passed'] and host['source']==hosted
fields='number,state,isDraft,title,headRefName,headRefOid,baseRefName,body';before=json.loads(run(['gh','pr','view','37','--json',fields]));parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,headRefName']))
assert before['state']=='OPEN' and before['isDraft'] and before['headRefName']=='phase22/integration' and before['baseRefName']=='phase22/description-poisoning'
assert before['headRefOid']==starting and parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455'
assert before['body']==(base/'v14-closeout-draft-body.md').read_text()
subprocess.run(['git','merge-base','--is-ancestor',parent['headRefOid'],hosted],cwd=root,check=True)
docs=list(json.loads((base/'v14-final-documentation-binding.json').read_text())['final_documents_sha256'])
subprocess.run(['git','diff','--check','--',*docs],cwd=root,check=True)
check=json.loads((base/'v15-final-docs-corrected-check.json').read_text());assert sha(base/'v15-final-docs-corrected-check.patch')==check['diff_sha256']
seal=json.loads((base/'evidence-v44.json').read_text());assert sha(base/seal['archive'])==seal['sha256']
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
binding={'recorded_at':now,'measured_source':measured,'profile_source':starting,'hosted_source':hosted,'scanner':json.loads((base/'v15-source-verification.json').read_text())['scanner'],'final_documents_sha256':{n:sha(root/n) for n in docs},'audit_sha256':sha(base/'v15-closeout-audit/packet.json'),'evidence_manifest_sha256':sha(base/'evidence-v44.json'),'evidence_archive_sha256':seal['sha256'],'next_combine_proposal_sha256':sha(base/'v15-next-combine-proposal.json'),'draft_body_sha256':sha(base/'v15-closeout-draft-body.md'),'final_docs_check_sha256':sha(base/'v15-final-docs-corrected-check.json'),'binding':'Final owning-document hashes supersede audit-stage document hashes only. Code/test/workflow/package inputs equal hosted592a9cd. Scanner/harness/configuration/fixture inputs equal measured2ac39aa; the retained typed regression test was validated by final592a9cd checks. This continuation changes no scanner/test input and claims no new full-suite run. This subsequent docs/evidence-only delivery uses authorized CI skip; final Git tree binds these bytes without a self-referential commit identity. No later hosted code pass is claimed.','new_paid_calls':0,'phase22_complete':False}
write('v15-final-documentation-binding.json',binding)
verification={'recorded_at':now,'delivery_parent':starting,'measured_source':measured,'profile_source':starting,'hosted_source':hosted,'remote_before':before,'parent_before':parent,'tested_inputs_identical_to_hosted':inputs,'native_inputs_identical_to_measured':native_inputs,'all_final_document_hashes_match':True,'raw_patch_hashes_match_original_captured_diffs':{'v15-final-docs-corrected-check':check['diff_sha256']},'diff_check_scope':docs,'diff_check_exit_code':0,'archive_sha256':seal['sha256'],'binding_sha256':sha(base/'v15-final-documentation-binding.json'),'new_paid_calls':0,'phase22_complete':False,'delivery_binding':'This receipt binds the verified pre-commit tree. Exact resulting commit and remote body readback are recorded after push in an explicitly local supplemental receipt; no self-referential commit hash is invented.'}
write('v15-delivery-verification.json',verification)
core=['evidence-v44.json','evidence-v44.tar.gz','v15-closeout-audit/packet.json','v15-closeout-draft-body.md','v15-final-documentation-binding.json','v15-delivery-verification.json','v15-next-combine-proposal.json','v15-combine-source-review.json','v15-merge-assessment.json','v15-delivery-preparation-correction.json','v15-delivery-corrected-command.untracked.tar.gz']+[f'{label}.{s}' for label in ['v15-closeout-command','v15-final-docs-check','v15-final-docs-corrected-check','v15-delivery-command','v15-delivery-whitespace-command'] for s in ['json','log','patch','untracked.tar.gz']]
subprocess.run(['git','add','--',*docs],cwd=root,check=True)
subprocess.run(['git','add','-f','--',*[str((base/n).relative_to(root)) for n in core]],cwd=root,check=True)
allowed=set(docs)|{str((base/n).relative_to(root)) for n in core};staged=set(run(['git','diff','--cached','--name-only']).splitlines());assert staged<=allowed,staged-allowed
subprocess.run(['git','diff','--cached','--check','--','.',':(exclude)artifacts/phase22/integration/*.patch'],cwd=root,check=True)
subprocess.run(['git','commit','-m','Seal bounded merge diagnostic and preserve verification [skip ci]'],cwd=root,check=True)
head=run(['git','rev-parse','HEAD']).strip();assert not run(['git','diff',hosted,head,'--',*inputs])
for name,digest in binding['final_documents_sha256'].items():assert sha(root/name)==digest
subprocess.run(['git','push','origin','phase22/integration'],cwd=root,check=True)
subprocess.run(['gh','pr','edit','37','--body-file',str(base/'v15-closeout-draft-body.md')],cwd=root,check=True)
after=json.loads(run(['gh','pr','view','37','--json',fields]));assert after['headRefOid']==head and after['isDraft'] and after['state']=='OPEN' and after['baseRefName']==before['baseRefName'] and after['body']==(base/'v15-closeout-draft-body.md').read_text()
assert not run(['git','diff','HEAD'])
expected_prompts={f'docs/{n}.md' for n in ['phase22-completion-agent-prompt','phase22-detection-timing-closeout-agent-prompt','phase22-final-agent-prompt']};assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==expected_prompts
write('v15-final-delivery-readback.json',{'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'delivered_head':head,'measured_source':measured,'profile_source':starting,'hosted_source':hosted,'remote_after':after,'verification_sha256':sha(base/'v15-delivery-verification.json'),'binding_sha256':sha(base/'v15-final-documentation-binding.json'),'all_final_document_hashes_match':True,'tested_inputs_equal':True,'tracked_worktree_clean':True,'user_prompts_preserved':sorted(expected_prompts),'new_paid_calls':0,'phase22_complete':False,'storage':'Supplemental ignored local post-delivery receipt. The final tracked/sealed packet is the Git tree at delivered_head.'})
print(head)
