"""Finish read-only delivery verification after GitHub's initial stale PR head."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v41-path-guard-recovery'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
old=read(OLD/'documentation-binding.json');protected=old['user_files_sha256'];stage=read(BASE/'v39-fresh-v7/staging-verification.json')
def verify_protected():
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 folder=stage['frozen_checkout'];assert run(['git','rev-parse','HEAD'],folder).strip()=='8c6256725f0948ee593eb4b73e90baf6f7b0d76a' and not run(['git','diff','HEAD'],folder)
 assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(stage['existing_untracked_files_sha256'])
 for n,d in stage['staged_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 fixed=Path(read(OLD/'freeze.json')['frozen_checkout'])
 for n,d in read(OLD/'frozen-source-validation.json')['source_receipts_staged'].items():assert sha(fixed/n)==d,n
verify_protected()
head=run(['git','rev-parse','HEAD']).strip();assert head=='c9637ba6ce0ffdbda5e639ea6eb1baa785599e9b'
r=read(OUT/'delivery-recheck-1.json');pr=r['pr'];binding=read(OUT/'documentation-binding.json')
assert r['local_head']==pr['headRefOid']==r['remote_branch']['object']['sha']==head
assert pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(OUT/'pr-body.md').read_text()
assert r['parent']['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455'
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached'])
assert not run(['git','diff',binding['tested_workflow'],'--',*binding['byte_identical_quality_inputs']])
for n,d in binding['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
for n,d in binding['review_packet_sha256'].items():assert sha(OUT/n)==d,n
assert read(OUT/'assessment.json')['detection_and_coverage_gate_passed']
assert read(BASE/'v42-delivery.json')['exit_code']==1
initial=read(OUT/'delivery-readback-history.json');assert len(initial)==5
assert all(p['headRefOid']=='7574bd9fbfbfdf8a8f639dd9af123f1950c73386' and p['body']==pr['body'] for p in initial)
record={'recorded_at':datetime.now(timezone.utc).isoformat(),'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-recheck-1.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'acceptance_proposal_sha256':sha(OUT/'acceptance-proposal.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':94,'exposed_regression_passed':True,'technical_acceptance_received':False,'phase22_complete':False,'initial_delivery_failure':{'receipt_sha256':sha(BASE/'v42-delivery.json'),'log_sha256':sha(BASE/'v42-delivery.log'),'history_sha256':sha(OUT/'delivery-readback-history.json'),'observed':'Commit and push succeeded, and PR body matched. All five initial PR reads still reported the prior7574bd9 head, causing the exact delivery assertion to fail.','resolution':'A subsequent PR and remote branch API read both report c9637ba and the exact draft/base/body. No second push, PR edit, evaluation, retry or paid call occurred. Protected worktrees and final document/source hashes reverified.'},'qualification':'Supplemental ignored post-delivery receipt; the sealed evidence and delivered commit remain immutable. This receipt and recovery helper will join the next evidence seal; they are not claimed inside the commit they verify.'}
with (OUT/'delivery-verification.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Verified delivered draft PR37',head,'after retained stale-head readback; no repeat push or evaluation.')
