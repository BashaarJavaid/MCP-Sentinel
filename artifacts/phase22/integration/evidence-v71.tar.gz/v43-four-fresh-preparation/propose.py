"""Freeze the concrete proposal; this file does not grant evaluation approval."""
import json
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd(); OUT = Path(__file__).resolve().parent
BASE = ROOT/'artifacts/phase22/corpus-four-fresh-v2'
sys.path[:0] = [str(ROOT), str(ROOT/'src')]
from scripts.phase20_corpus import digest

def ref(p):
    return {'path':p.relative_to(ROOT).as_posix(), 'sha256':digest(p.read_bytes())}
def save(p, value):
    with p.open('x') as f:
        json.dump(value,f,indent=2);f.write('\n')
    return ref(p)

checkpoint_path = BASE/'checkpoint-2e0efb2.json'
checkpoint = json.loads(checkpoint_path.read_text())
freeze = json.loads((OUT/'scope-and-precuration-freeze.json').read_text())
staging = {}
def visit(value):
    if isinstance(value, dict):
        if set(value) == {'path','sha256'}:
            p = ROOT/value['path']; assert ref(p) == value
            assert value['path'].startswith('artifacts/phase22/')
            staging[value['path']] = value['sha256']
        else:
            for item in value.values(): visit(item)
    elif isinstance(value,list):
        for item in value: visit(item)
for case in checkpoint['repositories']:
    visit(json.loads((ROOT/case['manifest']['path']).read_text()))
for p in BASE.rglob('*'):
    if p.is_file(): staging[p.relative_to(ROOT).as_posix()] = digest(p.read_bytes())
staging_ref = save(OUT/'staging-files.json', staging)
rubric = {'status':'frozen_before_first_observation', 'cases':ref(OUT/'cases-v2.json'),
          'matching':'Each case condition-review.json defines its exact rule, caller argument, real sink, guard, prerequisites and scope. Require a finding identifying that flow and the missing/ineffective scored boundary. Rule ID or line overlap, warnings, metadata-only operations and unrelated sinks are insufficient. Record every matching key and source rationale. A generic false assertion of the named boundary violation remains a matching false alert, even in an upstream fixed tree.',
          'narrow_ssrf':'Lightning scores only initial literal IPv4 link-local rejection. A broader destination/DNS/redirect candidate with an explicit accurate initial link-local exclusion does not claim this named violation. Lack of qualification for the named initial boundary does not become an unrelated finding merely because source is fixed.',
          'negative_support':'Zero matching fixed/safe alerts counts toward discrimination only if source-bound scanner analysis actually covers the named caller-to-sink path and effective relevant guard/value. Assess discovery/dispatch and guard/sink support separately from counts. Existing native schema has no positive per-sink guard trace; do not invent one. Unsupported/absent/unresolved fixed paths that prevent this conclusion fail this support gate and require explicit disposition. No silent denominator exclusion.',
          'success_per_repository':{'vulnerable_hits_per_pass':1,'matching_fixed_safe_alerts_per_pass':0,'supported_fixed_safe_paths_required':True,'complete_inputs_per_pass':3,'passes':2,'entire_ordered_repeat_pairs':3},
          'overall_success':'All four repository gates pass independently, all24reports complete/valid within bounds, and all12entire ordered pairs equal. Four repository cases are four conditions, not24independent discoveries or population accuracy.',
          'assessment':'Assess every finding, warning, unresolved flow, surface and coverage entry in every report against retained source. Preserve unrelated candidates, unmatched raw scorer totals, actual support/completion denominators, failures and timing classes. Identical occurrences may share an explicit source judgment with occurrence-level bindings. No target runtime safety claim.',
          'repeat_exclusions':['scan_id','finding_id','timestamp','started_at','completed_at','duration_ms','reviewed_at','applied_at','latency_ms','execution_latency_ms','origin_latency_ms'],
          'collection_stop':'Infrastructure, identity, execution, timeout, native/SARIF schema, cleanup or entire ordered-repeat failure stops and closes all unused budget. Detection misses, false alerts and unsupported fixed paths remain outcomes and do not alone stop collecting the other approved sources. No tuning, retry, replacement, comparator or extra observation is authorized.',
          'history':'Original heldout/fresh misses and later exposed corrections remain at their actual scanner revisions. Same-agent source curation is not independent human review or model-training-data novelty.'}
rubric_ref = save(OUT/'scoring-rubric.json', rubric)
files = dict(staging)
for p in [*BASE.rglob('*'), OUT/'scope-and-precuration-freeze.json', OUT/'cases-v2.json', OUT/'novelty-comparison.json', OUT/'runner.py', OUT/'launch.py', OUT/'build-runner.py', OUT/'check-runner.py', OUT/'runner-synthetic-checks.json', OUT/'supervisor-checks/selfcheck.json', OUT/'scoring-rubric.json', OUT/'staging-files.json', OUT/'preparation-baseline.json', OUT.parent/'v20-linux-diagnostic-v1/runner.py']:
    if p.is_file(): files[p.relative_to(ROOT).as_posix()] = digest(p.read_bytes())
for label in ['faf','no-bash','lightning','engram']:
    for suffix in ['repository','security-fix' if label == 'faf' else 'fix']:
        p = OUT/f'research/{label}-{suffix}.json'; files[p.relative_to(ROOT).as_posix()] = digest(p.read_bytes())
proposal = {'status':'prepared_not_approved_not_executed', 'recorded_at':datetime.now(timezone.utc).isoformat(),
    'decision_requested':'Approve exactly one serial local macOS sequence at frozen2e0efb2: four distinct repositories, two TypeScript/two Python, vulnerable/fixed/safe inputs twice,24native observations. No additional paid calls, comparator, profiles, retries, source replacement, target execution or installation. This is not Phase22 technical acceptance.',
    'scanner':freeze['scanner'], 'lock_sha256':freeze['lock_sha256'], 'frozen_checkout':'/private/tmp/mcp-phase22-four-fresh-2e0efb2',
    'checkpoint':ref(checkpoint_path), 'pre_curation_freeze':ref(OUT/'scope-and-precuration-freeze.json'), 'scoring_rubric':rubric_ref, 'novelty':checkpoint['novelty'],
    'repositories':checkpoint['repositories'], 'input_order':checkpoint['input_order'], 'batch_order':['rules-first','rules-repeat'],
    'bounds':{'local_sequences':1, 'hosted_dispatches':0, 'native_observations':24, 'comparator_observations':0, 'normal_target_seconds':120, 'native_and_whole_input_maximum_seconds':300, 'cleanup_maximum_seconds_per_input':15, 'sequence_maximum_minutes':150, 'internal_stop_minutes':148, 'shutdown_reserve_minutes':2, 'profiles':0, 'retries':0, 'paid_calls':0, 'target_execution':False, 'target_dependency_installation':False, 'detector_changes':0},
    'ceiling_rationale':'24*300s=120input-minutes plus24*15s=6cleanup-minutes;22minutes bounded setup/validation/finalization margin before148-minute internal stop,2additional minutes reserved for shutdown within150minutes. SIGALRM stops the parent collection at the internal deadline; outer retained supervisor enforces9000s. Child creation/import/materialization/analysis/report handling share each300s whole-input allowance. No child starts without315s before internal stop. No rounding tolerance or second initialization allowance.',
    'environment':'Existing local macOS locked /Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python with isolated -I imports from the separately staged frozen2e0efb2 checkout. Python3.12.13,Semgrep1.176.0,mcp1.29.0,pytest9.0.3,pydantic2.13.4. Record actual full packages,CPU,memory,load,commands and process cleanup. No concurrent owned timing work.',
    'staging':staging_ref, 'runner':ref(OUT/'runner.py'), 'launcher':ref(OUT/'launch.py'),
    'approval_contract':'After the exact user decision only, create one main evaluation-authorization.json binding this proposal/checkpoint/scanner/bounds/order; derive four per-manifest authorizations carrying the exact decision and main receipt hash for existing frozen()/measure() validation. Bind every final input/runner/approval byte in binding.json. One-use launch output and execution-consumed receipt prohibit replay. No old approval or unused historical budget applies.',
    'command_after_approval':['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(OUT/'launch.py')],
    'output':'artifacts/phase22/integration/v44-four-fresh-evaluation',
    'stop':rubric['collection_stop'],
    'safety':'Rules-only/static-only; model transport forbidden, OPENAI_/SENTINEL_ environment values removed, cache disabled. Native analysis never imports/executes target source, installs target dependencies, starts services, contacts endpoints or follows source symlinks. All target startup/environment values in conditions are source prerequisites, not actions. Synthetic supervision uses scanner-owned dummy Python only.',
    'unevaluated':'All8format-required mutation records and eachmanifest45retained records remain unexecuted. Previous manifests stay unchanged; no new whole50/25/45 batch claim.',
    'acceptance':'All existing89original and115addedrequirements remain. New evaluation/source assessments precede a separate explicit technical acceptance and closeout delivery. Git312/1040 incomplete,paidbenchmark/pilots deferred,Phase21incomplete,Phase24/15unchanged. No merge/ready/release/outreach/Phase23.',
    'files_sha256':files, 'technical_acceptance_received':False, 'phase22_complete':False}
save(OUT/'evaluation-proposal.json',proposal)
print('Frozen exact24-observation proposal; not approved and not executed. Checkpoint',proposal['checkpoint']['sha256'])
