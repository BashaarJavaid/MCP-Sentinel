"""Test the final approval contract in temporary paths, without scanner calls."""
import copy
import importlib.util
import json
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('approval_runner', OUT/'runner.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
p = r.verify_packet(); original_cwd = Path.cwd()
checks = []
os.chdir(p['frozen_checkout'])
try:
    try: r.approved()
    except FileNotFoundError: checks.append('actual evaluation denied: no user authorization exists')
    else: raise AssertionError('unapproved evaluation accepted')
    with tempfile.TemporaryDirectory(prefix='phase22-four-approval-test-') as tmp:
        assets = Path(tmp); (assets/'authorizations').mkdir()
        approval_path = assets/'authorization.json'
        decision = {'approved':True, 'user_decision':'SYNTHETIC VALIDATION ONLY: never authorizes a scanner invocation.', 'proposal_sha256':r.sha(r.PROPOSAL), 'checkpoint_sha256':p['checkpoint']['sha256'], 'scanner':p['scanner'], 'bounds':p['bounds'], 'input_order':p['input_order']}
        def setup(d):
            r.write(approval_path,d)
            for case in p['repositories']:
                r.write(assets/'authorizations'/(case['id']+'.json'), {'approved':True,'parent_authorization_sha256':r.sha(approval_path),'user_decision':d['user_decision'],'corpus':{'manifest':case['manifest']['path'],'sha256':case['manifest']['sha256'],'freeze_approved':True,'input_ids':case['input_ids'],'treatments':['rules']}})
            r.write(assets/'binding.json', {'files':{}})
        with patch.object(r,'ASSETS',assets), patch.object(r,'APPROVAL',approval_path):
            setup(decision); r.approved(); checks.append('complete synthetic approval structure accepted by validator only')
            for field,value in [('approved',False),('proposal_sha256','0'*64),('checkpoint_sha256','0'*64),('input_order',list(reversed(p['input_order']))),('bounds',{**p['bounds'],'native_observations':25}),('scanner',{**p['scanner'],'source_sha256':'0'*64})]:
                setup({**decision,field:value})
                try: r.approved()
                except AssertionError: checks.append('rejected altered '+field)
                else: raise AssertionError(field)
            for field,value in [('input_ids',p['input_order']),('treatments',['semgrep']),('freeze_approved',False),('sha256','0'*64)]:
                setup(decision); path=assets/'authorizations'/(p['repositories'][0]['id']+'.json'); child=json.loads(path.read_text()); child['corpus'][field]=value; r.write(path,child)
                try: r.approved()
                except AssertionError: checks.append('rejected altered manifest authorization '+field)
                else: raise AssertionError(field)
finally:
    os.chdir(original_cwd)
result={'passed':True,'checks':checks,'proposal_sha256':r.sha(r.PROPOSAL),'runner_sha256':r.sha(OUT/'runner.py'),'scanner_observations':0,'paid_calls':0,'target_execution':False,'actual_authorization_exists':r.APPROVAL.exists(),'temporary_synthetic_authorizations_removed':True}
assert not result['actual_authorization_exists']
with (OUT/'approval-checks-final.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
