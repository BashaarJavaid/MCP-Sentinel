"""Four source-only packets using the existing immutable 50-record schema."""
import copy
import difflib
import gzip
import io
import json
import re
import sys
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'artifacts/phase22/corpus-four-fresh-v1'
sys.path[:0] = [str(ROOT), str(ROOT / 'src')]
from scripts import phase20_measurements as h
from scripts.phase20_corpus import archive_files, digest, input_files, materialize, tree_digest
from scripts.phase20_corpus import validate as validate20
from scripts.phase22_corpus import validate

def ref(p):
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': digest(p.read_bytes())}

def save(p, obj):
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x') as f:
        json.dump(obj, f, indent=2); f.write('\n')
    return ref(p)

freeze = json.loads((OUT / 'scope-and-precuration-freeze.json').read_text())
actual = h.scanner_identity()
assert all(actual[k] == freeze['scanner'][k] for k in ['source_sha256', 'harness_sha256'])
assert digest((ROOT / 'uv.lock').read_bytes()) == freeze['lock_sha256']
cases = json.loads((OUT / 'cases.json').read_text())
assert sorted(c['language'] for c in cases) == ['python', 'python', 'typescript', 'typescript']
assert len({c['repository'].casefold() for c in cases}) == 4
old_path = ROOT / 'artifacts/phase22/corpus-replacement-v7/manifest.json'
old = json.loads(old_path.read_text())
previous = json.loads((old_path.parent / 'provenance/novelty.json').read_text())
prior_manifests = previous['prior_manifests'] + [ref(old_path)]
prior_trees, prior_repositories = {}, set(previous['excluded_repositories'])
for record in prior_manifests:
    p = ROOT / record['path']
    assert ref(p)['sha256'] == record['sha256'], record['path']
    m = validate20(p) if p.suffix == '.yaml' else validate(p)
    snapshots = {s.revision: s for s in m.snapshots}
    for item in m.inputs:
        prior_repositories.add(item.repository.casefold())
        if item.tree_sha256 not in prior_trees:
            prior_trees[item.tree_sha256] = {n: digest(b) for n, b in input_files(item, snapshots[item.snapshot]).items()}
comparison = json.loads((OUT / 'novelty-comparison.json').read_text())
assert not comparison['archive_read_failures']
assert all('::' in r['path'] and r['term'] == 'wolfe-jam' and r['path'].endswith('/README.md') for r in comparison['name_matches'])
old_faf = json.loads((OUT / 'research/faf-old-name.json').read_text())
new_faf = json.loads((OUT / 'research/faf-repository.json').read_text())
assert old_faf['id'] != new_faf['id']
assert 'ubidev/engram' not in prior_repositories
novelty = save(BASE / 'novelty.json', {
    'passed': True, 'precuration_freeze': ref(OUT / 'scope-and-precuration-freeze.json'),
    'prior_manifests': prior_manifests, 'prior_effective_trees_checked': len(prior_trees),
    'excluded_repositories': sorted(prior_repositories), 'full_baseline_comparison': ref(OUT / 'novelty-comparison.json'),
    'name_match_assessment': "Five historical modelcontextprotocol/servers README catalog entries link Wolfe-Jam/claude-faf-mcp (ID 1056826668); selected faf-mcp is distinct ID 1056798446. This is incidental same-owner ecosystem metadata, not previous source selection or tuning of either FAF server. No prior FAF source is present. Relationship retained explicitly.",
    'source_overlap_assessment': "Only empty Engram tests/__init__.py and Lightning py.typed match previous bytes. No substantive candidate source matches any prior regular archive member or baseline source file. No complete effective tree matches. Engram's ubidev parent/source family is absent from the prior identity records.",
    'limits': comparison['limits'], 'target_execution': False, 'observations': 0,
})
packets = []
for case in cases:
    label, family = case['archive_label'], case['id']
    assert case['repository'].casefold() not in prior_repositories
    directory = BASE / family
    metadata = json.loads((OUT / f'research/{label}-repository.json').read_text())
    fix_path = OUT / ('research/faf-security-fix.json' if label == 'faf' else f'research/{label}-fix.json')
    fix = json.loads(fix_path.read_text())
    assert metadata['full_name'].casefold() == case['repository'].casefold()
    trees, downloads, snapshots = {}, {}, []
    for version in ['vulnerable', 'fixed']:
        path = OUT / f'research/source-archives/{label}-{version}.tar.gz'
        row = json.loads(path.with_suffix('.json').read_text())
        files = archive_files(path.read_bytes(), strip_root=True)
        assert digest(path.read_bytes()) == row['sha256'] and tree_digest(files) == row['tree_sha256']
        assert {n: digest(b) for n, b in files.items()} == row['files_sha256']
        assert tree_digest(files) not in prior_trees
        assert all(n in files for n in case['licenses'])
        if label == 'no-bash':
            assert json.loads(files['package.json'])['license'] == 'MIT'
            assert re.search(r'##\s*License\s+MIT', files['README.md'].decode(), re.I)
        else:
            assert all(b'MIT License' in files[n] for n in case['licenses'])
        trees[version], downloads[version] = files, row
        snapshots.append({'repository': case['repository'], 'revision': row['revision'], 'url': row['url'], 'archive': ref(path), 'licenses': case['licenses'], 'files': row['files_sha256']})
    assert fix['sha'] == downloads['fixed']['revision']
    assert fix['parents'][0]['sha'] == downloads['vulnerable']['revision']
    a, b = trees['vulnerable'], trees['fixed']
    changed = sorted(n for n in a.keys() | b.keys() if a.get(n) != b.get(n))
    directory.mkdir(parents=True, exist_ok=False)
    diff = ''.join(''.join(difflib.unified_diff(a.get(n,b'').decode(errors='replace').splitlines(True), b.get(n,b'').decode(errors='replace').splitlines(True), fromfile='vulnerable/'+n, tofile='fixed/'+n)) for n in changed)
    (directory / 'full-pair.diff').write_text(diff)
    review = save(directory / 'condition-review.json', {**case, 'reviewer': 'Same implementation agent after immutable scanner freeze; source-only, not independent human review.',
        'vulnerable_revision': downloads['vulnerable']['revision'], 'fixed_revision': downloads['fixed']['revision'],
        'actual_first_parent_verified': True, 'all_changed_files': changed, 'full_pair_diff': ref(directory / 'full-pair.diff'),
        'actual_detector_support': 'Unmeasured. Existing Python/TypeScript path and HTTPX sink families are relevant, but source-level reachability does not establish actual discovery, dispatch, guarded value propagation or fixed-path coverage at this frozen scanner. Those are mandatory post-run source-assessment gates. No positive per-sink guard trace is assumed.',
        'negative_rule': 'Fixed and safe use the same complete upstream fixed tree and configuration, with distinct frozen source prerequisites/labels. A static report is not specialized by the illustrative caller value. Broad candidates remain visible. Zero matching alerts count as discrimination only when the named fixed/safe path is demonstrably within scanner support.',
        'source_archives': [s['archive'] for s in snapshots], 'target_execution': False, 'observations': 0, 'paid_calls': 0})
    provenance = save(directory / 'provenance.json', {'repository_metadata': ref(OUT / f'research/{label}-repository.json'), 'upstream_fix': ref(fix_path), 'download_receipts': [ref(OUT / f'research/source-archives/{label}-{v}.tar.json') for v in trees], 'novelty': novelty, 'condition_review': review,
        'fork': metadata['fork'], 'parent': metadata.get('parent', {}).get('full_name'), 'source': metadata.get('source', {}).get('full_name'), 'notes': case['provenance_notes']})
    old_family = next(p['id'] for p in old['pairs'] if p['rule_id'] == case['rule_id'] and any(i['family'] == p['id'] and i['split'] == 'held_out' for i in old['inputs']))
    template = next(i for i in old['inputs'] if i['family'] == old_family and i['label'] == 'vulnerable' and i['variant'] == 'original')
    def evidence(files):
        return [{'path': n, 'start_line': 1, 'end_line': len(files[n].splitlines()), 'sha256': digest(files[n]), 'role': 'Complete source-bound caller, guard, actual sink or startup/configuration context; see condition-review.json.'} for n in case['evidence_files'] if n in files]
    inputs = []
    for version, files in trees.items():
        item = {**copy.deepcopy(template), 'id': family+'-'+version, 'family': family, 'repository': case['repository'], 'language': case['language'], 'snapshot': downloads[version]['revision'], 'label': version, 'condition': case['condition'], 'prerequisites': case['prerequisites'], 'scan_root': case['scan_root'], 'tree_sha256': tree_digest(files), 'evidence': evidence(files),
            'static_applicability': 'Source-established MCP caller and supported operation family; actual scanner dispatch/guard/sink support requires post-evaluation assessment.',
            'matching': 'Require '+case['rule_id']+' on the named '+case['tool']+' caller '+case['argument']+' flowing to the actual scored sink and asserting the frozen boundary violation. Rule/line overlap or generic diagnostics alone do not match.'}
        inputs.append(item)
        text = files[case['mutation_file']].decode()
        start = text.index(case['mutation_start']); end = text.index(case['mutation_end'], start+1)
        block, count = re.subn(r'\b'+case['mutation_identifier']+r'\b', case['mutation_replacement'], text[start:end])
        assert count >= 2 and case['mutation_replacement'] not in text
        modified = (text[:start]+block+text[end:]).encode()
        assert modified.decode().replace(case['mutation_replacement'], case['mutation_identifier']) == text
        overlay = directory / (version+'-unevaluated-rename.tar.gz')
        with overlay.open('xb') as stream, gzip.GzipFile(fileobj=stream, mode='wb', mtime=0, filename='') as gz, tarfile.open(fileobj=gz, mode='w') as archive:
            info = tarfile.TarInfo(case['mutation_file']); info.size=len(modified); info.mode=0o644
            archive.addfile(info, io.BytesIO(modified))
        assert archive_files(overlay.read_bytes(), strip_root=False) == {case['mutation_file']: modified}
        mutated = {**files, case['mutation_file']: modified}
        inputs.append({**copy.deepcopy(item), 'id':item['id']+'-mutation', 'variant':'mutation', 'parent':item['id'], 'overlay':ref(overlay), 'transformation':f"Reversible identifier rename {case['mutation_identifier']} -> {case['mutation_replacement']} inside the selected function, {count} occurrences. Schema-only record; explicitly excluded from all proposed observations.", 'tree_sha256':tree_digest(mutated), 'evidence':evidence(mutated)})
    inputs.append({**copy.deepcopy(inputs[2]), 'id':family+'-safe', 'variant':'safe_control', 'label':'safe', 'condition':case['condition']+' Safe input uses '+case['inside']+' under the stated prerequisites.', 'prerequisites':case['prerequisites']+['For this safe record only, replace the scored caller value with '+case['inside']+'. The complete fixed source and static configuration remain unchanged.']})
    manifest = copy.deepcopy(old)
    manifest['methodology'] = 'Four-fresh-v1 '+family+': one of four distinct repository cases at frozen2e0efb2. Separate manifest reuses the established schema; retain45other records byte-for-byte and add5source records, only3original/safe records proposed twice. Prior manifests unchanged; no new whole50batch, mutations, comparator or runtime execution.'
    manifest['snapshots'] += snapshots
    kept = [i for i in old['inputs'] if i['family'] != old_family]
    manifest['inputs'] = kept + inputs
    manifest['pairs'] = [p for p in old['pairs'] if p['id'] != old_family] + [{'id':family, 'rule_id':case['rule_id'], 'fix_origin':'upstream', 'provenance':[provenance, review, novelty], 'review':case['flow']}]
    manifest['packet'] += [provenance, review, novelty, ref(directory/'full-pair.diff')]
    manifest['repository_aliases'][case['repository'].casefold()] = case['repository']
    manifest_ref = save(directory/'manifest.json', manifest)
    m = validate(directory/'manifest.json')
    assert manifest['inputs'][:45] == kept
    configs = {}; sources = {s.revision:s for s in m.snapshots}
    for item in m.inputs[-5:]:
        with tempfile.TemporaryDirectory(prefix='phase22-four-source-only-') as tmp:
            target = materialize(item, sources[item.snapshot], Path(tmp).resolve()/'source', m.packet)
            config = h.load_configuration(target, environ={}, static_only=True, cli_overrides={'rules_only':True, 'ignore_paths':['.phase20/**'], 'max_findings_per_scan':500}, llm_cli_overrides={'model':h.LLM.model, 'reasoning_effort':'medium', 'retries':0, 'max_concurrency':1, 'cache_enabled':False})
            payload = {'scanner':config.scanner.model_dump(mode='json'), 'target':config.target.model_dump(mode='json') if config.target else None, 'static_only':config.static_only, 'language':config.language.value}
            assert payload['language'] == case['language'], (item.id, payload['language'])
            configs[item.id] = {'configuration':payload, 'sha256':digest((json.dumps(payload, indent=2, sort_keys=True)+'\n').encode())}
    config_ref = save(directory/'configurations.json', configs)
    packets.append({'id':family, 'repository':case['repository'], 'language':case['language'], 'rule_id':case['rule_id'], 'manifest':manifest_ref, 'configuration':config_ref, 'condition_review':review, 'provenance':provenance, 'input_ids':[inputs[i]['id'] for i in [0,2,4]], 'unexecuted_mutation_ids':[inputs[i]['id'] for i in [1,3]], 'unchanged_prior_records':45, 'snapshots':snapshots})
    print('Prepared', family, '; source-only configuration language:',case['language'], flush=True)
save(BASE/'checkpoint-2e0efb2.json', {'status':'prepared_pending_exact_evaluation_approval', 'recorded_at':datetime.now(timezone.utc).isoformat(), 'scanner':freeze['scanner'], 'precuration_freeze':ref(OUT/'scope-and-precuration-freeze.json'), 'cases':ref(OUT/'cases.json'), 'novelty':novelty, 'repositories':packets, 'input_order':[i for p in packets for i in p['input_ids']], 'observations':0, 'paid_calls':0, 'target_execution':False, 'evaluation_approved':False, 'technical_acceptance_received':False, 'phase22_complete':False})
print('All four packets prepared: zero scans, zero target execution, zero paid calls.')
