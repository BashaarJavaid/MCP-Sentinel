"""Synthetic-only control-flow checks; this never imports or measures a target."""
import copy
import importlib.util
import json
import tempfile
from contextlib import redirect_stdout
from pathlib import Path
from unittest.mock import patch

OUT = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('four_runner', OUT/'runner.py')
r = importlib.util.module_from_spec(spec); spec.loader.exec_module(r)
checkpoint = json.loads((OUT.parents[1]/'corpus-four-fresh-v2/checkpoint-2e0efb2.json').read_text())
proposal = {'input_order':checkpoint['input_order'], 'batch_order':['rules-first','rules-repeat'],
            'scanner':checkpoint['scanner'], 'bounds':{'internal_stop_minutes':148},
            'repositories':checkpoint['repositories'], 'frozen_checkout':str(Path.cwd())}
results = []
for scenario in ['complete_with_false_alerts', 'infrastructure_failure', 'ordered_repeat_failure', 'identity_failure']:
    with tempfile.TemporaryDirectory(prefix='phase22-four-synthetic-') as tmp:
        assets = Path(tmp); raw = assets/'raw'; raw.mkdir()
        for name in ['proposal.json','approval.json','binding.json']:
            (assets/name).write_text('{}\n')
        counter = [0]; identity_calls = [0]
        def identity(_):
            identity_calls[0] += 1
            if scenario == 'identity_failure' and identity_calls[0] == 2:
                raise AssertionError('synthetic identity mismatch')
        def supervise(command, log, limit):
            assert limit == 300
            counter[0] += 1
            batch, input_id, destination = command[-3:]
            destination = Path(destination); (destination/input_id).mkdir(parents=True)
            report = {'static_analysis':{'duration_ms':1}, 'findings':[{'synthetic_false_alert':True}], 'warnings':['retained'], 'coverage':{'synthetic':True}, 'timestamp':str(counter[0])}
            if scenario == 'ordered_repeat_failure' and counter[0] == 13:
                report['warnings'].append('different')
            r.write(destination/'results.json', {'outcomes':[{'input_id':input_id, 'state':'completed'}]})
            r.write(destination/'validation.json', {'passed':True, 'synthetic_only':True})
            r.write(destination/input_id/'report.json', report)
            return {'returncode':1 if scenario == 'infrastructure_failure' and counter[0] == 2 else 0,
                    'timed_out':False, 'cleanup_verified':True, 'remaining_group_killed':False,
                    'elapsed_seconds':0.01, 'elapsed_including_cleanup_seconds':0.02}
        with patch.object(r,'ASSETS',assets), patch.object(r,'PROPOSAL',assets/'proposal.json'), patch.object(r,'APPROVAL',assets/'approval.json'), patch.object(r,'approved',return_value=proposal), patch.object(r,'check_identity',identity), patch.object(r.supervisor,'supervise',supervise), patch.object(r.supervisor,'selfcheck',lambda _:None), (assets/'stdout.log').open('w') as log, redirect_stdout(log):
            try:
                r.run(raw)
            except AssertionError:
                assert scenario != 'complete_with_false_alerts'
            else:
                assert scenario == 'complete_with_false_alerts'
        result = json.loads((raw/'packet.json').read_text())
        expected = {'complete_with_false_alerts':24, 'infrastructure_failure':2, 'ordered_repeat_failure':13, 'identity_failure':1}[scenario]
        assert len(result['attempts']) == expected and len(result['unstarted']) == 24-expected
        assert result['budget_closed'] and result['remaining_observation_budget'] == 0
        assert result['passed'] == (scenario == 'complete_with_false_alerts')
        assert all(x['command'][1] == '-I' for x in result['attempts'])
        if result['passed']:
            assert sum(x.get('ordered_repeat_equal',False) for x in result['attempts']) == 12
        results.append({'scenario':scenario, 'attempts':expected, 'unstarted_closed':24-expected, 'passed':True})
r.selfcheck()
result = {'passed':True, 'controls':results, 'boundary_and_eleven_field_canonicalizer_checks':True,
          'real_process_supervision_checks':'supervisor-checks/selfcheck.json', 'scanner_observations':0,
          'target_execution':False, 'paid_calls':0, 'method':'Run the actual parent collection loop with synthetic supervision/results and temporary authorization-path placeholders. No child scanner invocation or target import. Actual authorization validation is checked separately against the final proposal.'}
with (OUT/'runner-synthetic-checks.json').open('x') as f:
    json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
