"""Preserve the full audit and document the unapproved four-repository scope."""
import copy
import hashlib
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd(); OUT = Path(__file__).resolve().parent; BASE = OUT.parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ref = lambda p: {'path':p.relative_to(ROOT).as_posix(),'sha256':sha(p)}
def save(path,value):
    with path.open('x') as f:json.dump(value,f,indent=2);f.write('\n')

p = json.loads((OUT/'evaluation-proposal.json').read_text())
old_path = BASE/'v42-path-guard-regression/audit.json'
old = json.loads(old_path.read_text())
verification = json.loads((OUT/'prior-requirement-verification.json').read_text())
assert not verification['missing'] and len(verification['rows']) == 204
assert json.loads((OUT/'approval-checks.json').read_text())['passed']
assert json.loads((OUT/'runner-synthetic-checks.json').read_text())['passed']
assert not (OUT/'evaluation-authorization.json').exists() and not (OUT/'execution-consumed.json').exists()
new = [
    ('V43-SCOPE','Freeze unchanged scanner and protected workspace before source-only curation','passed',['scope-and-precuration-freeze.json','preparation-baseline.json']),
    ('V43-NOVELTY','Prepare four distinct project-unused repository families, exactly two actual TypeScript and two Python configurations; disclose aliases/forks/copied-code checks','passed',['novelty-comparison.json','cases-v2.json']),
    ('V43-SOURCE','Retain complete upstream pairs, licenses/declarations, safe controls, conditions/prerequisites and source-bound caller/guard/sink review','passed',['cases-v2.json','preparation-corrections.json']),
    ('V43-RUNNER','Prepare existing evaluator for the exact24-observation order, approval checks, deadlines, cleanup and ordered-repeat collection without scanner previews','passed',['runner.py','runner-synthetic-checks.json','approval-checks.json','supervisor-checks/selfcheck.json']),
    ('V43-COMPATIBILITY','Verify unaffected engineering, prior204requirement bindings and protected history without remeasurement','passed',['compatible-reuse.json','prior-requirement-verification.json']),
    ('V43-PREPARATION-DELIVERY','Complete affected docs/package checks, seal evidence and verify delivery of concrete proposal to the existing draft','unresolved',[]),
    ('V43-APPROVAL','Obtain exact new user evaluation approval bound to frozen sources/scanner/configurations/rubric/runner/order/bounds','unresolved',['evaluation-proposal.json']),
    ('V43-EVALUATION','Execute only the approved24native observations or accurately close stopped/unstarted budget, preserving every first-frozen outcome','unresolved',['evaluation-proposal.json']),
    ('V43-ASSESSMENT','Assess every new report occurrence and each repository detection/discrimination/support/repeat/timing gate, preserving failures without automatic waivers','unresolved',['scoring-rubric.json']),
    ('V43-ACCEPTANCE-CLOSEOUT','Obtain explicit human technical acceptance of the completed final packet and verified subsequent closeout delivery, retaining deferrals','unresolved',['scope-and-precuration-freeze.json']),
]
added = copy.deepcopy(old['additional_scope_requirements'])
for name,requirement,status,evidence in new:
    added.append({'id':name,'requirement':requirement,'disposition':status,'evidence':[(OUT/n).relative_to(ROOT).as_posix() for n in evidence], 'assessment':'Source-only preparation; zero fresh observations and zero paid/target calls. Detection, fixed-path support, technical acceptance and final delivery are not inferred from preparation.'})
audit = {'recorded_at':datetime.now(timezone.utc).isoformat(),'source':p['scanner']['revision'],'scanner_identity':p['scanner'],
         'requirements':copy.deepcopy(old['requirements']),'additional_scope_requirements':added,
         'dispositions':dict(Counter(r['disposition'] for r in old['requirements'])),
         'additional_scope_dispositions':dict(Counter(r['disposition'] for r in added)),
         'prior_audit':ref(old_path),'historical_v42_status_fields':{k:v for k,v in old.items() if k not in {'requirements','additional_scope_requirements'}},
         'current_requirement_interpretations':{r['id']:'The complete prior row remains historical and source-bound. The new four-repository gate is pending separately; no v42 readiness/measurement field grants new approval or current acceptance.' for r in old['requirements']+old['additional_scope_requirements']},
         'current_evidence':{'proposal':ref(OUT/'evaluation-proposal.json'),'checkpoint':p['checkpoint'],'prior_requirement_verification':ref(OUT/'prior-requirement-verification.json'),'engineering_reuse':ref(OUT/'compatible-reuse.json')},
         'four_repository_prepared':True,'four_repository_approved':False,'four_repository_executed':False,'proposed_native_observations':24,'current_continuation_corpus_observations':0,'new_paid_calls':0,'target_executions':0,
         'acceptance_packet_ready':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'phase22_complete':False,
         'status':'Four source-only cases prepared at immutable2e0efb2. Exact evaluation approval, execution/source assessment, explicit technical acceptance and verified closeout remain. Priorv42 readiness is superseded; all historical outcomes and limitations retain their actual sources.'}
audit['current_requirement_interpretations']['R66'] = 'Original fresh/heldout failures and later exposed corrections remain. User requested four additional fresh repositories before acceptance; preparation is complete, results and any final disposition remain pending.'
audit['current_requirement_interpretations']['R88'] = audit['current_requirement_interpretations']['R66']
audit['current_requirement_interpretations']['R84'] = 'Explicit technical acceptance remains unresolved. Pilots and paid benchmark are user-deferred/nonblocking; incomplete Git coverage retains its actual user deferral. New24-observation scope is not yet approved.'
save(OUT/'audit.json',audit)

summary = '''# Four-repository fresh evaluation preparation

**Prepared, not approved or executed. Phase 22 remains incomplete.** The user requested two new TypeScript repositories and two Python repositories before technical acceptance. The scanner was frozen at `2e0efb268b733a14d7eca87555fdd87f134ba78c` before source research; no detector preview, comparator, target execution or paid call occurred.

| Repository / actual selected language | Named condition | Vulnerable commit | Upstream fixed commit |
| --- | --- | --- | --- |
'''
cases=json.loads((OUT/'cases-v2.json').read_text())
for case,row in zip(cases,p['repositories'],strict=True):
    versions={s['revision'] for s in row['snapshots']}; assert len(versions)==2
    summary += f"| [{case['repository']}](https://github.com/{case['repository']}) / {case['language']} | `{case['tool']}`: {case['condition']} | `{row['snapshots'][0]['revision']}` | `{row['snapshots'][1]['revision']}` |\n"
summary += '''
Each repository supplies its original vulnerable input, upstream fixed input and a distinct safe-control record. Controls use the fixed tree with a safe illustrative caller value; static analysis is not specialized to that value. All complete archives, actual first-parent relationships, member/tree hashes, configurations and source prerequisites are frozen in the [checkpoint](../../../corpus-four-fresh-v2/checkpoint-2e0efb2.json). Four separate manifests reuse the existing 50-input schema: 45 prior records remain byte-for-byte unchanged in each, and eight required mutation records remain explicitly unexecuted. No historical manifest is modified.

Novelty checks cover nine prior manifests, 104 effective source trees, the complete baseline text inventory and 2,910 distinct retained archives. No substantive source file matches; only empty `tests/__init__.py` and `py.typed` overlap. Five historical catalog entries link the same owner's **different** `claude-faf-mcp` repository (distinct GitHub ID); the relationship is disclosed. Engram is a fork of `ubidev/engram`; both identities are absent from prior source-selection records. This establishes recorded project-source novelty only, with same-agent source curation and no independent human or training-data novelty claim.

FAF, Lightning and Engram retain their complete MIT licenses. No-bash has MIT declarations in its README and package metadata but no standalone license or full grant text; all actual declaration files are preserved, and GitHub's null license metadata is disclosed. FAF's security fix precedes its later v2.1.3 changelog tag. Lightning is a mixed C#/Python repository; the actual selected Python member and configuration are verified. Engram requires an operator-configured PostgreSQL database and `ENGRAM_EMBEDDER=none` for the source-established route; an initial unapproved draft's incorrect SQLite prerequisite is preserved and superseded. None of these target setup prerequisites is executed.

The [proposal](evaluation-proposal.json) requests **24 native observations**, one serial local macOS sequence, frozen scanner source SHA-256 `0eac8832012e213744d752c6c33a0ba6a2e378f6230e273030f5043f00cf6ebb`, harness SHA-256 `9bfc9229b7ec7d23580c44f2306edb9274bc1d2a3c2261d01db0445b8b480add`, unchanged lock and isolated locked Python 3.12.13. Order is the table order, vulnerable/fixed/safe for each repository, followed by the same twelve-input repeat. The 120-second target, 300-second native/whole-input maximum and 15-second cleanup cap remain; sequence ceiling is 150 minutes, internal stop 148 minutes, with two minutes reserved for shutdown. No child starts without its full 315 seconds fitting before the internal stop.

Infrastructure, identity, execution, timeout, schema, cleanup or ordered-repeat failure stops and closes unused budget. Detection misses, false alerts and unsupported fixed paths are retained outcomes and do not alone abort remaining collection. The [rubric](scoring-rubric.json) requires vulnerable detection on both passes, zero matching fixed/control alerts **with actual relevant support**, and all twelve entire ordered reports equal after only the established eleven volatile exclusions. A quiet report alone is insufficient; native reports do not emit a positive per-sink guard trace. All findings, warnings, unresolved flows and surfaces require source assessment. No tuning, retry, comparator, replacement, target execution or paid call is included.

The retained evaluator and process supervisor pass synthetic collection, failure/closure, timeout/cleanup, approval and ordered-report controls. Four source-only manifests/configuration sets validate. All 301 engineering inputs still equal tested `2e0efb2`; local and all twelve hosted suites retain 2,317 tests / 36 skips, local branch coverage 89.915%, all 29 normal jobs in CI `34712751779` and docs `34712751789`. This preparation is not a new hosted code pass. Six production-request replays and Git runtime/image bindings remain compatible without additional calls or runtime work.

Current exposed TypeScript evidence remains 94/94 at `2e0efb2`, 47 ordered repeats, maximum whole input 106.857 seconds. Python's 87 observations remain measured at `8c62567`; historical whole 25 development reuse and 45+45 Linux timing/condition passes remain at `1f3f72f`, with the Meta operator erratum. Partial language subsets are never pooled into a new whole execution. Memorykeeper's original fresh fixed/control false alerts, DDG's original unsupported fixed send and wrong manifest language label, Lighthouse's original misses, all earlier corrections and closed failed attempts remain preserved. The original heldout baseline remains ten completed, ten unsupported and five incomplete, zero hits among four completed vulnerable inputs out of ten vulnerable inputs total.

The [audit](audit.json) preserves all 89 original and 115 added rows in full and adds ten explicit continuation requirements. The original statuses remain 84 passed, two user-deferred, two proposed documented limitations and one unresolved human acceptance; the earlier added rows retain 109 passed and six proposed historical closure decisions. None of the eight proposed limitations/closures is accepted by this preparation. The new rows separate preparation, approval, execution, source assessment and acceptance/closeout. Prior v42 readiness is historical and superseded.

Git campaigns remain **312/1,040 incomplete**, paid benchmark and external pilots remain deferred, Phase 21 remains incomplete, and Phase 24/15 gates remain unchanged. Historical approved Phase 22 model spend is $0.071799; this continuation adds **$0 and zero calls**. Final technical acceptance is a separate explicit human decision after the actual four-repository outcomes and completed packet. No merge, ready-state change, release, outreach or Phase 23 is authorized.
'''
# Relative checkpoint link is from integration/v43 to phase22/corpus (two parents).
summary=summary.replace('../../../corpus-four-fresh-v2/','../../corpus-four-fresh-v2/')
(OUT/'summary.md').write_text(summary)
(OUT/'pr-body.md').write_text(summary.replace('# Four-repository fresh evaluation preparation', '# Phase 22: four fresh repositories prepared; exact evaluation approval pending').replace('(evaluation-proposal.json)','(https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v43-four-fresh-preparation/evaluation-proposal.json)').replace('(scoring-rubric.json)','(https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v43-four-fresh-preparation/scoring-rubric.json)').replace('(audit.json)','(https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v43-four-fresh-preparation/audit.json)').replace('(../../corpus-four-fresh-v2/checkpoint-2e0efb2.json)','(https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/corpus-four-fresh-v2/checkpoint-2e0efb2.json)'))
old_binding=json.loads((BASE/'v42-path-guard-regression/documentation-binding.json').read_text())
for name in old_binding['owning_docs_sha256']:
    path=ROOT/name; text=path.read_text(); first,rest=text.split('\n',1)
    link=('https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v43-four-fresh-preparation/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md',path.parent))
    status=f'''\n## Current four-repository preparation: exact evaluation approval pending

Two new TypeScript repositories (FAF and no-bash) and two Python repositories
(Lightning's Python member and Engram) are source-prepared at frozen `2e0efb2`.
The [reviewable preparation packet]({link}) proposes 24 native observations;
**zero have run and no evaluation approval has been received**. Actual fixed-path
support and first-frozen detection/discrimination remain unmeasured. All prior
results, failures, closed budgets and proposed historical limitations remain intact.
The v42 acceptance-readiness statement below is historical and superseded by this
new requirement. **Phase 22 remains incomplete** pending exact evaluation approval,
execution/source assessment, explicit human technical acceptance and verified closeout.
No new paid calls; Git 312/1,040 remains incomplete, paid benchmark/pilots deferred,
Phase 21 incomplete and Phase 24/15 gates unchanged. No merge, ready-state, release,
outreach or Phase 23 is authorized.
'''
    assert '## Current four-repository preparation:' not in text
    path.write_text(first+'\n'+status+rest.replace('## Current v42 regression result and pending technical acceptance','## Historical v42 regression result and pending technical acceptance',1))
for version,state in [('v1','Superseded unapproved draft: Engram storage prerequisite corrected in v2; zero observations.'),('v2','Current source-only packet: exact24-observation evaluation proposal is unapproved; zero observations.')]:
    path=ROOT/f'artifacts/phase22/corpus-four-fresh-{version}/README.md'
    path.write_text(f'# Four-repository corpus {version}\n\n{state}\n\nSee the [preparation summary](../integration/v43-four-fresh-preparation/summary.md), complete per-repository manifests, source reviews and checkpoint. All original source archives and historical manifests are preserved.\n')
print('Preserved204audit rows, added10scope rows and reconciled15owning documents; no approval inferred.')
