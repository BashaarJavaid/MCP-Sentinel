"""Adapt the retained v39 evaluator, preserving its measurement and supervision."""
from pathlib import Path

OUT = Path(__file__).resolve().parent
source = (OUT.parent / 'v39-fresh-v7/runner.py').read_text()
def replace(old, new):
    global source
    assert source.count(old) == 1, old
    source = source.replace(old, new)

replace('"""Bounded replacement-v7 evaluation; requires a separate exact approval."""', '"""Bounded four-repository evaluation; requires separate exact approval."""')
replace('CORPUS = DELIVERY / "artifacts/phase22/corpus-replacement-v7"\n', '')
start = source.index('def verify_packet():'); end = source.index('\ndef configuration(', start)
source = source[:start] + '''def verify_packet():
    proposal = json.loads(PROPOSAL.read_text())
    for name, digest in proposal["files_sha256"].items():
        assert sha(DELIVERY / name) == digest, name
    assert proposal["batch_order"] == ["rules-first", "rules-repeat"]
    assert len(proposal["input_order"]) == 12 and len(set(proposal["input_order"])) == 12
    assert proposal["bounds"]["native_observations"] == 24
    assert [i for c in proposal["repositories"] for i in c["input_ids"]] == proposal["input_order"]
    assert sorted(c["language"] for c in proposal["repositories"]) == ["python", "python", "typescript", "typescript"]
    return proposal


def approved():
    proposal = verify_packet()
    assert Path.cwd().resolve() == Path(proposal["frozen_checkout"]).resolve()
    approval = json.loads(APPROVAL.read_text())
    assert approval["approved"] is True and approval["user_decision"].strip()
    assert approval["proposal_sha256"] == sha(PROPOSAL)
    assert approval["checkpoint_sha256"] == proposal["checkpoint"]["sha256"]
    assert approval["scanner"] == proposal["scanner"] and approval["bounds"] == proposal["bounds"]
    assert approval["input_order"] == proposal["input_order"]
    for case in proposal["repositories"]:
        path = ASSETS / "authorizations" / (case["id"] + ".json")
        decision = json.loads(path.read_text())
        assert decision["approved"] is True
        assert decision["parent_authorization_sha256"] == sha(APPROVAL)
        assert decision["user_decision"] == approval["user_decision"]
        assert decision["corpus"] == {
            "manifest": case["manifest"]["path"], "sha256": case["manifest"]["sha256"],
            "freeze_approved": True, "input_ids": case["input_ids"], "treatments": ["rules"],
        }
    binding = json.loads((ASSETS / "binding.json").read_text())
    for name, digest in binding["files"].items():
        assert sha(DELIVERY / name) == digest, name
    return proposal

''' + source[end:]
replace('    validate(Path.cwd() / proposal["manifest"]["path"])', '    for case in proposal["repositories"]:\n        validate(Path.cwd() / case["manifest"]["path"])')
start = source.index('def check_identity():'); end = source.index('\ndef child(', start)
source = source[:start] + '''def check_identity(input_id):
    from scripts import phase20_measurements as harness
    from scripts.phase22_corpus import frozen
    from sentinel.static.engine import STATIC_TIMEOUT_SECONDS

    proposal = approved()
    assert harness.scanner_identity() == proposal["scanner"]
    assert sha(Path.cwd() / "uv.lock") == proposal["lock_sha256"]
    assert STATIC_TIMEOUT_SECONDS == 300
    case = next(c for c in proposal["repositories"] if input_id in c["input_ids"])
    approval_path = ASSETS / "authorizations" / (case["id"] + ".json")
    manifest = frozen(approval_path=approval_path)
    selected = [i for i in manifest.inputs if i.id in case["input_ids"]]
    assert [i.id for i in selected] == case["input_ids"]
    return proposal, manifest, selected, case, approval_path

''' + source[end:]
replace('    proposal, manifest, selected = check_identity()', '    proposal, manifest, selected, case, approval_path = check_identity(input_id)')
replace('    configs = json.loads((CORPUS / "configurations.json").read_text())', '    configs = json.loads((DELIVERY / case["configuration"]["path"]).read_text())')
replace('            phase22_approval=APPROVAL,', '            phase22_approval=approval_path,')
replace('    assert result["manifest_sha256"] == proposal["manifest"]["sha256"]', '    assert result["manifest_sha256"] == case["manifest"]["sha256"]')
replace('    assert result["authorization_sha256"] == sha(APPROVAL)', '    assert result["authorization_sha256"] == sha(approval_path)')
replace('def run(out):\n    proposal = approved()', 'def run(out):\n    sequence_start = time.monotonic()\n    proposal = approved()\n    signal.signal(signal.SIGALRM, supervisor.stopped)\n    signal.setitimer(signal.ITIMER_REAL, max(0.001, proposal["bounds"]["internal_stop_minutes"] * 60 - (time.monotonic() - sequence_start)))')
replace('        stop = time.monotonic() + proposal["bounds"]["internal_stop_minutes"] * 60', '        stop = sequence_start + proposal["bounds"]["internal_stop_minutes"] * 60')
replace('            check_identity()', '            check_identity(observation["input_id"])')
replace('        assert len(packet["attempts"]) == 6 and not packet["unstarted"]', '        assert len(packet["attempts"]) == 24 and not packet["unstarted"]')
replace('        packet["budget_closed"] = True', '        signal.setitimer(signal.ITIMER_REAL, 0)\n        packet["elapsed_sequence_seconds"] = time.monotonic() - sequence_start\n        packet["budget_closed"] = True\n        packet["remaining_observation_budget"] = 0')
with (OUT / 'runner.py').open('x') as f:
    f.write(source)
print('Adapted retained v39 evaluator for four manifests, 24 observations and a bounded sequence alarm. No execution.')
