"""Deliver the verified evaluation and proposed acceptance scope to draft PR37."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v41-path-guard-recovery'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(args,cwd=ROOT):return subprocess.check_output(args,cwd=cwd,text=True)
def write(path,data):
 with path.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
baseline='7574bd9fbfbfdf8a8f639dd9af123f1950c73386';tested='2e0efb268b733a14d7eca87555fdd87f134ba78c';old=read(OLD/'documentation-binding.json')
assert run(['git','rev-parse','HEAD']).strip()==baseline and run(['git','branch','--show-current']).strip()=='phase22/integration'
assert not run(['git','diff','--cached'])
fields='headRefOid,headRefName,baseRefName,isDraft,state,body,url'
pr=readback=json.loads(run(['gh','pr','view','37','--json',fields]));write(OUT/'pre-delivery-pr37.json',pr)
assert pr['headRefOid']==baseline and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning'
assert pr['body']==(OLD/'pr-body.md').read_text()
parent=json.loads(run(['gh','pr','view','36','--json','headRefOid,state,isDraft']));write(OUT/'pre-delivery-pr36.json',parent)
assert parent['headRefOid']=='8b6b0ddf1d6f6cf5a8da3ab9421471865b801455';run(['git','merge-base','--is-ancestor',parent['headRefOid'],'HEAD'])
checks=read(OLD/'local-checks.json');inputs=list(checks['source_files_sha256']);assert not run(['git','diff',tested,'--',*inputs])
protected=old['user_files_sha256'];stage=read(BASE/'v39-fresh-v7/staging-verification.json')
def verify_protected():
 assert set(run(['git','ls-files','--others','--exclude-standard']).splitlines())==set(protected)
 for n,d in protected.items():assert sha(ROOT/n)==d,n
 for folder,row in old['worktrees'].items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  if folder.endswith('frozen-f85a90f'):
   staged=old['authorized_staged_frozen_artifacts_sha256'];assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(staged)
   for n,d in staged.items():assert sha(Path(folder)/n)==d,n
  else:assert not run(['git','status','--porcelain'],folder)
 for folder,row in read(BASE/'v34-import-binding/older-frozen-source-bindings.json').items():
  assert run(['git','rev-parse','HEAD'],folder).strip()==row['revision'];assert not run(['git','diff','HEAD'],folder)
  assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(row['existing_untracked_files_sha256'])
  for n,d in row['existing_untracked_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 folder=stage['frozen_checkout'];assert run(['git','rev-parse','HEAD'],folder).strip()=='8c6256725f0948ee593eb4b73e90baf6f7b0d76a' and not run(['git','diff','HEAD'],folder)
 assert set(run(['git','ls-files','--others','--exclude-standard'],folder).splitlines())==set(stage['existing_untracked_files_sha256'])
 for n,d in stage['staged_files_sha256'].items():assert sha(Path(folder)/n)==d,n
 fixed=Path(read(OLD/'freeze.json')['frozen_checkout'])
 for n,d in read(OLD/'frozen-source-validation.json')['source_receipts_staged'].items():assert sha(fixed/n)==d,n
verify_protected()
proposal=read(OLD/'evaluation-proposal.json');audit=read(OUT/'audit.json');assessment=read(OUT/'assessment.json')
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==115
assert audit['dispositions']=={'passed':84,'explicitly user-deferred':2,'proposed documented limitation awaiting decision':2,'unresolved':1}
assert audit['additional_scope_dispositions']=={'passed':109,'proposed documented limitation awaiting decision':6}
assert assessment['detection_and_coverage_gate_passed'] and assessment['native_observations']==94 and assessment['whole_ordered_repeats']==47
assert audit['current_continuation_corpus_observations']==94 and audit['current_source_typescript_regression_executed'] and not audit['technical_acceptance_received']
assert read(OLD/'evaluation-authorization.json')['approved'] and read(OUT/'raw/packet.json')['budget_closed']
for n,d in audit['current_source_and_test_files'].items():assert sha(ROOT/n)==d,n
for label in ['v42-docs','v42-build','v42-distributions','v42-validate','v42-assess']:assert read(BASE/(label+'.json'))['exit_code']==0,label
assert read(OUT/'owned-work.json')['owned_processes']==[]
assert read(OUT/'final-checks.json')['all_final_checks_passed']
for n,d in read(OUT/'final-checks.json')['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
for n,d in proposal['files_sha256'].items():assert sha(ROOT/n)==d,n
seal=read(BASE/'evidence-v70.json');assert sha(BASE/seal['archive'])==seal['sha256']
for r in seal['files']:assert sha(BASE/r['path'])==r['sha256'],r['path']
dist=read(OUT/'final-distributions.json');assert sha(ROOT/'README.md')==dist['README_sha256']
for r in dist['distributions']:assert sha(ROOT/r['path'])==r['sha256']
docs=list(old['owning_docs_sha256']);refs=['audit.json','summary.md','pr-body.md','assessment.json','acceptance-proposal.json','guard-source-proof.json','condition-assessment.json','coverage-source-assessment.json','finding-source-assessment.json','final-distributions.json','deliver.py','validation.json','execution.json','preflight.json','final-checks.json','compatible-reuse.json','check-failure-assessment.json']
b={'recorded_at':datetime.now(timezone.utc).isoformat(),'baseline_delivery':baseline,'tested_workflow':tested,'scanner':proposal['scanner'],'byte_identical_quality_inputs':inputs,'owning_docs_sha256':{n:sha(ROOT/n) for n in docs},'review_packet_sha256':{n:sha(OUT/n) for n in refs},'evaluation_proposal_sha256':sha(OLD/'evaluation-proposal.json'),'evaluation_authorization_sha256':sha(OLD/'evaluation-authorization.json'),'user_files_sha256':protected,'worktrees':old['worktrees'],'authorized_staged_frozen_artifacts_sha256':old['authorized_staged_frozen_artifacts_sha256'],'new_frozen_staging_verification':old['new_frozen_staging_verification'],'prior_v39_staging_verification':old['prior_v39_staging_verification'],'evidence_seal':{'path':seal['archive'],'sha256':seal['sha256'],'members':len(seal['files'])},'evaluation_approved':True,'evaluation_executed':True,'new_native_observations':94,'exposed_regression_passed':True,'first_frozen_fresh_discrimination_passed':False,'new_paid_calls':0,'acceptance_packet_ready':True,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Post-seal binding directly tracked. Product/tests/workflows equal tested2e0efb2; finaldocs/package separatelychecked. Originalfreshfailures preserved. Explicit human acceptance and subsequentcloseout delivery still pending.'}
write(OUT/'documentation-binding.json',b)
paths=sorted(docs);extra=[str(p.relative_to(ROOT)) for p in [BASE/'evidence-v70.json',BASE/'evidence-v70.tar.gz',OUT/'documentation-binding.json']]
subprocess.run(['git','add','--',*paths],check=True);subprocess.run(['git','add','-f','--',*extra],check=True)
assert set(run(['git','diff','--cached','--name-only']).splitlines())==set(paths+extra)
subprocess.run(['git','commit','-m','Deliver passing TypeScript regression and technical acceptance packet [skip ci]'],check=True)
subprocess.run(['git','push','origin','phase22/integration'],check=True)
subprocess.run(['gh','pr','edit','37','--title','Phase 22: import regression passed; technical acceptance pending','--body-file',str(OUT/'pr-body.md')],check=True)
head=run(['git','rev-parse','HEAD']).strip();readbacks=[]
for attempt in range(5):
 pr=json.loads(run(['gh','pr','view','37','--json',fields]));readbacks.append(pr)
 if pr['headRefOid']==head and pr['body']==(OUT/'pr-body.md').read_text():break
 time.sleep(2)
write(OUT/'delivery-readback-history.json',readbacks);write(OUT/'delivery-readback.json',pr)
assert pr['headRefOid']==head and pr['isDraft'] and pr['state']=='OPEN' and pr['headRefName']=='phase22/integration' and pr['baseRefName']=='phase22/description-poisoning' and pr['body']==(OUT/'pr-body.md').read_text()
assert json.loads(run(['gh','pr','view','36','--json','headRefOid']))['headRefOid']==parent['headRefOid']
assert not run(['git','diff','HEAD']) and not run(['git','diff','--cached']);verify_protected()
for n,d in b['owning_docs_sha256'].items():assert sha(ROOT/n)==d,n
write(OUT/'delivery-verification.json',{'delivered_revision':head,'pr':pr['url'],'readback_sha256':sha(OUT/'delivery-readback.json'),'binding_sha256':sha(OUT/'documentation-binding.json'),'acceptance_proposal_sha256':sha(OUT/'acceptance-proposal.json'),'product_tests_workflows_equal_tested_source':True,'protected_worktrees_and_user_files_unchanged':True,'paid_calls':0,'native_observations':94,'exposed_regression_passed':True,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Supplemental ignored post-delivery receipt; sealed evidence and delivered commit remain immutable.'})
print('Verified existing OPEN draft delivery',head,pr['url'])
