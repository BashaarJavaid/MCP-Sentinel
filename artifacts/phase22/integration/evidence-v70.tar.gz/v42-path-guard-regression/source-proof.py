"""Bind source reasoning to the actual import guard; no detector invocation."""
import hashlib,json,re,subprocess
from pathlib import Path
from scripts.phase22_corpus import frozen,input_files
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
m=frozen(approval_path=BASE/'v39-fresh-v7/evaluation-authorization.json')
rows=[]
for input_id in ['memory-import-path-vulnerable','memory-import-path-fixed','memory-import-safe']:
 i=next(i for i in m.inputs if i.id==input_id);snapshot=next(s for s in m.snapshots if s.revision==i.snapshot);files=input_files(i,snapshot,ROOT);data=files['src/index.ts'];lines=data.decode().splitlines()
 spans=[(370,385),(1717,1727)] if i.label=='vulnerable' else [(30,70),(92,130),(470,484),(1829,1853)]
 if i.label=='vulnerable':assert 'fs.readFileSync(filePath' in lines[1723]
 else:
  assert 'let exportsDirReal: string;' in lines[60] and 'exportsDirReal = fs.realpathSync(exportsDir);' in lines[62]
  assert 'process.exit(1);' in lines[68]
  assert [n+1 for n,t in enumerate(lines) if re.search(r'\bexportsDirReal\s*=(?!=)',t)]==[63]
  assert 'resolved === exportsDirReal || resolved.startsWith(exportsDirReal + path.sep)' in lines[115]
  assert 'return resolved;' in lines[128] and 'safePath = resolveConfinedImportPath(filePath);' in lines[1836]
  assert 'fs.readFileSync(safePath' in lines[1848]
 rows.append({'input_id':input_id,'label':i.label,'snapshot':i.snapshot,'tree_sha256':i.tree_sha256,'source_sha256':sha(data),'source_spans':[{'start_line':a,'end_line':b,'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(a,b+1))} for a,b in spans]})
scanner=ROOT/'src/sentinel/static/typescript_path_flow.py';data=scanner.read_bytes();lines=data.decode().splitlines()
spans=[(105,202),(475,489),(583,603),(1707,1716),(1810,1845),(1894,1923),(2047,2067),(2296,2311)]
assert subprocess.check_output(['git','show','2e0efb2:src/sentinel/static/typescript_path_flow.py'])==data
record={'source_only':True,'corpus_observations':0,'paid_calls':0,'target_execution':False,'inputs':rows,'scanner_file':str(scanner.relative_to(ROOT)),'scanner_sha256':sha(data),'scanner_spans':[{'start_line':a,'end_line':b,'text':'\n'.join(f'{n}: {lines[n-1]}' for n in range(a,b+1))} for a,b in spans],
 'reasoning':[
 'The source binds context_import caller filePath to direct vulnerable read1724; fixed source calls the locally declared helper1837 and returns on its rejection before the actual same-value read1849.',
 'The fixed root is operator-controlled, initialized exactly once at63 by realpathSync. Failure calls the ordinary global process.exit at69. Visible process uses are env/cwd/exit; no rebound or escaped process/root is accepted by the narrow scanner proof. Under frozen ordinary Node startup prerequisites the handler cannot run with an uninitialized root.',
 'initialized_global recovers that one successful assignment through the existing Try branch merge; a proven terminal catch contributes no continuing unknown root. This changes the canonical root fact, not the filesystem sink recognizer or caller-input definition.',
 'Both root and candidate are canonical. Existing equality or separator-bounded prefix branches establish the same boundary fact; rejection throws. apply_facts marks the resolved caller value contained. The helper returns resolved129, the handler preserves the returned value as safePath and its rejecting catch returns before the read.',
 'readFileSync remains an explicitly supported path sink. path_sink emits SENT-012 for a caller-derived value only when containment is not established. The measured disappearance must be paired with evaluated rule/file status, unchanged coverage/unresolved records and the retained vulnerable positive; a silent or unsupported report alone cannot satisfy the gate.',
 'v41 full engineering exercises the exact initialization/helper-return/read pattern, including operator root and stat metadata. Raw prefix, caller root, replaced read, later writes, eval and shadow/rebound process remain alerting controls. These synthetic checks are engineering evidence, not independent repository detection.',
 ],'limitations':['Source reasoning under the exact frozen initial-path, environment and ordinary-filesystem prerequisites; no target execution, exploit or runtime/race safety proof.','Named tool metadata/dispatch remains unresolved in the report; preserved source mapping does not claim complete static MCP dispatch coverage.','The report does not emit a positive per-sink guard trace; support is assessed by source/code path, unchanged coverage, evaluated rule status, synthetic controls and the exact measured finding change. No extra diagnostic scan or profile was run.'],
 'retained_engineering':{'path':'artifacts/phase22/integration/v41-path-guard-recovery/local-checks.json','sha256':sha((BASE/'v41-path-guard-recovery/local-checks.json').read_bytes())},'tests_file_sha256':sha((ROOT/'tests/test_typescript_containment.py').read_bytes())}
with (OUT/'guard-source-proof.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Bound source proof for original vulnerable/fixed/control inputs; zero added observations.')
