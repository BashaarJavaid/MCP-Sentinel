"""Reconcile completed regression and prepare an explicit human acceptance decision."""
import copy,hashlib,json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v41-path-guard-recovery'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
a=read(OUT/'assessment.json');assert a['detection_and_coverage_gate_passed'] and a['completed']==94 and a['whole_ordered_repeats']==47
oldbinding=read(OLD/'documentation-binding.json');checks=read(OLD/'local-checks.json');proposal=read(OLD/'evaluation-proposal.json')
text=f'''The approved **94-observation exposed TypeScript regression passes** at frozen
scanner **`2e0efb2`**, source SHA-256 **`{proposal['scanner']['source_sha256']}`**.
All **47 input records completed twice**, with all **47 entire ordered report
pairs equal** after only the established 11 volatile exclusions. There were
**{a['timing_classes'].get('completed_within_target',0)} observations within the 120-second target** and
**{a['timing_classes'].get('completed_using_extended_time',0)} using the extended allowance**; the maximum whole input was
**{a['maximum_whole_seconds']:.6f} seconds**, within the uniform 300-second maximum.
The serial sequence took **{a['sequence_seconds']:.3f} seconds**. All 94 observations
are consumed and the budget is closed, with zero remaining. No comparator, retry,
profile, new repository, target execution or paid call occurred.

**Memory-keeper passes both original three-input batches:** one vulnerable import
read hit and zero matching alerts on the fixed and safe inputs in each batch.
The source assessment establishes the canonical operator root, component-bounded
guard, checked helper return and supported actual read. Exactly **four matching
fixed/control false-alert occurrences** and their derived counters disappear.
All other ordered findings, warnings, unresolved flows, coverage and surfaces equal
their bound references. The report has no positive per-sink guard trace; recognition
is established by the code/source path, measured delta, evaluated rule and synthetic
controls. Its unnamed MCP dispatch remains unresolved. Broader export and Git-message
candidates and the upstream fixture-secret false positive remain visible.

All affected prior TypeScript conditions pass: SearXNG, fetch-mcp, open-webSearch
and Lighthouse each retain two vulnerable hits and zero matching negative alerts
per five-input batch; the precise initial-destination qualifiers remain intact.
The ten TypeScript development records pass twice (four vulnerable hits and six
valid negatives per batch), and the 14 historical TypeScript records pass twice
(six vulnerable hits and eight valid negatives per batch). These language subsets
are never pooled into a new whole historical/development execution. The whole
45+45 Linux timing/condition passes and explicitly reused whole 25 development
batch retain their actual **`1f3f72f`** evidence and Meta operator erratum.
All 87 Python regression observations at **`8c62567`** remain source-compatible.
The frozen DDG manifest's TypeScript label error remains disclosed: its actual
hash-bound execution configuration selected Python.

**The original fresh memory-keeper result remains unchanged:** at **`8c62567`**,
one vulnerable hit and two matching fixed/control false alerts per batch, six
complete observations and three equal report pairs. The repository was absent
from eight prior manifests and 100 prior effective source trees. This demonstrates
one narrow vulnerable detection on a project-unused repository before tuning;
its discrimination correction is now exposed regression. It does **not** establish
clean unseen vulnerable/fixed discrimination at the final corrected scanner.
DDG's original fresh detections and initially unsupported fixed send, Lighthouse's
original misses, and all earlier corrections/failures remain source-bound.
The original held-out baseline stays 10 completed, 10 unsupported and five
incomplete, with zero hits among four completed vulnerable inputs out of ten
vulnerable inputs total. Same-agent curation/review is not independent human
validation, training-data novelty, broad accuracy or runtime safety proof.

Product, tests, workflows, schemas and lock remain identical to engineering-tested
**`2e0efb2`**: local and all 12 hosted suites passed **2,317 tests / 36 skips**,
local branch coverage **89.92%**, all 29 normal CI jobs passed in **34712751779**,
and docs passed in **34712751789**. Those are retained source-bound passes; this
continuation adds report validation, source assessments and final docs/package
checks, not a new hosted code pass. Six zero-call production replays and the
approved Git image/runtime bindings remain compatible. **Git campaigns remain
incomplete at 312/1,040**, as requested. Paid benchmark and pilots remain deferred;
Phase 21 is incomplete and Phase 24/15 gates are unchanged.

The audit retains **all 89 original requirements: 84 passed, two user-deferred,
two proposed documented limitations and one unresolved human acceptance**.
All **115 added requirements** remain: **109 passed and six historical closure
proposals awaiting decision**. R66/R88 and V39-EVALUATION explicitly propose
accepting the preserved fresh discrimination failure plus the later verified
exposed correction. Five older failed optimization/preparation/execution attempts
also retain their individual proposed closure decisions. None is relabeled as a
historical pass or silently waived. The exact proposed acceptance scope and
consequences are in `v42-path-guard-regression/acceptance-proposal.json`.
**Phase 22 remains incomplete until explicit human technical acceptance and
subsequent closeout delivery.** No merge, ready-state change, release, outreach
or Phase 23 is authorized.
'''
old='## Current v41 source correction and pending exposed regression\n\n'+(OLD/'summary.md').read_text().split('\n\n',1)[1]+'\n';new='## Current v42 regression result and pending technical acceptance\n\n'+text+'\n'
for n,d in oldbinding['owning_docs_sha256'].items():
 path=ROOT/n;assert sha(path)==d,n;s=path.read_text()
 if n=='artifacts/phase22/corpus-replacement-v7/README.md':
  assert s=='# Replacement v7: source correction; exposed regression pending\n\n'+(OLD/'summary.md').read_text().split('\n\n',1)[1]
  path.write_text('# Replacement v7: exposed regression passed; acceptance pending\n\n'+text)
 else:assert s.count(old)==1,n;path.write_text(s.replace(old,new))
path=BASE/'README.md';s=path.read_text().replace('batches 1–69','batches 1–70',1);start=s.index('Review the [source correction]');end=s.index('\n',start);s=s[:start]+'Review the [94-observation assessment](v42-path-guard-regression/assessment.json), [89 + 115 row audit](v42-path-guard-regression/audit.json) and [explicit acceptance proposal](v42-path-guard-regression/acceptance-proposal.json). Restore seal 70 after seals 1–69, verifying every archive/member hash. Original fresh failures remain preserved; technical acceptance is pending.'+s[end:];path.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 regression result and pending technical acceptance\n\n'+text)
(OUT/'pr-body.md').write_text('# Phase 22: import regression passed; technical acceptance pending\n\nA canonical exports root initialized inside a startup try/catch was being treated as arbitrary rebinding, causing alerts on memory-keeper’s protected import read. The shared TypeScript analysis now preserves the proven initialization and follows the checked path through the rejecting helper to the actual read.\n\n'+text+'\nEvidence: `artifacts/phase22/integration/v42-path-guard-regression/`, seal70 after all69 earlier seals.\n\nCI: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34712751779\nDocs: https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34712751789\n')
p=copy.deepcopy(read(OLD/'audit.json'));common='94/94 exposed TypeScript observations at2e0efb2 pass,47 whole ordered repeats. Memory-keeper vulnerable hit twice and0matching fixed/control alerts; guard/read source-assessed,4false-alert occurrences removed,allotherreportcontent equal references. Python87 reuse retains8c62567. Original fresh false positives/misses and Git312/1040 remain; explicit technical acceptance pending.'
for r in p['requirements']:
 r['historical_v41_assessment']={k:r.get(k) for k in ['assessment','disposition','interpretation','current_tests']};r['interpretation']=common
 if 'current_tests' in r:r['current_tests']={n:checks['tests_by_file'][n] for n in r['current_tests']}
 if r['id'] in {'R22','R26','R27','R28','R65','R87','R89'}:r.update(disposition='passed',assessment=common)
 elif r['id'] in {'R66','R88'}:r.update(disposition='proposed documented limitation awaiting decision',assessment='Fresh repository selection, bounded execution and source assessment are complete. Original memory-keeper detects1/1vulnerable but falsely alerts on both negatives per batch at8c62567. Current2e0efb2 exposed correction passes; no clean unseen discrimination atfinalsource is claimed. Explicitly proposed revised technical closure accepts that preserved limitation; no approval or relabeling inferred.',explicit_acceptance_pending=True)
 elif r['id']=='R84':r.update(disposition='unresolved',assessment='Final source-bound packet is prepared for explicit Phase22 technical acceptance, followed by actual closeout delivery. Evaluation approval is not acceptance; pilots remain user-deferred.')
 elif r['id'] in {'R62','R67','R69','R79','R80','R83'}:r['assessment']=common
 r['evidence']=list(dict.fromkeys(r.get('evidence',[])+['artifacts/phase22/integration/v42-path-guard-regression/'+n for n in ['assessment.json','condition-assessment.json','coverage-source-assessment.json','guard-source-proof.json']]))
for r in p['additional_scope_requirements']:
 if r['id'] in {'V39-EVALUATION','V41-EXPOSED'}:
  r['historical_v41_assessment']={k:r.get(k) for k in ['assessment','disposition']};r['assessment']=common
  r['disposition']='passed' if r['id']=='V41-EXPOSED' else 'proposed documented limitation awaiting decision'
  r['explicit_acceptance_pending']=r['id']=='V39-EVALUATION'
  r['evidence']+=['artifacts/phase22/integration/v42-path-guard-regression/assessment.json']
  if r['id']=='V39-EVALUATION':r.update(historical_gate_failed=True,current_implementation_gate=False,assessment='Originalv40 fresh discrimination fails: one vulnerable hit and two matching negative false alerts per batch. The separately approved current2e0efb2 exposed regression passes all six memory-keeper observations and88affected compatibility observations. Propose closure with original first-frozen failure retained, not reclassified as fresh success.')
p['historical_v41_current_fields']={k:copy.deepcopy(x) for k,x in p.items() if k.startswith(('current_','corrected_')) or k in ['status','acceptance_packet_ready','fresh_evaluation_status_basis']}
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),prior_audit={'path':'v41-path-guard-recovery/audit.json','sha256':sha(OLD/'audit.json')},status=common,current_source_corpus_runs=94,current_source_native_observations=94,current_continuation_corpus_observations=94,current_compatibility_observations_this_continuation=88,current_source_typescript_regression_approved=True,current_source_typescript_regression_executed=True,current_exposed_evaluation_approved=True,current_exposed_evaluation_executed=True,current_exposed_gate_passed=True,current_compatibility_passed=True,corrected_scanner_evaluation_approved=True,corrected_scanner_evaluation_executed=True,current_fixed_guard_recognition_established=True,current_source_observation_interpretation=common,latest_measured_scanner=proposal['scanner'],acceptance_packet_ready=True,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,fresh_evaluation_status_basis='All original fresh results preserved. R66/R88/V39-EVALUATION require explicit acceptance of historical discrimination limits plus later exposed correction, not a fresh success relabel.',owning_document_binding='Finalv42 documentation binding follows docs/package checks andseal70.')
p['source_only_recovery_checkpoint']=False
p['full_sequence_status_basis']='Original whole25 reuse and45+45 Linux passes retain actual1f3f72f. Current94TypeScript observations pass at2e0efb2; prior87Python observations retain8c62567 by source compatibility. These subsets are not pooled into a new whole original corpus execution.'
p['technical_acceptance_request_history']+=' Currentv42: the requested additional repository was evaluated at8c62567, its correction now passes94exposed observations at2e0efb2. A new explicit technical acceptance proposal is ready; no decision inferred.'
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert p['dispositions']=={'passed':84,'proposed documented limitation awaiting decision':2,'explicitly user-deferred':2,'unresolved':1}
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==115
assert p['additional_scope_dispositions']=={'passed':109,'proposed documented limitation awaiting decision':6}
p['final_documentation_source_files']={n:sha(ROOT/n) for n in oldbinding['owning_docs_sha256']}
p['references_sha256'].update({str((OUT/n).relative_to(ROOT)):sha(OUT/n) for n in ['assessment.json','condition-assessment.json','coverage-source-assessment.json','guard-source-proof.json','summary.md']})
p['current_source_and_test_files']={n:sha(ROOT/n) for n in p['current_source_and_test_files']}
write('audit.json',p)
limitations=[{k:r.get(k) for k in ['id','requirement','assessment','evidence']} for r in p['requirements']+p['additional_scope_requirements'] if r['disposition']=='proposed documented limitation awaiting decision']
write('acceptance-proposal.json',{'status':'prepared_for_explicit_human_decision_not_accepted','proposed_decision':'Accept Phase22 technical completion under the recorded revised scope and enumerated limitations; retain all original fresh failures and close superseded failed attempts without relabeling them. Then deliver the accepted closeout to existing draftPR37.','scanner':proposal['scanner'],'tested_workflow':'2e0efb268b733a14d7eca87555fdd87f134ba78c','review_files_sha256':{n:sha(OUT/n) for n in ['assessment.json','audit.json','summary.md','guard-source-proof.json']},'proposed_limitation_dispositions':limitations,'consequence':'No clean unseen vulnerable/fixed discrimination result at the final corrected scanner is claimed. Original fresh vulnerable detection remains actual8c62567; current94-observation verification is exposed regression. These limitations become accepted only after the user explicitly decides.','preserved_limits':['Original heldout10completed10unsupported5incomplete;0hitsamong4completedvulnerableinputs/10totalvulnerableinputs.','OriginalLighthousemisses,DDGinitialfixed-sendunsupportedstatus and memory-keeperfixed/controlfalsepositives remain unchanged; all later exposed corrections keep actualsources.','Same-agent curation and review; no independent human or training-data novelty claim.','UnresolvednamedMCPdispatch,broaderunconfirmedcandidates and narrowinitialpath/URLprerequisites; no complete security or runtime safety claim.','120secondtarget/300secondmaximum; historicalwhole25reuse+45+45at1f3f72f; language subsets do not create a new whole-batch execution.','Git13campaigns312/1040remainincomplete and user-deferred; paid396-requestbenchmark and pilots remain deferred; Phase21incomplete andPhase24/15unchanged.'],'budget':{'new_paid_calls':0,'native_consumed':94,'remaining':0,'closed':True},'next_after_acceptance':'Record exact human decision; updateR84 and explicit limitation dispositions; complete final checks,evidence seal and verified closeout delivery to the same draftPR37.','not_authorized':['merge','ready state','release','outreach','Phase23','additional paid calls'],'technical_acceptance_received':False,'phase22_complete':False})
print('89+115requirements reconciled; exact technical acceptance proposal prepared, not accepted.')
