"""Assess the approved reports against exact references and the guard source proof."""
import copy,hashlib,json
from collections import Counter,defaultdict
from pathlib import Path
from scripts.phase20_scoring import candidate_identity,score,metrics
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
p=read(BASE/'v41-path-guard-recovery/evaluation-proposal.json');v=read(OUT/'validation.json');proof=read(OUT/'guard-source-proof.json')
assert v['budget_closed'] and proof['source_only']
excluded=set(p['volatile_exclusions'])
def clean(x):
 if isinstance(x,dict):return {k:clean(t) for k,t in x.items() if k not in excluded}
 if isinstance(x,list):return [clean(t) for t in x]
 return x
rows=[];changes=[];coverage=[];unassessed=[];batches=defaultdict(list)
for a in v['attempts']:
 if a['state']!='completed':continue
 g=a['group'];item=p['groups'][g]['inputs'][a['input_id']];label=item['input']['label'];r=read(OUT/'raw'/a['directory']/a['input_id']/'report.json');old=read(ROOT/item['reference_report'])
 expected=clean(old);actual=clean(r);removed=[];matches=[]
 if g=='memorykeeper':
  line=1724 if label=='vulnerable' else 1849
  named=[f for f in r['findings'] if f['rule_id']=='SENT-012' and f['location']['path']=='src/index.ts' and f['location']['range']['start_line']==line]
  for f in named:assert 'readFileSync' in f['evidence']['snippet'] and 'without enforced containment' in f['description']
  matches=[f['dedup_key'] for f in named]
  if label!='vulnerable':
   removed=[f for f in expected['findings'] if f['dedup_key']=='95cec91e2517a516fa0ee4f72645dc7f7622de2f0a2028200a020b7b81b17581']
   assert len(removed)==1 and removed[0]['location']['range']['start_line']==1849
   expected['findings']=[f for f in expected['findings'] if f not in removed]
   for path in [('review_activity','static','candidate_count'),('review_activity','static','unreviewed_count'),('static_analysis','total_matches'),('summary','by_severity','Medium'),('summary','by_status','needs_review'),('summary','total')]:
    node=expected
    for k in path[:-1]:node=node[k]
    node[path[-1]]-=1
   rule=next(x for x in expected['static_analysis']['rule_outcomes'] if x['rule_id']=='SENT-012');assert rule['status']=='evaluated' and rule['skip_reason'] is None;rule['match_count']-=1
  rationale='Original source-reviewed context_import caller/read. Fixed and safe sources retain the same actual read, with canonical root, separator boundary, checked helper return and rejecting catch established in guard-source-proof.json. Only the original matching false alert and its counters may disappear; all other ordered report content must equal the first-frozen reference.'
 elif g=='lighthouse':
  witness=p['witnesses'][g][a['input_id']];named=[f for f in r['findings'] if f['rule_id']=='SENT-015' and f['location']['path']==witness['path'] and f['location']['range']['start_line']==witness['sink_line']]
  assert named and all('lighthouse' in f['evidence']['snippet'] for f in named)
  qualified=all(f['description'].startswith('The source rejects literal link-local IPv4 destinations for this caller URL before the request.') for f in named)
  assert qualified==(label!='vulnerable')
  matches=[f['dedup_key'] for f in named] if label=='vulnerable' else []
  rationale='Entire report equals the bound v30 reference, including the source-reviewed actual Lighthouse request and narrow initial link-local qualifier on negatives. Broader candidates remain visible; no DNS, redirect or runtime protection claim.'
 else:
  matches=item['assessment']['matches'];rationale='Entire ordered report must equal the bound previously source-assessed TypeScript reference. Reuse its unchanged condition keys, prerequisites and all unrelated finding/diagnostic/surface judgments; do not reinterpret unmatched candidates as false positives.'
 if expected!=actual:
  unassessed.append({'group':g,'input_id':a['input_id'],'batch':a['batch'],'reference_deltas':a['reference_deltas']});continue
 c=r['static_analysis']['coverage'];oc=old['static_analysis']['coverage']
 assert clean(c)==clean(oc) and clean(r['warnings'])==clean(old['warnings'])
 if g=='memorykeeper':
  assert len(c['surfaces'])==1 and c['surfaces'][0]['status']=='unresolved' and c['surfaces'][0]['name'] is None
  assert any(x['code']=='ambiguous_dispatch' for x in c['surfaces'][0]['reasons'])
  assert not any('SENT-012 at src/index.ts:1849:' in d['message'] for d in [*r['warnings'],*c['unresolved_flows']])
 adjudication={'candidate_identity':candidate_identity(r['findings']),'matches':matches,'rationale':rationale}
 row={k:a[k] for k in ['group','batch','input_id','report_sha256','reference_sha256','native_seconds','timing_class']}
 row.update(label=label,source_condition=item['input']['condition'],whole_seconds=a['timing']['elapsed_seconds'],source_assessment=adjudication,**score(label=label,state='completed',findings=r['findings'],assessment=adjudication))
 rows.append(row);batches[g+'/'+a['batch']].append(row)
 for f in removed:changes.append({**{k:row[k] for k in ['group','batch','input_id','report_sha256']},'before':f,'after':None,'assessment':'Matching fixed/control import false alert removed by recognized canonical-root/checked-path containment. Supported read and evaluated rule remain; all other candidates, warnings, coverage and surfaces equal original. Source proof bound separately.','source_proof_sha256':sha(OUT/'guard-source-proof.json'),'counter_changes':a['reference_deltas']})
 coverage.append({**{k:row[k] for k in ['group','batch','input_id','report_sha256','reference_sha256']},'reference_report':item['reference_report'],'entire_remaining_report_equal':True,'warnings':len(r['warnings']),'unresolved_flows':len(c['unresolved_flows']),'surfaces':len(c['surfaces']),'findings':len(r['findings']),'ordered_warning_coverage_surface_equality':True,'interpretation':'Every unchanged diagnostic and surface retains its original source assessment. For memory-keeper only the prior root/guard nonrecognition conclusion is superseded by guard-source-proof.json; unresolved named dispatch, unrelated export/Git candidates and the upstream fixture-secret false positive remain.'})
write('unexpected-changes.json',unassessed)
assert not unassessed, f'{len(unassessed)} reports require further source assessment'
write('condition-assessment.json',{'rows':rows,'batches':{k:metrics(rs) for k,rs in batches.items()},'raw_unmatched_keys_retained':True})
write('finding-source-assessment.json',{'rows':changes,'occurrences':len(changes),'new_candidates':0,'expected_changes':'Only matching fixed/control memory-keeper read false alert removed, plus exact derived counters.','all_other_candidates_equal_bound_reference':True})
refs=['v40-fresh-v7/finding-source-assessment.json','v40-fresh-v7/diagnostic-source-assessment.json','v40-fresh-v7/source-context-assessment.json','v40-fresh-v7/surface-source-assessment.json','v31-compatibility/source-assessment.json','v30-lighthouse-regression/assessment.json']
write('coverage-source-assessment.json',{'rows':coverage,'diagnostic_or_surface_changes':0,'source_assessment_reuse':{n:sha(BASE/n) for n in refs},'memorykeeper_current_guard_interpretation':'guard-source-proof.json supersedes only historical guard-nonrecognition interpretation; exact unchanged warnings and unnamed dispatch remain limitations.','original_assessments_unchanged':True})
conditions=all(r['retained_detected'] if r['label']=='vulnerable' else r['false_alarm'] is False for r in rows)
mem=[r for r in rows if r['group']=='memorykeeper'];memgate=len(mem)==6 and all(r['retained_detected'] if r['label']=='vulnerable' else r['false_alarm'] is False for r in mem)
gate=v['passed'] and len(rows)==94 and conditions and memgate
r={'scanner':p['scanner'],'execution_gate_passed':v['passed'],'detection_and_coverage_gate_passed':gate,'memorykeeper_regression_passed':memgate,'fixed_sink_supported':memgate,'fixed_guard_recognition_established_by_source_assessment':memgate,'named_dispatch_resolved':False,'source_assessment_complete':True,'native_observations':len(v['attempts']),'completed':len(rows),'whole_ordered_repeats':sum(a.get('ordered_repeat_equal',False) for a in v['attempts']),'timing_classes':dict(Counter(r['timing_class'] for r in rows)),'maximum_whole_seconds':max(r['whole_seconds'] for r in rows),'maximum_native_seconds':max(r['native_seconds'] for r in rows),'sequence_seconds':read(OUT/'execution.json')['elapsed_seconds'],'condition_batches':{k:metrics(rs) for k,rs in batches.items()},'removed_false_alert_occurrences':len(changes),'diagnostic_changes':0,'surface_changes':0,'budget_closed':True,'remaining':0,'unstarted_closed':len(v['unstarted_closed']),'paid_calls':0,'target_execution':False,'technical_acceptance_received':False,'phase22_complete':False,'original_fresh_result_unchanged':True,'assessment_files_sha256':{n:sha(OUT/n) for n in ['validation.json','condition-assessment.json','finding-source-assessment.json','coverage-source-assessment.json','guard-source-proof.json']},'qualification':'Exposed regression only, not fresh evidence or a new whole25/45 Linux corpus sequence. All first-frozen failures, prior budgets, narrow source prerequisites, unresolved dispatch and incomplete Git312/1040 remain preserved.'}
write('assessment.json',r);print(json.dumps({k:x for k,x in r.items() if k!='condition_batches'},indent=2))
