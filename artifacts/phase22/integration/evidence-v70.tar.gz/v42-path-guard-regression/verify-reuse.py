"""Rebind unchanged engineering, Python and runtime evidence without rerunning it."""
import hashlib,json,subprocess
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent;OLD=BASE/'v41-path-guard-recovery'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=read(OLD/'evaluation-proposal.json');checks=read(OLD/'local-checks.json')
for n,d in checks['source_files_sha256'].items():assert sha(ROOT/n)==d,n
assert not subprocess.check_output(['git','diff','2e0efb2','--',*checks['source_files_sha256']])
assert checks['full_suite']['passed']==2317 and checks['full_suite']['skipped']==36 and checks['paid_calls']==0
assert sha(BASE/'v41-final-quality/packet.json')==checks['quality_packet_sha256']
assert sha(BASE/'v41-final-quality-audit/packet.json')==checks['quality_audit_sha256']
for n,d in p['files_sha256'].items():assert sha(ROOT/n)==d,n
refs=['v41-path-guard-recovery/local-checks.json','v41-final-quality/packet.json','v41-final-quality-audit/packet.json','v41-production-capture-revalidation/packet.json','v41-path-guard-recovery/compatibility.json','v41-path-guard-recovery/source-proof.json','v41-path-guard-recovery/python-reuse-execution-binding.json','v41-path-guard-recovery/check-failure-assessment.json']
r={'scanner':p['scanner'],'product_tests_workflows_schemas_lock_unchanged':True,'source_files_sha256':checks['source_files_sha256'],'retained_evidence_sha256':{n:sha(BASE/n) for n in refs},'full_suite':checks['full_suite'],'quality_run':34712751779,'docs_run':34712751789,'normal_jobs_passed':29,'hosted_quality_suites':12,'production_requests_replayed':6,'new_paid_calls':0,'new_engineering_test_execution':False,'python_observations_reused':87,'python_actual_measured_source':'8c6256725f0948ee593eb4b73e90baf6f7b0d76a','git_runtime_tested':312,'git_runtime_planned':1040,'git_campaigns_incomplete':13,'qualification':'Only result assessment and owning documentation change in this continuation. Every product/test/workflow/schema/lock input equals tested2e0efb2; no new hosted code pass or new Python/Git execution is claimed. README package metadata is checked separately after final docs edits.'}
with (OUT/'compatible-reuse.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print('Verified all301 engineering inputs and retained quality/replay/Python/runtime evidence.')
