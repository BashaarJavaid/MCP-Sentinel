"""Run the exact approved frozen sequence once and retain its process result."""
import json,os,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path('/private/tmp/mcp-phase22-options')
OUT=Path(__file__).resolve().parent
ASSETS=OUT.parent/'v41-path-guard-recovery'
p=json.loads((ASSETS/'evaluation-proposal.json').read_text())
command=['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python','-I',str(ASSETS/'evaluate.py'),'run',str(OUT/'raw')]
assert not (ASSETS/'execution-consumed.json').exists()
env={k:v for k,v in os.environ.items() if not k.startswith(('OPENAI_','SENTINEL_'))}
env['PATH']='/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin:'+env.get('PATH','')
r={'command':command,'cwd':p['frozen_checkout'],'started_at':datetime.now(timezone.utc).isoformat(),'paid_calls':0}
with (OUT/'launch.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
start=time.monotonic()
with (OUT/'sequence.log').open('x') as log:
 result=subprocess.run(command,cwd=p['frozen_checkout'],env=env,stdout=log,stderr=subprocess.STDOUT)
r.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,completed_at=datetime.now(timezone.utc).isoformat())
with (OUT/'execution.json').open('x') as f:json.dump(r,f,indent=2);f.write('\n')
print(json.dumps(r,indent=2),flush=True)
raise SystemExit(result.returncode)
