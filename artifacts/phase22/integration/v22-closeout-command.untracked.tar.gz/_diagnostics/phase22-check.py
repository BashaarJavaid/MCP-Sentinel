import datetime, hashlib, json, os, pathlib, subprocess, sys, time, tarfile
root=pathlib.Path('/private/tmp/mcp-phase22-options')
out=root/'artifacts/phase22/integration'; out.mkdir(exist_ok=True)
label,*command=sys.argv[1:]
env=dict(os.environ, PYTHONPATH='src', PATH='/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin:'+os.environ['PATH'])
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
diff=subprocess.check_output(['git','diff','HEAD'],cwd=root)
(out/(label+".patch")).write_bytes(diff)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard','src','tests','scripts'],cwd=root,text=True).splitlines()
untracked_archive=out/(label+'.untracked.tar.gz')
with tarfile.open(untracked_archive,'w:gz') as archive:
 for name in untracked:
  path=root/name
  if path.is_symlink(): raise ValueError('untracked source symlink: '+name)
  if path.is_file(): archive.add(path,arcname=name,recursive=False)
 for path in {pathlib.Path(__file__), *(pathlib.Path(arg) for arg in command if arg.startswith('/private/tmp/') and arg.endswith('.py'))}:
  if path.is_symlink(): raise ValueError('diagnostic source symlink: '+str(path))
  if path.is_file(): archive.add(path,arcname='_diagnostics/'+path.name,recursive=False)
start=time.monotonic()
with (out/(label+'.log')).open('wb') as log:
 result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
record={'command':command,'cwd':str(root),'environment_overrides':{k:env[k] for k in ('PYTHONPATH','PATH')},'source_commit':source,'untracked_source_archive':untracked_archive.name,'untracked_source_sha256':hashlib.sha256(untracked_archive.read_bytes()).hexdigest(),'diff_sha256':hashlib.sha256(diff).hexdigest(),'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-start,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'log':label+'.log'}
(out/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(label, "exit", result.returncode);sys.exit(result.returncode)
