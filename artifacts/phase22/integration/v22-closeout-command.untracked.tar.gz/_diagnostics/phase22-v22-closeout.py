import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=read('v22-refresh-disposition-corrected.json');v=read('v22-source-verification.json');prior=read('v21-closeout-audit/packet.json');seal=read('evidence-v51.json');full=d['passed'];rows=[]
for old in prior['requirements']:
 row={**old,'evidence':list(old['evidence'])+['artifacts/phase22/integration/v22-source-verification.json'],'prior_requirement_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),'historical_assessment':{'audit':'v21-closeout-audit/packet.json','text':old['assessment']}}
 row['assessment']='Scanner, test, runtime and package bytes remain1f3f72f. Fresh normal CI/docs pass at61b19ae. Prior requirement-specific judgments retain their source bindings in the previous audit. The approved assessment refresh is separately recorded; no fresh-evaluation or human-acceptance result is inferred.'
 if row['id'] in [f'R{n}' for n in range(18,28)]+['R63','R64']:
  row['disposition']='passed' if full else 'unresolved';row['assessment']='The explicitly approved scoped sequence '+('passes two whole45/45historical batches, each20/20vulnerable hits and0matching alerts on25negatives; all45ordered reports match.' if full else 'does not pass; preserve complete/partial results and closed unused budget.')+' The passed whole25development batch is reused by explicit approval. The37+8assessment preparation is not a whole45execution pass. All120-second target/300-second maximum classifications remain visible.';row['evidence'].append('artifacts/phase22/integration/v22-refresh-disposition-corrected.json')
 if row['id'] in ['R35','R65']:row['assessment']='The already passed whole25development batch at identical1f3f72f is explicitly reused under v22 approval; preserve10vulnerable hits, exactly2raw Meta erratum alerts and0matching alerts on13valid negatives.'
 if row['id']=='R67':row['assessment']='All prior judgments retained. Five preparatory report deltas,1191individual diagnostic changes and the additional kubectl_logs command-injection suspicion are source-assessed. The latter is separate from the unchanged kubectl_get condition. Final reports have no new canonical deltas.';row['evidence'].append('artifacts/phase22/integration/v22-preparatory-source-deltas/packet.json')
 if row['id'] in ['R66','R88']:row['disposition']='unresolved';row['assessment']='Replacement-v4 source packet remains prepared after immutable1f3f72f freeze and unapproved/unevaluated. Exact manifest, source exposure, checkpoint and15-observation proposal are preserved; fresh evaluation is the next separate checkpoint.'
 if row['id']=='R84':row['disposition']='unresolved';row['assessment']='No final human technical acceptance. Pilots remain explicitly deferred and are not a Phase22 completion prerequisite; Phase21 stays incomplete.'
 if row['id'] in ['R77','R78']:row['assessment']='Full paid benchmark remains explicitly user-deferred, not passed; zero new paid calls.'
 if row['id']=='R79':row['evidence'].append('artifacts/phase22/integration/evidence-v51.json')
 if row['id']=='R82':row['evidence'].append('artifacts/phase22/integration/v22-delivery-verification.json')
 rows.append(row)
counts=dict(collections.Counter(r['disposition'] for r in rows));assert len(rows)==89 and counts==({'passed':84,'explicitly user-deferred':2,'unresolved':3} if full else {'passed':72,'explicitly user-deferred':2,'unresolved':15})
additional=[{**r,'scope':'Preserved historical attempt; closed budgets do not reopen. V21 sequence is superseded prospectively only by the explicit V22 scope amendment.'} for r in prior['additional_scope_requirements']]
for suffix,title,evidence,status in [('APPROVAL','Bind exact98-observation and scoped-development-reuse approval',['v22-refresh-authorization.json'],'passed'),('PREPARATION','Eight preparatory executions and source assessment of every delta',['v22-preparatory-assessment/packet.json','v22-preparatory-source-deltas/packet.json'],'passed'),('FREEZE','Freeze45source-bound assessments before final dispatch',['v22-assessment-freeze.json','v22-refresh-v1/final-binding.json'],'passed'),('HISTORICAL','Two complete historical45-input batches with ordered equality',['v22-refresh-disposition-corrected.json'],'passed' if full else 'unresolved'),('ENGINEERING','Final normal CI and source-bound verification',['v22-final-quality-audit/packet.json','v22-source-verification.json'],'passed'),('DELIVERY','Seal evidence and deliver existing draft',['evidence-v51.json','v22-delivery-verification.json'],'passed')]:additional.append({'id':'V22-'+suffix,'requirement':title,'disposition':status,'evidence':evidence})
p={**prior,'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':v['source'],'scanner_identity':v['scanner'],'measured_scanner':v['measured_scanner'],'requirements':rows,'dispositions':counts,'additional_scope_requirements':additional,'additional_scope_dispositions':dict(collections.Counter(r['disposition'] for r in additional)),'prior_audit':{'path':'v21-closeout-audit/packet.json','sha256':sha(b/'v21-closeout-audit/packet.json')},'current_source_and_test_files':v['source_and_test_files_sha256'],'references_sha256':{n:sha(b/n) for n in ['v22-source-verification.json','v22-final-quality-audit/packet.json','v22-refresh-disposition-corrected.json','v22-assessment-freeze.json','v21-fresh-proposal-verification.json','evidence-v51.json']},'current_source_corpus_runs':d['total_attempts_consumed'],'full_sequence_passed':full,'fresh_evaluation_approved':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'new_paid_calls':0,'phase22_complete':False,'status':'Approved scoped historical gate '+('passed; fresh evaluation and acceptance remain unmet.' if full else 'failed; closed unused budget, fresh evaluation and acceptance remain unmet.'),'owning_document_binding':'v22-final-documentation-binding.json supersedes audit-stage document hashes only.'}
out=b/'v22-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
ci=read('v22-final-hosted-run-ids.json');summary=f'''The approved **98-observation assessment refresh {'passes' if full else 'does not pass'}** at
scanner **`1f3f72f`**, final workflow **`61b19ae`**, run **{d['workflow_run']}**.
It consumed **{d['total_attempts_consumed']}/98** observations; **{d['execution_completed']}** completed.
**{d['timing_classifications'].get('completed_within_target',0)}** completed within the 120-second target and
**{d['timing_classifications'].get('completed_using_extended_time',0)}** used extended time within the 300-second maximum.
The longest whole-input execution took **{d['maximum_whole_input_seconds']:.3f} seconds**.
All consumed attempts and any closed remainder are retained in `v22-refresh-disposition-corrected.json`.

'''
if full:summary+='''Both whole historical batches pass **45/45**, each with **20/20 vulnerable
condition hits** and **zero matching alerts on 25 negatives**. All 45 entire ordered
reports match across the pair, excluding only the established volatile fields.
The previously passed whole **25-input development batch** at identical scanner
bytes is reused under the user's explicit scope amendment: 10 vulnerable hits,
exactly two raw Meta operator erratum alerts, and zero matching alerts on 13 valid
negatives. These results measure completion under the approved timing policy.

'''
summary+='''The eight preparatory observations completed, and all 45 historical assessments
were frozen before the final dispatch. The retained 37 plus new eight reports
were used only for source assessment, never presented as a whole-batch execution
pass. Five preparatory report deltas include 1,191 individually source-assessed
diagnostic changes. The additional `kubectl_logs` command-injection suspicion is
separate from the unchanged `kubectl_get` benchmark condition; it remains visible,
without claiming runtime proof. Final reports have no new canonical deltas.

The original **15/25** Linux result at `7555a9d`, its ten 120-second Meta timeouts,
and the later **62-attempt stale-assessment stop** in run 34555414891 remain
preserved failures. Neither result is relabeled or its closed budget reopened.
No detector, condition label, prerequisite, deadline or target source changed.
No paid calls, profiles, benchmark retries or target execution occurred.

'''
summary+=f'''Final CI **{ci['ci']}** passes all **29 normal jobs** and documentation
**{ci['docs']}** passes. All 12 quality suites pass **2,194 tests with 36 skips**.
The wheel and sdist retain byte-verified source bindings. Local coverage, six
zero-call production replays and Git runtime compatibility retain their exact
source evidence. Git's 13 campaigns remain incomplete (312/1,040 attempts);
the three exposed SSRF families retain their passing regressions at `2ac39aa`.

The next separate checkpoint is **replacement-v4 freeze/evaluation**, prepared
but **unapproved and unevaluated** in `artifacts/phase22/corpus-replacement-v4/`:
10 native and five Semgrep observations, one standard Linux job, 300 seconds per
whole input, a 90-minute job limit and zero paid calls. Its independent repository
pair was curated after the immutable scanner freeze; source exposure and
correlated variants are disclosed. No independent human or unseen-source review
is claimed.

The 89-row audit is **{counts['passed']} passed, two user-deferred and {counts['unresolved']} unresolved**.
**Phase 22 remains incomplete** pending actual remaining gates and explicit final
human technical acceptance. The original held-out result remains 10 completed,
10 unsupported and five incomplete, with zero hits among four completed vulnerable
inputs out of ten vulnerable inputs total. Paid benchmark and pilots remain
deferred; Phase 21 stays incomplete, and Phase 24/15 gates are unchanged.
No merge, release, outreach or Phase 23 work is authorized.
'''
(b/'v22-closeout-summary.md').write_text(summary)
# Add the current checkpoint and explicitly retain the entire preceding history.
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md','docs/phase22-corpus-review.md','docs/phase22-timeout-policy.md']:
 f=root/name;s=f.read_text();marker='The approved full Linux sequence at scanner';at=s.find(marker)
 if at<0:
  at=s.find('\n')+1
 s=s[:at]+summary+'\n### Historical v21 sequence and proposal checkpoint\n\n'+s[at:];s=s.replace('Current v21 full Linux sequence','Current v22 historical assessment refresh',1)
 if name=='AGENTS.md' and full:s=s.replace('all three exposed SSRF gates and Linux development pass; historical assessment refresh/repeat, fresh evaluation and acceptance pending; paid benchmark/pilots deferred','all three exposed SSRF gates and approved historical repeat pass; fresh evaluation and acceptance pending; paid benchmark/pilots deferred',1)
 f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text();at=s.find('\n')+1;s=s[:at]+f'\n## Current v22 approved assessment-refresh audit\n\nAll 89 original rows: **{counts["passed"]} passed, two user-deferred, {counts["unresolved"]} unresolved**.\nSee `v22-closeout-audit/packet.json` and `v22-refresh-disposition-corrected.json`. The original\nfailed sequences remain historical; only the explicitly approved scoped gate is updated.\nFresh replacement-v4 evaluation and final human acceptance remain separate.\n\n'+s[at:];f.write_text(s)
# Append the new numbered restoration entry without altering prior entries.
f=b/'README.md';s=f.read_text()+f'\nEvidence seal **51**: `evidence-v51.tar.gz`, SHA-256 `{seal["sha256"]}`, {len(seal["files"])} files. Restore after seals 1–50 using the unchanged verified restoration procedure.\n';f.write_text(s)
body=summary+'''\n[Assessment refresh and final results](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v22-refresh-disposition-corrected.json), [89-row audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v22-closeout-audit/packet.json), [next fresh proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/corpus-replacement-v4/evaluation-proposal.json), [evidence index](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nFinal documentation/evidence delivery uses authorized CI skip only after proving all code, test, workflow and package inputs equal tested 61b19ae; it is not a new hosted code pass.\n'''
(b/'v22-closeout-draft-body.md').write_text(body);print(counts)
