"""Assess every immutable result and source limitation without further analysis runs."""
import collections,gzip,hashlib,json,tarfile
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];PREP=OUT.parent/'v79-unseen-metadata-correction';DEST=OUT/'final-assessment'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,data):
 with (DEST/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
p=read(PREP/'evaluation-proposal.json');v=read(DEST/'validation.json');inv=read(DEST/'inventory.json');assert v['validation_passed'] and v['completed']==12 and v['entire_ordered_pairs_equal']==6
scanner_sources={}
for name,start,end in [('src/sentinel/static/ast_utils.py',37,96),('src/sentinel/static/discovery.py',715,817),('src/sentinel/static/coverage.py',290,343),('src/sentinel/static/rules/sent012.py',15,73),('src/sentinel/static/typescript_execution.py',237,291)]:
 path=ROOT/name;lines=path.read_text().splitlines();assert sha(path)==p['files_sha256'][name];scanner_sources[name]={'sha256':sha(path),'lines':{str(n):lines[n-1] for n in range(start,min(end,len(lines))+1)}}
case_sources={}
manifest=read(ROOT/p['manifest']['path'])
for snapshot in manifest['snapshots']:
 archive=ROOT/snapshot['archive']['path'];assert sha(archive)==snapshot['archive']['sha256'];files={}
 with tarfile.open(archive) as t:
  for member in t:
   if not member.isfile():continue
   name=member.name.split('/',1)[1]
   if name in ['index.ts','src/proxmox_mcp/server.py','src/proxmox_mcp/client.py','src/proxmox_mcp/tools/storage.py','src/proxmox_mcp/tools/backup.py']:
    data=t.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==snapshot['files'][name];files[name]={'sha256':hashlib.sha256(data).hexdigest(),'complete_source':data.decode()}
 case_sources[snapshot['revision']]=files
save('decisive-source-review.json',{'scanner_sources':scanner_sources,'target_source':case_sources,'taskwarrior':'ShellFlow explicitly handles child_process.execFileSync with absent shell option as shell-free, independent of argv contents. Source exact dispatcher/parsed identifier and operator executable bind the named condition. Report has no positive per-sink trace; shared callback is unresolved at metadata level and safeParse remains unresolved. This supports only shell-boundary discrimination, not complete schema/dispatch coverage.','proxmox':'discover_tool_regions recognizes literal selector If or Match branches inside call_tool, not _DISPATCH.get(name) populated by nested loops over module.get_tools(). PythonProgram.tools consumes those regions and explicit add/register_tool; SENT012 starts only from recovered entries. Actual report marks the call_tool handler unsupported and only SENT004 examined. Its zero unresolved-flow list and global rule evaluated status do not establish path analysis. Recovery would require a new conservative computed-module dispatch recognizer with receiver/name/mutation/alias/duplicate checks; no such change or additional scan was performed.','source_conditions':'Proxmox tool/storage forwards caller file_path to client upload; vulnerable isfile then open original permits outside regular file. Fixed helper requires stable operator root, resolves both paths, rejects commonpath mismatch and passes checked value to open. This source proof does not make detector support pass. No target code was imported or executed.'})
contexts={}
for key,c in inv['contexts'].items():
 if c['case_id']=='taskwarrior-shell':
  if c['line'] is None:role='Complete module context for unresolved TypeScript binding diagnostics. SDK imports/receiver, Zod schemas, listed names, switch arms, task executable calls, catch and startup are source-visible. A file-only diagnostic has no invented precise line. Metadata conversion and named dispatch remain unresolved in the report.'
  elif c['line']==116:role='Official SDK CallToolRequestSchema callback. request.params supplies name and arguments; literal switch selects each source arm. Aggregate coverage records an unnamed unresolved surface, not three fully resolved tools.'
  elif 'safeParse' in c['statement']:role='Zod parsing of the indicated tool arguments. Failed parse throws; mark_task_done.identifier and add_task.description accept arbitrary strings. Report does not establish validation/protection. Exact shell-free fixed behavior does not depend on accepting a particular string or a complete schema model.'
  elif 'execFileSync' in c['statement']:role='Fixed shell-free child_process call with constant task executable and caller data in argv; no shell option is present. SENT002 recognizes this call form; other rules retain their own unresolved-call warnings. This is not a Taskwarrior option/filter/authorization or platform-wide safety guarantee.'
  elif 'execSync' in c['statement']:role='Vulnerable command string built from caller values before child_process.execSync invokes a shell. The line146 mark_task_done sink is the frozen condition; line175 add_task is a separate source-supported candidate. No command ran.'
  else:raise AssertionError(c)
 else:
  if c['path'].endswith('server.py'):role='Module-table SDK dispatcher: _build_dispatch_table derives a module owner from get_tools names, _DISPATCH.get(name) selects it, and module.handle_tool forwards arguments. Current literal-branch region discovery does not recover this form. The actual surface is unsupported and relevant downstream read/guard support is unestablished.'
  else:
   assert c['path'].endswith('tools/backup.py') and c['line']==82
   role='Static JSON-schema property named description whose value is a literal schema dictionary. The source contains static text Snapshot description; the retained SENT013 dynamic-description warning is overbroad for this schema field. It is neither a poisoning finding nor the scored upload route, and it establishes no tool discovery.'
 contexts[key]={'source':c,'assessment':role,'disposition':'Retained source-assessed context; raw uncertainty unchanged.'}
findings=[];diagnostics=[];surfaces=[];rows=[]
for row,validated in zip(inv['rows'],v['observations'],strict=True):
 assert row['input_id']==validated['input_id'] and row['batch']==validated['batch'];report=read(ROOT/row['report']);task=row['case_id']=='taskwarrior-shell';matched=[]
 for frow in row['findings']:
  f=frow['finding'];line=f['location']['range']['start_line'];assert task and row['label']=='vulnerable' and f['rule_id']=='SENT-002' and line in [146,175] and f['status']=='needs_review'
  named=line==146
  if named:matched.append(f['dedup_key']);assessment='Named vulnerable hit: mark_task_done takes an arbitrary string identifier through request.params, safeParse and the exact execSync template. Source witness changes shell syntax under the frozen POSIX/executable prerequisites. Flow locations116/142/146 bind this route. No executed exploit or runtime confirmation.'
  else:assessment='Unmatched add_task shell-injection candidate: caller description and optional due strings enter task_args and join into execSync. Source supports a separate shell boundary concern under the same startup/executable prerequisites. Project/tag validation does not constrain description/due. Fixed source changes this call to execFileSync argv. It is outside the frozen mark_task_done condition and remains needs_review, not a second scored hit or runtime-confirmed exploit.'
  findings.append({'input_id':row['input_id'],'batch':row['batch'],'report_sha256':row['report_sha256'],**frow,'matches_condition':named,'assessment':assessment})
 for d in row['diagnostics']:
  assert d['context'] in contexts;diagnostics.append({'input_id':row['input_id'],'batch':row['batch'],'report_sha256':row['report_sha256'],**d,'assessment_context':d['context'],'assessment':'Retain this exact occurrence, rule, code and original index. Context judgment does not resolve unknown binding/call or establish safety; Proxmox schema-field warning qualification is explicit in its context.'})
 for srow in row['surfaces']:
  s=srow['surface'];assert s['name'] is None
  if task:
   assert s['status']=='unresolved' and s['examined_rule_ids']==['SENT-002','SENT-012','SENT-014','SENT-015','SENT-016']
   assessment='One unnamed unresolved SDK callback covers source-visible switch arms. SENT002 caller-to-shell flow is present in vulnerable findings; source and exact ShellFlow semantics establish fixed shell-free handling. This does not turn metadata/schema/named-dispatch coverage into recognized status or imply other tools/rules are safe.'
  else:
   assert s['status']=='unsupported' and s['examined_rule_ids']==['SENT-004'];assessment='Unsupported computed module-table call_tool dispatcher. Named upload caller/guard/read analysis is not established; no findings and no unresolved-flow entries cannot support a negative gate. SENT004 examination and globally evaluated rule counts are separate from recovered SENT012 entry support.'
  surfaces.append({'input_id':row['input_id'],'batch':row['batch'],'report_sha256':row['report_sha256'],**srow,'assessment':assessment})
 assert len(matched)==(1 if task and row['label']=='vulnerable' else 0)
 if task and row['label']!='vulnerable':
  assert not report['findings'] and not any(w['message'].startswith('SENT-002') and ('execFileSync' in w['message'] or ':151:' in w['message']) for w in report['warnings'])
 assert row['coverage']['workspace'] is None and row['coverage']['total_possible_surfaces'] is None
 rows.append({**{k:validated[k] for k in ['group','batch','input_id','state','report_sha256','sarif_sha256','timing','native_seconds']},'label':row['label'],'matching_keys':matched,'named_vulnerable_detected':bool(matched) if row['label']=='vulnerable' else None,'supported_negative':task if row['label']!='vulnerable' else None,'named_dispatch_fully_resolved':False,'findings':len(row['findings']),'diagnostics':len(row['diagnostics']),'surfaces':len(row['surfaces'])})
comparisons=[]
with gzip.open(DEST/'complete-report-differences.jsonl.gz','rt') as f:
 for d in map(json.loads,f):
  paths={ '/'.join(x['path']) for x in d['changes'] }
  if d['kind']=='repeat':assert not paths;explanation='Entire ordered reports equal after only the11approved volatile exclusions.'
  elif d['kind']=='fixed_to_safe':assert paths=={'target/display_name'};explanation='Only the different input record display_name changes. Full fixed tree and configuration are identical; illustrative safe value does not specialize analysis.'
  elif d['case_id']=='proxmox-upload-root':
   assert paths=={'static_analysis/scanned_file_count','target/display_name'};explanation='Fixed adds one retained upstream test source (25to26scanned files) and record display_name changes. No findings/diagnostics/surface differences appear; this stable unsupported output is not guard or read support.'
  else:explanation='Upstream replaces shell calls with argv calls. Both vulnerable findings disappear: named mark_task_done and unmatched add_task. Exact row/source judgments cover changed warnings/unresolved calls and shifted callback spans. Rule match totals, candidate/unreviewed counts and summary severity/status counts change consistently2to0. Other rule statuses remain unchanged; missing permissions is still a skipped SENT001. Complete arrays and all path changes are retained without collapsing order.'
  comparisons.append({**{k:d[k] for k in d if k!='changes'},'changed_paths':sorted(paths),'assessment':explanation,'complete_ordered_reconstruction_verified':True})
assert (len(findings),len(diagnostics),len(surfaces),len(contexts),len(comparisons))==(4,504,12,18,14)
for name,data in [('source-context-assessment.json',{'contexts':contexts,'count':18,'unassessed':0}),('finding-source-assessment.json',{'rows':findings,'count':4,'unassessed':0}),('diagnostic-source-assessment.json',{'rows':diagnostics,'count':504,'by_kind':dict(collections.Counter(d['kind'] for d in diagnostics)),'unassessed':0}),('surface-source-assessment.json',{'rows':surfaces,'count':12,'total_possible_surfaces':'unknown','unassessed':0}),('ordered-difference-assessment.json',{'rows':comparisons,'count':14,'unassessed':0,'full_differences_sha256':sha(DEST/'complete-report-differences.jsonl.gz')})]:save(name,data)
cases=[]
for group,g in p['groups'].items():
 task=group=='taskwarrior-shell';selected=[r for r in rows if r['group']==group]
 cases.append({'case_id':group,'repository':g['repository'],'language':g['actual_language'],'completed':6,'entire_ordered_pairs_equal':3,'vulnerable_detected':2 if task else 0,'vulnerable_total':2,'matching_negative_alerts':0,'supported_negatives':4 if task else 0,'negative_total':4,'named_dispatch_fully_resolved':False,'named_sink_and_fixed_boundary_supported':task,'repository_gate_passed':task,'qualification':'Narrow shell-free argument discrimination; metadata/parse/other-rule uncertainty retained.' if task else 'Vulnerable read missed; fixed/safe unsupported. Computed module-table dispatch is outside the current recognizer; global evaluated status and zero warnings/flows are not coverage.'})
files=['decisive-source-review.json','source-context-assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json','ordered-difference-assessment.json']
save('assessment.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':p['scanner'],'proposal_sha256':sha(PREP/'evaluation-proposal.json'),'approval_sha256':sha(PREP/'evaluation-authorization.json'),'rubric_sha256':sha(PREP/'scoring-rubric.json'),'validation_sha256':sha(DEST/'validation.json'),'execution_gate_passed':True,'source_assessment_complete':True,'fresh_detection_gate_passed':False,'repository_gates_passed':1,'repository_gates_total':2,'cases':cases,'rows':rows,'budget':{'planned':12,'attempted':12,'completed':12,'unstarted':0,'remaining':0,'closed':True,'paid_calls':0,'retries':0,'profiles':0,'comparators':0,'target_executions':0},'entire_ordered_repeat_pairs_equal':6,'complete_ordered_comparisons':14,'finding_count':4,'diagnostic_count':504,'surface_count':12,'source_contexts':18,'whole_input_seconds_min':min(r['timing']['elapsed_seconds'] for r in rows),'whole_input_seconds_max':max(r['timing']['elapsed_seconds'] for r in rows),'all_within120_target':all(r['timing']['elapsed_seconds']<=120 for r in rows),'assessment_files_sha256':{name:sha(DEST/name) for name in files},'original_v78_metadata_failure_retained':True,'technical_acceptance_received':False,'phase22_complete':False,'qualification':'Same-agent static source assessment, not independent review, target execution, model-training novelty, population accuracy or whole-repository safety. All original source prerequisites and unrelated results remain. V78 failed before analysis; V80 supplies the first complete reports on these unchanged first-frozen sources. Proxmox remains a failed fresh gate; no automatic waiver or tuning occurred.'})
print('All4findings/504diagnostics/12surfaces/18contexts/14ordered comparisons assessed. Taskwarrior narrow pass; Proxmox missed read and unsupported negatives. 12completed,6pairs,budgetclosed,zero paid.')
