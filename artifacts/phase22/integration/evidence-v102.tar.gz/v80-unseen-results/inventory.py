"""Source-bind every retained occurrence and complete ordered comparison; no scans."""
import ast,collections,copy,gzip,hashlib,importlib.util,json,re,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[3];PREP=OUT.parent/'v79-unseen-metadata-correction';DEST=OUT/'final-assessment'
sys.path[:0]=[str(ROOT/'src'),str(ROOT)]
from scripts.phase20_corpus import input_files
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
c=load('unseen_corpus',PREP/'corpus.py');r=load('unseen_runner',PREP/'evaluate.py');p=r.verify();v=read(DEST/'validation.json');assert v['validation_passed'] and v['completed']==12
m=c.frozen(approval_path=PREP/'source-freeze-authorization.json');items={i.id:i for i in m.inputs};snapshots={s.revision:s for s in m.snapshots};sources={}
for i in m.inputs:
 if i.snapshot not in sources:sources[i.snapshot]=input_files(i,snapshots[i.snapshot],ROOT)
contexts={};rows=[]
def context(item,path,line=None):
 data=sources[item.snapshot][path];lines=data.decode().splitlines();key=f'{item.snapshot}:{path}:{line or "file"}'
 if key not in contexts:
  c={'repository':item.repository,'case_id':item.family,'snapshot':item.snapshot,'path':path,'source_sha256':hashlib.sha256(data).hexdigest(),'line':line}
  if line:
   assert 0<line<=len(lines),(path,line);c.update(statement=lines[line-1],excerpt=[f'{n+1}: {lines[n]}' for n in range(max(0,line-5),min(len(lines),line+5))])
   if path.endswith('.py'):
    scopes=[n for n in ast.walk(ast.parse(data)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)) and n.lineno<=line<=n.end_lineno];c['scope']=min(scopes,key=lambda n:n.end_lineno-n.lineno).name if scopes else 'module'
  else:c.update(full_source=data.decode(),precision='file only; diagnostic supplies no line')
  contexts[key]=c
 return key
for row in v['observations']:
 item=items[row['input_id']];path=OUT/'raw'/row['directory']/item.id/'report.json';d=read(path);assert sha(path)==row['report_sha256'];findings=[];diagnostics=[];surfaces=[]
 for f in d['findings']:
  loc=f['location'];findings.append({'finding':f,'context':context(item,loc['path'],loc['range']['start_line']),'flow_contexts':[context(item,l['path'],l['range']['start_line']) for l in f['evidence'].get('flow_locations',[]) if l.get('kind')=='file']})
 coverage=d['static_analysis']['coverage']
 for kind,entries in [('warning',d['warnings']),('unresolved_flow',coverage['unresolved_flows'])]:
  for index,w in enumerate(entries):
   match=re.fullmatch(r'SENT-\d+ at (.+):(\d+): (.+)',w['message'])
   if match:key=context(item,match[1],int(match[2]))
   else:
    paths=[n for n in sources[item.snapshot] if w['message'].startswith(n+': ')];assert len(paths)==1,w;key=context(item,paths[0])
   diagnostics.append({'kind':kind,'index':index,'diagnostic':w,'context':key})
 for index,s in enumerate(coverage['surfaces']):
  loc=s['location'];surfaces.append({'index':index,'surface':s,'context':context(item,loc['path'],loc['range']['start_line'])})
 rows.append({'input_id':item.id,'batch':row['batch'],'case_id':item.family,'snapshot':item.snapshot,'label':item.label,'report':str(path.relative_to(ROOT)),'report_sha256':sha(path),'findings':findings,'diagnostics':diagnostics,'surfaces':surfaces,'coverage':coverage})
# Preserve arrays wholesale whenever changed; no ordering information is discarded.
def changes(a,b,path=()):
 if a==b:return []
 if isinstance(a,dict) and isinstance(b,dict) and a.keys()==b.keys():return [d for k in a for d in changes(a[k],b[k],path+(k,))]
 return [{'path':list(path),'before':a,'after':b}]
comparisons=[]
by={(x['batch'],x['input_id']):x for x in rows}
with gzip.open(DEST/'complete-report-differences.jsonl.gz','xt',encoding='utf-8') as stream:
 for group,g in p['groups'].items():
  ids=g['input_ids']
  pairs=[('repeat',by['first',i],by['repeat',i]) for i in ids]+[(kind,by[batch,ids[0 if kind=='vulnerable_to_fixed' else 1]],by[batch,ids[1 if kind=='vulnerable_to_fixed' else 2]]) for batch in ['first','repeat'] for kind in ['vulnerable_to_fixed','fixed_to_safe']]
  for kind,left,right in pairs:
   before=r.supervisor.clean(read(ROOT/left['report']),set(p['volatile_exclusions']));after=r.supervisor.clean(read(ROOT/right['report']),set(p['volatile_exclusions']));delta=changes(before,after);reconstructed=copy.deepcopy(before)
   for d in delta:
    target=reconstructed
    for k in d['path'][:-1]:target=target[k]
    assert d['path'] and target[d['path'][-1]]==d['before'];target[d['path'][-1]]=d['after']
   assert reconstructed==after
   if kind=='repeat':assert not delta
   common={'case_id':group,'kind':kind,'before_report':left['report'],'after_report':right['report'],'before_sha256':left['report_sha256'],'after_sha256':right['report_sha256']}
   stream.write(json.dumps({**common,'changes':delta},separators=(',',':'))+'\n');comparisons.append({**common,'changed_paths':['/'.join(d['path']) for d in delta],'ordered_reconstruction_verified':True})
result={'rows':rows,'contexts':contexts,'source_files':{rev:{name:hashlib.sha256(data).hexdigest() for name,data in files.items()} for rev,files in sources.items()},'comparisons':comparisons,'complete_report_differences_sha256':sha(DEST/'complete-report-differences.jsonl.gz'),'volatile_exclusions':p['volatile_exclusions'],'source_assessment_pending':True}
with (DEST/'inventory.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(len(rows),'reports;',len(contexts),'source contexts;',sum(len(x['findings']) for x in rows),'findings;',sum(len(x['diagnostics']) for x in rows),'diagnostics;',sum(len(x['surfaces']) for x in rows),'surfaces;',len(comparisons),'complete ordered comparisons.')
