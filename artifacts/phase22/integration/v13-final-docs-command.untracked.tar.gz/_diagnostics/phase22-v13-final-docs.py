import hashlib,json,re
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');base=root/'artifacts/phase22/integration';read=lambda n:json.loads((base/n).read_text());audit=read('v13-closeout-audit/packet.json');host=read('v13-hosted-audit/packet.json');retained=read('v13-hosted-current/packet.json');seal=read('evidence-v42.json');local=read('v13-full-suite-coverage.json')['totals']['percent_covered'];low=min(r['branch_coverage_percent'] for r in host['quality']);high=max(r['branch_coverage_percent'] for r in host['quality']);ci=retained['runs']['ci']['databaseId'];docs=retained['runs']['docs']['databaseId'];assert audit['dispositions']['passed']==70 and audit['dispositions']['unresolved']==17
quality=f'''Final-source local and all 12 hosted quality suites pass **2,182 tests, 36 skips
and no expected failures**. Local branch coverage is **{local:.2f}%**; hosted coverage
is **{low:.2f}–{high:.2f}%**. All 29 normal jobs and docs pass at `1be0650`, whose
code/test/workflow/package inputs equal measured `2ac39aa`
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/{ci}),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/{docs})). Actual
wheel/sdist source members match Git. Ruff/format, strict mypy, lock, schemas,
notices, offline artifacts, dependencies, wheel smoke, Docker replay, isolation
and hook checks pass. Both approved production requests regenerate and replay
without new paid calls. The exact approved Git image/runtime bindings match;
its 13 campaigns remain incomplete (312 tested, 728 remaining).
'''
pattern=re.compile(r'Final-source local verification passes:.*?hosted passes below retain their historical source\.\n',re.S)
paths=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']
for name in paths:
 p=root/name;s=p.read_text();assert len(pattern.findall(s))==1,name;p.write_text(pattern.sub(lambda m:quality,s,count=1))
p=base/'requirements.md';s=p.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current continuation at `2ac39aa`','## Historical initial v13 delivery',1)
lines=['## Current 89-row audit at `2ac39aa`','','**70 passed, 2 explicitly user-deferred, 17 unresolved.** All IDs and prior','evidence remain preserved. Exact implementation, executed tests, source hashes','and evidence for every row are in `v13-closeout-audit/packet.json` and','`v13-current-source-test-bindings/packet.json`. Hosted source `1be0650` has','identical code/test/workflow/package inputs. The three exposed SSRF gates pass;','timing, fresh evaluation and final human acceptance remain unmet.','','| ID | Requirement | Current disposition |','| --- | --- | --- |']
for row in audit['requirements']:
 requirement=row['requirement'].replace('|','\\|').replace('\n',' ');lines.append(f"| {row['id']} | {requirement} | **{row['disposition']}** |")
p.write_text(title+'\n\n'+'\n'.join(lines)+'\n'+rest)
count=len(seal['files']);raw=sum(r['bytes'] for r in seal['files']);compressed=(base/seal['archive']).stat().st_size
index=f'''Batch 42 is sealed: **{count:,} files**, {raw:,} raw bytes and
{compressed:,} compressed bytes, SHA-256
`{seal['sha256']}`.
Every member was read back and all 41 prior numbered archive hashes reverified
after native/test/collector writers stopped. Restore after batches 1–41 into
separate staging; validate the archive and each member against `evidence-v42.json`
before copying. Existing destinations must match identical bytes or their prior
numbered-manifest hashes; stop on unexpected conflicts.

This batch preserves the passing three-family exposed gates, the one fixed
trace, the attempted/reverted performance change and all 14 observations,
current local/hosted checks, production replay and Git compatibility, full
reports, failed attempts, commands and helper sources. Final audit, docs and
delivery bindings are directly tracked after the seal, including
`v13-closeout-audit/packet.json`, `v13-final-documentation-binding.json`,
`v13-delivery-verification.json` and `v13-closeout-draft-body.md`.
The archive is evidence delivery, not a timing pass or Phase 22 acceptance.

'''
p=base/'README.md';s=p.read_text();assert 'Batch 42 is sealed:' not in s and s.count('## Evidence archives\n')==1;s=s.replace('batches 1–41 and closeout audit','batches 1–42 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);p.write_text(s)
p=base/'progress.md';p.write_text(p.read_text().rstrip()+'\n\n### Evidence batch 42 and current audit\n\n'+index.rstrip()+'\n\nThe current audit records 70 passed, two explicitly user-deferred and 17\nunresolved requirements. Timing/fresh evaluation/final acceptance remain unmet.\n')
initial=(base/'v13-initial-draft-body.md').read_text();pattern=re.compile(r'Local final-source verification passes .*?previous hosted passes retain their historical source\.',re.S);assert len(pattern.findall(initial))==1
body=pattern.sub(lambda m:quality.strip()+' Pinned historical reproduction jobs retain their original scanner and do not establish current-source timing.',initial,count=1)
body=body.replace('preserve the measurements, failed attempts and separate gates.','preserve all 89 requirements: **70 passed, two explicitly user-deferred, 17 unresolved**, with verified evidence batches 1–42. Full logs, reports, distributions and helper sources are retained.',1)
body=body.replace('[core verification packet](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v13-prehosted-packet.json)','[current 89-row audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v13-closeout-audit/packet.json)')
body+='\nFinal documentation/evidence delivery uses the explicitly permitted CI-skip convention after proving its code/test/workflow/package inputs equal hosted `1be0650` and measured `2ac39aa`. Final docs are checked locally; no new hosted code pass is claimed for that later commit.\n'
p=base/'v13-closeout-draft-body.md';assert not p.exists();p.write_text(body)
print('Updated final current docs/audit table/restore index/draft body',count,local,low,high)
