## Current v67 invalidation regression: timed out, budget closed

The approved 205-observation sequence at frozen **`4145d35`** stopped on its first
FAF vulnerable input after **1800.008716 seconds** whole-input time.
**One incomplete, zero reports, 204 unstarted closed, zero remaining.** Cleanup
passed within its separate 15-second allowance. Findings, detection, fixed/control
support and ordered repeats remain unknown. No retry, profile or paid call ran.

`v67-invalidation-regression/diagnostic-proposal.json` prepares **one unapproved,
unexecuted parent-and-worker sampled FAF input**, maximum 1800 seconds plus
15 seconds cleanup. It reuses the existing sampler and worker layout with actual
source identities verified before timers/target access. Synthetic identity,
completion/interruption, timer and missing-approval controls pass. The older
`1948bf9` parent profile cannot establish residual costs after the accumulator
change. No optimization, resource/deadline revision or native speedup is included.

All **383 requirements (89 original + 294 added)** remain, including seven native
timeouts, five valid partial profiles, invalid stale-root preparation, both
singleton failures, the original strict invalidation failure and six unaccepted
historical closure proposals. Product retains tested `4145d35`: **2,419 tests /
36 skips** locally and all 12 hosted suites, 29 normal CI jobs and docs passed.
Combined coverage is 90.08%, branch-only 85.92%; six zero-call production replays
and approved runtime/image bindings remain compatible. This continuation adds
outcome, preparation and docs/package checks, not another hosted code pass.

**Phase 22 remains incomplete**, pending current-source gates, explicit human
technical acceptance and accepted closeout. Git stays 312/1,040 incomplete, with
728 deferred; paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No merge, ready-state change, release, outreach or Phase 23 is authorized.

