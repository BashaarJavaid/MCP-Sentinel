import json, subprocess, sys, time
from pathlib import Path

root = Path('/private/tmp/mcp-phase22-options')
evidence = root/'artifacts/phase22/integration'
while not (evidence/'v2-installed-queue-dcb965f.json').exists():
    time.sleep(5)
assert not subprocess.check_output(['git','diff','dcb965f','HEAD','--','src/sentinel','scripts','tests'], cwd=root)
for scope in ['historical', 'development', 'held_out']:
    path = evidence/f'v2-{scope}-rules-dcb965f-first/results.json'
    data = json.loads(path.read_text())
    assert len(data['outcomes']) == (45 if scope == 'historical' else 25)
    assert all(r['state'] == 'completed' for r in data['outcomes'])
    label = f'v2-{scope}-native-requests-dcb965f'
    assert not (evidence/(label+'.json')).exists()
    print('Preparing exact offline requests:', scope, flush=True)
    code = subprocess.run([sys.executable, '/private/tmp/phase22-check.py', label, sys.executable, '/private/tmp/phase22-v2-fixed-parent-evidence-command.py', sys.executable, '/private/tmp/phase22-v2-native-request-preparation-dcb965f.py', scope], cwd=root).returncode
    if code:
        sys.exit(code)
print('Offline requests retained; not paid authorization or an assertion that other gates passed.', flush=True)
