# Thirty-minute static deadline: engineering in progress

Candidate `7bf4c6e1cf0c8d83229b1273f80737e7cacc5b82` changes the shared deterministic static deadline from 300 to 1,800 seconds. The user accepted a longer supported limit to prioritize completed, correct results. The 120-second target is informational; shorter caller deadlines and incomplete-on-expiry behavior remain enforced. Workers, rule selection, detector logic, schemas and cleanup are unchanged. This revises the timing policy; it does not claim a speedup or relabel any earlier failure.

Source proof shows exactly one changed product AST literal. Focused static/worker/deadline regressions and whole-scope Ruff/format/strict mypy pass. Existing tests now cover completion beyond 300 seconds, the new maximum, shorter caller deadlines and late report assembly. Full local and hosted verification are in progress. No new corpus observation, profile or paid call has run.

All four native timeouts, three partial profiles, invalid stale-root preparation, both singleton failures, original four fresh failures, prior Python/TypeScript and whole Linux evidence, and unaccepted historical closure proposals remain preserved. The unexecuted v58 sampled diagnostic is superseded as the next step by this user-directed policy revision; it has not been approved or executed.

Phase 22 remains incomplete. The exact new frozen-source regression, its results, explicit human technical acceptance and accepted closeout remain separate. Git stays 312/1,040 incomplete; paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. PR stays OPEN DRAFT; no merge, ready-state change, release, outreach or Phase 23. Main and all eight protected user documents remain preserved.

The preceding complete audit and failure evidence remain in [v58](https://github.com/BashaarJavaid/MCP-Sentinel/blob/b168738236d9f0b637fa8764f1ad0f3bbcae50d8/artifacts/phase22/integration/v58-credential-regression/summary.md). The final engineering packet and exact evaluation proposal will follow verification.
