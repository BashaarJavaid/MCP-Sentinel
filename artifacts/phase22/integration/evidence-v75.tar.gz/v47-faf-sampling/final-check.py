"""Verify final profile/proposal evidence and unchanged engineering source."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ENGINEERING = BASE/'v45-four-source-recovery'
OLD = BASE/'v46-four-source-regression'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
checks = ['v47-profile-assessment', 'v47-owned-cleanup-after-assessment', 'v47-reconciliation', 'v47-final-docs', 'v47-final-build', 'v47-final-distributions']
for name in checks:
    assert read(BASE/(name+'.json'))['exit_code'] == 0, name
assert read(BASE/'v47-owned-cleanup.json')['exit_code'] == 1
engineering = read(ENGINEERING/'local-checks.json')['candidate_engineering_files_sha256']
assert len(engineering) == 302
for name, digest in engineering.items():
    assert sha(ROOT/name) == digest, name
    assert sha(Path('/private/tmp/mcp-phase22-frozen-17b4784')/name) == digest, name
binding = read(OLD/'documentation-binding.json')
for name, digest in binding['user_files_sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in read(OUT/'owning-docs.json')['sha256'].items():
    assert sha(ROOT/name) == digest, name
prior = read(ENGINEERING/'prior-row-preservation.json')['referenced_evidence_sha256']
for name, digest in prior.items():
    assert sha(ROOT/name) == digest, name
p = read(OUT/'optimization-proposal.json')
assert p['profile_assessment_sha256'] == sha(OUT/'assessment.json')
assert p['source_assessment_sha256'] == sha(OUT/'source-assessment.json')
assert p['target_source_sha256'] == sha(ROOT/'src/sentinel/static/typescript_path_flow.py')
assert p['bounds']['source_only_optimization_attempts'] == 1
assert all(p['bounds'][k] == 0 for k in ['corpus_observations', 'profiles', 'comparators', 'retries', 'new_repositories', 'paid_calls', 'runtime_campaigns'])
assert not (OUT/'optimization-authorization.json').exists()
assert not (BASE/'v48-merge-allocation').exists()
a = read(OUT/'assessment.json')
assert a['profile_attempts'] == 1 and a['incomplete_inputs'] == 1 and a['completed_inputs'] == 0
assert a['budget_closed'] and a['remaining'] == 0 and a['optimization_attempts'] == 0
assert sum(r['samples'] for r in a['sample_rows']) == 86659
for row in a['sample_rows']:
    assert sha(OUT/(row['rule']+'-cpu-samples.json')) == row['profile_sha256']
assert read(OUT/'final-distributions.json')['wheel_product_schema_fixture_members_byte_identical_to_hosted']
audit = read(OUT/'audit.json')
assert len(audit['requirements']) == 89 and len(audit['additional_scope_requirements']) == 150
assert audit['requirements'] == read(OLD/'audit.json')['requirements']
assert not audit['technical_acceptance_received'] and not audit['phase22_complete']
assert not subprocess.check_output(['git', 'diff', '17b4784', '--', 'src', 'tests', 'scripts', 'schemas', '.github', 'uv.lock', 'pyproject.toml', 'CHANGELOG.md'])
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', '8b6b0ddf1d6f6cf5a8da3ab9421471865b801455', 'HEAD'], check=True)
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=main, text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=main)
raw = [OUT/n for n in ['sampling-worker.py', 'attempt.json', 'execution.json', 'budget-closed.json', 'observation.log']]
raw.extend(OUT.glob('SENT-*-cpu-samples.json'))
raw.extend(p for p in (OUT/'measurement').rglob('*') if p.is_file())
write('raw-binding.json', {'files_sha256': {str(p.relative_to(OUT)): sha(p) for p in raw}, 'writer_stopped': True, 'paid_calls': 0})
write('command-provenance.json', {'wrapper_commands': {n: read(BASE/(n+'.json')) for n in checks+['v47-owned-cleanup']},
    'direct_commands': [
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'authorize-diagnostic.py')], 'exit_code': 0, 'evidence': 'v46-four-source-regression/diagnostic-preflight.json', 'qualification': 'Recorded exact decision and source/cleanup bindings; no input execution.'},
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'diagnostic.py')], 'exit_code': 1, 'evidence': 'v47-faf-sampling/execution.json', 'qualification': 'One approved300-second profile timeout; output retained in observation.log,measurement results and periodic profiles.'}],
    'failure_assessment': 'The diagnostic timeout is retained. The first cleanup check correctly detected the concurrent read-only assessment; cleanup-check-correction.json binds the later success after that process ended. No extra input or kill occurred.', 'paid_calls': 0})
write('final-checks.json', {'passed': True, 'recorded_at': datetime.now(timezone.utc).isoformat(), 'scanner': a['scanner'],
    'engineering_files_verified': 302, 'prior_evidence_files_verified': len(prior), 'requirements': 239, 'protected_user_files': 8,
    'owning_docs': 16, 'main_and_parent_preserved': True, 'checks_sha256': {n: sha(BASE/(n+'.json')) for n in checks},
    'optimization_proposal_sha256': sha(OUT/'optimization-proposal.json'), 'sampled_attempts': 1, 'native_observations': 0,
    'optimization_attempts': 0, 'budget_closed': True, 'remaining': 0, 'paid_calls': 0, 'technical_acceptance_received': False, 'phase22_complete': False})
print('Final checks passed:302engineering files,239requirements,16docs,one closed profile and zero optimization.')
