"""Reconcile the bounded profile, source-only next decision and every audit row."""
import copy
import hashlib
import json
import os
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ROOT = OUT.parents[3]
OLD = BASE/'v46-four-source-regression'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
a = read(OUT/'assessment.json')
assert a['validation_passed'] and a['profile_attempts'] == 1 and a['completed_inputs'] == 0
assert read(OUT/'owned-work.json')['owned_processes'] == []
assert not (OUT/'optimization-authorization.json').exists()
old = read(OLD/'audit.json')
rows = copy.deepcopy(old['additional_scope_requirements'])
for row in rows:
    if row['id'] == 'V46-DELIVERY':
        row['previous_row'] = copy.deepcopy(row)
        row['disposition'] = 'passed'
        row['evidence'] = [str((OLD/'delivery-verification.json').relative_to(ROOT))]
        row['assessment'] = 'Actual73d7b61draft delivery verified before the separate profile approval; failed regression remains unchanged.'
new = [
    ('V47-AUTH', 'Bind exact single-profile approval without reopening the closed regression budget', 'passed', ['../v46-four-source-regression/diagnostic-authorization.json', '../v46-four-source-regression/diagnostic-preflight.json']),
    ('V47-EXECUTION', 'Execute only one bounded sampled attempt and retain partial snapshots, timeout and verified cleanup with zero budget remaining', 'passed', ['execution.json', 'budget-closed.json', 'owned-work.json']),
    ('V47-ASSESSMENT', 'Validate every retained profile and source attribution while preserving sampling limitations and absent report content', 'passed', ['assessment.json', 'sample-attribution.json', 'source-assessment.json', 'frame-source-bindings.json']),
    ('V47-PREPARATION', 'Prepare a narrow evidence-supported source-only optimization proposal without modifying the scanner', 'passed', ['optimization-proposal.json']),
    ('V47-OPTIMIZATION-DECISION', 'Obtain an explicit decision on the single source-only optimization attempt before starting it', 'unresolved', ['optimization-proposal.json']),
    ('V47-DELIVERY', 'Seal completed diagnostic evidence and verify the concrete next decision in existing draftPR37', 'unresolved', []),
]
for identity, requirement, disposition, evidence in new:
    rows.append({'id': identity, 'requirement': requirement, 'disposition': disposition,
        'evidence': [str((OUT/n).resolve().relative_to(ROOT)) for n in evidence],
        'assessment': 'Single sampled input incomplete at300seconds; partial attribution validated, no report or native pass. No optimization, retry, extra observation or technical acceptance authorized.'})
assert len(old['requirements']) == 89 and len(rows) == 150
assert len({r['id'] for r in old['requirements']+rows}) == 239
audit = copy.deepcopy(old)
audit['historical_v46_status_fields'] = {k: old[k] for k in ['diagnostic_prepared', 'diagnostic_approved', 'diagnostic_executed', 'status']}
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(), additional_scope_requirements=rows,
    additional_scope_dispositions=dict(Counter(r['disposition'] for r in rows)),
    prior_audit={'path': str((OLD/'audit.json').relative_to(ROOT)), 'sha256': sha(OLD/'audit.json')},
    diagnostic_approved=True, diagnostic_executed=True, diagnostic_attempts=1, diagnostic_completed_inputs=0,
    diagnostic_budget_closed=True, diagnostic_remaining=0, optimization_prepared=True, optimization_approved=False,
    optimization_attempts=0, new_paid_calls=0, acceptance_packet_ready=False, technical_acceptance_received=False,
    phase22_complete=False, status='One approved FAF sampled input timed out at300seconds with four retained partial snapshots and cleanup verified. Profile attribution supports a narrow fallback-allocation proposal; no optimization or new native observation occurred. Corrected detection/compatibility and human acceptance remain unresolved.')
audit['current_evidence'] = {n: sha(OUT/n) for n in ['assessment.json', 'sample-attribution.json', 'source-assessment.json', 'optimization-proposal.json', 'owned-work.json']}
for identity in ['R66', 'R88']:
    audit['current_requirement_interpretations'][identity] = 'Original24first-frozen observations and all4failed fresh gates remain at2e0efb2. Corrected17b4784regression stopped at1incomplete/204unstarted closed. A separately approved one-input worker profile also timed out; it identifies a merge-allocation concentration but establishes no completed detection/compatibility or native performance pass. No original failure or proposed limitation is accepted.'
write('audit.json', audit)
write('prior-row-preservation.json', {'prior_audit_sha256': sha(OLD/'audit.json'), 'retained_prior_rows': 233, 'updated_rows': ['V46-DELIVERY'],
    'rows': {r['id']: hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']}})
table = '\n'.join(f"| {r['rule']} | {r['samples']:,} | {r['merge_inclusive_percent']:.2f}% | {r['merge_fallback_constructor_leaf_percent']:.2f}% |" for r in a['sample_rows'])
summary = f'''# FAF sampled timeout and narrow source-only proposal

**The approved single FAF CPU-sampled input at frozen `17b4784` timed out at {a['timing']['elapsed_seconds']:.6f} seconds. Four partial snapshots retain 86,659 samples; no scan report was produced. The one-use diagnostic budget is closed, with zero remaining. Phase 22 remains incomplete.**

The exact user decision `approved` binds the [diagnostic authorization](../v46-four-source-regression/diagnostic-authorization.json), proposal SHA `3cb2a24fdd718c4cee63c84a9d10c3f8694dc004d9ef621651e9ced93f7ba575` and draft delivery `73d7b61`. The same `faf-read-root-vulnerable` source/configuration ran once, using the approved existing worker wrapper at at most 100Hz. Scanner methods, selected rules, process layout and deadlines remained unchanged. No parent sampling, target execution, optimization, retry, comparator or paid call occurred.

The [validated attribution](sample-attribution.json) and [source assessment](source-assessment.json) identify this concentration:

| Worker | Retained samples | Merge, inclusive | Fallback constructor, leaf |
| --- | ---: | ---: | ---: |
{table}

Each worker places about 99.5% of retained samples in TypeScript factory-registration discovery. Within that traversal, branch merging accounts for 58.36–59.06% inclusively; the generated immutable `Value` constructor called directly from merge line 307 accounts for 25.78–26.41% as a leaf. **These shares overlap and are not additive costs, unused-allocation counts or promised savings.** Source shows `Value(key=root)` is constructed before `branch.get`, even when every branch contains the record-state name. Samples contain no locals, so the fraction actually unused and the achievable speedup remain unmeasured.

All four snapshots are periodic, not final; final timer/restoration flags are false because mandatory scanner cleanup killed the workers before their final snapshots. No process remains, so this is incomplete sample coverage rather than a surviving timer. Captured stacks have at most 192 frames, below the 1,024 cap, with no recorded truncation. Signal delivery/GIL/native-code delays, reentrant skipped signals, snapshot overhead and separately copied event counters limit attribution; the last unsnapshotted interval and parent-stage cost remain unknown. All frame references/counts and available scanner/sampler/dependency source hashes validate. No raw profile or first result was edited.

The [execution assessment](assessment.json) retains one incomplete instrumented input and cleanup by **{a['timing']['elapsed_including_cleanup_seconds']:.6f} seconds**, within the 15-second allowance, without a remaining group kill. The harness's incomplete record and no report leave findings, warnings, surfaces, named detection and negative discrimination **unknown**, not zero. This is no completed native timing, condition, repeat or fresh pass. The prior uninstrumented regression remains one incomplete attempt and 204 unstarted closed; no part of that budget reopened.

The [source-only optimization proposal](optimization-proposal.json), SHA-256 `{sha(OUT/'optimization-proposal.json')}`, is **unapproved and unstarted**. It requests one narrow attempt in `TypeScriptPathFlow.merge`: construct the record-root fallback only when at least one branch lacks the name. Keep every used fallback, branch order, guard, source-free safety, combined metadata and missing-record behavior intact. Prefer a local dictionary-membership predicate, with no cache or new abstraction. Do not broaden traversal, suppress diagnostics, change source labels or alter deadlines.

Approval would cover scanner-owned synthetic baseline/candidate state equivalence and allocation accounting, affected regressions and required full local/hosted engineering. It would authorize **zero corpus observations, profiles, comparators, retries, new repositories, target executions, runtime campaigns or paid calls**. If the proposed synthetic reduction or semantics cannot be established, stop and retain the failed attempt; do not expand to another optimization. After a verified candidate, freeze it and prepare a separate exact measurement proposal. Neither samples nor synthetic checks establish a native speedup or resolution of the 300-second failure.

The initial [cleanup check](cleanup-check-correction.json) ran while this read-only assessment was still active and correctly reported that assessment and its wrapper. After awaiting their completion, the separate cleanup check passed. No process was killed and no scanner observation was added by that recheck.

Product, tests, workflow, schema and lock remain tested **`17b4784`**: **2,380 tests / 36 skips** locally and in all 12 hosted suites, all **29 normal CI jobs** and docs passed in [34737757018](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34737757018) / [34737757049](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34737757049). Combined statement/branch coverage is 89.98%, branch-only 85.85%. The hosted merge `0511e6a57741ac6152922c809c3e0ad72fee0f7f` has the candidate tree. The 302 engineering files, six exact zero-call production replays, owned Docker 20/20 fixture and Git image/runtime bindings remain source-bound. This continuation adds profile assessment and final docs/package checks, not a new hosted code pass.

The [full audit](audit.json) preserves all 89 original and 144 prior added rows, then adds six: **239 total**. Original dispositions remain 84 passed, two user-deferred, two proposed limitations and one unresolved human acceptance. All six historical failed-attempt closure proposals remain unaccepted. Corrected four-repository and affected prior-language gates remain unestablished, and no timeout or original fresh failure is accepted as a limitation.

The original four-repository result at `2e0efb2` remains 24 complete observations and four failed fresh gates. Memory-keeper's original fresh false alerts, DDG's unsupported initial fixed send and erroneous TypeScript manifest label despite actual Python configuration, Lighthouse misses and later exposed passes retain their sources. The original held-out result remains 10 completed, 10 unsupported and five incomplete, with zero hits among four completed vulnerable inputs out of ten vulnerable total. Whole 25 development reuse and 45+45 Linux timing/conditions remain at `1f3f72f`, with the Meta operator erratum. Prior TS94 at `2e0efb2` and Python87 at `8c62567` are historical results; language subsets are never pooled into a new whole batch. All earlier failed/stopped attempts remain preserved. Same-agent curation/review is not independent human validation, broad accuracy, training-data novelty or runtime proof.

Git campaigns remain **312/1,040 incomplete**, with 728 deferred. Paid benchmark and pilots remain deferred, Phase 21 incomplete and Phase 24/15 gates unchanged. No merge, ready-state change, release, outreach or Phase 23 is authorized. Continue after the next explicit scope decision toward verified corrected-source gates, separate human technical acceptance and accepted closeout to the same draft PR.
'''
with (OUT/'summary.md').open('x') as stream:
    stream.write(summary)
url = 'https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/'
body = summary.replace('(../v46-four-source-regression/', '('+url+'v46-four-source-regression/')
for name in ['sample-attribution.json', 'source-assessment.json', 'assessment.json', 'optimization-proposal.json', 'cleanup-check-correction.json', 'audit.json']:
    body = body.replace('('+name+')', '('+url+'v47-faf-sampling/'+name+')')
with (OUT/'pr-body.md').open('x') as stream:
    stream.write(body)
docs = list(read(OLD/'documentation-binding.json')['owning_docs_sha256'])
for name in docs:
    path = ROOT/name
    text = path.read_text().replace('## Current v46 regression timeout: budget closed', '## Historical v46 regression timeout: budget closed', 1)
    link = url+'v47-faf-sampling/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md', path.parent)
    status = f'''## Current v47 sampled timeout: source-only proposal pending

The separately approved single FAF worker profile at frozen `17b4784` timed out
at 300 seconds with verified cleanup: **one incomplete sampled input, four partial
snapshots / 86,659 samples, no report, zero budget remaining**. The [review packet]({link})
attributes 58.36–59.06% of worker samples inclusively to TypeScript branch merging
and 25.78–26.41% as leaves in its fallback Value constructor. These overlapping
sample shares are not promised savings; unused allocations remain uncounted.
One narrow **source-only fallback-allocation optimization** is proposed, unapproved
and unstarted, with zero new corpus/profile/paid budget. The prior regression's
one incomplete attempt and 204 closed unstarted observations remain unchanged.
Corrected detection/compatibility gates remain unresolved. Engineering retains
tested `17b4784`: 2,380 tests / 36 skips locally and in all 12 hosted suites,
29 normal CI jobs and docs passed; combined coverage 89.98%, branch-only 85.85%.
All 239 audit rows and original fresh failures remain. **Phase 22 is incomplete**;
no limitation or human technical acceptance is inferred. Git remains 312/1,040
incomplete, paid benchmark/pilots deferred, Phase 21 incomplete and Phase 24/15
unchanged. No optimization, retry, paid call, target execution, merge, ready-state,
release, outreach or Phase 23 occurred or is newly authorized.

'''
    first, rest = text.split('\n', 1)
    path.write_text(first+'\n\n'+status+rest)
write('owning-docs.json', {'sha256': {n: sha(ROOT/n) for n in docs}})
print('Reconciled239requirements and16owning docs; profile closed, optimization unapproved.')
