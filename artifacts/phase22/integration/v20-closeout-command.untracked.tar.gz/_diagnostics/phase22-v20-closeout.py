import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read('v20-source-verification.json');d=read('v20-diagnostic-assessment/packet.json');seal=read('evidence-v49.json');prior=read('v19-closeout-audit/packet.json');assert d['passed']
rows=[]
for old in prior['requirements']:
 row={**old,'prior_requirement_record_sha256':hashlib.sha256(json.dumps(old,sort_keys=True).encode()).hexdigest(),'historical_assessment':{'audit':'v19-closeout-audit/packet.json','text':old['assessment']},'evidence':list(dict.fromkeys(old['evidence']+['artifacts/phase22/integration/v20-source-verification.json','artifacts/phase22/integration/v20-hosted-audit/packet.json']))}
 row['assessment']='Scanner, detector, test, runtime and package bytes remain identical to1f3f72f. Fresh normal hosted CI/docs pass at71906a7 after the optional workflow change. Earlier local/source/capture/runtime and exposed-detection evidence retains its measured identity; no full timing/fresh/acceptance pass is inferred. The prior requirement-specific assessment is preserved separately with its measured source.'
 if row['id'] in [f'R{n}' for n in range(18,28)]+['R35','R63','R64','R65']:
  row['assessment']='The four approved Linux observations pass within 300seconds with exact ordered reference/repeat equality. This covers only two named Meta inputs twice, not the required complete25+45+45 sequence. The full sequence remains unapproved and unrun; original15/25 completion and120-second timeouts remain unchanged. Condition truth, raw Meta erratum and historical requirements are preserved.'
  row['evidence']+=['artifacts/phase22/integration/v20-diagnostic-assessment/packet.json','artifacts/phase22/integration/v20-full-linux-sequence-proposal.json']
 if row['id'] in ['R66','R88']:row['assessment']='No post-stabilization fresh freeze/evaluation approved or run. Exposed-family successes and original frozen misses remain source-bound; this diagnostic is not fresh evidence.'
 if row['id']=='R84':row['assessment']='Final technical acceptance has not been requested or received; timing and fresh-evaluation gates remain unresolved. Phase 22 remains incomplete, Phase 21 deferred/incomplete, Phase 24/15 unchanged.'
 if row['id'] in ['R77','R78']:row['assessment']='The full paid benchmark remains explicitly user-deferred, not passed. No additional paid model call occurred.'
 if row['id']=='R79':row['evidence'].append('artifacts/phase22/integration/evidence-v49.json')
 if row['id']=='R82':row['evidence'].append('artifacts/phase22/integration/v20-delivery-verification.json')
 rows.append(row)
additional=[{**r,'scope':'Preserved historical approved scope; unused maxima do not reopen.'} for r in prior['additional_scope_requirements']]
for suffix,title,evidence in [('APPROVAL','Record exact approval and single consumed dispatch',['v20-diagnostic-authorization.json','v20-dispatch-consumed.json']),('SUPERVISOR','Enforce whole-input limit and verify owned process cleanup',['v20-linux-diagnostic-v1/runner.py','v20-supervisor-selfchecks/selfcheck.json']),('DIAGNOSTIC','Complete four named native Linux observations with ordered report equality',['v20-diagnostic-assessment/packet.json']),('VERIFY','Verify final workflow candidate and byte-identical scanner compatibility',['v20-source-verification.json','v20-hosted-audit/packet.json']),('PROPOSAL','Prepare bounded full sequence without running it',['v20-full-linux-sequence-proposal.json']),('DELIVERY','Preserve evidence and deliver to existing draft',['evidence-v49.json','v20-delivery-verification.json'])]:additional.append({'id':'V20-'+suffix,'requirement':title,'disposition':'passed','evidence':evidence})
counts=dict(collections.Counter(r['disposition'] for r in rows));assert len(rows)==89 and counts=={'passed':70,'unresolved':17,'explicitly user-deferred':2}
p={'recorded_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':v['source'],'scanner_identity':v['scanner'],'measured_scanner':v['measured_scanner'],'requirements':rows,'dispositions':counts,'additional_scope_requirements':additional,'additional_scope_dispositions':dict(collections.Counter(r['disposition'] for r in additional)),'prior_audit':{'path':'v19-closeout-audit/packet.json','sha256':sha(b/'v19-closeout-audit/packet.json')},'current_tests_by_file':prior['current_tests_by_file'],'current_source_and_test_files':v['source_and_test_files_sha256'],'references_sha256':{n:sha(b/n) for n in ['v20-source-verification.json','v20-hosted-audit/packet.json','v20-diagnostic-assessment/packet.json','v20-full-linux-sequence-proposal.json','evidence-v49.json']},'original_failed_gate':v['original_failed_gate'],'policy_approved':True,'native_and_whole_input_hard_limit_seconds':300,'performance_target_seconds':120,'current_source_corpus_runs':4,'diagnostic_approved':True,'diagnostic_passed':True,'full_sequence_approved':False,'fresh_evaluation_approved':False,'technical_acceptance_requested':False,'technical_acceptance_received':False,'new_paid_calls':0,'phase22_complete':False,'status':'Four-observation Linux diagnostic passed. Full 25 + 45 + 45 gate, fresh evaluation and final human acceptance remain separately gated and unmet.','owning_document_binding':'v20-final-documentation-binding.json supersedes audit-stage owning-document hashes only.'}
out=b/'v20-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
target=d['classification_counts'].get('completed_within_target',0);times=[r['whole_input_seconds'] for r in d['rows']]
summary=f'''The approved Linux diagnostic **passes all four observations** at scanner
`1f3f72f`, workflow `71906a7`, run **34550284556**. Both named Meta inputs complete
twice, with valid native JSON/SARIF and **entire ordered reference/repeat equality**.
Whole-input times range from **{min(times):.3f} to {max(times):.3f} seconds**;
**{target}/4** meet the 120-second target and **{4-target}/4** use the extended allowance.
All are within the approved 300-second maximum. Each owned process group is
reaped. Four observations and the single dispatch are consumed; no retries,
profiles, tuning, target execution or paid calls occurred. The raw fixed-label
Meta operator alert and approved source erratum remain unchanged.

Only the optional diagnostic workflow changed. Scanner/test/package bytes equal
`1f3f72f`; the prior local **2,194 passed / 36 skipped**, **89.68%** branch coverage
and six zero-call production replays remain valid source-bound evidence.
Fresh CI **34550284081** passes all **29 normal jobs**, with **2,194 passed /
36 skipped** in every one of 12 suites; docs **34550284214** passes. The unchanged
Git image/runtime evidence still describes 13 incomplete campaigns: 1,040 planned,
312 tested and 728 remaining; this is not complete Git coverage. All three exposed SSRF families retain their passing source-bound
regressions at `2ac39aa`; they are not fresh generalization results. The original
held-out baseline remains 10 completed, 10 unsupported and 5 incomplete, with zero
hits among 4 completed vulnerable inputs out of 10 vulnerable inputs total.

This is a two-input diagnostic, **not a full corpus timing pass or a speedup**.
The original Linux gate at `7555a9d` remains **15/25 complete, ten Meta timeouts at 120 seconds,
both historical batches skipped**. The prospective policy remains a 120-second
target and uniform 300-second maximum. No earlier result is relabeled.

The next exact proposal is `v20-full-linux-sequence-proposal.json`, **unapproved**:
one 25-input development batch then two 45-input historical batches, **115 native observations**, one
dispatch across three dependent standard Linux jobs with **145/245/245-minute**
limits (635 minutes total maximum), no retries/profiles/paid calls. The next job
starts only after its predecessor's completion and condition gate passes. Stop
on the first incomplete, late or mismatching result; do not pool attempts.
The existing condition requirements and ordered historical repeat gate remain.

All 89 requirements remain **70 passed, 2 user-deferred, 17 unresolved**.
**Phase 22 remains incomplete.** Full timing, fresh freeze/evaluation and final
human acceptance remain separate checkpoints. Paid benchmark/pilots remain
deferred; Phase 21 incomplete and Phase 24/15 unchanged. No merge/release/outreach.
'''
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']:
 f=root/name;s=f.read_text();start=s.index('The approved **120-second performance target / 300-second static maximum** is')
 prefix=s[:start].replace('Current v19 timeout policy','Current v20 Linux diagnostic')
 s=prefix+summary+'\n### Historical v19 timeout policy and unapproved diagnostic checkpoint\n\n'+s[start:]
 if name=='AGENTS.md':s=s.replace('all three exposed SSRF gates pass; timing fails; fresh evaluation and acceptance pending; paid benchmark/pilots deferred','all three exposed SSRF gates and four Linux diagnostic observations pass; full timing, fresh evaluation and acceptance pending; paid benchmark/pilots deferred',1)
 f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text();s=s.replace('## Current v19 timeout-policy transition','## Current v20 diagnostic audit\n\nAll 89 original rows are mapped in `v20-closeout-audit/packet.json`: **70 passed,\n2 explicitly user-deferred, 17 unresolved**. All 39 added rows retain **38 passed,\n1 unresolved** (historical v14 retention). Six new rows cover the approved\ndiagnostic, supervisor, verification, full-sequence proposal and delivery.\nThe four diagnostic observations pass; full25+45+45, fresh evaluation and final\nhuman acceptance remain unmet. No paid calls.\n\n## Historical v19 timeout-policy transition',1);f.write_text(s)
index=f'''Batch 49 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 48 prior archives were verified. Restore
after batches 1–48 in separate staging using `evidence-v49.json`; require existing
destinations to match identical bytes or the recorded prior hash, and stop on
unexpected conflict. This batch retains diagnostic approval/dispatch, supervisor
and selfchecks, raw Linux reports/environment/logs, independent assessment, fresh
normal hosted verification, full-sequence proposal and helper sources. Final
audit/documentation/delivery bindings are tracked directly after sealing.
'''
f=b/'README.md';s=f.read_text().replace('batches 1–48 and closeout audit','batches 1–49 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text(f.read_text().rstrip()+'\n\n### Evidence batch49\n\n'+index)
f=root/'docs/phase22-timeout-policy.md';s=f.read_text().replace('The first proposed diagnostic is the two named slow Meta inputs, each twice:','The approved diagnostic covered the two named slow Meta inputs, each twice:').replace('It would allow four native observations at 300 seconds each in one standard\nLinux job, with zero paid calls, profiles, target execution or retries. Its\nexact source-bound proposal is prepared separately before requesting approval.\nNo new corpus measurement is authorized merely by this document.',f'Run34550284556 completed all four native observations within 300 seconds in one\nstandard Linux job; {target}/4 met120 seconds. Reports matched retained references\nand repeats in their entirety and order. Zero paid calls, profiles, target\nexecution or retries occurred. The approval and budget are consumed; this\ndocument does not authorize additional runs.').replace('If the diagnostic passes, the entire 25 + 45 + 45 sequence remains a separately','After this diagnostic pass, the entire 25 + 45 + 45 sequence remains a separately').replace('normal hosted CI jobs and docs. The four-observation diagnostic proposal remains\nunapproved and unexecuted. See the','normal hosted CI jobs and docs. Workflow candidate `71906a7` also passes fresh normal\nCI/docs; its scanner bytes equal `1f3f72f`. The four-observation diagnostic passes,\nwhile the full 115-observation proposal is unapproved and unexecuted. See the');f.write_text(s)
f=root/'docs/phase22-corpus-review.md';s=f.read_text().replace('## Historical proposal', 'The four approved Meta diagnostic observations at `1f3f72f` pass within the\n300-second maximum with ordered report equality. These are existing development\ninputs. Full 25 + 45 + 45 and a new fresh evaluation remain separately gated.\n\n## Historical proposal',1);f.write_text(s)
body='The four approved Linux observations now finish within the 300-second maximum with unchanged ordered reports. Phase 22 remains incomplete.\n\n'+summary+'\n[Diagnostic assessment](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v20-diagnostic-assessment/packet.json), [current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v20-closeout-audit/packet.json), [unapproved full sequence](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v20-full-linux-sequence-proposal.json), [evidence1–49](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nFinal docs/evidence delivery uses authorized CI skip after proving code/test/workflow/package inputs equal tested71906a7; it is not another hosted code pass.\n'
f=b/'v20-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(counts,p['additional_scope_dispositions'])
