import json,re
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');base=root/'artifacts/phase22/integration';read=lambda n:json.loads((base/n).read_text());audit=read('v14-closeout-audit/packet.json');host=read('v14-hosted-final-audit/packet.json');seal=read('evidence-v43.json');local=read('v14-final-full-suite-coverage.json')['totals']['percent_covered'];low=min(r['branch_coverage_percent'] for r in host['quality']);high=max(r['branch_coverage_percent'] for r in host['quality'])
quality=f'''Final local and all 12 hosted quality suites pass **2,183 tests, 36 skips and
no expected failures** at corrected `592a9cd`. Local branch coverage is
**{local:.2f}%**; hosted coverage is **{low:.2f}–{high:.2f}%**. All 29 normal jobs and
docs pass ([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34518818910),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34518818938)).
Wheel/sdist source members match actual Git blobs; all 12 wheel combinations,
Docker replay, network isolation, dependencies and hooks pass. Configured strict
mypy checks all 146 files; Ruff/format, lock, schemas, notices and offline
artifacts pass. Both approved production requests regenerate and checked-replay
without new paid calls. The approved Git runtime/image bindings match; its
13 campaigns remain incomplete (312 tested, 728 remaining).

The candidate's 1,034 affected tests and semantic before/after control passed.
Initial `12748e4` CI failed all 12 quality jobs because its source-only local mypy
check missed a required test-helper annotation. The annotation is corrected;
initial failed/cancelled CI and the superseded local suite interrupted after
365 passing tests are retained. Detector source and measurements are unchanged.
'''
pattern=re.compile(r"The candidate's 1,034 affected tests, semantic before/after check, lint, format and\nsource-only mypy pass\..*?No detector source or measured report changed\.\n",re.S)
paths=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']
for name in paths:
 p=root/name;s=p.read_text();assert len(pattern.findall(s))==1,name;s=pattern.sub(lambda m:quality,s,count=1);s=s.replace('Current bounded follow-up at `a7d7de0`','Current verification at `592a9cd`',1);s=s.replace('The prior 89-row audit remains 70 passed, two explicitly user-deferred and\n17 unresolved, pending its current verification bindings.','The current 89-row audit records 70 passed, two explicitly user-deferred and\n17 unresolved, with current test/evidence bindings. Seven additional v14 scope\nrequirements are mapped separately: six passed and the performance-retention\nrequirement remains unresolved.',1);s=s.replace('A new concrete measurement\nscope requires separate approval.','The prepared `v14-next-merge-diagnostic-proposal.json` requests only one\n120-second merge diagnostic on the named Meta input, with no optimization or\nadditional native/comparator run; it is unapproved. A new measurement scope\nrequires separate approval.',1);p.write_text(s)
p=base/'requirements.md';s=p.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current v14 verification in progress','## Historical v14 initial verification',1)
lines=['## Current 89-row audit at `592a9cd`','','**70 passed, 2 explicitly user-deferred, 17 unresolved.** Current implementation,','executed tests and evidence hashes are in `v14-closeout-audit/packet.json` and','`v14-current-source-test-bindings/packet.json`. Scanner/harness bytes equal','measured `2ac39aa`; original native reports retain that revision. All 29 normal','jobs and docs pass on corrected `592a9cd`. Timing, fresh evaluation and human','acceptance remain unmet.','','| ID | Requirement | Current disposition |','| --- | --- | --- |']
for r in audit['requirements']:lines.append('| '+r['id']+' | '+r['requirement'].replace('|','\\|').replace('\n',' ')+' | **'+r['disposition']+'** |')
lines+=['','### Additional v14 scope requirements','','These supplement the original 89 IDs: **6 passed, 1 unresolved**. The failed','retention condition remains failed despite correct execution of its stop/revert','requirements.','','| ID | Requirement | Disposition |','| --- | --- | --- |']
for r in audit['additional_scope_requirements']:lines.append('| '+r['id']+' | '+r['requirement']+' | **'+r['disposition']+'** |')
p.write_text(title+'\n\n'+'\n'.join(lines)+'\n'+rest)
count=len(seal['files']);raw=sum(r['bytes'] for r in seal['files']);compressed=(base/seal['archive']).stat().st_size
index=f'''Batch 43 is sealed: **{count:,} files**, {raw:,} raw bytes and
{compressed:,} compressed bytes, SHA-256
`{seal['sha256']}`. Every member was read back and all 42 prior numbered archive
hashes reverified after native/test/collector writers stopped.
Restore after batches 1–42 into separate staging; verify archive/member hashes
against `evidence-v43.json`. Existing destinations must match identical bytes or
their recorded previous hashes; stop on unexpected conflicts.

This batch retains the approved v14 diagnostic and reverted attempt, all ten
completed reports and the interrupted native attempt, cancelled-run accounting,
initial type failures and partial local suite, corrected final local/hosted
verification, distributions, production replay, Git compatibility, commands and
helper sources. The next merge diagnostic is prepared but unapproved. Final
89-row/added-scope audit, docs and delivery bindings are tracked directly after
the seal (`v14-closeout-audit/packet.json`, `v14-final-documentation-binding.json`,
`v14-delivery-verification.json`, `v14-closeout-draft-body.md`). No timing pass,
fresh evaluation or Phase 22 acceptance is implied.

'''
p=base/'README.md';s=p.read_text();assert 'Batch 43 is sealed:' not in s and s.count('## Evidence archives\n')==1;s=s.replace('batches 1–42 and closeout audit','batches 1–43 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);p.write_text(s)
p=base/'progress.md';p.write_text(p.read_text().rstrip()+'\n\n### Evidence batch 43 and current audit\n\n'+index.rstrip()+'\n')
s=(base/'v14-corrected-draft-body.md').read_text();pattern=re.compile(r"The candidate's 1,034 affected tests, before/after control, lint, format and source-only mypy pass\..*?Detector source and measurements are unchanged\.",re.S);assert len(pattern.findall(s))==1;s=pattern.sub(lambda m:quality.strip(),s,count=1)
s+='\nThe [current 89-row audit and seven additional scope requirements](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v14-closeout-audit/packet.json) retain the failed timing/retention gates and verified evidence batches 1–43. The [next proposal](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v14-next-merge-diagnostic-proposal.json) requests one merge diagnostic at 120 seconds, zero optimizations and zero paid calls; it is unapproved.\n\nThis final docs/evidence-only delivery uses authorized CI skip after proving code/test/workflow/package inputs equal hosted `592a9cd`. Final docs are checked locally; no new hosted code pass is claimed for the later delivery commit.\n'
p=base/'v14-closeout-draft-body.md';assert not p.exists();p.write_text(s)
print(count,local,low,high,audit['dispositions'],audit['additional_scope_dispositions'])
