"""Reconcile completed evaluation and prepare explicit human acceptance."""
import copy,hashlib,json,subprocess
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
 with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
a=json.loads((OUT/'assessment.json').read_text());assert a['fresh_detection_gate_passed'] and not a['fixed_guard_recognition_established']
write('assessment-corrections.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'final_exit_code':0,'final_helper_sha256':sha(OUT/'assess.py'),'attempts':[{'helper':'assess-initial.py','log':'assessment.log','exit_code':1,'reason':'Read-only assessor incorrectly expected requests as [] instead of actual empty {}. Raw zero-call results unchanged.'},{'helper':'assess-request-shape-correction.py','log':'assessment-corrected.log','exit_code':1,'reason':'Assessor required forwarding call line206 in flow_locations. Actual list has registered handler197 and argument198, but not forwarding line206. Corrected assessment explicitly distinguishes report provenance from separately source-bound forwarding call; no provenance invented.'},{'helper':'assess-flow-location-correction.py','log':'assessment-final.log','exit_code':1,'reason':'Assessor incorrectly expected annotated assignment for ARGUMENT_DESCRIPTIONS; actual source is ordinary Assign. Corrected literal-only AST inspection; no target import/execution.'},{'helper':'assess.py','log':'assessment-complete.log','exit_code':0}], 'additional_preexecution_correction':'Corrected arithmetic assertion from6356 to6366 diagnostics while fixing request shape, before reaching that check. Actual3308 warnings+3058 unresolved-flow occurrences.', 'raw_evidence_changed':False,'additional_observations':0,'paid_calls':0})
prior=BASE/'v32-fresh-v6/audit.json'; audit=json.loads(prior.read_text());audit['prior_audit']={'path':prior.relative_to(BASE).as_posix(),'sha256':sha(prior)}
status='First-frozen replacement-v6 atf85a90f passes the exact approved output gate:10native+5Semgrep complete,2/2 vulnerable hits and0/3 matching negative alerts in each native batch,5 ordered repeats. Fixed build_request/send is unresolved, so guard recognition is not established; explicit limitation disposition is proposed, not accepted. Source assessments complete; user-required new repository detection demonstrated. Git312/1040 retained incomplete. Phase22 awaits explicit technical acceptance and verified closeout.'
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='8a3c070122a4196df07287ea91807ff3f946cbf2',status=status,acceptance_packet_ready=True,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,new_paid_calls=0,new_fresh_v6_evaluation_approved=True,new_fresh_v6_evaluation_executed=True,new_fresh_v6_observations=15,new_fresh_v6_native_observations=10,new_fresh_v6_semgrep_observations=5,new_fresh_v6_gate_passed=True,new_fresh_v6_fixed_guard_recognition_established=False,current_source_corpus_runs=79,current_source_native_observations=74,current_source_comparator_observations=5)
audit['fresh_evaluation_status_basis']='Historical originalv5 retains0/2misses per batch/comparator; separate newv6 atf85a90f first-frozen candidate detections2/2 per native batch. Native completion and output discrimination pass; unresolved fixed send path explicitly proposed limitation. No relabeling of prior results.'
audit['owning_document_binding']='Finalv33 documentation binding follows final owning-doc edits; prior document hashes remain historical.'
for r in audit['requirements']:
 r['interpretation']=status
 if r['id'] in {'R66','R88'}:
  r['prior_v32_assessment']=copy.deepcopy({k:r[k] for k in ['disposition','assessment']});r['disposition']='passed';r['assessment']='Replacement-v6 is a new repository absent from seven prior manifests/96source trees, selected after immutablef85a90f freeze and evaluated only after exact user yes receipt. All15observations completed and source-assessed, native2/2 correlated vulnerable hits per batch,0/3matching negative alerts,5ordered repeats. The frozen output threshold passes; scanner recognition of the fixed guard is not established because send is unsupported. That separate limitation is proposed for explicit acceptance inV33-FIXED-COVERAGE. Original1f Lighthouse and original heldout misses remain unchanged; no broad generalization or independent human review.'
  r['evidence'] += ['artifacts/phase22/integration/v33-fresh-v6/assessment.json','artifacts/phase22/integration/v32-fresh-v6/evaluation-authorization.json']
 if r['id']=='R84':r['assessment']='Technical packet ready under enumerated proposed limitations; explicit human acceptance and post-decision closeout delivery still required. Evaluation yes is not technical acceptance. Pilots remain explicitly deferred.'
for r in audit['additional_scope_requirements']:
 if r['id']=='V32-FRESH-DETECTION':r.update(disposition='passed',assessment='Exact first-frozen output threshold passes after approved15-observation sequence. New-source detection is demonstrated, while fixed send/guard recognition remains explicitly unresolved inV33-FIXED-COVERAGE. All findings/warnings/flows/surfaces source-assessed; no same-source tuning.');r['evidence']+=['v33-fresh-v6/assessment.json']
audit['additional_scope_requirements'] += [
 {'id':'V33-EVALUATION','requirement':'Execute exact v6 budget, retain identities/schema/timing/repeats/cleanup and assess every diagnostic without paid calls','disposition':'passed','assessment':'15/15 complete,10native allwithin120s,max8.451895s;5comparator max21.078982s;201.977208s sequence.80findings,3308warnings,3058flows,60surfaces source-assessed. Failed read-only assessor checks preserved/corrected without new observations. Budget closed.','evidence':['v33-fresh-v6/assessment.json','v33-fresh-v6/assessment-corrections.json']},
 {'id':'V33-FIXED-COVERAGE','requirement':'Explicitly dispose of fixed HTTP sink/guard coverage limitation without implying recognized safety','disposition':'proposed documented limitation awaiting decision','assessment':a['fixed_sink_coverage_limitation'],'evidence':['v33-fresh-v6/assessment.json','v33-fresh-v6/diagnostic-source-assessment.json']}
]
audit['dispositions']=dict(Counter(r['disposition'] for r in audit['requirements']));audit['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in audit['additional_scope_requirements']))
assert len(audit['requirements'])==89 and audit['dispositions']=={'passed':86,'explicitly user-deferred':2,'unresolved':1}
assert len(audit['additional_scope_requirements'])==88 and audit['additional_scope_dispositions']=={'passed':82,'proposed documented limitation awaiting decision':6}
for n in ['assessment.json','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json','assessment-corrections.json']:
 audit['references_sha256'][str((OUT/n).relative_to(ROOT))]=sha(OUT/n)
write('audit.json',audit)
text='''The approved **replacement-v6 fresh evaluation passes its frozen output gate**
at scanner **`f85a90f`**, selected before source curation. The new repository is
**isyuricunha/mcp-ddg-research**, absent from seven prior manifests and 96 unique
source trees. Both native batches detect **2/2 correlated vulnerable variants**
and produce **zero matching alerts on three fixed/control inputs**. All **five
entire ordered repeats agree**. All **15 observations** completed: 10 native and
five pinned Semgrep; Semgrep detected **0/2** vulnerable variants. The native
maximum is **8.452 seconds**, comparator maximum **21.079 seconds**, and local
sequence **201.977 seconds**. Zero retries, target execution or paid calls; the
budget is closed. This is one repository and one narrow vulnerability, not broad
accuracy, independent human review or runtime proof.

**Fixed guard recognition is not established.** The native finding identifies the
registered `web_fetch` caller URL reaching `client.get` without sufficient destination
restriction, which includes the missing `100.64.0.0/10` rejection. Upstream also
changed fixed HTTP access to `build_request`/`send`, which Sentinel explicitly
reports as unresolved. Zero fixed alerts therefore establish the measured output
contrast, not recognition of the CGNAT fix or complete fixed-path coverage. This
limitation is prominently proposed for explicit human acceptance, never silently
accepted. All **80 findings, 3,308 warnings, 3,058 unresolved-flow occurrences and
60 recognized surface occurrences** are source-assessed. The 76 unmatched findings
include framework-validation and hashed-cache-path false positives under stated
source prerequisites; raw findings and unresolved coverage remain visible.

Current exposed Lighthouse and the three prior SSRF repeat gates remain passed.
The existing 54-observation compatibility packet and historical whole 25 + 45 + 45
Linux evidence retain their actual source bindings; no new whole-batch timing
claim is made. Product/test/package/workflow bytes equal tested **`439c3fe`**:
**2,242 tests / 36 skips**, **89.76%** local branch coverage, all **29 normal CI
jobs** and docs passed. Six production-request replays retain zero-call evidence.
Git campaigns remain **312/1,040 incomplete**, as the user instructed.

Original fresh Lighthouse misses at `1f3f72f` and original held-out failures remain
unchanged; later Lighthouse passes are exposed regressions. All earlier failed
optimizations, stale-assessment stops, invalid v4 novelty and corrective attempts
remain preserved with closed budgets. The audit contains **89 original rows:
86 passed, two user-deferred and one pending acceptance**, plus **88 added rows:
82 passed and six proposed documented limitations awaiting decision**.
**Phase 22 remains incomplete** until explicit human technical acceptance and
verified closeout delivery. Paid benchmark/pilots remain deferred; Phase 21 stays
incomplete and Phase 24/15 gates are unchanged. No merge, ready-state, release,
outreach or Phase 23 is authorized.
'''
(OUT/'summary.md').write_text('# Phase 22 fresh detection and technical acceptance packet\n\n'+text+'\nReview `assessment.json`, `audit.json` and `acceptance-proposal.json` in this directory. The exact prospective output criterion is retained in `../v32-fresh-v6/scoring-rubric.json`; approval is in `../v32-fresh-v6/evaluation-authorization.json`.\n')
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','docs/phase22-timeout-policy.md','docs/phase22-corpus-review.md','artifacts/phase22/integration/requirements.md','artifacts/phase22/integration/progress.md','artifacts/phase22/integration/README.md']:
 p=ROOT/name;s=p.read_text();level='###' if name=='ROADMAP.md' else '##';marker=level+' Current fresh detection prerequisite';assert s.count(marker)==1
 s=s.replace(marker,level+' Current fresh detection and acceptance checkpoint\n\n'+text+'\n'+level+' Historical v32 fresh preparation checkpoint',1)
 s=s.replace('new unseen-repository detection required; replacement-v6 prepared, evaluation and acceptance pending','replacement-v6 first-frozen detection passes; explicit acceptance and closeout pending')
 if name.endswith('integration/README.md'):
  s=s.replace(level+' Historical v32 fresh preparation checkpoint','Review [current summary](v33-fresh-v6/summary.md), [89 + 88 row audit](v33-fresh-v6/audit.json), [source-assessed evaluation](v33-fresh-v6/assessment.json) and [exact acceptance proposal](v33-fresh-v6/acceptance-proposal.json). Restore seal 60 after seals 1–59, verifying archive/member hashes in numeric order.\n\n'+level+' Historical v32 fresh preparation checkpoint',1)
 p.write_text(s)
p=ROOT/'ARCHITECTURE.md';s=p.read_text();old='The user now requires first-frozen detection on another previously unused repository\nbefore technical acceptance. Replacement-v6 is prepared at immutable `f85a90f`;\nits exact evaluation remains unapproved and unexecuted. Git runtime coverage stays\n312/1,040 incomplete. Phase 22 awaits this new gate, acceptance and closeout delivery.'
assert old in s;s=s.replace(old,'Replacement-v6 first-frozen detection at `f85a90f` passes its approved output\nthreshold: two vulnerable hits per native batch, zero matching negative alerts\nand five ordered repeats. Fixed `build_request`/`send` remains unresolved, so\nrecognition of the fixed guard is not established and requires explicit acceptance\nas a limitation. Git runtime coverage stays 312/1,040 incomplete. Phase 22 awaits\nhuman technical acceptance and verified closeout delivery.');p.write_text(s)
p=ROOT/'artifacts/phase22/corpus-replacement-v6/README.md';s=p.read_text();s=s.replace('Prepared only; no native/comparator evaluation or target execution.','Approved first-frozen evaluation completed: 10 native + 5 Semgrep, zero paid calls or target execution. Native2/2 hits per batch and0/3matching negative alerts;5ordered repeats. Fixed HTTP send remains unresolved, so no recognized-fix claim. See `../integration/v33-fresh-v6/assessment.json` and `summary.md` for complete source assessments and the proposed limitation.');s=s.replace('Current-source detection remains unproven.','Current-source first-frozen candidate detection is demonstrated for this narrow condition.');p.write_text(s)
pr='# Phase 22: fresh detection demonstrated; explicit acceptance pending\n\n'+text+'\nReview `artifacts/phase22/integration/v33-fresh-v6/summary.md`, `assessment.json`, `audit.json` and `acceptance-proposal.json`. Seal60 preserves raw reports, exact approval, failed assessor checks and completed source assessments; preceding59seals and all original failures remain intact.\n\n## Retained technical verification\n\n'+(BASE/'v31-compatibility/summary.md').read_text().split('At frozen scanner',1)[1].split('The proposed acceptance',1)[0]
(OUT/'pr-body.md').write_text(pr)
proposal=json.loads((BASE/'v31-compatibility/acceptance-proposal.json').read_text());proposal.update(recorded_at=datetime.now(timezone.utc).isoformat(),fresh_evaluation_runner_revision='8a3c070122a4196df07287ea91807ff3f946cbf2',technical_gates_passed=True,fresh_detection_gate_passed=True,fixed_guard_recognition_established=False)
proposal['current_source_observations'].update(fresh_v6_native=10,fresh_v6_semgrep=5)
proposal['proposed_requirement_dispositions']=[{k:r[k] for k in ['id','requirement','assessment']} for r in audit['additional_scope_requirements'] if r['disposition'].startswith('proposed')]
proposal['retained_limitations']=[a['fixed_sink_coverage_limitation'],'Fresh result is one repository/one narrow vulnerability with two correlated variants, agent source review after scanner freeze; no broad accuracy, runtime proof, independent human review or training-data novelty claim.']+proposal['retained_limitations']
proposal['retained_limitations'][2]='Original Lighthouse fresh misses remain0/2per native batch/comparator at1f3f72f; later exposed fixes never replace those observations. New DDGf85a90f first-frozen detection is separate, source-bound evidence.'
proposal['explicit_prior_git_decision']='User: Git runtime coverage leave this;312/1040remains incomplete with no new campaigns.'
proposal['files_sha256'].update({str((OUT/n).relative_to(BASE)):sha(OUT/n) for n in ['audit.json','assessment.json','summary.md','finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json']})
for n in ['evaluation-authorization.json','evaluation-proposal.json','scoring-rubric.json']:
 proposal['files_sha256']['v32-fresh-v6/'+n]=sha(BASE/'v32-fresh-v6'/n)
proposal['evidence_seal']='evidence-v60.json (final archive hash bound in supplemental documentation/delivery record)'
for n,d in proposal['files_sha256'].items():assert sha(BASE/n)==d,n
write('acceptance-proposal.json',proposal)
assert not subprocess.check_output(['git','diff','439c3fe','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile','README.md','CHANGELOG.md','LICENSE'])
print('Reconciled89+88rows; acceptance proposal prepared, not accepted. Product/workflow bytes remain equal439c3fe.')
