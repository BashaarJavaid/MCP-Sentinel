"""Record the user's exact approval of the delivered first-frozen evaluation."""
import hashlib
import importlib.util
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v32-fresh-v6'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('approved_v6',ASSETS/'runner.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=m.verify_packet()
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()=='8a3c070122a4196df07287ea91807ff3f946cbf2'
assert not subprocess.check_output(['git','diff','HEAD'])
assert not subprocess.check_output(['git','diff','--cached'])
assert not (ASSETS/'execution-consumed.json').exists()
delivery=json.loads((ASSETS/'delivery-verification.json').read_text())
assert delivery['delivered_revision']=='8a3c070122a4196df07287ea91807ff3f946cbf2'
receipt={'recorded_at':datetime.now(timezone.utc).isoformat(),'approved':True,'user_decision':'yes','decision_context':'User approved the immediately preceding exact evaluation proposal:10native+5Semgrep locally on macOS,300seconds per input,90minutes maximum,zero paid calls/retries; success requires vulnerable detections,fixed/control discrimination and matching repeats.','proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'checkpoint_sha256':p['checkpoint']['sha256'],'scanner':p['scanner'],'bounds':p['bounds'],'corpus':{'manifest':p['manifest']['path'],'sha256':p['manifest']['sha256'],'freeze_approved':True,'input_ids':p['input_order'],'treatments':['rules','semgrep']},'approved_delivery_revision':delivery['delivered_revision'],'scoring_rubric_sha256':p['scoring_rubric']['sha256'],'technical_acceptance':False,'paid_calls_authorized':0,'old_budgets_reopened':False}
approval=ASSETS/'evaluation-authorization.json'
with approval.open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
files={**p['files_sha256'],str((ASSETS/'evaluation-proposal.json').relative_to(ROOT)):sha(ASSETS/'evaluation-proposal.json'),str(approval.relative_to(ROOT)):sha(approval)}
binding={'recorded_at':datetime.now(timezone.utc).isoformat(),'runner_revision':delivery['delivered_revision'],'scanner':p['scanner'],'files':files,'staging_files_sha256':sha(ASSETS/'staging-files.json'),'scoring_rubric_sha256':p['scoring_rubric']['sha256'],'new_paid_calls':0}
with (ASSETS/'binding.json').open('x') as f:json.dump(binding,f,indent=2);f.write('\n')
m.approved()
print('Exact user approval and all source/runner/rubric bindings recorded; no observations yet.')
