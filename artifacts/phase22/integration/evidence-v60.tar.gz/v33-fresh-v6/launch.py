"""Launch the one approved sequence and retain the exact command and exit."""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
ASSETS=OUT.parent/'v32-fresh-v6';SCANNER=Path('/private/tmp/mcp-phase22-frozen-f85a90f')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable,str(OUT/'owned-work.py')],cwd=ROOT,check=True)
assert not (ASSETS/'execution-consumed.json').exists()
assert (OUT/'stage.log').read_text().strip()=='Staged and validated corpus assets; zero observations.'
assert not subprocess.check_output(['git','diff','HEAD'],cwd=SCANNER)
staging=json.loads((ASSETS/'staging-files.json').read_text())
for name,d in staging.items():assert sha(SCANNER/name)==d,name
extras=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=SCANNER,text=True).splitlines()
assert all(name in staging for name in extras),extras
command=[sys.executable,'-I',str(ASSETS/'runner.py'),'run',str(OUT/'raw'),'/private/tmp/phase22-v2-comparator-rules']
env={k:v for k,v in os.environ.items() if not k.startswith(('OPENAI_','SENTINEL_'))}
env['PATH']=str(Path(sys.executable).parent)+':'+env['PATH']
receipt={'recorded_at':datetime.now(timezone.utc).isoformat(),'command':command,'cwd':str(SCANNER),'runner_sha256':sha(ASSETS/'runner.py'),'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'approval_sha256':sha(ASSETS/'evaluation-authorization.json'),'binding_sha256':sha(ASSETS/'binding.json'),'stage_exit_code':0,'stage_log_sha256':sha(OUT/'stage.log'),'known_staged_artifact_files_sha256':{n:sha(SCANNER/n) for n in extras},'tracked_frozen_checkout_unchanged':True,'credentials_removed':True,'paid_calls_authorized':0,'target_execution':False}
with (OUT/'launch-started.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
started=time.monotonic()
with (OUT/'sequence.log').open('xb') as log:
    result=subprocess.run(command,cwd=SCANNER,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log_sha256=sha(OUT/'sequence.log'))
with (OUT/'launch-completed.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print('Approved sequence exit',result.returncode,'elapsed',receipt['elapsed_seconds'],flush=True)
raise SystemExit(result.returncode)
