"""Adjudicate retained v6 reports against the frozen rubric; never scan a target."""
import ast
import hashlib
import importlib.util
import json
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from scripts.phase20_scoring import candidate_identity, metrics, score
from scripts.phase22_corpus import frozen, input_files
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data

ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent; ASSETS=OUT.parent/'v32-fresh-v6'; RAW=OUT/'raw'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):
    with (OUT/name).open('x') as f: json.dump(data,f,indent=2);f.write('\n')

def source_at(files,path,line):
    source=files[path]; lines=source.decode().splitlines(); assert 0<line<=len(lines)
    funcs=[n for n in ast.walk(ast.parse(source)) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef)) and n.lineno<=line<=n.end_lineno]
    fun=min(funcs,key=lambda n:n.end_lineno-n.lineno) if funcs else None
    assert fun is not None,(path,line)
    return {'path':path,'sha256':hashlib.sha256(source).hexdigest(),'line':line,'text':lines[line-1], 'function':fun.name,'function_start':fun.lineno,'function_end':fun.end_lineno}

# Source-reviewed function roles, not inferred safety from warning counts.
ROLES={
'cache.py':{
 'stable_cache_key':'JSON canonicalization is SHA256-hashed to hexadecimal before use as a filename. The unresolved serialization/hash operations do not establish arbitrary path control.',
 'get':'Reads a cache file under the fixed namespace using the hashed payload; JSON shape and TTL are checked. Local cache tampering/symlinks are outside the remote-argument prerequisite; no destination policy is established here.',
 'set':'Writes JSON to a NamedTemporaryFile in the configured cache namespace, flushes/fsyncs and replaces the hashed destination; finally removes that generated temporary name. Caller payload affects the hash/content, not an arbitrary path component.',
 'delete':'Removes the hashed payload filename in the fixed cache namespace after a poisoned cache value. This is unrelated to the scored initial HTTP destination.',
},
'server.py':{
 'ddg_search':'Official FastMCP tool forwards typed/Annotated search arguments to the imported local search helper and serializes its response. SENT-002 helper resolution warnings are retained; other rules independently analyze the helpers.',
 'web_fetch':'Official FastMCP tool forwards the caller url directly to the local fetch.web_fetch helper, then serializes the response. This is the registered source for the scored URL flow; a serialization warning does not negate the separate SENT-015 finding.',
 'ddg_deep_search':'Registered typed search tool delegates to fetch.ddg_deep_search; resulting page URLs are search-selected. This is a distinct entrypoint from the frozen direct web_fetch condition.',
 'cache_prune':'Registered bool arguments select pruning policy/dry run; helper returns statistics. No URL is requested and root directory is not a caller argument.',
 'cache_clear':'Registered namespace uses a Literal alias and confirm uses bool; clear_cache independently validates namespace and requires confirm. This is not an outbound URL condition.',
 'cache_stats':'Registered no-argument tool returns namespace file statistics; no caller URL or path parameter.',
},
'security.py':{
 '_normalize_hostname':'Strips a trailing dot and lowercases a hostname. It does not itself reject shared-space addresses.',
 '_canonical_hostname':'The approved reversible mutation only renames the hostname normalization helper; behavior and the shared-space classification are unchanged.',
 'is_blocked_hostname':'Tests a fixed hostname set/suffix list. Numeric100.100.200.200 matches neither; this is separate from network membership.',
 'is_unsafe_ip':'Parses the IP, checks explicit BLOCKED_NETWORKS and six flags. Vulnerable source omits100.64/10; fixed adds it. Python3.12 classification prerequisites are frozen in the source review. Unresolved calls are retained; this source judgment is not scanner guard recognition.',
 'validate_url_shape':'Requires HTTP/S and hostname, then hostname/network rejection. The scored literal passes the first two tests; the version-specific explicit network set determines its source rejection.',
 'validate_fetch_url':'Runs shape classification before scheduling resolved-address checks with asyncio.to_thread. Fixed literal rejection occurs before that callback. DNS remains unexecuted; callback warning is a real analysis boundary.',
 'resolve_safe_address':'Fixed code resolves and validates all addresses then returns one for pinning. Async resolution is unresolved in the scanner and unexecuted here. Initial fixed literal rejection precedes this helper.',
},
'fetch.py':{
 '_cache_payload':'Serializes the typed FetchRequest for a cache key; it is not a URL rejection predicate.',
 '_cacheable_fetch_response':'Copies cached=False and serializes the response to JSON, after the request; not an initial destination guard.',
 '_error_response':'Builds a structured unsuccessful FetchResponse; construction warnings do not prove safe or unsafe network behavior.',
 'web_fetch':'Constructs FetchRequest, awaits URL validation before cache/client access, handles cache hits and invokes validated redirect fetching on a miss. Fixed rejects100.100.200.200 first; vulnerable does not under frozen prerequisites. Model/cache warnings remain visible.',
 '_get_with_validated_redirects':'Vulnerable requests current_url through client.get after incomplete CGNAT validation. Fixed validates/pins a destination then uses build_request/send, closes responses, caps streamed bytes and validates redirects. SENT-015 recognizes get but has no send sink support; unresolved build_request/send warnings are material coverage gaps, so absence of a fixed alert is not guard recognition.',
 '_pinned_request_url':'Fixed URL parser substitutes the previously checked IP into netloc while retaining scheme/port/path/query. Scanner does not prove this transformation or the send sink safe.',
 '_original_host_header':'Preserves the original logical netloc in the Host header during IP pinning; it is not a standalone destination guard.',
 '_response_to_fetch_response':'Processes response status/content type/body and constructs success/error response models. These operations follow network access and cannot establish initial CGNAT rejection.',
 'ddg_deep_search':'Builds typed search input, fetches selected result URLs using a semaphore/gather, and combines page/error models. Separate search-driven entrypoint; callback/concurrency/model warnings do not establish protection or a direct web_fetch condition hit.',
},
'search.py':{
 'ddg_search':'Builds validated SearchRequest, reads cache and selects configured providers, handling errors and serializing responses. ddgs is optionally called in a thread; provider internals remain outside this source proof and no runtime was executed.',
 '_cache_payload':'Serializes request and provider/backend into the cache payload; path_for hashes it before disk use.',
 '_cacheable_search_response':'Copies cached=False and serializes the search response; not an HTTP destination guard.',
 '_search_with_duckduckgo_html':'Makes a GET to the constant DUCKDUCKGO_HTML_URL with caller query in params, then checks status. This request is unrelated to the scored caller-supplied web_fetch host; no query exfiltration or other vulnerability is inferred.',
 'has_domain_controls':'Boolean test of configured domain lists; controls search results, not arbitrary web_fetch literals.',
 'provider_request_size':'Bounds expanded search result count with min; not a network address check.',
 'parse_duckduckgo_html_results':'BeautifulSoup parses returned results, extracts link/title/snippet, normalizes redirects and constructs result models. Unresolved parser calls concern response processing; no full content-safety claim.',
 'resolve_duckduckgo_redirect_url':'Normalizes result links and unwraps DuckDuckGo /l redirects using uddg query data. Not the web_fetch initial rejection guard.',
 'normalize_url_for_dedupe':'Canonicalizes URL scheme/netloc/query for duplicate detection; normalization alone is not destination restriction.',
 '_dedupe_results':'Uses a set and count bound to deduplicate normalized result URLs; no URL authorization.',
},
'domains.py':{
 'normalize_domain':'Strips scheme/path/query/www and lowercases configured domain names; normalization is not the scored shared-space check.',
 'domain_matches':'Exact or dot-delimited suffix comparison for domain list policy; no numeric network classification.',
 'url_matches_domains':'Parses a result hostname then any-matches configured domains; this is search filtering, not direct web_fetch authorization.',
 'apply_domain_controls':'Applies allow/block/preferred filters to search results; unresolved copying/callback behavior remains visible, outside the named literal condition.',
},
 'text.py':{
 'normalize_whitespace':'Regex whitespace substitution/strip on response text; no initial destination validation.',
 'truncate_text':'Bounds response text length and appends a truncation marker; post-request operation.',
 'is_plain_text_content':'Checks content type/path suffix after retrieval; not URL destination validation.',
 '_clean_soup':'Removes selected script/style/navigation tags from parsed HTML; not proof of complete content sanitization.',
 '_tag_text':'Extracts visible tag text and normalizes whitespace; post-request response processing.',
 '_candidate_tags':'Collects preferred article/main/body tags for text extraction; parser/instance checks remain unresolved.',
 'extract_html_text':'Parses HTML, selects title and longest content candidate, then truncates; output extraction is separate from initial URL restrictions.',
}}

def role(s): return ROLES[Path(s['path']).name][s['function']]

spec=importlib.util.spec_from_file_location('v6runner',ASSETS/'runner.py'); runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
proposal=runner.approved(); packet=json.loads((RAW/'packet.json').read_text()); launch=json.loads((OUT/'launch-completed.json').read_text())
assert launch['exit_code']==0 and launch['elapsed_seconds']<5400 and sha(OUT/'sequence.log')==launch['log_sha256']
assert packet['passed'] and packet['execution_gate_passed'] and packet['budget_closed'] and packet['unstarted']==[]
assert packet['model_calls']==0 and not packet['target_execution']
assert packet['scanner']==proposal['scanner'] and packet['runner_revision']=='8a3c070122a4196df07287ea91807ff3f946cbf2'
assert packet['approval_sha256']==sha(ASSETS/'evaluation-authorization.json') and packet['binding_sha256']==sha(ASSETS/'binding.json')
for n,h in packet['files_sha256'].items():assert sha(RAW/n)==h,n
m=frozen(approval_path=ASSETS/'evaluation-authorization.json'); ss={s.revision:s for s in m.snapshots}; selected={i.id:i for i in m.inputs if i.id in proposal['input_order']}
sources={k:input_files(i,ss[i.snapshot],ROOT) for k,i in selected.items()}; configs=json.loads((ROOT/proposal['configuration']['path']).read_text())
assert [(a['batch'],a['input_id']) for a in packet['attempts']]==[(b,i) for b in proposal['batch_order'] for i in proposal['input_order']]
rows=[]; findings_review=[]; diagnostics=[]; surfaces=[]; first={}; seen_roles=set()
for a in packet['attempts']:
    assert a['state']=='completed';runner.completed(a['timing']);i=selected[a['input_id']]; files=sources[i.id];folder=RAW/a['directory'];result=json.loads((folder/'results.json').read_text())
    assert result['scanner']==packet['scanner'] and result['model_calls']==0 and result['requests']=={} and result['outcomes']==[a['outcome']]
    assert result['manifest_sha256']==proposal['manifest']['sha256'] and result['authorization_sha256']==packet['approval_sha256']
    row={'batch':a['batch'],'input_id':i.id,'label':i.label,'snapshot':i.snapshot,'tree_sha256':i.tree_sha256,'source_condition':i.condition,'source_evidence':[e.model_dump(mode='json') for e in i.evidence], 'whole_seconds':a['timing']['elapsed_seconds'],'timing':a['timing'],'outcome':a['outcome']}
    findings=[];matches=[]
    if a['batch']!='semgrep-first':
        p=folder/i.id/'report.json';report=json.loads(p.read_text());validate_report_data(report);validate_sarif_data(json.loads(p.with_suffix('.sarif').read_text()))
        assert sha(p)==a['outcome']['report_sha256']; assert sha(p.parent/'configuration.json')==configs[i.id]['sha256']==a['outcome']['configuration_sha256']
        assert report['analysisComplete'] and report['executionSuccessful']; findings=report['findings'];assert len(findings)==8
        c=report['static_analysis']['coverage'];assert len(c['surfaces'])==6 and c['total_possible_surfaces'] is None
        assert len(report['warnings'])==(278 if i.label=='vulnerable' else 366) and len(c['unresolved_flows'])==(253 if i.label=='vulnerable' else 341)
        canon=runner.supervisor.clean(report,runner.EXCLUDED)
        if a['batch']=='rules-first': first[i.id]=canon
        else: assert a['ordered_repeat_equal'] and canon==first[i.id]
        for f in findings:
            s=source_at(files,f['location']['path'],f['location']['range']['start_line']); explanation=role(s)
            matched=f['rule_id']=='SENT-015'
            if matched:
                assert i.label=='vulnerable' and s['path'].endswith('/fetch.py') and s['line']==76 and 'client.get(current_url)' in s['text']
                locs={(l['path'],l['range']['start_line']) for l in f['evidence']['flow_locations']}
                assert ('src/mcp_ddg_research/server.py',198) in locs and ('src/mcp_ddg_research/server.py',197) in locs
                assert f['dedup_key']=='d32f91b0412a78f68f438816ff072d282d1dc94955b4fbc8404d4e4dea896987'
                matches.append(f['dedup_key']);disposition='Source-established candidate hit on named condition; needs_review, no model or runtime confirmation.'
                explanation='Exact registered web_fetch url198 is forwarded at206 into FetchRequest and the validated redirect helper, whose outbound client.get at76 uses current_url. The report asserts missing enforced destination restrictions and includes the handler/argument and sink locations; source review additionally binds the forwarding call at206 (which is absent from the flow-location list). Existing scheme and private-range checks omit100.64/10, so this broad candidate correctly includes100.100.200.200 under the frozen cache/DNS/client prerequisites. It does not specifically name CGNAT or prove an exploit. '+explanation
            elif f['rule_id']=='SENT-003':
                assert Path(s['path']).name=='server.py';disposition='Unmatched validation false-positive under ordinary official FastMCP/Pydantic dispatch; no runtime verification.'
                explanation+=' Handler parameters use Annotated types and Field bounds/descriptions (namespace is CacheNamespace Literal); request helpers construct Pydantic request models. The warning that no framework or explicit validation occurs is unsupported under the declared SDK prerequisite. Framework type validation alone does not reject the scored URL.'
            else:
                assert f['rule_id']=='SENT-012' and Path(s['path']).name=='cache.py';disposition='Unmatched path-control false-positive under frozen remote-argument/trusted-local-cache prerequisites; local filesystem attack possibilities remain untested.'
                explanation+=' path_for uses stable_cache_key(payload), whose sha256(...).hexdigest produces a basename, under operator-configured root and literal fetch/search namespace. Cleanup temp_path comes from NamedTemporaryFile. No remote-argument escape is established; this does not certify resistance to malicious local filesystem changes.'
            findings_review.append({'batch':a['batch'],'input_id':i.id,'report_sha256':sha(p),'dedup_key':f['dedup_key'],'finding':{k:f[k] for k in ('rule_id','description','location','status','suppression')},'source':s,'matches_condition':matched,'disposition':disposition,'assessment':explanation})
        for kind,entries in [('warning',report['warnings']),('unresolved_flow',c['unresolved_flows'])]:
            for index,w in enumerate(entries):
                match=re.match(r'(SENT-\d+) at (.+):(\d+): (.+)',w['message']);assert match,w
                rule,path,line,message=match.groups();s=source_at(files,path,int(line));seen_roles.add((Path(path).name,s['function']));explanation=role(s)
                if w['code']=='static_description_unresolved':
                    assert 'ARGUMENT_DESCRIPTIONS[' in s['text'];key=re.search(r'ARGUMENT_DESCRIPTIONS\["([^"]+)"\]',s['text']).group(1)
                    tree=ast.parse(files['src/mcp_ddg_research/models.py']);dictionary=next(n.value for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='ARGUMENT_DESCRIPTIONS');descriptions=ast.literal_eval(dictionary);assert isinstance(descriptions[key],str)
                    explanation=f'The reported dynamic description is the source-literal ARGUMENT_DESCRIPTIONS[{key!r}] imported from models.py: {descriptions[key]!r}. Static description resolution skipped this dictionary subscript. It is not a model decision, a detected injection or proof that all descriptions were analyzed. '+explanation
                else: assert w['code']=='static_flow_unresolved'
                diagnostics.append({'batch':a['batch'],'input_id':i.id,'report_sha256':sha(p),'kind':kind,'index':index,'diagnostic':w,'rule_id':rule,'source':s,'assessment':explanation,'disposition':'Source-assessed analysis limitation retained; not a finding, safety conclusion or runtime proof.'})
        for index,surf in enumerate(c['surfaces']):
            assert surf['status']=='recognized' and not surf['reasons'];s=source_at(files,surf['handler']['path'],surf['handler']['range']['start_line']);assert s['function']==surf['name']
            surfaces.append({'batch':a['batch'],'input_id':i.id,'index':index,'surface':surf,'source':s,'assessment':role(s)+' Source decorator uses the official FastMCP instance. Recognition is not complete sink/guard coverage; total possible surfaces remains unknown.'})
        row.update(report_sha256=sha(p),sarif_sha256=sha(p.with_suffix('.sarif')),native_seconds=a['native_seconds'],ordered_repeat_equal=a.get('ordered_repeat_equal'),coverage=c,rule_outcomes=report['static_analysis']['rule_outcomes'],scanned_file_count=report['static_analysis']['scanned_file_count'],warning_count=len(report['warnings']))
    else:
        p=folder/i.id/'raw.json';raw=json.loads(p.read_text());assert sha(p)==a['outcome']['raw_sha256'];assert raw['version']=='1.176.0' and raw['results']==[] and raw['errors']==[] and raw['skipped_rules']==[]
        paths=[p.split('/source/',1)[1] for p in raw['paths']['scanned']];assert len(paths)==11 and set(paths)<=files.keys();assert {'src/mcp_ddg_research/server.py','src/mcp_ddg_research/fetch.py','src/mcp_ddg_research/security.py'}<=set(paths)
        row.update(raw_sha256=sha(p),comparator_version=raw['version'],scanned_paths=paths,error_count=0,coverage_assessment='Nine Python implementation files plus two YAML files scanned. No findings/errors from533 pinned rules; this does not prove semantic MCP coverage or competitor superiority.')
    adjudication={'candidate_identity':candidate_identity(findings),'matches':matches,'rationale':'Exact findings source-adjudicated in finding-source-assessment.json. Fixed/control send path remains unresolved; no matching alert is not recognized fix. Comparator returned no findings.'}
    row.update(score(label=i.label,state='completed',findings=findings,assessment=adjudication));row['condition_assessment']=adjudication;rows.append(row)
ms={b:metrics([r for r in rows if r['batch']==b]) for b in proposal['batch_order']}
for b in ['rules-first','rules-repeat']:
    assert ms[b]['candidate']['completed_detections']==2 and ms[b]['retained']['completed_detections']==2 and ms[b]['false_alarm_conditions']==0 and ms[b]['states']=={'completed':5}
assert ms['semgrep-first']['candidate']['completed_detections']==0 and ms['semgrep-first']['false_alarm_conditions']==0
assert len(findings_review)==80 and len(diagnostics)==6366 and len(surfaces)==60
write('finding-source-assessment.json',{'rows':findings_review,'count':80,'unassessed':0,'interpretation':'All76 unmatched finding occurrences separately source-assessed; scorer unadjudicated_keys retains its established meaning of unmatched condition keys.'})
write('diagnostic-source-assessment.json',{'rows':diagnostics,'count':len(diagnostics),'by_kind':dict(Counter(d['kind'] for d in diagnostics)),'reviewed_function_roles':sorted(seen_roles),'unassessed':0})
write('surface-source-assessment.json',{'rows':surfaces,'count':60,'unassessed':0,'total_possible_surfaces':'unknown in all10 reports'})
limitation='Fixed/control source rejects the scored address, but scanner SENT-015 supports get/post/put/patch/delete/head/options/request, not httpx build_request/send (sent015.py:619-647). Fixed fetch.py:129/135 is explicitly unresolved. Therefore first-frozen detection and the prospectively specified output discrimination pass; actual CGNAT-fix recognition is not established. Safe control tests a public initial literal only and is not proof of arbitrary URL safety. This limitation requires explicit human disposition at technical acceptance.'
write('assessment.json',{'recorded_at':datetime.now(timezone.utc).isoformat(),'execution_checks_passed':True,'source_assessment_complete':True,'fresh_detection_gate_passed':True,'fixed_guard_recognition_established':False,'fixed_sink_coverage_limitation':limitation,'limitation_accepted':False,'technical_acceptance_received':False,'phase22_complete':False,'scanner':packet['scanner'],'runner_revision':packet['runner_revision'],'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'authorization_sha256':sha(ASSETS/'evaluation-authorization.json'),'rubric_sha256':sha(ASSETS/'scoring-rubric.json'),'raw_packet_sha256':sha(RAW/'packet.json'),'launch_sha256':sha(OUT/'launch-completed.json'),'budget':{'native_consumed':10,'semgrep_consumed':5,'unstarted':0,'remaining':0,'closed':True,'dispatches':0,'paid_calls':0,'target_executions':0,'retries':0},'native_within120':10,'native_extended':0,'max_whole_native_seconds':max(r['whole_seconds'] for r in rows if r['batch']!='semgrep-first'),'max_whole_comparator_seconds':max(r['whole_seconds'] for r in rows if r['batch']=='semgrep-first'),'sequence_seconds':launch['elapsed_seconds'],'entire_ordered_repeat_equal':5,'batch_metrics':ms,'rows':rows,'assessment_files_sha256':{n:sha(OUT/n) for n in ['finding-source-assessment.json','diagnostic-source-assessment.json','surface-source-assessment.json']},'scanner_source_review':{'path':'src/sentinel/static/rules/sent015.py','sha256':sha(ROOT/'src/sentinel/static/rules/sent015.py'),'lines':[619,647]},'source_exposure':'Source first selected after f85a90f freeze; same implementation agent curated and adjudicated. One repository/one narrow vulnerability; two vulnerable variants correlated. No independent human review, training-data absence, runtime proof or broad generalization/superiority claim.'})
print('All15 observations verified: native2/2 hits per batch,0/3 matching negative alerts,5 ordered repeats. Fixed send coverage limitation retained. Assessed80 findings,6366 diagnostics,60 surfaces.')
