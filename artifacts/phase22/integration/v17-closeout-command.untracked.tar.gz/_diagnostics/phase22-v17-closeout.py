import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=read('v17-sampling-assessment.json');v=read('v17-source-verification.json');seal=read('evidence-v46.json');p=read('v16-closeout-audit/packet.json')
assert a['scope_stopped'] and a['remaining_authorized_executions']==0
p.update(source=a['scanner']['revision'],scanner_identity=a['scanner'],workflow_delivery=v['executed_engineering_source'],recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_diagnostic=a,latest_timing_disposition=read('v17-timing-disposition.json'),prior_audit={'path':'artifacts/phase22/integration/v16-closeout-audit/packet.json','sha256':sha(b/'v16-closeout-audit/packet.json')},current_verification={'path':'artifacts/phase22/integration/v17-source-verification.json','sha256':sha(b/'v17-source-verification.json'),'actual_executed_engineering_source':v['executed_engineering_source'],'new_full_suite_or_hosted_run':False},next_worker_sampling_approved=True,current_sampling_scope_consumed=True,further_optimization_proposed=False,current_source_fresh_evaluation_approved=False,new_paid_calls=0,phase22_complete=False,technical_acceptance_requested=False,technical_acceptance_received=False)
p['current_source_and_test_files']=v['source_and_test_files_sha256'];p['owning_document_binding']='Final owning-document hashes are bound after this update in v17-final-documentation-binding.json. Profile127763c, actual engineering592a9cd and original exposed native2ac39aa remain distinct.'
p['current_check_failure']={'command':'v17-verification-command','exit_code':1,'reason':'Sandbox denied the read-only Docker socket inspection; no measurement or product check failed.','recheck':'v17-verification-authorized-command','recheck_exit_code':0,'both_records_preserved':True}
for row in p['requirements']:
 row['evidence']=list(dict.fromkeys(row['evidence']+['artifacts/phase22/integration/v17-source-verification.json']))
 row['current_verification']='Code/test/workflow/package inputs equal actual engineering source592a9cd. Retained full-suite, hosted, replay and compatibility results keep their executed source; no new full suite is claimed.'
 if row['id'] in ['R63','R64','R65','R69','R85','R86']:
  row['evidence']+=['artifacts/phase22/integration/v17-sampling-assessment.json','artifacts/phase22/integration/v17-timing-disposition.json'];row['latest_diagnostic']='One sampled Meta operator input completed69.906s native,71.578s outer; ordered baseline report equal and four final worker snapshots. No safe larger optimization established. One profile consumed, zero optimizations/native observations/paid calls; scope closed. Timing/fresh/acceptance remain unmet.'
 if row['id']=='R79':row['evidence']+=['artifacts/phase22/integration/evidence-v46.json']
 if row['id']=='R82':row['evidence']+=['artifacts/phase22/integration/v17-delivery-verification.json']
for i,title,evidence in [('AUTH','Exact one-profile approval and source/input bindings',['v17-sampling-authorization.json']),('DIAG','Bounded CPU sampling with unchanged methods, valid accounting and report',['v17-sampling-assessment.json','v17-sampler-selfcheck/packet.json']),('STOP','Stop after one attempted input without inferring an optimization or gate pass',['v17-timing-disposition.json']),('REUSE','Verify unchanged source and preserve actual engineering/runtime evidence',['v17-source-verification.json']),('DELIVERY','Seal and deliver completed scope while retaining unmet timing and acceptance',['evidence-v46.json','v17-delivery-verification.json'])]:
 p['additional_scope_requirements'].append({'id':'V17-'+i,'requirement':title,'disposition':'passed','evidence':evidence})
p['additional_scope_dispositions']=dict(collections.Counter(r['disposition'] for r in p['additional_scope_requirements']));assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==22 and p['additional_scope_dispositions']=={'passed':21,'unresolved':1}
p['references_sha256'].update({'artifacts/phase22/integration/'+n:sha(b/n) for n in ['v17-sampling-authorization.json','v17-sampling-assessment.json','v17-source-verification.json','v17-timing-disposition.json','evidence-v46.json']})
out=b/'v17-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
summary='''The approved whole-worker sampling scope is complete at `127763c`:
**one Meta operator input**, **69.906s native / 71.578s outer**, 49 findings,
full ordered baseline equivalence after established volatile exclusions and valid
native JSON/SARIF. Four final snapshots restore timer/signal state. The sampler
changes no scanner methods and records no locals or target values.

Active workers retain 4,220 / 5,093 / 4,903 samples (SENT-012/015/016).
Shared merge inclusive shares are 24.81% / 19.18% / 22.58%; expression leaf
shares are 11.66% / 15.92% / 14.28%, mostly at function entry. Caller shares
overlap, signal delivery biases attribution, and no share is wholly removable
cost. **No safe larger optimization or native speedup is established.** See
`v17-sampling-assessment.json` and the source review in `v17-timing-disposition.json`.

The one-profile budget is closed: **zero optimization attempts, additional native
observations, comparator runs, full retries or paid calls**. No scanner/test code
changed. Existing local and 12 hosted suites retain 2,183 passed / 36 skipped,
29 normal jobs and docs, replay and Git compatibility at actual `592a9cd`.
All three exposed SSRF gates remain source-compatible at measured `2ac39aa`.
The read-only cleanup check initially encountered sandbox Docker permission;
the authorized recheck passed and both records are retained.

**Phase 22 remains incomplete.** The Linux result remains 15/25 development
complete, ten Meta timeouts and both historical batches skipped. Retain the
timing gate; no scope revision, fresh evaluation or final acceptance is inferred.
Further performance experiments need a justified bounded proposal and approval;
this profile does not justify another speculative micro-optimization. Any timing
scope revision needs an explicit user decision and would still require fresh
evaluation and final human acceptance. Pilots/full paid benchmark remain deferred,
Phase 21 incomplete, and Phase 24/15 unchanged. No merge, release or next phase.
'''
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']:
 f=root/name;s=f.read_text()
 if name=='AGENTS.md':needle='## Current phase\n\n';assert s.count(needle)==1;s=s.replace(needle,needle+summary+'\n### Historical v16 diagnostic at `46b8786`\n\n',1)
 else:
  level='###' if name=='ROADMAP.md' else '##';needle=level+' Current v16 diagnostic at `46b8786`';assert s.count(needle)==1;s=s.replace(needle,level+' Current v17 diagnostic at `127763c`\n\n'+summary+'\n'+level+' Historical v16 diagnostic at `46b8786`',1)
 f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current v16 source-bound audit','## Historical v16 source-bound audit',1)
text='''\n## Current v17 source-bound audit\n\nAll 89 original rows are mapped in `v17-closeout-audit/packet.json`:
**70 passed, 2 explicitly user-deferred, 17 unresolved**. Five v17 execution
requirements pass. All 22 additional rows retain **21 passed and 1 unresolved**
(the historical v14 performance-retention requirement). This diagnostic executed
at `127763c`; unchanged engineering inputs retain actual verification at `592a9cd`.
No timing pass, fresh result, scope waiver or human acceptance is inferred.

| ID | Requirement | Disposition |
| --- | --- | --- |
'''
for row in p['additional_scope_requirements']:
 if row['id'].startswith('V17-'):text+='| '+row['id']+' | '+row['requirement']+' | **passed** |\n'
f.write_text(title+'\n'+text+rest)
index=f'''Batch 46 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 45 prior archive hashes are verified.
Restore after batches 1–45 in separate staging using `evidence-v46.json`; existing
destinations must match identical bytes or a recorded previous hash. Stop on
unexpected conflicts. The batch retains approval, synthetic controls, the single
profile, raw stack catalogs/counts, complete reports, assessment, source review,
verification, the initial permission failure and helpers. Final audit/docs/delivery
bindings are tracked directly after the seal.\n\n'''
f=b/'README.md';s=f.read_text().replace('batches 1–45 and closeout audit','batches 1–46 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text((f.read_text().rstrip()+'\n\n### Evidence batch 46\n\n'+index).rstrip()+'\n')
body=(b/'v16-closeout-draft-body.md').read_text().split('\n\n',1)[0]+'\n\n'+summary+'\n[Current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v17-closeout-audit/packet.json), [sampling result](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v17-sampling-assessment.json), [source review and timing disposition](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v17-timing-disposition.json), and [evidence batches 1–46](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nThis docs/evidence-only delivery uses authorized CI skip after proving tested inputs unchanged. Final docs are checked locally; no later hosted code pass is claimed.\n'
f=b/'v17-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(p['dispositions'],p['additional_scope_dispositions'])
