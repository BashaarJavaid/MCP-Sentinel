"""Render measured times and actual gate outcomes after the authorized run closes."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
a = read(OUT / 'final-assessment/assessment.json')
e = read(OUT / 'execution.json')
audit = read(OUT / 'audit.json')
assert a['completed'] == 24 and a['budget_closed'] and a['source_assessment_complete']
assert len(audit['requirements']) + len(audit['additional_scope_requirements']) == 399
labels = {'faf-read-root': 'FAF', 'no-bash-write-prefix': 'no-bash', 'lightning-discover-linklocal': 'Lightning Python member', 'engram-export-home': 'Engram'}
outcomes = {'faf-read-root': 'Fail: vulnerable miss and unsupported negatives', 'no-bash-write-prefix': 'Narrow pass: lexical boundary / physical gap', 'lightning-discover-linklocal': 'Fail: fixed/safe initial rejection is unqualified', 'engram-export-home': 'Narrow pass: initial home guard / reconstructed-use uncertainty'}
table = '\n'.join(f"| {labels[c['case_id']]} | {c['completed']} | {min(c['timings_seconds']):.6f}–{max(c['timings_seconds']):.6f} | {outcomes[c['case_id']]} |" for c in a['cases'])
faf = [r for r in a['rows'] if r['case_id'] == 'faf-read-root']
timings = '\n'.join(f"| {r['batch']} | {r['label']} | {r['timing']['elapsed_seconds']:.9f} | {r['native_seconds']:.3f} |" for r in faf)
s = f'''# Uncapped four-repository experiment: complete, two gates failed

**All 24 authorized observations completed at `4145d35`, with all 12 entire ordered report pairs equal and verified cleanup. No-bash and Engram pass their narrow exposed conditions; Lightning and FAF fail their required gates. Phase 22 remains incomplete.**

The user requested a run without a time limit and explicitly selected **“Four repositories first — 24 observations.”** [Intake](../v69-uncapped-four-repository/intake.json), [exact proposal](../v69-uncapped-four-repository/evaluation-proposal.json), [authorization](../v69-uncapped-four-repository/evaluation-authorization.json), preflight and one-use consumption bind this experiment. The 18 non-FAF observations ran first in their original first/repeat order, followed by six FAF observations. All 12 distinct inputs retain original source archives, conditions and labels. There were no retries, profiles, comparators, replacement/new repositories, target execution or paid calls. The 181 earlier Python/TypeScript observations were outside this approval and remain unexecuted at this source.

Scanner `{a['scanner']['revision']}`; source SHA-256 `{a['scanner']['source_sha256']}`; harness `{a['scanner']['harness_sha256']}`; lock `c34da413d4761ca42f243bc41a10afd8961a98daa1f3a236d37fe03720743b2b`. Frozen checkout `/private/tmp/mcp-phase22-frozen-4145d35`. Proposal SHA-256 `{a['proposal_sha256']}`. Rules-only configuration, actual imported source identities, forbidden model transport and absent credentials were verified.

## Measured duration and completion

| Repository | Observations | Whole-input seconds | Current narrow exposed gate |
| --- | ---: | ---: | --- |
{table}

| FAF pass | Input | Whole-input seconds | Native harness seconds |
| --- | --- | ---: | ---: |
{timings}

The sequence took **{e['elapsed_sequence_including_preparation_seconds']:.6f} seconds** from the launcher's retained start, including preparation between inputs. Whole-input time starts before materialization/import/analysis/report handling; narrower native times are shown separately. All 18 non-FAF observations met the informational 120-second target. **{a['beyond1800']} observations exceeded the ordinary 1,800-second policy.** These are observed local durations, not an isolated performance benchmark, portable runtime guarantee, cross-version speedup or causal attribution. Read-only source/report assessment and passive progress checks also occurred on this Mac during the sequence.

The experimental launcher removed whole-input, outer-sequence and Semgrep rule time caps only for these inputs. The shipped 1,800-second scanner default and normal Semgrep setting remain unchanged. Finite cleanup stages, interruption handling, identity/schema/report checks and stop-on-execution/cleanup/repeat-failure behavior remained. The [synthetic boundary checks](../v69-boundaries.json) and [full ordered synthetic equivalence](../v69-synthetic-equivalence.json) precede the sole execution. Removing the cap allowed these reports to complete; it does not establish success under the ordinary deadline or fix detection.

[Execution](execution.json), the complete raw packet and [final validation](final-assessment/validation.json) bind 24 completed outputs, native JSON/SARIF, zero unstarted remainder, zero remaining budget and 12 entire ordered pairs. Only the established 11 volatile field names are excluded. Findings, diagnostics and coverage arrays retain full order; no sorting or narrowed comparison was used. This budget is closed and cannot be reused.

## Source assessment and product consequences

The [final assessment](final-assessment/assessment.json) retains **260 findings, 52,492 diagnostic occurrences, 282 surfaces and 4,963 source contexts**, all source-assessed. [Full reference differences](final-assessment/complete-report-differences.jsonl.gz) reconstruct every current report from its original `2e0efb2` counterpart after only the approved exclusions; [difference assessment](final-assessment/report-difference-assessment.json) covers every changed field. No diagnostic removal is silently treated as resolved support. Surface totals have no established complete denominator. Review was by the same agent, not independent human validation or executed exploit validation.

**FAF:** both vulnerable reports contain zero findings and miss the named `faf_read` route. Fixed/safe reports are also empty but remain unsupported, so silence fails the required negative-path gate. Each report now exposes two unnamed startup registrations with unresolved `this.toolHandler.callTool` delegation. The actual `FafToolHandler` constructor has a private parameter property; current `class_members` rejects constructor parameter attributes. The read route and this source-visible support barrier are bound in [named diagnosis](first-faf-assessment/named-source-diagnosis.json). This is not proof that one edit alone resolves every gate or runtime cost. The [fixed helper assessment](first21-assessment/faf-fixed-source-assessment.json) establishes source-level ordinary-file rejection under the frozen operator-root prerequisites; the scanner has not established the caller/guard/value/sink path. Other roots, custom hooks, symlinks and races are not certified.

**Lightning:** optional HTTPX resolution now reaches the actual named `client.get`, so vulnerable detection succeeds. The fixed helper parses the initial URL, rejects the selected link-local literal and returns before client creation through a caught `SsrfError`. Both negative reports nevertheless describe a generic unrestricted request, without the required initial-only qualifier. This is a failed discrimination gate. [Read-only diagnosis](lightning-readonly-diagnosis.json) identifies whole-URL `rstrip('/')` and suffix handling as visible propagation barriers; it does not claim newly traced guard state or a unique sufficient fix. DNS, redirect, rebinding and full destination safety remain outside the narrow conclusion.

**No-bash:** the named vulnerable overwrite is detected. The fixed checked value preserves exact-root or root-plus-separator containment under ordinary-file prerequisites, and its raw report accurately retains physical/symlink uncertainty. Both batches therefore pass the frozen narrow condition. Unrelated read/append/delete/command candidates remain fully assessed. The current assessment corrects an old prose detail: recursive parent `mkdir` is called in the overwrite branch even if the parent already exists; no new directory is needed under that prerequisite. Old source, raw reports and original failed gates are unchanged.

**Engram:** the actual manifest write is detected. The fixed source's initial home-relative check rejects the selected outside path, but later reconstruction of the original value still leaves equivalence/containment at use uncertain. The raw qualifier preserves that distinction, so both batches pass only the frozen initial-boundary condition with stable home/cwd/environment, ordinary files and helper/database availability. Other export writes and import reads remain separately assessed; no runtime or complete fixed-path safety is certified.

The immutable `first-three-assessment/`, `first-faf-assessment/` and `first21-assessment/` checkpoints remain. Final repeated FAF judgments are reused only after exact canonical reports, complete ordered deltas and source contexts agree. The failed conceptual-warning index helper and corrected file-precision handling are retained. The initial relative-module binding index falsely matched an empty identifier and was corrected to the actual import line; both versions remain. The first21 helper's vacuous revision assertion was corrected, with all actual source/report/revision bindings independently verified in [binding check](first21-assessment/assessment-binding-check.json). No scanner output changed and no extra observation was used for these assessment corrections.

## Engineering, authority and retained history

[Compatible reuse](compatible-reuse.json) verifies all 303 unchanged engineering inputs against `4145d35`: **2,419 tests / 36 skips** locally and in all 12 hosted suites; **29 normal jobs and docs passed** in CI 34808261686 / 34808261635. Combined coverage is 90.08%, branch-only 85.92%. Six complete production requests retain zero-call replay and approved runtime/image bindings. Final documentation/package metadata is checked separately; this experiment is not another hosted code pass or production capture.

The [audit](audit.json) preserves **all 391 prior rows**, the previous V68 delivery row and the explicit [v68 status correction](../v68-invalidation-sampling/audit-current-status.json). Eight new rows give **399 total: 89 original + 310 added**. Original dispositions remain 84 passed, two user-deferred, two proposed limitations and unresolved human acceptance. Added dispositions before supplemental draft delivery are 283 passed, six proposed historical closures and 21 unresolved. A later verified draft delivery does not accept technical limitations.

All seven earlier native timeouts remain source-bound, each one incomplete/no reports/204 unstarted closed. All six valid partial profiles, invalid v50 stale-root attribution/V49 preparation, both singleton failures and the original strict invalidation failure remain. The prior `4145d35` native attempt and partial profile are separate closed budgets; with this experiment, that source has 25 native attempts (24 complete, one incomplete) and one incomplete sampled attempt. No historical timeout becomes an uncapped pass retroactively.

The original four-repository batch remains 24 complete reports/12 pairs with **all four fresh gates failed at `2e0efb2`**. These new outcomes are exposed regression. Historical TS94/47 pairs, Python87/36 pairs, whole25 development reuse and whole45+45 Linux retain their actual scanner/source bindings and DDG/Meta errata; no subsets form new whole batches. Original held-out results remain 10 complete/10 unsupported/five incomplete, zero hits among four completed vulnerable inputs out of ten vulnerable total. All memory-keeper, DDG and Lighthouse failures remain. Six historical closure proposals remain unaccepted: V14-RETENTION, V21-SEQUENCE, V21-FRESH-PROPOSAL, V25-EXPOSED-REGRESSION, V27-REGRESSION and V39-EVALUATION.

The [v68 literal-serialization optimization](../v68-invalidation-sampling/optimization-proposal.json), SHA `fa4ffc3760d4b85b4f8236eec5c7b28d979ece894515bb1495046dd1db108cf6`, remains separately **unapproved, unimplemented and unopened**. The uncapped request did not approve it, another profile, additional regression inputs, paid work or a permanent deadline revision. The remaining detection/qualification gaps require actual recovery or an explicit applicable user-approved disposition; they are not automatically documented limitations.

Verified file recovery and selective user-authorized Docker cleanup remain in the v68 packet. No additional cleanup or resource change occurred in this experiment. The disappearance cause is still unknown; successful scans do not identify it. Protected user documents and retained worktrees remain preserved.

Git remains **312/1,040 incomplete, 728 deferred**; the paid 396-request benchmark and external pilots are user-deferred. Historical two paid calls total **$0.071799**, with **zero added**. Phase 21 remains incomplete; Phase 24/15 are unchanged. **Phase 22 remains incomplete:** failed current-source gates, earlier-language compatibility, separate explicit human technical acceptance and verified accepted closeout remain. No merge, ready-state change, release, outreach or Phase 23 is authorized.
'''
with (OUT / 'summary.md').open('x') as f:
    f.write(s)
url = 'https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v70-uncapped-four-results/'
body = f'''The approved uncapped experiment at `4145d35` completed all 24 four-repository observations with 12 entire ordered report pairs equal and verified cleanup. No-bash and Engram pass their narrow exposed conditions; Lightning fails fixed/safe qualification and FAF misses the vulnerable read while leaving negatives unsupported.

[Review and measured times]({url}summary.md) · [399-row audit]({url}audit.json) · [complete source assessment]({url}final-assessment/assessment.json)

The other repositories took 6.28–10.72 seconds per observation; exact FAF first/repeat times are in the review. {a['beyond1800']} observations exceeded the unchanged 1,800-second product policy. The temporary launcher-only override does not establish normal-policy success or speedup. All 260 findings, 52,492 diagnostics, 282 surfaces and complete ordered reference differences are assessed. Original fresh failures remain unchanged.

The 181 earlier-language observations are outside this approval. The pending literal-serialization optimization remains unapproved/unimplemented. No new paid call, retry, profile, comparator, target execution or source tuning occurred. Unchanged engineering retains 2,419 tests/36 skips locally and all 12 hosted suites, 29 normal jobs and docs, six zero-call request replays and approved runtime bindings.

Phase 22 remains incomplete pending failed gates, current earlier-language compatibility, explicit human technical acceptance and accepted closeout. All 399 requirements and historical failures remain; Git 312/1,040 is incomplete, paid benchmark/pilots deferred, Phase 21 incomplete, Phase 24/15 unchanged. No merge, ready-state change, release, outreach or Phase 23.
'''
with (OUT / 'pr-body.md').open('x') as f:
    f.write(body)
print('Rendered actual uncapped timing and source-assessed outcomes; technical acceptance remains unresolved.')
