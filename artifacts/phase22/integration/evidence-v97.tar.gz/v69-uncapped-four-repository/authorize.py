"""Bind explicit no-time-limit request and24-observation confirmation; no further permission needed."""
import hashlib,importlib.util,json,os,subprocess,sys
from datetime import datetime,timezone
from pathlib import Path
out=Path(__file__).resolve().parent;base=out.parent;root=out.parents[3];previous=base/'v68-invalidation-sampling'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def run(*args,cwd=root):return subprocess.check_output(args,cwd=cwd,text=True)
def save(n,v):
 with (out/n).open('x') as f:json.dump(v,f,indent=2);f.write('\n')
assert not (out/'evaluation-authorization.json').exists() and not (out/'execution-consumed.json').exists() and not (base/'v70-uncapped-four-results').exists()
head='8f4c4486ab9644ace9adac2e3570d2f3d4afe9fb'
assert run('git','rev-parse','HEAD').strip()==head and not run('git','diff','HEAD') and not run('git','diff','--cached')
binding=read(previous/'documentation-binding.json');delivery=read(previous/'delivery-verification.json')
assert delivery['passed'] and delivery['head']==head
for field in ['owning_docs_sha256','review_packet_sha256','user_files_sha256']:
 for n,d in binding[field].items():assert sha(root/n)==d,n
remote=json.loads(run('gh','pr','view','37','--json','state,isDraft,headRefName,headRefOid,baseRefName,title,body'))
assert remote['state']=='OPEN' and remote['isDraft'] and remote['headRefName']=='phase22/integration' and remote['baseRefName']=='phase22/description-poisoning' and remote['headRefOid']==head
assert remote['title']==delivery['title'] and remote['body']==(previous/'pr-body-delivery.md').read_text()
assert run('gh','api','repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration','--jq','.commit.sha').strip()==head
main=Path('/Users/bashaarjavaid/Projects/MCP-Sentinel');assert run('git','rev-parse','HEAD',cwd=main).strip()=='4cd57593b2585b9ee05c0f175930e6a0d76d362a' and not run('git','status','--porcelain',cwd=main)
local=read(base/'v66-invalidation-contract/local-checks.json')
for n,d in local['candidate_engineering_files_sha256'].items():assert sha(root/n)==sha(Path('/private/tmp/mcp-phase22-frozen-4145d35')/n)==d,n
assert read(base/'v66-production-capture-revalidation/packet.json')['model_calls']==0
for n in ['v69-synthetic-equivalence','v69-boundaries','v69-preparation-corrected','v69-approval-boundary-corrected']:assert read(base/(n+'.json'))['exit_code']==0,n
rows={}
for line in run('ps','-axo','pid=,ppid=,command=').splitlines():
 f=line.strip().split(None,2)
 if len(f)==3:rows[int(f[0])]=(int(f[1]),f[2])
ancestors=set();pid=os.getpid()
while pid in rows and pid not in ancestors:ancestors.add(pid);pid=rows[pid][0]
markers=[f'v{n}-' for n in range(20,71)]+['phase22-check.py','mcp-phase22-four-fresh-']
owned=[{'pid':pid,'command':command} for pid,(_,command) in rows.items() if pid not in ancestors and any(m in command for m in markers)]
assert not owned,owned
for selector in ['label=com.securemcp.sentinel=true','name=sentinel']:assert not run('docker','ps','-aq','--filter',selector)
p=read(out/'evaluation-proposal.json');assert p['bounds']['native_observations']==24 and p['bounds']['native_and_whole_input_maximum_seconds'] is None and p['bounds']['paid_calls']==0
assert read(out/'intake.json')['scope_confirmation']=='Four repositories first — 24 observations'
spec=importlib.util.spec_from_file_location('r',out/'evaluate.py');r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r);assert r.verify()==p
save('evaluation-authorization.json',{'approved':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'user_decision':read(out/'intake.json')['user_request']+'\n'+read(out/'intake.json')['scope_confirmation'],'decision_context':'The user explicitly requested no time limit and selected four repositories first,24observations. This records the already supplied permission after preparing and verifying its concrete implementation. One uncapped experimental sequence, no retry/profile/optimization/paid call; shipped default and source unchanged. FAF follows the18non-FAF observations as communicated. No technical acceptance is inferred.','proposal_sha256':sha(out/'evaluation-proposal.json'),'scanner':p['scanner'],'bounds':p['bounds'],'order':p['order'],'rubric_sha256':sha(out/'scoring-rubric.json'),'intake_sha256':sha(out/'intake.json'),'launcher_binding_sha256':sha(out/'launcher-binding.json'),'runtime_policy_sha256':sha(out/'uncapped.py'),'prior_delivery_sha256':sha(previous/'delivery-verification.json'),'technical_acceptance_received':False,'phase22_complete':False})
os.chdir(p['frozen_checkout']);sys.path[:0]=[str(Path.cwd()/'src'),str(Path.cwd())];assert r.approved()==p
for group in p['groups']:r.identity(group)
assert not run('git','status','--porcelain',cwd=Path.cwd())
save('execution-preflight.json',{'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'head':head,'scanner':p['scanner'],'proposal_sha256':sha(out/'evaluation-proposal.json'),'approval_sha256':sha(out/'evaluation-authorization.json'),'source_engineering_files_verified':303,'protected_user_files_verified':9,'default_engineering_and_six_zero_call_replays_reused':True,'synthetic_policy_results':6,'worker_tests':10,'owned_processes':owned,'owned_containers':[],'runtime_policy_sha256':sha(out/'uncapped.py'),'host_available_bytes':os.statvfs(root).f_bavail*os.statvfs(root).f_frsize,'corpus_attempts':0,'paid_calls':0,'qualification':'Same tested source under an explicit experimental no-time-limit policy. Current-source compatibility and default1800-second completion are not established. All prior budgets remain closed; new scope is exactly24observations.'})
print('Authorized24uncapped observations; exact source/proposal/cleanup/protected-state preflight passed; no input started yet.')
