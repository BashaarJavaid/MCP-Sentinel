"""Deliver the stopped run and exact next proposal to the existing draft only."""
import hashlib
import json
import subprocess
import tarfile
import time
from datetime import datetime, timezone
from pathlib import Path
ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OLD = BASE/'v49-allocation-regression'
EXPECTED = '2933d39493b8cf7d52bfb8e1ffdca879d20d5c1d'
TITLE = 'Phase 22: sampler binding corrected; profile approval pending'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
def run(args):
    return subprocess.check_output(args, cwd=ROOT, text=True, stderr=subprocess.STDOUT, timeout=180)
def save(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
def pr():
    return json.loads(run(['gh', 'pr', 'view', '37', '--json', 'number,state,isDraft,headRefName,headRefOid,baseRefName,title,body']))
def guard(d):
    assert d['state'] == 'OPEN' and d['isDraft'] and d['headRefName'] == 'phase22/integration' and d['baseRefName'] == 'phase22/description-poisoning'
binding = read(OUT/'documentation-binding.json')
head = read(OUT/'delivery-commit.json')['head']
seal = read(BASE/'evidence-v78.json')
assert run(['git','rev-parse','HEAD']).strip()==head
for field in ['owning_docs_sha256','review_packet_sha256','user_files_sha256']:
    for name,digest in binding[field].items():assert sha(ROOT/name)==digest,name
for name,digest in read(BASE/'v48-merge-allocation/local-checks.json')['candidate_engineering_files_sha256'].items():assert sha(ROOT/name)==digest,name
save('delivery-client-error.json',{'action':'gh pr edit37 title/body','exit_code':1,'commit_and_push_completed':True,'head':head,'qualification':'The client returned a nonzero status after the metadata mutation. Subsequent read-only PR inspection showed expected title/body and head. No repeat edit or push is performed; exact readback follows. Underlying error output was not retained by subprocess.check_output exception display, so its cause is unknown.','paid_calls':0})
history = []
for attempt in range(12):
    current = pr()
    branch = run(['gh', 'api', 'repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration', '--jq', '.commit.sha']).strip()
    guard(current)
    history.append({'recorded_at': datetime.now(timezone.utc).isoformat(), 'pr': current, 'branch_head': branch})
    if current['headRefOid'] == head and branch == head and current['title'] == TITLE and current['body'] == (OUT/'pr-body-delivery.md').read_text():
        break
    print('Remote readback stale; retrying read only.', flush=True)
    time.sleep(5)
else:
    save('delivery-readback-history.json', history)
    raise AssertionError('Remote readback stale; preserve completed mutations and recheck read only.')
save('delivery-readback-history.json', history)
for name, digest in binding['user_files_sha256'].items():
    assert sha(ROOT/name) == digest, name
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=main, text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=main)
assert not run(['git', 'diff', 'HEAD', '--name-only'])
receipt = {'passed': True, 'recorded_at': datetime.now(timezone.utc).isoformat(), 'head': head, 'base': 'phase22/description-poisoning', 'draft': True, 'open': True, 'title': TITLE,
    'body_sha256': sha(OUT/'pr-body-delivery.md'), 'diagnostic_proposal_sha256': binding['diagnostic_proposal_sha256'], 'scanner': binding['corrected_scanner'],
    'seal78_sha256': seal['sha256'], 'readback_history_sha256': sha(OUT/'delivery-readback-history.json'), 'documentation_binding_sha256': sha(OUT/'documentation-binding.json'),
    'protected_user_files_and_main_preserved': True, 'invalid_profile_budget': binding['invalid_profile_budget'], 'invalid_profile_attempts': 1, 'corrected_profile_executions': 0, 'paid_calls': 0,
    'technical_acceptance_received': False, 'phase22_complete': False,
    'effective_scope_disposition': {'id': 'V50-DELIVERY', 'disposition': 'passed', 'basis': 'Final docs/package/source checks, seal, commit/push and exact remote branch/PR head/base/draft/title/body readback verified. Supersedes sealed pending row for delivery only.'},
    'effective_additional_counts': {'passed': 155, 'historical_closure_proposals': 6, 'unresolved': 9},
    'provenance': 'Supplemental post-commit readback, outside seal78 and the commit it verifies; retain in next authorized seal.'}
save('delivery-verification.json', receipt)
print(json.dumps(receipt, indent=2), flush=True)
