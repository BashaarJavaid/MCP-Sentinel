"""Retain the full audit and source-bound sampled result without accepting failures."""
import copy,hashlib,json,os
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3];OLD=BASE/'v50-faf-allocation-sampling'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
a=read(OUT/'assessment.json');old=read(OLD/'audit.json');rows=copy.deepcopy(old['additional_scope_requirements'])
for row in rows:
    if row['id']=='V50-DELIVERY':
        row['previous_row']=copy.deepcopy(row);row.update(disposition='passed',evidence=['artifacts/phase22/integration/v50-faf-allocation-sampling/delivery-verification.json'],assessment='Actualcd5e9aehead/base/draft/title/body readback passed. The metadata client error and subsequent matching read-only verification are preserved; no mutation was repeated.')
    if row['id']=='V50-PROFILE-GATE':
        row['previous_row']=copy.deepcopy(row);row.update(disposition='passed',evidence=['artifacts/phase22/integration/v51-faf-bound-sampling/validation.json','artifacts/phase22/integration/v51-faf-bound-sampling/assessment.json'],assessment='The separately approved corrected attempt now supplies a valid current-source partial diagnostic: four verified worker identities,79307samples and source attribution. Static input completion still fails at300seconds. This satisfies obtaining a valid diagnostic only, not a native gate or acceptance of the prior invalid attempt. V49-DIAGNOSTIC-PREPARATION remains unresolved with its failed history.')
new=[('V51-AUTH','Bind the exact corrected single-profile approval to delivered proposal and frozen scanner','passed',['../v50-faf-allocation-sampling/diagnostic-authorization.json','../v50-faf-allocation-sampling/diagnostic-preflight.json']),('V51-PROFILE-VALIDATION','Validate current-source worker identities, all retained partial samples, output and closed budget','passed',['validation.json','owned-work.json']),('V51-SOURCE-ASSESSMENT','Source-assess all retained frame/stack attribution and state sampling limitations','passed',['assessment.json','source-assessment.json','frame-source-bindings.json','sample-attribution.json']),('V51-OPT-PREPARATION','Prepare one bounded source-only merge fast-path optimization proposal with zero implementation or new measurement','passed',['optimization-proposal.json']),('V51-OPT-DECISION','Obtain a separate decision before another source-only optimization attempt','unresolved',['optimization-proposal.json']),('V51-DELIVERY','Seal partial diagnostic, reconcile every prior row and verify existing draft delivery','unresolved',[])]
for identity,requirement,disposition,evidence in new:rows.append({'id':identity,'requirement':requirement,'disposition':disposition,'evidence':[str((OUT/n).resolve().relative_to(ROOT)) for n in evidence],'assessment':'One current-source sampled timeout with four valid partial worker snapshots; no report/native pass. Source-only optimization remains unapproved; all old budgets and failures preserved.'})
assert len(old['requirements'])==89 and len(rows)==176 and len({r['id'] for r in old['requirements']+rows})==265
audit=copy.deepcopy(old);audit['historical_v50_status_fields']={k:copy.deepcopy(v) for k,v in old.items() if k not in ['requirements','additional_scope_requirements'] and not k.startswith('historical_')}
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(),additional_scope_requirements=rows,additional_scope_dispositions=dict(Counter(r['disposition'] for r in rows)),prior_audit={'path':str((OLD/'audit.json').relative_to(ROOT)),'sha256':sha(OLD/'audit.json')},diagnostic_approved=True,diagnostic_executed=True,diagnostic_attempts=1,diagnostic_completed_inputs=0,diagnostic_budget_closed=True,diagnostic_remaining=0,valid_current_source_profiles=1,current_diagnostic_approved=True,current_diagnostic_executed=True,current_optimization_prepared=True,current_optimization_approved=False,current_optimization_attempts=0,acceptance_packet_ready=False,technical_acceptance_requested=False,technical_acceptance_received=False,phase22_complete=False,new_paid_calls=0,status='Corrected current-source single profile timed out at300seconds with4verified worker identities and79307retained partial samples; budget closed. Shared TypeScript branch merge remains a sample concentration. One source-only early equal-value fast-path proposal is unapproved/unstarted. No native completion, detection/compatibility or acceptance follows.')
audit['current_evidence']={n:sha(OUT/n) for n in ['assessment.json','validation.json','source-assessment.json','sample-attribution.json','optimization-proposal.json','owned-work.json']}
write('audit.json',audit)
write('prior-row-preservation.json',{'prior_audit_sha256':sha(OLD/'audit.json'),'retained_prior_rows':259,'updated_rows':['V50-DELIVERY','V50-PROFILE-GATE'],'rows':{r['id']:hashlib.sha256(json.dumps(r,sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']}})
table='\n'.join(f"| {r['rule']} | {r['samples']:,} | {r['merge_inclusive_percent']:.2f}% | {r['missing_branch_predicate_leaf_percent']:.2f}% | {r['equality_predicate_leaf_percent']:.2f}% | {r['merge_fallback_constructor_leaf_percent']:.3f}% |" for r in a['sample_rows'])
summary=f'''# Current-source profile assessed; source-only proposal pending

**The corrected single FAF profile retained four verified `6e4fd67` worker identities and 79,307 partial samples, then timed out. One incomplete input, no report, zero remaining budget. Phase 22 remains incomplete.**

The exact `approved` decision binds the [corrected proposal and authorization](../v50-faf-allocation-sampling/diagnostic-authorization.json) delivered at `cd5e9ae`. The [worker receipts and validation](validation.json) establish actual worker/flow import paths and full revision/source/harness identity before sampling or target snapshot deserialization. The whole-input supervisor reached **{a['timing']['elapsed_seconds']:.6f} seconds**; cleanup finished by **{a['timing']['elapsed_including_cleanup_seconds']:.6f} seconds**, within the 15-second allowance, with no remaining group kill. The post-run owned process/container inventory is empty. The harness retained `incomplete`, `reason: null` and {a['harness_outcome']['wall_duration_ms']:,} ms within its narrower interval. No JSON/SARIF report, finding/diagnostic inventory, vulnerable detection, negative discrimination or ordered-repeat result exists.

The [complete sample attribution](sample-attribution.json) validates every stack/frame reference, source-file hash and count. Each row is a different worker's last retained periodic snapshot:

| Worker | Samples | Merge inclusive | Missing-branch predicate leaf | Equal-value predicate leaf | Fallback constructor leaf |
| --- | ---: | ---: | ---: | ---: | ---: |
{table}

All four snapshots lack final/restored-state records because mandatory cleanup killed unfinished workers. This does not mean a worker remains active. Their retained CPU intervals differ; all are partial. Approximately 99.61–99.62% of each snapshot is inclusively in TypeScript tool registration. Inclusive shares overlap; leaf counts partition a snapshot. Signal/GIL/native-code delays, snapshot-thread overhead and unsampled parent stages limit attribution. These are sample shares, **not a measured speedup, additive savings or proof of 300-second completion**. The earlier `17b4784` profile's normalized shares cannot be compared as an absolute timing experiment.

[Source assessment](source-assessment.json) traces every direct shared-merge caller. Current merge prepares a record fallback by traversing branch membership before checking whether all present branch values are equal and eligible for unchanged reuse. For the all-present equal cases, that fallback is never consumed. This establishes a narrow source-level opportunity; samples contain no locals, so its frequency and removable cost remain unknown. Guard markers, source-free safety claims, missing-record defaults and ordered metadata/combined behavior must stay conservative.

The [exact source-only optimization proposal](optimization-proposal.json), SHA-256 `{sha(OUT/'optimization-proposal.json')}`, is **unapproved and unstarted**. It requests one attempt to move the existing eligible all-present equal-value fast path before record-fallback preparation in `TypeScriptPathFlow.merge`. No new cache, dependency, generic abstraction, analysis pruning, worker/resource change or timeout relaxation is proposed. Preserve the baseline first; compare complete flow state and inputs across scanner-owned synthetic branches, including missing values equal to defaults, distinct equal instances, guards and source-free safety claims. Synthetic lookup accounting must show avoided fallback preparation. A failed equivalence/work-avoidance check closes the attempt without a new target. Required engineering and candidate freeze follow only if approved and successful. Bounds are **zero corpus observations, profiles, retries, comparators, paid calls, target executions or runtime campaigns**. Any native/compatibility measurement requires another exact proposal and approval.

The prior `6e4fd67` native regression remains one FAF timeout at 300.004111 seconds, no report and 204 unstarted closed. The older `17b4784` native and sampled timeouts remain source-bound. The invalid interrupted v50 sampler attempt remains invalid with no report or snapshot; corrected attribution does not rewrite it. V49-DIAGNOSTIC-PREPARATION remains unresolved with its original claim and correction retained. This profile satisfies the current diagnostic-binding gate only. All four first-frozen repository gates at `2e0efb2` still fail; later corrections are exposed. No additional repository or measurement budget is inferred.

Product retains tested **`6e4fd67`: 2,384 tests / 36 skips locally and in all 12 hosted suites**, 29 normal CI jobs and docs passed in [34743452798](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452798) / [34743452818](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452818), with combined statement/branch coverage 89.98% and branch-only 85.85%. All 302 engineering files, six zero-call production replays, owned Docker fixture result and Git runtime/image bindings retain that source. The earlier 10,944 synthetic allocation comparisons still pass at their actual source; they establish no native speedup. Restored tracked/evidence/worktree files and 3.704 GiB Docker cleanup remain preserved. This docs/evidence continuation separately checks packages and documentation; it is not a new hosted code pass.

The [audit](audit.json) retains all **265 requirements: 89 original and 176 added**. Original dispositions remain 84 passed, two user-deferred, two proposed limitations and one pending human acceptance; six historical closure proposals remain unaccepted. TS94 at `2e0efb2`, Python87 at `8c62567`, whole development25 reuse and historical45+45 at `1f3f72f` retain actual source bindings and the Meta operator erratum. Original memory-keeper false alerts, DDG's unsupported fixed send and wrong TypeScript metadata despite actual Python configuration, Lighthouse misses, and held-out10 completed/10 unsupported/5 incomplete with zero hits among four completed vulnerable out of ten total vulnerable remain unchanged. Same-agent review is not independent human validation, broad accuracy, training novelty or runtime proof.

Git remains **312/1,040 incomplete**, 728 deferred. Paid benchmark and pilots stay deferred, Phase 21 incomplete and Phase 24/15 unchanged. Explicit human technical acceptance and verified final closeout remain pending. No merge, ready-state, release, outreach or Phase 23 is authorized.
'''
with (OUT/'summary.md').open('x') as f:f.write(summary)
url='https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/'
body=summary.replace('(../v50-faf-allocation-sampling/','('+url+'v50-faf-allocation-sampling/')
for n in ['validation.json','sample-attribution.json','source-assessment.json','optimization-proposal.json','audit.json']:body=body.replace('('+n+')','('+url+'v51-faf-bound-sampling/'+n+')')
with (OUT/'pr-body.md').open('x') as f:f.write(body)
docs=list(read(OLD/'documentation-binding.json')['owning_docs_sha256']);assert len(docs)==16
for name in docs:
    path=ROOT/name;text=path.read_text().replace('## Current v50','## Historical v50',1);first,rest=text.split('\n',1)
    link=url+'v51-faf-bound-sampling/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md',path.parent)
    status=f'''## Current v51 bound profile: source-only decision pending

The approved corrected profile at frozen `6e4fd67` retains **four verified worker
identities and 79,307 partial samples**. Its whole input timed out at 300 seconds;
cleanup passed, no report exists, and the one-use budget is closed. Shared
TypeScript branch merge is 43.02–44.46% inclusive sample share; its missing-branch
predicate is 8.40–9.08% leaf share. These are not speedup or removable-cost claims.
The [review packet]({link}) proposes **one unapproved source-only optimization**:
recognize eligible all-present equal branch values before fallback preparation.
No implementation, corpus/profile/retry, resource change or paid call is authorized.
The invalid old-root profile and V49 preparation failure remain preserved; this
passes current diagnostic attribution only. Original native/fresh failures remain.
Product retains tested `6e4fd67`: 2,384 tests / 36 skips locally and in all 12 hosted
suites, 29 normal jobs and docs passed; combined coverage 89.98%, branch-only
85.85%. All **265 requirements** remain. **Phase 22 is incomplete**; explicit
human acceptance is separate. Git stays 312/1,040 incomplete, paid benchmark and
pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state, release, outreach or Phase 23.

'''
    path.write_text(first+'\n\n'+status+rest)
write('owning-docs.json',{'sha256':{n:sha(ROOT/n) for n in docs}})
print('Retained265requirements and16owning docs; valid partial attribution, no native/acceptance pass, source-only proposal unapproved.')
