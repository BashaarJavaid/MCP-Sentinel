"""Verify final runner boundaries and reconcile corrections before sealing."""
import copy
import hashlib
import importlib.util
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import patch

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('fresh_v6_final',OUT/'runner.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
proposal=m.verify_packet();m.selfcheck()
try:m.approved()
except FileNotFoundError:pass
else:raise AssertionError('Missing approval accepted')
with patch.object(m,'original_group_exists',side_effect=PermissionError),patch.object(m.subprocess,'check_output',return_value='11 123 S\n12 124 Z\n'):
    assert m.group_exists(123)
    assert not m.group_exists(124)
    assert not m.group_exists(125)
with patch.object(m,'original_group_exists',side_effect=PermissionError),patch.object(m.subprocess,'check_output',return_value='malformed'):
    try:m.group_exists(123)
    except AssertionError:pass
    else:raise AssertionError('Malformed process status accepted')
with patch.object(m,'original_group_exists',side_effect=PermissionError),patch.object(m.subprocess,'check_output',side_effect=subprocess.CalledProcessError(1,'ps')):
    try:m.group_exists(123)
    except subprocess.CalledProcessError:pass
    else:raise AssertionError('Unreadable process status accepted')
assert json.loads((OUT/'supervisor-checks-final/selfcheck.json').read_text())['passed']
assert json.loads((OUT/'preflight.json').read_text())['passed']
assert not (OUT/'evaluation-authorization.json').exists()
assert not (OUT/'execution-consumed.json').exists()
for name,d in json.loads((OUT/'staging-files.json').read_text()).items():assert sha(ROOT/name)==d,name
quality_inputs=['src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile','README.md','CHANGELOG.md','LICENSE']
assert not subprocess.check_output(['git','diff','439c3fe','--',*quality_inputs])
record={'passed':True,'recorded_at':datetime.now(timezone.utc).isoformat(),'proposal_sha256':sha(OUT/'evaluation-proposal.json'),'runner_sha256':sha(OUT/'runner.py'),'initial_preflight_exit':1,'corrected_preflight_exit':0,'initial_synthetic_supervisor_exit':1,'permitted_synthetic_supervisor_exit':1,'corrected_synthetic_supervisor_exit':0,'supervisor_checks':{'path':'supervisor-checks-final/selfcheck.json','sha256':sha(OUT/'supervisor-checks-final/selfcheck.json')},'observed_group_fallback':json.loads((OUT/'supervisor-checks-final/darwin-group-checks.json').read_text()),'interpretation':'Corrected orphan control observed an absent process group after EPERM; no live process was ignored. The cause of earlier EPERM is not independently established. Separate mock checks reject live, malformed and unreadable state. Adopted zombie handling is explicitly disclosed in the local proposal.','byte_identical_quality_inputs':quality_inputs,'tested_workflow':'439c3fe658d30ebbc6cf6e21296261a38a6a3e92','native_observations':0,'comparator_observations':0,'paid_calls':0,'target_execution':False,'source_preparation_commands':{'freeze.py':0,'download.py':0,'prepare.py':0,'prepare-runner.py':0,'propose.py':0,'correct-preparation.py':0,'correct-supervisor.py':0,'reconcile.py':0},'log_storage':'prepare.log, both preflight logs and all three supervisor logs are retained; other source-preparation stdout/exits are retained in tool transcript, not invented standalone log files.','files_sha256':{p.name:sha(p) for p in OUT.glob('*.py')}}
p=OUT/'preparation-final.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
path=OUT/'audit.json';old=OUT/'audit-before-runner-correction.json';assert not old.exists();path.rename(old)
audit=json.loads(old.read_text())
audit['runner_preparation_final']=record
audit['references_sha256']['artifacts/phase22/integration/v32-fresh-v6/evaluation-proposal.json']=sha(OUT/'evaluation-proposal.json')
audit['references_sha256']['artifacts/phase22/integration/v32-fresh-v6/preparation-final.json']=sha(OUT/'preparation-final.json')
for row in audit['additional_scope_requirements']:
    if row['id']=='V32-FRESH-PREPARATION':
        row['evidence'].append('v32-fresh-v6/preparation-final.json')
        row['assessment']+=' Synthetic cleanup also exposed macOS killpg EPERM; both failures and unapproved draft revisions are preserved. Final local runner fallback and live/malformed/unreadable-state controls pass without target observations.'
path.write_text(json.dumps(audit,indent=2)+'\n')
print('Final source-only controls pass; all preparation failures preserved; zero corpus observations.')
