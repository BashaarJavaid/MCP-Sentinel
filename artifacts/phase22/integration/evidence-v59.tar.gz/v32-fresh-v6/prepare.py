"""Prepare and validate a new source-only pair using the existing corpus contract."""
import ast
import copy
import difflib
import gzip
import io
import ipaddress
import json
import re
import subprocess
import tarfile
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from scripts import phase20_measurements as h
from scripts.phase20_corpus import archive_files, digest, input_files, materialize, tree_digest
from scripts.phase20_corpus import validate as validate20
from scripts.phase22_corpus import validate

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = ROOT/'artifacts/phase22/corpus-replacement-v6'
REPO = 'isyuricunha/mcp-ddg-research'
FAMILY = 'ddg-cgnat'
FREEZE = OUT/'scope-and-precuration-freeze.json'


def ref(p):
    return {'path': p.relative_to(ROOT).as_posix(), 'sha256': digest(p.read_bytes())}


def save(p, obj):
    assert not p.exists(), p
    p.write_text(json.dumps(obj, indent=2)+'\n')
    return ref(p)


freeze = json.loads(FREEZE.read_text())
actual = h.scanner_identity()
assert actual['source_sha256'] == freeze['scanner']['source_sha256']
assert actual['harness_sha256'] == freeze['scanner']['harness_sha256']
assert not subprocess.check_output(['git','diff','439c3fe','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github'])
oldpath = ROOT/'artifacts/phase22/corpus-replacement-v5/manifest.json'
old = json.loads(oldpath.read_text())
inventory = json.loads((OUT.parent/'v23-fresh-v4/prior-source-exclusion-inventory.json').read_text())
manifests = inventory['manifests']+[{'path':str(oldpath.relative_to(ROOT)), 'sha256':digest(oldpath.read_bytes())}]
prior, repositories = {}, set()
for row in manifests:
    p = ROOT/row['path']
    assert digest(p.read_bytes()) == row['sha256']
    m = validate20(p) if p.suffix == '.yaml' else validate(p)
    snapshots = {s.revision:s for s in m.snapshots}
    for item in m.inputs:
        repositories.add(item.repository.casefold())
        if item.tree_sha256 not in prior:
            prior[item.tree_sha256] = {n:digest(b) for n,b in input_files(item,snapshots[item.snapshot]).items()}
repositories.add('cyanheads/git-mcp-server')  # Earlier source-inspected, rejected research candidate.
assert REPO.casefold() not in repositories
metadata = json.loads((BASE/'provenance/repository.json').read_text())
assert metadata['full_name'].casefold() == REPO.casefold() and not metadata['fork']
downloads = json.loads((BASE/'provenance/downloads.json').read_text())['rows']
trees, snapshots = {}, []
for row in downloads:
    p = ROOT/row['archive']
    assert digest(p.read_bytes()) == row['sha256']
    files = archive_files(p.read_bytes(),strip_root=True)
    assert b'GNU AFFERO GENERAL PUBLIC LICENSE' in files['LICENSE']
    assert tree_digest(files) == row['tree_sha256']
    trees[row['label']] = files
    snapshots.append({'repository':REPO,'revision':row['revision'],'url':row['url'],'archive':ref(p),'licenses':['LICENSE'],'files':{n:digest(b) for n,b in files.items()}})
hashes = set(d for files in prior.values() for d in files.values())
overlap = {label:{n:digest(b) for n,b in files.items() if digest(b) in hashes} for label,files in trees.items()}
assert all(tree_digest(f) not in prior for f in trees.values())
assert not any(n.endswith(('.py','.ts','.js','.tsx','.jsx')) for files in overlap.values() for n in files)
novelty = save(BASE/'provenance/novelty.json', {'passed':True,'pre_curation_freeze':ref(FREEZE),'prior_manifests':manifests,'prior_effective_trees_checked':len(prior),'excluded_repositories':sorted(repositories),'repository_absent':True,'github_fork':False,'whole_tree_matches':0,'source_file_matches_any_prior_path':0,'other_file_overlap':overlap,'qualification':'Novel relative to retained project corpora and source inspection; not proof of model training-data absence, independent human review, or a novel vulnerability concept.'})
a,b = trees['vulnerable'],trees['fixed']
changed = sorted(n for n in a.keys()|b.keys() if a.get(n) != b.get(n))
diff = ''.join(''.join(difflib.unified_diff(a.get(n,b'').decode().splitlines(True),b.get(n,b'').decode().splitlines(True),fromfile='vulnerable/'+n,tofile='fixed/'+n)) for n in changed)
(BASE/'provenance/full-pair.diff').write_text(diff)
security = 'src/mcp_ddg_research/security.py'
flags = ['is_private','is_loopback','is_link_local','is_reserved','is_multicast','is_unspecified']
literal_checks = {}
for label,files in trees.items():
    tree = ast.parse(files[security])
    networks = [ipaddress.ip_network(ast.literal_eval(n.args[0])) for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='ip_network']
    literal_checks[label] = {host:{'network_match':any(ipaddress.ip_address(host) in net for net in networks),'stdlib_flags':{f:getattr(ipaddress.ip_address(host),f) for f in flags}} for host in ['100.100.200.200','8.8.8.8']}
assert not literal_checks['vulnerable']['100.100.200.200']['network_match']
assert literal_checks['fixed']['100.100.200.200']['network_match']
assert all(not any(c['stdlib_flags'].values()) for rows in literal_checks.values() for c in rows.values())
assert all(not rows['8.8.8.8']['network_match'] for rows in literal_checks.values())
condition = 'The registered web_fetch tool rejects initial http://100.100.200.200/ in shared address space 100.64.0.0/10 before issuing an outbound HTTP request.'
prerequisites = [
    'Run the unmodified upstream stdio entrypoint, python -m mcp_ddg_research.server, with Python3.12 and compatible official MCP SDK1.x/Pydantic2/httpx dependencies. Registration, imports and ordinary startup succeed. No evaluator entrypoint, wrappers or target execution.',
    'Invoke web_fetch with url=http://100.100.200.200/ and default max_chars=12000. The declared nonempty-string schema admits this literal; no target environment, proxy, DNS override or source monkeypatch is applied.',
    'For the vulnerable onward request, the system resolver returns the same literal address, the fetch cache misses, cache access and HTTP client construction succeed, and no external egress policy blocks it. These are explicit unexecuted prerequisites, not runtime observations.',
    'On Python3.12, this shared-space address has none of the six tested ipaddress flags. It is absent from the vulnerable explicit networks and present in the fixed explicit 100.64.0.0/10 entry. Fixed validate_url_shape raises before resolution, cache access or HTTP creation.',
    'This condition covers initial literal destination rejection only. DNS rebinding, redirects, response contents, cloud credentials, live network reachability and other tools are outside the label. No complete SSRF protection or runtime exploit proof is claimed.',
]
(BASE/'review').mkdir()
(BASE/'mutations').mkdir()
roles = {security:'Complete URL shape, address classification, explicit networks and resolver guards.', 'src/mcp_ddg_research/server.py':'Official FastMCP registration, web_fetch forwarding, stdio startup and unchanged optional HTTP paths.', 'src/mcp_ddg_research/fetch.py':'FetchRequest validation, pre-cache guard, cache miss, client and per-hop request flow.', 'src/mcp_ddg_research/models.py':'Caller schema and FetchRequest string/max_chars constraints.', 'pyproject.toml':'Actual source package version, Python minimum and dependency declarations.'}
def evidence(files):
    return [{'path':n,'start_line':1,'end_line':len(files[n].splitlines()),'sha256':digest(files[n]),'role':role} for n,role in roles.items()]
inputs, mutations = [], []
for row in downloads:
    label = row['label']; files = trees[label]
    item = {**copy.deepcopy(old['inputs'][-5]),'id':FAMILY+'-'+label,'family':FAMILY,'repository':REPO,'snapshot':row['revision'],'label':label,'condition':condition,'prerequisites':prerequisites,'evidence':evidence(files),'tree_sha256':tree_digest(files),'scan_root':'.'}
    inputs.append(item)
    oldsym,newsym = b'_normalize_hostname',b'_canonical_hostname'
    assert files[security].count(oldsym)==3 and newsym not in files[security]
    notice = b'# Modified by the Sentinel evaluation curator on 2026-09-11: local helper rename only.\n# This source remains under the upstream GNU AGPL v3 license; see LICENSE.\n'
    modified = notice+re.sub(rb'\b_normalize_hostname\b',newsym,files[security])
    assert modified.removeprefix(notice).replace(newsym,oldsym)==files[security]
    overlay = BASE/f'mutations/{label}-helper-rename.tar.gz'
    with overlay.open('wb') as stream, gzip.GzipFile(fileobj=stream,mode='wb',mtime=0,filename='') as gz, tarfile.open(fileobj=gz,mode='w') as tar:
        info=tarfile.TarInfo(security);info.size=len(modified);info.mode=0o644;tar.addfile(info,io.BytesIO(modified))
    assert archive_files(overlay.read_bytes(),strip_root=False)=={security:modified}
    mutated={**files,security:modified}
    transformation='Rename _normalize_hostname and its two calls to _canonical_hostname. Add dated modification/license comment; removing that notice and reversing all three identifiers exactly restores original bytes. No runtime semantics change.'
    inputs.append({**copy.deepcopy(item),'id':item['id']+'-mutation','variant':'mutation','parent':item['id'],'overlay':ref(overlay),'transformation':transformation,'tree_sha256':tree_digest(mutated),'evidence':evidence(mutated)})
    mutations.append({'label':label,'overlay':ref(overlay),'transformation':transformation,'reverse_verified':True})
inputs.append({**copy.deepcopy(inputs[2]),'id':'ddg-public-safe','variant':'safe_control','label':'safe','condition':'The fixed web_fetch initial destination policy permits public literal http://8.8.8.8/ without classifying it as restricted shared address space.','prerequisites':[prerequisites[0], 'Same fixed source and initial-literal prerequisites with url=http://8.8.8.8/. Only initial policy classification is evaluated; no service availability or successful fetch claim.']})
review = save(BASE/'review/condition-review.json', {'reviewer':'Same implementation agent, source inspected only after immutable f85a90f freeze.','freeze':ref(FREEZE),'condition':condition,'prerequisites':prerequisites,'source_flow':'server.web_fetch -> perform_web_fetch alias -> fetch.web_fetch -> FetchRequest -> validate_fetch_url -> validate_url_shape -> is_unsafe_ip; vulnerable continues via cache miss -> _get_with_validated_redirects -> validate_fetch_url -> client.get. Fixed rejects the literal in the first validate_url_shape call.','literal_checks':literal_checks,'source_only_check':'AST-read constant network strings plus local stdlib ipaddress operations; no target imports/functions, resolver, scanner or comparator run.','mutations':mutations,'correlation':'One previously unused repository and one upstream shared-address-space exclusion, with two correlated renames and one fixed-tree control.','dependency_scope':'Both source versions declare0.5.1 and Python>=3.12. Vulnerable dependencies are unpinned. Fixed pins minimums and mcp>=1.27.2,<2, and adds requirements-lock.txt with mcp1.30.0/httpx0.28.1/Pydantic2.13.5. Runtime compatibility is a prerequisite, not an executed result.','other_fix_changes':changed,'limitations':'The upstream commit also changes DNS pinning, body caps, cache handling, search, HTTP authentication and tool annotations. Complete sources/diff retained. These are not separate evaluated vulnerabilities; no guarantee of detector support or detection.','scans':0,'paid_calls':0})
comparison=save(BASE/'provenance/pair-comparison.json',{'vulnerable_revision':downloads[0]['revision'],'fixed_revision':downloads[1]['revision'],'direct_parent':True,'changed_files':changed,'full_diff':ref(BASE/'provenance/full-pair.diff'),'projection':'None: complete23/25-file upstream archives including licenses, tests and configuration. Target files are never executed.','review':review})
manifest=copy.deepcopy(old)
manifest['methodology']='Replacement-v6: new project-unseen repository selected on public upstream source evidence after frozenf85a90f, without detector results. Retain45 old records exactly; evaluate only five new records. One correlated vulnerability; same-agent source review, no independent-human or model-training-data claim.'
manifest['snapshots']+=snapshots
manifest['inputs']=old['inputs'][:45]+inputs
manifest['pairs']=[*old['pairs'][:-1],{'id':FAMILY,'rule_id':'SENT-015','fix_origin':'upstream','provenance':[comparison,review,novelty],'review':'Source-bound shared-address-space initial URL exclusion; no prior evaluation.'}]
manifest['packet'] += [ref(p) for folder in ['provenance','review','mutations'] for p in sorted((BASE/folder).iterdir()) if p.is_file()]
manifest['repository_aliases'][REPO.casefold()]=REPO
manifestref=save(BASE/'manifest.json',manifest)
m=validate(BASE/'manifest.json');assert manifest['inputs'][:45]==old['inputs'][:45]
configs={};sources={s.revision:s for s in m.snapshots}
for item in m.inputs[-5:]:
    with tempfile.TemporaryDirectory(prefix='phase22-v6-source-only-') as tmp:
        target=materialize(item,sources[item.snapshot],Path(tmp).resolve()/'source',m.packet)
        config=h.load_configuration(target,environ={},static_only=True,cli_overrides={'rules_only':True,'ignore_paths':['.phase20/**'],'max_findings_per_scan':500},llm_cli_overrides={'model':h.LLM.model,'reasoning_effort':'medium','retries':0,'max_concurrency':1,'cache_enabled':False})
        payload={'scanner':config.scanner.model_dump(mode='json'),'target':config.target.model_dump(mode='json') if config.target else None,'static_only':config.static_only,'language':config.language.value}
        configs[item.id]={'configuration':payload,'sha256':digest((json.dumps(payload,indent=2,sort_keys=True)+'\n').encode())}
configref=save(BASE/'configurations.json',configs)
checkpoint=save(BASE/'checkpoint-f85a90f.json',{'status':'prepared_pending_explicit_evaluation_approval','manifest':manifestref,'configuration':configref,'scanner_identity':freeze['scanner'],'pre_curation_freeze':ref(FREEZE),'new_input_ids':[i['id'] for i in inputs],'unchanged_input_records':45,'novelty':novelty,'review':review,'source_archives':[s['archive'] for s in snapshots],'harness_and_lock_sha256':{n:digest((ROOT/n).read_bytes()) for n in ['uv.lock','scripts/phase20_corpus.py','scripts/phase22_corpus.py','scripts/phase20_measurements.py','scripts/phase20_scoring.py','scripts/prepare_phase20_semgrep.py','artifacts/phase20/semgrep-preparation.json']},'freeze_approved':False,'scanner_evaluation':False,'comparator_evaluation':False,'target_execution':False,'model_calls':0})
save(BASE/'preparation.json',{'passed':True,'manifest':manifestref,'checkpoint':checkpoint,'configuration':configref,'all50_records_validated':True,'unchanged45_records_exact':True,'five_source_only_materializations_and_configurations':True,'novelty':novelty,'prepared_files_sha256':{p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in BASE.rglob('*') if p.is_file()},'observations':0,'paid_calls':0,'target_execution':False})
print(f'Prepared five inputs; validated50 manifest records and {len(prior)} prior unique trees; zero observations.')
