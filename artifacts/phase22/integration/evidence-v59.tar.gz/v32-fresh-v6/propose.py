"""Bind a reviewable prospective evaluation; this file grants no execution authority."""
import json
from pathlib import Path
from datetime import datetime, timezone
from scripts.phase20_corpus import digest

ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent
BASE=ROOT/'artifacts/phase22/corpus-replacement-v6'
def ref(p):
    return {'path':p.relative_to(ROOT).as_posix(),'sha256':digest(p.read_bytes())}
def save(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,indent=2)+'\n')

manifest=json.loads((BASE/'manifest.json').read_text())
staging={}
def visit(x):
    if isinstance(x,dict):
        if set(x)=={'path','sha256'}:
            p=ROOT/x['path']
            assert digest(p.read_bytes())==x['sha256']
            assert x['path'].startswith('artifacts/phase22/'),x['path']
            staging[x['path']]=x['sha256']
        else:
            for value in x.values():visit(value)
    elif isinstance(x,list):
        for value in x:visit(value)
visit(manifest)
for p in BASE.rglob('*'):
    if p.is_file():staging[p.relative_to(ROOT).as_posix()]=digest(p.read_bytes())
save(OUT/'staging-files.json',staging)
freeze=json.loads((OUT/'scope-and-precuration-freeze.json').read_text())
old=json.loads((ROOT/'artifacts/phase22/corpus-replacement-v5/evaluation-proposal.json').read_text())
rubric={
 'status':'prospectively_frozen_before_any_evaluation',
 'condition':'Initial web_fetch literal http://100.100.200.200/ rejection before outbound HTTP; fixed public control is http://8.8.8.8/.',
 'matching':'Source-adjudicate exact native findings and comparator results against the registered web_fetch caller argument, actual HTTP flow and missing/effective shared-space boundary. A rule ID, generic file overlap, warning, unrelated request or unresolved coverage alone is not a detection. Bind every matched dedup_key and rationale to full actual reports and source lines.',
 'negatives':'Use the same rule for fixed and safe inputs. A retained assertion that the named destination can cross the boundary counts as an alert unless the report correctly qualifies/excludes this destination. Do not excuse a fixed alert merely because upstream is labeled fixed. Generic candidates unrelated to this exact condition remain separately assessed and visible; source knowledge alone is not detector recognition of the fix.',
 'required_native_result':{'complete_inputs_per_batch':5,'vulnerable_condition_hits_per_batch':2,'matching_fixed_or_control_alerts_per_batch':0,'ordered_repeat_equal_inputs':5,'batches':2},
 'all_results':'Assess every finding, warning, unresolved flow and surface; preserve support/completion denominators, misses, false alerts and timing. JSON/SARIF must validate. Assessment cannot tune the frozen scanner, inputs, labels or rubric.',
 'comparator':'Same five materialized inputs, pinned Semgrep1.176.0/533 rules; source-bound scoring and actual outcomes. Comparative success is not a prerequisite, and no superiority claim follows.',
 'freshness':'One previously unused repository held out from scanner tuning after f85a90f freeze. Two vulnerable variants are correlated, not two independent discoveries. Same implementation agent curated source; no independent human review or model-training-data absence claim.',
 'failure':'A first-frozen miss, matching negative alert or incomplete result does not satisfy the user\'s new acceptance prerequisite. A later same-source repair/regression cannot turn this attempt into an unseen-source success. Preserve all outcomes; any further work needs a concrete separate decision.'
}
save(OUT/'scoring-rubric.json',rubric)
save(OUT/'selection-record.json',{
 'recorded_at':datetime.now(timezone.utc).isoformat(),
 'precuration_freeze':ref(OUT/'scope-and-precuration-freeze.json'),
 'searches':['Public web search for MCP SSRF upstream advisories/fixes; already used servers/Atlassian/auth-fetch/open-webSearch/SearXNG excluded; SDK/client/Go/Deno cases are outside the source-server pair scope.','GitHub public commit search q=SSRF mcp, per_page=50, sort=author-date; full response retained.'],
 'search_response':ref(OUT/'ssrf-commit-search.json'),
 'selected_repository':'isyuricunha/mcp-ddg-research',
 'selection_reason':'The first newly inspected upstream source fix in this search with a Python MCP server source pair and a source-established initial-address restriction change. Chosen from source evidence before any detector execution. Recent preceding metadata included dependency-only commits and a browser guard false-positive fix, not the requested missing-boundary pair.',
 'condition_choice':'Within the upstream multi-part security fix, use its explicit100.64.0.0/10 addition because initial literal classification has a source-established contrast without runtime DNS assumptions. DNS pinning, HTTP authentication and body/cache changes remain present and disclosed, not separate labels.',
 'preexisting_text_search':'rg --hidden --no-ignore over prior src/tests/scripts/docs and Phase20/22 JSON/Markdown/Python, excluding only newv32/v6 and evidence index files, found no repository/name reference (exit1/no matches).',
 'old_source_inspected_candidate_excluded':'cyanheads/git-mcp-server',
 'scanner_or_comparator_previews':0,'paid_calls':0,
})
files={p.relative_to(ROOT).as_posix():digest(p.read_bytes()) for p in [*BASE.rglob('*'),OUT/'scope-and-precuration-freeze.json',OUT/'runner.py',OUT/'staging-files.json',OUT/'scoring-rubric.json',OUT/'selection-record.json',OUT.parent/'v20-linux-diagnostic-v1/runner.py'] if p.is_file()}
proposal={
 'status':'prepared_not_approved_not_executed',
 'recorded_at':datetime.now(timezone.utc).isoformat(),
 'decision_requested':'Approve exactly one local macOS first-frozen evaluation of replacement-v6 atf85a90f: ten native observations and five pinned Semgrep observations, without tuning or paid calls. This is not Phase22 technical acceptance.',
 'scanner':freeze['scanner'],'lock_sha256':freeze['lock_sha256'],
 'checkpoint':ref(BASE/'checkpoint-f85a90f.json'),'manifest':ref(BASE/'manifest.json'),'configuration':ref(BASE/'configurations.json'),
 'pre_curation_freeze':ref(OUT/'scope-and-precuration-freeze.json'),'source_only_authorization':ref(OUT/'scope-and-precuration-freeze.json'),
 'condition_review':ref(BASE/'review/condition-review.json'),'novelty':ref(BASE/'provenance/novelty.json'),'scoring_rubric':ref(OUT/'scoring-rubric.json'),
 'comparator_preparation':old['comparator_preparation'],'comparator':old['comparator'],
 'input_order':[i['id'] for i in manifest['inputs'][-5:]],'batch_order':['rules-first','rules-repeat','semgrep-first'],
 'bounds':{'local_sequences':1,'hosted_dispatches':0,'native_observations':10,'comparator_observations':5,'normal_target_seconds':120,'native_and_whole_input_maximum_seconds':300,'comparator_and_whole_input_maximum_seconds':300,'cleanup_maximum_seconds_per_input':15,'sequence_maximum_minutes':90,'internal_stop_minutes':88,'profiles':0,'retries':0,'paid_calls':0,'target_execution':False,'target_dependency_installation':False,'detector_changes':0},
 'environment':'Existing local macOS host and /Users/bashaarjavaid/Projects/MCP-Sentinel/.venv Python3.12.13. Execute in immutable /private/tmp/mcp-phase22-frozen-f85a90f using isolated child imports. Record actual Python/packages/CPU/memory/load. Reuse byte-verified local /private/tmp/phase20-community-rules. No procurement, paid resources or hosted dispatch. This explicitly proposes local execution for the new detection gate; historical Linux timing results retain their original identities.',
 'commands_after_approval':[
  'Write a new exact evaluation-authorization.json and binding.json using the actual user decision and final proposal/runner/source identities; do not edit this prepared proposal.',
  'Source-only runner stage from the frozen checkout copies only absent hash-bound artifact files; mismatches stop. Reverify scanner/harness/lock and Semgrep rules before measurements.',
  'From the frozen checkout: /Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python -I /private/tmp/mcp-phase22-options/artifacts/phase22/integration/v32-fresh-v6/runner.py run <new-unique-output-directory> /private/tmp/phase20-community-rules',
  'After the one sequence ends, source-assess every report and reconcile the gate against the prospectively frozen rubric. Preserve raw reports, logs, all attempts and closed unstarted budget.'
 ],
 'stop':'First infrastructure, timeout, identity/configuration/schema/cleanup or ordered-repeat failure closes all unused observations. Do not start a child with less than315seconds before the internal deadline. Detection misses/false alerts remain outcomes: collect remaining authorized observations without tuning, retries or candidate replacement. End after15. One execution-consumed receipt prevents another sequence.',
 'safety':'Rules-only/static-only with model transport forbidden and OPENAI_/SENTINEL_ credentials removed. No upstream target imports/functions/tests/builds/dependency installs/browser/network requests; normal static source reads only. No old budgets reopened.',
 'acceptance_gate':'User now requires first-frozen unseen-repository detection and vulnerable/fixed discrimination under the attached rubric before another technical acceptance request. Git campaigns stay312/1040 incomplete as the retained limitation; paid benchmark/pilots remain deferred. All original failures remain historical evidence.',
 'files_sha256':files,'technical_acceptance_received':False,'phase22_complete':False
}
save(OUT/'evaluation-proposal.json',proposal)
print('Exact proposed15-observation local scope bound; evaluation remains unapproved.')
