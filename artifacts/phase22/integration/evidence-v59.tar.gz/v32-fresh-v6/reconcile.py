"""Record the new acceptance prerequisite without rewriting historical evidence."""
import copy
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path.cwd(); OUT=Path(__file__).resolve().parent; BASE=OUT.parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((OUT/'preflight.json').read_text())['passed']
prior=BASE/'v31-compatibility/audit.json'
audit=json.loads(prior.read_text())
audit['prior_audit']={'path':prior.relative_to(BASE).as_posix(),'sha256':sha(prior)}
audit['recorded_at']=datetime.now(timezone.utc).isoformat()
status='User requires detection on another previously unused repository before Phase22 acceptance. Replacement-v6 source-only preparation and96-tree novelty checks pass at frozenf85a90f. Exact15-observation local proposal is unapproved and unexecuted. Git312/1040 stays incomplete as the retained limitation; no new Git work. Original fresh misses, all historical failures, current64 exposed/compatibility observations and paid/pilot deferrals remain unchanged.'
audit['status']=status
for row in audit['requirements']:
    row['interpretation']=status
    if row['id'] in {'R66','R88','R84'}:
        row['prior_v31_assessment']=copy.deepcopy({k:row[k] for k in ['disposition','assessment']})
        row['disposition']='unresolved'
        row['assessment']=('User has not accepted technical completion. The earlier request is superseded by the new fresh detection prerequisite; return for acceptance only after an approved first-frozen demonstration and final packet.' if row['id']=='R84' else 'First-frozen detection on another previously unused repository is now an explicit acceptance prerequisite. Preserve original1f3f72f Lighthouse misses and later exposedf85a90f passes. The newf85a90f DDG pair is source-prepared, novel across seven prior manifests/96trees, but has zero observations and requires exact evaluation approval. Same-source tuning cannot satisfy this gate.')
        row['evidence'] += ['artifacts/phase22/integration/v32-fresh-v6/scope-and-precuration-freeze.json','artifacts/phase22/integration/v32-fresh-v6/evaluation-proposal.json']
audit['additional_scope_requirements'] += [
 {'id':'V32-GIT-SCOPE','requirement':'Retain incomplete Git coverage without reopening its campaigns','disposition':'passed','evidence':['v32-fresh-v6/scope-and-precuration-freeze.json'],'assessment':'Actual user instruction leaves Git runtime coverage as recorded312/1040 incomplete. This is a limited scope decision, not Phase22 acceptance or completed coverage.'},
 {'id':'V32-FRESH-PREPARATION','requirement':'Freeze current scanner before new source selection; prepare a licensed novel pair, source labels and bounded reviewable proposal with zero scans','disposition':'passed','evidence':['v32-fresh-v6/scope-and-precuration-freeze.json','../corpus-replacement-v6/preparation.json','v32-fresh-v6/preflight.json','v32-fresh-v6/scoring-rubric.json'],'assessment':'Immutablef85a90f source; complete23/25-file DDG upstream pair;96 prior unique trees checked, no source file matches; five configurations/materializations validated. Initial missing comparator directory failed preflight, preserved and corrected to the existing byte-verified511-rule-config directory. No target/scanner/comparator execution.'},
 {'id':'V32-FRESH-DETECTION','requirement':'After exact approval, demonstrate detection on the new first-frozen repository with fixed/control discrimination, repeats and complete source assessments before technical acceptance','disposition':'unresolved','evidence':['v32-fresh-v6/evaluation-proposal.json','v32-fresh-v6/scoring-rubric.json'],'assessment':'No evaluation approval or observation yet. Proposed local sequence10native+5Semgrep;120target/300maximum, no retries or paid calls. No outcome is predicted.'},
]
assert len(audit['requirements'])==89 and len(audit['additional_scope_requirements'])==86
assert len({r['id'] for r in audit['additional_scope_requirements']})==86
audit['dispositions']=dict(Counter(r['disposition'] for r in audit['requirements']))
audit['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in audit['additional_scope_requirements']))
audit['acceptance_packet_ready']=False
audit['technical_acceptance_requested']=False
audit['technical_acceptance_request_history']='The v31 acceptance request was delivered; user required an additional unseen-repository detection gate rather than accepting it.'
audit['technical_acceptance_received']=False
audit['phase22_complete']=False
audit['new_paid_calls']=0
audit['new_fresh_v6_evaluation_approved']=False
audit['new_fresh_v6_evaluation_executed']=False
audit['new_fresh_v6_observations']=0
audit['fresh_evaluation_status_basis']='Existing true approval/execution fields refer only to originalv5 at1f3f72f. Newv6 atf85a90f has separate false fields; no old budget is reused.'
audit['full_sequence_status_basis']='Historical approved1f3f72f whole-batch evidence; currentf85a90f partial compatibility passes its approved54-observation scope and source-only Python compatibility proof.'
audit['owning_document_binding']='Finalv32 documentation binding follows all current owning-doc edits; old per-file hashes remain historical.'
for p in [OUT/'scope-and-precuration-freeze.json',OUT/'evaluation-proposal.json',OUT/'scoring-rubric.json',OUT/'preflight.json',ROOT/'artifacts/phase22/corpus-replacement-v6/preparation.json']:
    audit['references_sha256'][str(p.relative_to(ROOT))]=sha(p)
(OUT/'audit.json').write_text(json.dumps(audit,indent=2)+'\n')
text='''The user requires **detection on another previously unused repository before
Phase 22 technical acceptance**. Git runtime campaigns stay incomplete at
**312/1,040** as the retained limitation; no additional Git work is planned.
The earlier v31 acceptance packet is preserved and its readiness is superseded.

Replacement-v6 prepares **isyuricunha/mcp-ddg-research** at immutable scanner
**`f85a90f`**, frozen before new source research. Novelty checks cover seven prior
manifests and **96 unique source trees**, with no matching source files. The
upstream pair changes initial rejection of `http://100.100.200.200/` in shared
address space. Complete source archives, prerequisites, two correlated helper
renames and a fixed-tree public control are retained. Source review is by the
same implementation agent after freeze; no independent human review is claimed.

`artifacts/phase22/integration/v32-fresh-v6/evaluation-proposal.json` is
**unapproved and unexecuted**: one local macOS sequence, **10 native + 5 Semgrep
observations**, 120-second target, 300-second whole-input maximum, 90-minute
sequence cap, no retries, target execution or paid calls. The prospective native
gate requires both vulnerable hits and zero matching alerts on three negatives
in each five-input batch, plus all five ordered repeats. A later repair on this
same source cannot become an unseen-source success. Existing measurements and
all original failures remain unchanged.

The audit is **84 passed, two user-deferred and three unresolved**, plus
86 added rows: **80 passed, five proposed historical limitations awaiting
decision and one unresolved**. **Phase 22 remains incomplete**. Exact evaluation
approval, actual detection/source assessment, explicit human acceptance and
verified closeout delivery remain. Paid benchmark/pilots stay deferred;
Phase 21 remains incomplete and Phase 24/15 gates are unchanged.
'''
(OUT/'summary.md').write_text('# New fresh detection prerequisite and evaluation proposal\n\n'+text)
names=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','docs/phase22-timeout-policy.md','docs/phase22-corpus-review.md','artifacts/phase22/integration/requirements.md','artifacts/phase22/integration/progress.md','artifacts/phase22/integration/README.md']
for name in names:
    p=ROOT/name;s=p.read_text();level='###' if name=='ROADMAP.md' else '##'
    marker=level+' Current technical acceptance checkpoint'
    assert s.count(marker)==1,(name,s.count(marker))
    s=s.replace(marker,level+' Current fresh detection prerequisite\n\n'+text+'\n'+level+' Historical v31 technical acceptance checkpoint',1)
    s=s.replace('replacement-v4 freshness failed; valid fresh evaluation and acceptance pending','new unseen-repository detection required; replacement-v6 prepared, evaluation and acceptance pending')
    p.write_text(s)
p=ROOT/'ARCHITECTURE.md';s=p.read_text();old='All current technical gates are ready for explicit human acceptance; Phase 22 remains\nincomplete until that decision and closeout delivery.'
assert old in s
s=s.replace(old,'The user now requires first-frozen detection on another previously unused repository\nbefore technical acceptance. Replacement-v6 is prepared at immutable `f85a90f`;\nits exact evaluation remains unapproved and unexecuted. Git runtime coverage stays\n312/1,040 incomplete. Phase 22 awaits this new gate, acceptance and closeout delivery.')
p.write_text(s)
readme='''# Replacement-v6: DDG shared-space URL condition

Prepared only; no native/comparator evaluation or target execution.

The complete upstream AGPL v3 source archives are retained verbatim with their
licenses and notices. The two mutation overlays rename one local helper and its
two calls; each changed file carries a dated modification/license notice. These
are evaluation source assets, not code incorporated into the Sentinel package.

Upstream repository: https://github.com/isyuricunha/mcp-ddg-research
Direct vulnerable parent: `97d3c6c511946be4dee99de0bfce82dbf3eb8687`.
Fixed child: `cf0a415758ce156f42db1dd48ec09663d0a21fd2`.
Both package versions say 0.5.1; labels bind exact source, not a patched release.

See `review/condition-review.json` for the complete flow, dependency prerequisites,
literal-address checks and unrelated upstream changes. See `provenance/novelty.json`
for the seven-manifest/96-tree exclusion check, `checkpoint-f85a90f.json` for the
source freeze, and `../integration/v32-fresh-v6/evaluation-proposal.json` for the
exact separately approvable scope and prospective scoring rubric.

One repository and one narrow vulnerability, with correlated variants. No target
imports, tests, builds, dependency installation, DNS or HTTP requests occurred.
Current-source detection remains unproven. Earlier misses and exposed regressions
are preserved; a fix after observing this source cannot count as fresh success.
'''
(ROOT/'artifacts/phase22/corpus-replacement-v6/README.md').write_text(readme)
pr=(BASE/'v31-compatibility/pr-body.md').read_text()
(OUT/'pr-body.md').write_text('# Current checkpoint: new fresh detection required\n\n'+text+'\nSee `v32-fresh-v6/summary.md`, `audit.json`, `evaluation-proposal.json` and `scoring-rubric.json` under integration evidence.\n\n## Historical v31 acceptance packet\n\n'+pr)
print('Reconciled89+86 requirements and current owning status; technical acceptance remains pending.')
