"""Record the user's revised gate and scanner identity before new source research."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

from scripts.phase20_measurements import scanner_identity

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
identity = scanner_identity()
assert identity['source_sha256'] == '1d2bac5dd7765af3872aa3c1b7f6d55e7dd371a7b8215b822afc9898546a1ac0'
assert identity['harness_sha256'] == '9bfc9229b7ec7d23580c44f2306edb9274bc1d2a3c2261d01db0445b8b480add'
assert not subprocess.check_output(['git', 'diff', '439c3fe', '--', 'src', 'tests', 'scripts', 'schemas', 'pyproject.toml', 'uv.lock', '.github', 'action.yml', 'Makefile'])
frozen = '/private/tmp/mcp-phase22-frozen-f85a90f'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=frozen)
revision = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=frozen, text=True).strip()
assert revision == 'f85a90f9ba2d1c43019e8505b977d57f3476a9c9'
protected = json.loads((ROOT/'artifacts/phase22/integration/v29-loopback-fix/protected-files.json').read_text())
for name, digest in protected.items():
    assert sha(ROOT/name) == digest
packet = {
    'recorded_at': datetime.now(timezone.utc).isoformat(),
    'user_instruction': 'Git runtime coverage leave this but before I accept we need to demonstrate\n     detection on another unseen repository.',
    'decision': 'Keep incomplete Git runtime coverage as a retained limitation; require a new first-frozen detection demonstration on another previously unused repository before requesting technical acceptance.',
    'technical_acceptance_received': False,
    'prior_acceptance_proposal': {'path': 'artifacts/phase22/integration/v31-compatibility/acceptance-proposal.json', 'sha256': sha(ROOT/'artifacts/phase22/integration/v31-compatibility/acceptance-proposal.json'), 'disposition': 'Superseded readiness: fresh misses alone are not accepted as sufficient for closure.'},
    'delivery_head': identity['revision'],
    'scanner': {**identity, 'revision': revision},
    'lock_sha256': sha(ROOT/'uv.lock'),
    'frozen_worktree': frozen,
    'new_source_research_started': False,
    'authorized_now': 'Source-only selection and preparation of one novel repository pair and a concrete bounded evaluation proposal. Existing exact evaluation checkpoint remains required before measurements.',
    'selection_policy': 'Exclude every prior corpus repository, alias, fork and equivalent source plus previously inspected research candidates. Use primary upstream evidence and licensed complete sources; no selection using detector results. Record exclusions and source review. Freeze scanner, labels and scoring before first evaluation; preserve every outcome. A same-source fix cannot satisfy this new first-frozen detection gate.',
    'freshness_claim': 'Previously unused by this project and withheld from scanner tuning; source reviewed by the same implementation agent only after this freeze. No independent human review, model-training-data absence or broad generalization claim.',
    'planned_pair_count': 1,
    'new_native_observations': 0,
    'new_comparator_observations': 0,
    'new_paid_calls': 0,
    'target_execution': False,
    'phase22_complete': False,
    'protected_files_sha256': protected,
}
path = OUT/'scope-and-precuration-freeze.json'
assert not path.exists()
path.write_text(json.dumps(packet, indent=2)+'\n')
print('Recorded amended acceptance gate and immutable f85a90f freeze before new source research; zero observations.')
