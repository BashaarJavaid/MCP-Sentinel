"""Retain the first cleanup failures and add a bounded macOS process-state fallback."""
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
path=OUT/'runner.py';old=OUT/'runner-before-supervisor-correction.py'
assert not old.exists();path.rename(old)
text=old.read_text()
marker='sha, write = supervisor.sha, supervisor.write\n'
assert text.count(marker)==1
addition='''
# macOS can deny killpg(..., 0) after an orphan is adopted by launchd.
# Verify exact group states instead; live members and unreadable ps fail closed.
DARWIN_GROUP_CHECKS = []
original_group_exists = supervisor.group_exists


def group_exists(pgid):
    try:
        return original_group_exists(pgid)
    except PermissionError:
        if sys.platform != "darwin":
            raise
        rows = subprocess.check_output(["ps", "-axo", "pid=,pgid=,stat="], text=True, timeout=2)
        members = []
        for line in rows.splitlines():
            fields = line.split()
            if not fields:
                continue
            assert len(fields) == 3, "Unexpected process-state record"
            pid, group, state = fields
            if int(group) == pgid:
                members.append({"pid": int(pid), "state": state})
        DARWIN_GROUP_CHECKS.append({"pgid": pgid, "members": members})
        return any(not item["state"].startswith("Z") for item in members)


supervisor.group_exists = group_exists
'''
text=text.replace(marker,marker+addition)
text=text.replace('        packet["budget_closed"] = True','        packet["budget_closed"] = True\n        packet["darwin_group_checks"] = DARWIN_GROUP_CHECKS')
text=text.replace('        if mode == "selfcheck":\n            supervisor.selfcheck(out)\n            selfcheck()','        if mode == "selfcheck":\n            supervisor.selfcheck(out)\n            selfcheck()\n            write(out / "darwin-group-checks.json", DARWIN_GROUP_CHECKS)')
path.write_text(text)
proposal=OUT/'evaluation-proposal.json';previous=OUT/'evaluation-proposal-before-supervisor-correction.json'
assert not previous.exists();proposal.rename(previous)
p=json.loads(previous.read_text())
p['files_sha256'][path.relative_to(Path.cwd()).as_posix()]=hashlib.sha256(path.read_bytes()).hexdigest()
p['environment']+=' On macOS, if killpg existence inspection returns EPERM, inspect exact process-group IDs/states with a two-second ps timeout. Live members remain failures; adopted non-running zombies are disclosed and left for launchd to reap. Direct child is always waited. No scanner or target execution semantics change.'
proposal.write_text(json.dumps(p,indent=2)+'\n')
record={'first_synthetic_check_exit_code':1,'permitted_synthetic_check_exit_code':1,'logs':['supervisor-checks.log','supervisor-checks-permitted.log'],'failure':'Both checks reach the orphan cleanup case and fail because os.killpg(pgid,0) raises PermissionError. This is an execution-environment error, not an automatic approval rejection.','change':'Only the evaluation runner supplies a macOS EPERM fallback using exact ps group/status inspection. Unknown/malformed/unreadable states fail; any live member remains present; zombie-only or absent groups have no executable process. Retain every fallback observation.','old_runner':old.name,'old_runner_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'new_runner_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'source_changes':0,'native_observations':0,'comparator_observations':0,'paid_calls':0,'verification_pending':True}
(OUT/'supervisor-correction.json').write_text(json.dumps(record,indent=2)+'\n')
