"""Adapt the established bounded runner for one proposed local fresh sequence."""
from pathlib import Path

OUT = Path(__file__).resolve().parent
source = OUT.parent/'v23-fresh-v5/runner.py'
text = source.read_text()
text = text.replace('replacement-v5', 'replacement-v6').replace('corpus-replacement-v5', 'corpus-replacement-v6')
text = text.replace('PROPOSAL = CORPUS / "evaluation-proposal.json"', 'PROPOSAL = ASSETS / "evaluation-proposal.json"')
text = text.replace('APPROVAL = ASSETS / "authorization.json"', 'APPROVAL = ASSETS / "evaluation-authorization.json"')
start = text.index('    assert (\n        sha(PROPOSAL)')
end = text.index('    for key in (', start)
text = text[:start]+'''    proposal = json.loads(PROPOSAL.read_text())
    for name, digest in proposal["files_sha256"].items():
        assert sha(DELIVERY / name) == digest, name
'''+text[end:]
start = text.index('    expected = json.loads(',text.index('def stage():'))
end = text.index('    for name, digest in expected.items():',start)
text = text[:start]+'''    expected = json.loads((ASSETS / "staging-files.json").read_text())
'''+text[end:]
text = text.replace('checkpoint-1f3f72f.json','checkpoint-f85a90f.json')
text = text.replace('def run(out, deadline_file, rules):','def run(out, rules):')
start=text.index('        "workflow_run":')
end=text.index('        "scanner":',start)
text=text[:start]+'''        "execution": "one local serial macOS sequence",
        "runner_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=DELIVERY, text=True).strip(),
'''+text[end:]
text=text.replace('        "memory": Path("/proc/meminfo").read_text(),\n        "cpu_topology": subprocess.check_output(["lscpu"], text=True),','        "cpu_topology": subprocess.check_output(["sysctl", "hw.ncpu", "hw.memsize"], text=True),')
text=text.replace('        assert packet["workflow_attempt"] == "1", "reruns forbidden"','''        assert sys.platform == "darwin"
        with (ASSETS / "execution-consumed.json").open("x") as receipt:
            json.dump({"proposal_sha256": sha(PROPOSAL), "approval_sha256": sha(APPROVAL), "output": str(out), "budget_consumed": True}, receipt)
        stop = time.monotonic() + proposal["bounds"]["internal_stop_minutes"] * 60''')
text=text.replace('        stop = float(deadline_file.read_text())\n','')
text=text.replace('and sys.platform == "linux"','and sys.platform == "darwin"')
text=text.replace('        assert ctypes.CDLL(None, use_errno=True).prctl(36, 1, 0, 0, 0) == 0\n','')
text=text.replace('import ctypes\n','')
text=text.replace('            run(out, Path(sys.argv[3]), Path(sys.argv[4]).resolve())','            run(out, Path(sys.argv[3]).resolve())')
text=text.replace('        packet["passed"] = True','        packet["passed"] = True\n        packet["execution_gate_passed"] = True\n        packet["fresh_detection_gate_passed"] = None  # Set only by separate source-bound assessment.')
text=text.replace('    assert batch in proposal["batch_order"]','''    assert batch in proposal["batch_order"]
    consumed = json.loads((ASSETS / "execution-consumed.json").read_text())
    assert consumed["proposal_sha256"] == sha(PROPOSAL)
    parent_packet = json.loads((Path(consumed["output"]) / "packet.json").read_text())
    assert not parent_packet.get("budget_closed", False)
    active = parent_packet["attempts"][-1]
    assert active["batch"] == batch and active["input_id"] == input_id and active["state"] == "attempted"
    assert out.resolve() == (Path(consumed["output"]) / active["directory"]).resolve()''')
path=OUT/'runner.py'
assert not path.exists()
path.write_text(text)
print('Prepared local runner; existing measurement and process supervisor reused; no execution.')
