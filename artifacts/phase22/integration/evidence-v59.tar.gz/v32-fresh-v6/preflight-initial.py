"""Check approval, drift, deadline and replay boundaries without measuring targets."""
import hashlib
import importlib.metadata
import importlib.util
import json
import subprocess
import sys
from pathlib import Path
from unittest.mock import patch

from scripts import phase20_measurements as h

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('fresh_v6',OUT/'runner.py')
runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
proposal=runner.verify_packet()
runner.selfcheck()
assert not runner.APPROVAL.exists()
try:
    runner.approved()
except FileNotFoundError:
    pass
else:
    raise AssertionError('Missing approval accepted')
with patch.object(runner,'sha',return_value='wrong'):
    try:
        runner.verify_packet()
    except AssertionError:
        pass
    else:
        raise AssertionError('Changed proposal-bound bytes accepted')
assert not (OUT/'execution-consumed.json').exists()
assert not subprocess.check_output(['git','diff','439c3fe','--','src','tests','scripts','schemas','pyproject.toml','uv.lock','.github','action.yml','Makefile','README.md','CHANGELOG.md','LICENSE'])
assert importlib.metadata.version('semgrep')==proposal['comparator']['engine_version']
h.verify_rules(Path('/private/tmp/phase20-community-rules'))
source=(OUT/'runner.py').read_text()
assert 'OpenAITransport.create = forbidden' in source
assert 'key.startswith(("OPENAI_", "SENTINEL_"))' in source
assert '"-I"' in source and '.open("x") as receipt' in source
assert 'not parent_packet.get("budget_closed", False)' in source
assert '315 < stop' in source and 'supervisor.supervise(command' in source
rubric=json.loads((OUT/'scoring-rubric.json').read_text())
assert rubric['required_native_result']=={'complete_inputs_per_batch':5,'vulnerable_condition_hits_per_batch':2,'matching_fixed_or_control_alerts_per_batch':0,'ordered_repeat_equal_inputs':5,'batches':2}
packet={'passed':True,'python':sys.version,'semgrep':importlib.metadata.version('semgrep'),'scanner':h.scanner_identity(),'proposal_sha256':runner.sha(runner.PROPOSAL),'checks':['Missing approval rejected','Bound file drift rejected','300-second timing and15-second cleanup boundaries','Entire ordered finding/warning/coverage repeat sensitivity','One-use sequence and active-child guards inspected','All511 local Semgrep configurations byte-verified','Product/test/package/workflow inputs equal tested439c3fe','Prospective detection/discrimination criterion bound'],'new_native_observations':0,'new_comparator_observations':0,'new_paid_calls':0,'target_execution':False,'files_sha256':{str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [OUT/'preflight.py',OUT/'runner.py',OUT/'prepare.py',OUT/'prepare-runner.py',OUT/'propose.py']}}
out=OUT/'preflight.json';assert not out.exists();out.write_text(json.dumps(packet,indent=2)+'\n')
print('Source-only preparation controls passed; scanner/target observations0; paid calls0.')
