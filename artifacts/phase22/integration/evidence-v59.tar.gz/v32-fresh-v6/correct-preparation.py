"""Preserve the failed preflight and fix its nonexistent local comparator path."""
import hashlib
import json
from pathlib import Path

OUT=Path(__file__).resolve().parent
old='/private/tmp/phase20-community-rules'
new='/private/tmp/phase22-v2-comparator-rules'
records=[]
for name in ['preflight.py','evaluation-proposal.json']:
    p=OUT/name; previous=p.with_name(p.stem+'-initial'+p.suffix)
    assert not previous.exists()
    data=p.read_text();assert old in data
    p.rename(previous)
    p.write_text(data.replace(old,new))
    records.append({'original':previous.name,'sha256':hashlib.sha256(previous.read_bytes()).hexdigest(),'corrected':name,'corrected_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
packet={'initial_preflight_exit_code':1,'failure':'Prepared comparator configuration drift: assumed /private/tmp/phase20-community-rules has zero files. No native/comparator/target execution started.','correction':'Use existing /private/tmp/phase22-v2-comparator-rules; all511 configuration paths/hashes match pinned metadata. No rule or engine change.','preserved_log':'preflight.log','files':records,'new_native_observations':0,'new_comparator_observations':0,'new_paid_calls':0}
(OUT/'preparation-correction.json').write_text(json.dumps(packet,indent=2)+'\n')
