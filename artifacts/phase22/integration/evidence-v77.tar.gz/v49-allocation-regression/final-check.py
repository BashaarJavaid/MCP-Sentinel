"""Verify unchanged engineering, complete stopped-budget evidence and final docs."""
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
OUT = Path(__file__).resolve().parent
BASE = OUT.parent
OLD = BASE/'v48-merge-allocation'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

checks = ['v49-output-validation', 'v49-sampler-synthetic', 'v49-owned-cleanup-settled', 'v49-assessment-preparation-settled', 'v49-diagnostic-boundary', 'v49-reconciliation', 'v49-final-docs', 'v49-final-build', 'v49-final-distributions']
for name in checks:
    assert read(BASE/(name+'.json'))['exit_code'] == 0, name
assert read(BASE/'v49-owned-cleanup.json')['exit_code'] == 1
assert read(BASE/'v49-assessment-preparation.json')['exit_code'] == 1
engineering = read(OLD/'local-checks.json')['candidate_engineering_files_sha256']
assert len(engineering) == 302
for name, digest in engineering.items():
    assert sha(ROOT/name) == digest, name
    assert sha(Path('/private/tmp/mcp-phase22-frozen-6e4fd67')/name) == digest, name
binding = read(OLD/'documentation-binding.json')
for name, digest in binding['user_files_sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in read(OUT/'owning-docs.json')['sha256'].items():
    assert sha(ROOT/name) == digest, name
for name, digest in read(BASE/'v45-four-source-recovery/prior-row-preservation.json')['referenced_evidence_sha256'].items():
    assert sha(ROOT/name) == digest, name
proposal = read(OUT/'diagnostic-proposal.json')
for name, digest in proposal['files_sha256'].items():
    assert sha(ROOT/name) == digest, name
assert not (OUT/'diagnostic-authorization.json').exists()
assert not (OUT/'diagnostic-consumed.json').exists()
assert not (BASE/'v50-faf-allocation-sampling').exists()
assert read(OUT/'assessment.json')['budget']['unstarted_closed'] == 204
assert read(OUT/'final-distributions.json')['wheel_product_schema_fixture_members_byte_identical_to_hosted']
audit = read(OUT/'audit.json')
assert len(audit['requirements']) == 89 and len(audit['additional_scope_requirements']) == 164
assert audit['requirements'] == read(OLD/'audit.json')['requirements']
assert not audit['technical_acceptance_received'] and not audit['phase22_complete']
assert not subprocess.check_output(['git', 'diff', '6e4fd67', '--', 'src', 'tests', 'scripts', 'schemas', '.github', 'uv.lock', 'pyproject.toml', 'CHANGELOG.md'])
subprocess.run(['git', 'diff', '--check'], check=True)
subprocess.run(['git', 'merge-base', '--is-ancestor', '8b6b0ddf1d6f6cf5a8da3ab9421471865b801455', 'HEAD'], check=True)
main = Path('/Users/bashaarjavaid/Projects/MCP-Sentinel')
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=main, text=True).strip() == '4cd57593b2585b9ee05c0f175930e6a0d76d362a'
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=main)
provenance = {'wrapper_commands': {n: read(BASE/(n+'.json')) for n in checks+['v49-owned-cleanup','v49-assessment-preparation']},
    'direct_commands': [
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'authorize-regression.py')], 'exit_code': 0, 'evidence': 'v48-merge-allocation/execution-preflight.json', 'console': 'Exact205-observation approval recorded; frozen source and one-use launcher preflight passed. Zero observations started.'},
        {'command': ['/Users/bashaarjavaid/Projects/MCP-Sentinel/.venv/bin/python', '-I', str(OLD/'launch.py')], 'exit_code': 1, 'evidence': 'v49-allocation-regression/execution.json', 'console': 'No direct stdout; child output retained in sequence.log and raw input log.'}],
    'failure_assessment': 'The actual corpus attempt timed out and its budget closed. The first owned-work check correctly detected the concurrently running synthetic sampler helper, so its receipt was absent and the dependent assessment preparation failed before writing outputs. The sampler then exited successfully. The unchanged owned-work and preparation scripts passed serially under new labels. Both initial logs are preserved. These were offline verification ordering failures, not new corpus attempts or changed scanner semantics. Documentation, package and boundary checks passed.',
    'paid_calls': 0, 'retry_observations': 0}
write('check-failure-assessment.json', {'failed_checks': ['v49-owned-cleanup','v49-assessment-preparation'], 'explanation': provenance['failure_assessment'], 'corrected_checks': ['v49-owned-cleanup-settled','v49-assessment-preparation-settled'], 'paid_calls': 0, 'corpus_retries': 0})
write('command-provenance.json', provenance)
write('final-checks.json', {'passed': True, 'recorded_at': datetime.now(timezone.utc).isoformat(),
    'scanner': read(OLD/'freeze.json')['scanner'], 'engineering_files_verified': 302, 'prior_evidence_files_verified': len(read(BASE/'v45-four-source-recovery/prior-row-preservation.json')['referenced_evidence_sha256']),
    'requirements': 253, 'protected_user_files': 8, 'owning_docs': 16, 'main_and_parent_preserved': True,
    'checks_sha256': {n: sha(BASE/(n+'.json')) for n in checks}, 'diagnostic_proposal_sha256': sha(OUT/'diagnostic-proposal.json'),
    'corpus_budget': read(OUT/'assessment.json')['budget'], 'diagnostic_executions': 0, 'paid_calls': 0,
    'technical_acceptance_received': False, 'phase22_complete': False})
print('Final checks passed:302engineering files,253requirements,16docs,closed205budget and unexecuted diagnostic.')
