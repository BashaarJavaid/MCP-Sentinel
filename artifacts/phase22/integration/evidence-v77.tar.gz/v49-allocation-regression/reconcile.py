"""Preserve all requirements and publish the actual stopped execution status."""
import copy
import hashlib
import json
import os
import subprocess
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
ROOT = OUT.parents[3]
OLD = BASE/'v48-merge-allocation'
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')

a = read(OUT/'assessment.json')
assert a['budget'] == {'planned': 205, 'attempted': 1, 'completed': 0, 'incomplete': 1, 'unstarted_closed': 204, 'remaining': 0, 'closed': True}
old = read(OLD/'audit.json')
rows = copy.deepcopy(old['additional_scope_requirements'])
for row in rows:
    if row['id'] == 'V48-DELIVERY':
        row['previous_row'] = copy.deepcopy(row)
        row['disposition'] = 'passed'
        row['evidence'] = ['artifacts/phase22/integration/v48-merge-allocation/delivery-verification.json']
        row['assessment'] = 'Actual129d346draft delivery readback passed; this does not accept the later execution failure.'
new = [
    ('V49-AUTH', 'Bind the exact205-observation approval to proposal, launcher, scanner and bounds', 'passed', ['../v48-merge-allocation/evaluation-authorization.json', '../v48-merge-allocation/execution-preflight.json']),
    ('V49-STOP', 'Preserve timeout/incomplete output and close all204unstarted observations with verified cleanup', 'passed', ['validation.json', 'assessment.json', 'owned-work.json']),
    ('V49-ASSESSMENT', 'Assess every available outcome without inventing report contents or corrected-scanner compatibility', 'passed', ['assessment.json']),
    ('V49-DIAGNOSTIC-PREPARATION', 'Prepare a separately gated single bounded sampled input with synthetic validation and zero execution', 'passed', ['diagnostic-proposal.json', 'sampler-selfcheck/packet.json', '../v46-diagnostic-boundary.json']),
    ('V49-REGRESSION-GATE', 'Complete current-source four-repository and affected compatibility gates or obtain an explicit disposition of actual failure', 'unresolved', ['assessment.json']),
    ('V49-DELIVERY', 'Seal stopped execution, reconcile every prior row and verify existing draft delivery of the concrete next decision', 'unresolved', []),
]
for identity, requirement, disposition, evidence in new:
    rows.append({'id': identity, 'requirement': requirement, 'disposition': disposition,
                 'evidence': [str((OUT/n).resolve().relative_to(ROOT)) for n in evidence],
                 'assessment': 'One incomplete timed-out observation, no reports,204closed unstarted,zero remaining. No corrected-source discrimination/compatibility or human acceptance is claimed.'})
assert len(old['requirements']) == 89 and len(rows) == 164
assert len({r['id'] for r in old['requirements']+rows}) == 253
audit = copy.deepcopy(old)
audit['historical_v48_status_fields'] = {k: copy.deepcopy(value) for k,value in old.items() if k not in ['requirements','additional_scope_requirements'] and not k.startswith('historical_')}
audit.update(recorded_at=datetime.now(timezone.utc).isoformat(), additional_scope_requirements=rows,
             additional_scope_dispositions=dict(Counter(r['disposition'] for r in rows)),
             prior_audit={'path': str((OLD/'audit.json').relative_to(ROOT)), 'sha256': sha(OLD/'audit.json')},
             regression_approved=True, regression_executed=True, current_regression_approved=True, current_regression_executed=True, current_source_corpus_observations=1,
             current_source_completed_observations=0, current_source_incomplete_observations=1,
             unstarted_closed=204, remaining=0, budget_closed=True,
             execution_gate_passed=False, diagnostic_prepared=True, diagnostic_approved=False,
             diagnostic_executed=False, diagnostic_attempts=0, diagnostic_completed_inputs=0, diagnostic_budget_closed=False, diagnostic_remaining=0, new_paid_calls=0, acceptance_packet_ready=False,
             technical_acceptance_requested=False, technical_acceptance_received=False, phase22_complete=False,
             status='Approved205-observation sequence stopped on first FAF vulnerable timeout;1incomplete,0complete,204unstarted closed. All corrected-source detection/compatibility gates remain unresolved. One300-second diagnostic is prepared,unapproved and unexecuted.')
audit['current_evidence'] = {n: sha(OUT/n) for n in ['assessment.json', 'validation.json', 'diagnostic-proposal.json', 'sampler-selfcheck/packet.json', 'owned-work.json']}
for identity in ['R66', 'R88']:
    audit['current_requirement_interpretations'][identity] = 'Original24first-frozen observations and all4failed fresh gates remain at2e0efb2. Approved corrected6e4fd67regression stopped on first FAF timeout,with no completed report and204unstarted closed. Current-source detection/compatibility remains unestablished. No historical closure or new failure is accepted.'
write('audit.json', audit)
write('prior-row-preservation.json', {'prior_audit_sha256': sha(OLD/'audit.json'), 'retained_prior_rows': 247, 'updated_rows': ['V48-DELIVERY'],
     'rows': {r['id']: hashlib.sha256(json.dumps(r, sort_keys=True).encode()).hexdigest() for r in old['requirements']+old['additional_scope_requirements']}})
summary = f'''# FAF timeout and closed regression budget

**The approved205-observation regression stopped at its first input at scanner `6e4fd67`: one incomplete attempt, zero completed reports,204unstarted observations closed,zero budget remaining. Phase22 remains incomplete.**

The exact user decision `approved.` binds the [205-observation authorization](../v48-merge-allocation/evaluation-authorization.json) and launcher delivered at `129d346`. The sole attempt was `faf-read-root-vulnerable` from Wolfe-Jam/faf-mcp. Its [whole-input supervisor](assessment.json) reached **{a['whole_seconds']:.6f} seconds**, including startup, and terminated the child. Cleanup finished by **{a['whole_including_cleanup_seconds']:.6f} seconds**, within the15-second allowance, without a remaining group kill. The outer sequence took **{a['sequence_seconds']:.6f} seconds** and exited1. All owned processes/containers were subsequently absent.

The harness retained `state: incomplete`, `reason: null` and{a['harness_wall_duration_ms']}ms within its narrower measurement interval. The source explains this record: the SIGTERM handler raises SystemExit, which bypasses the harness's exceptException branch but runs its finally block. **No JSON/SARIF report was produced. Findings, warnings, surfaces, vulnerable detection and negative discrimination are unknown, not zero.** There is no native exit3 report, completed batch or ordered repeat. The current expensive operation is not established by these outputs. The earlier v47 profile remains at `17b4784`, before the allocation predicate. Its sample shares cannot establish the residual costs at `6e4fd67`. The new timeout establishes failure to complete within the limit; it does not quantify a speedup or slowdown. No retry, profile, comparator, target execution or paid call occurred.

[Output validation](validation.json) and [assessment](assessment.json) retain the exact scanner, source/configuration/approval identities, logs, resource totals and all204closed observations. The23remaining four-source observations and all181prior-language observations did not start. The corrected FAF, no-bash, Lightning and Engram gates, and affected prior Python/TypeScript compatibility, remain unestablished. The original four-repository24-observation result at `2e0efb2` remains four failed gates; later source corrections cannot make that first-frozen result a fresh pass.

The [next diagnostic proposal](diagnostic-proposal.json), SHA-256 `{sha(OUT/'diagnostic-proposal.json')}`, is **unapproved and unexecuted**. It requests current-source attribution after the allocation change, exactly **one sampled rules-only input**: the same FAF vulnerable source/configuration at frozen `6e4fd67`, existing macOS environment,120-second target,300-second whole-input maximum and15-second cleanup allowance. It reuses the stdlib CPU-timer worker sampler at at most100Hz per worker, with15-second atomic snapshots and no locals/source values. Scanner methods, rule selection, worker layout and deadlines remain unchanged. The wrapper entry point is explicit instrumentation; sampled timing is not a native performance result.

The [synthetic sampler check](sampler-selfcheck/packet.json) preserves six value-flow vectors, unchanged scanner method identities, valid sample/frame counts and restored timer/signal state. The prepared runner's missing-approval check passes before output or budget mutation. One diagnostic attempt would consume its entire separate budget even on timeout. Partial worker snapshots may lack final/restored-state records after mandatory cleanup; signal/GIL/native-code delays and sampler overhead limit attribution. No automatic optimization, uninstrumented retry, comparator, deadline/resource upgrade, target execution or paid call is proposed. The closed204observations stay closed.

The allocation candidate retains 10,944 equal scanner-owned synthetic cases and its specific allocation accounting. That does not satisfy the failed native completion gate. The single optimization budget is closed; no second optimization is authorized. Restored files, historical worktrees and the verified 3.704 GiB of reclaimed Docker space remain bound to the v48 maintenance receipts.

Product/tests/workflows/schema/lock remain engineering-tested `6e4fd67`: **2,384 tests /36skips** locally and in all12hosted suites, **29normalCIjobs** and docs passed in [34743452798](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452798) / [34743452818](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34743452818). Local combined statement/branch coverage is89.98%, branch-only85.85%. The actual merge checkout `3b11d543be3f08ba2cdb171ca4d56a00f5f18da5` has the candidate tree. All302engineering inputs, six exact zero-call production replays, owned Docker20/20fixture result and Git image/runtime bindings remain source-bound. This docs/evidence continuation claims no new hosted code pass.

The [full audit](audit.json) preserves all89original and158prior added rows, then adds six requirements: **253total**. The original dispositions remain84passed,2user-deferred,2proposed limitations and1human-acceptance unresolved. Prior proposed closures retain their actual failed measurements. Neither this timeout nor the four fresh failures are silently accepted. Current execution/discrimination/compatibility work and final human acceptance remain unresolved.

Historical whole25development reuse and45+45Linux timing/conditions remain at `1f3f72f`, with the Meta operator erratum. Prior TS94 at `2e0efb2` and Python87 at `8c62567` retain their original results; no partial subsets are pooled into a new whole batch. Memory-keeper's original fresh false alerts, DDG's initially unsupported fixed send and erroneous frozen TypeScript label despite actual Python configuration, Lighthouse misses, original held-out10complete/10unsupported/5incomplete with0hits among4completed vulnerable out of10total vulnerable, and all earlier failed/stopped attempts remain unchanged. Same-agent curation/review is not independent human validation, broad accuracy, training-data novelty or runtime proof.

Git stays **312/1,040incomplete**,728deferred. Paid benchmark and pilots remain deferred; Phase21 incomplete and Phase24/15 gates unchanged. No merge, ready-state change, release, outreach or Phase23 is authorized. After the next separately approved diagnostic and necessary technical work, continue toward a concrete explicit human technical acceptance decision and verified accepted closeout to the same draft PR.
'''
# Keep the delivered prose readable without changing its precise counts.
for left, right in [('approved205','approved 205'),('204unstarted','204 unstarted'),('zero budget','zero budget'),('Phase22','Phase 22'),('the15','the 15'),('exited1','exited 1'),('and298133','and 298133'),('exceptException','except Exception'),('23remaining','23 remaining'),('all181prior-language','all 181 prior-language'),('four-repository24','four-repository 24'),('120-second','120-second'),('environment,120','environment, 120'),('and15','and 15'),('most100','most 100'),('with15','with 15'),('closed204','closed 204'),('/36skips','/ 36 skips'),('all12hosted','all 12 hosted'),('29normalCIjobs','29 normal CI jobs'),('is89.98','is 89.98'),('branch-only85.85','branch-only 85.85'),('All302engineering','All 302 engineering'),('Docker20/20fixture','Docker 20/20 fixture'),('all89original','all 89 original'),('and158prior','and 138 prior'),('253total','253 total'),('remain84passed,2user-deferred,2proposed','remain 84 passed, 2 user-deferred, 2 proposed'),('and1human','and 1 human'),('whole25development','whole 25 development'),('and45+45Linux','and 45+45 Linux'),('held-out10complete/10unsupported/5incomplete with0hits among4completed vulnerable out of10total','held-out 10 complete/10 unsupported/5 incomplete with 0 hits among 4 completed vulnerable out of 10 total'),('312/1,040incomplete','312/1,040 incomplete'),('**,728deferred','**, 728 deferred'),('Phase21','Phase 21'),('Phase24/15','Phase 24/15'),('Phase23','Phase 23')]:
    summary = summary.replace(left, right)
with (OUT/'summary.md').open('x') as stream:
    stream.write(summary)
url = 'https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/'
body = summary.replace('(../v48-merge-allocation/', '('+url+'v48-merge-allocation/')
for name in ['assessment.json', 'validation.json', 'diagnostic-proposal.json', 'sampler-selfcheck/packet.json', 'audit.json']:
    body = body.replace('('+name+')', '('+url+'v49-allocation-regression/'+name+')')
with (OUT/'pr-body.md').open('x') as stream:
    stream.write(body)
docs = list(read(OLD/'documentation-binding.json')['owning_docs_sha256'])
assert len(docs) == 16
for name in docs:
    path = ROOT/name
    text = path.read_text()
    link = url+'v49-allocation-regression/summary.md' if name.startswith('docs/') else os.path.relpath(OUT/'summary.md', path.parent)
    status = f'''## Current v49 allocation regression timeout: budget closed

The approved 205-observation sequence at frozen `6e4fd67` stopped on its first
FAF vulnerable input at the 300-second whole-input maximum: **one incomplete,
zero completed reports, 204 unstarted closed, zero remaining**. Cleanup passed.
No finding, guard, negative-path or ordered-repeat result is available; corrected
four-repository and prior-language compatibility gates remain unestablished.
The [review packet]({link}) retains the failure and an **unapproved single
300-second CPU-sampling diagnostic** on the same FAF input. No new retry, profile,
target execution or paid call occurred in this sequence. The v47 profile remains
bound to the earlier scanner; another optimization is not authorized. All original fresh failures and
historical source-bound passes remain unchanged. Engineering retains `6e4fd67`:
2,384 tests / 36 skips locally and in all 12 hosted suites, 29 normal CI jobs and
docs passed; combined coverage 89.98%, branch-only 85.85%. The audit retains all
253 requirements. **Phase 22 remains incomplete**; no failure/limitation or human
technical acceptance is inferred. Git stays 312/1,040 incomplete; paid benchmark
and pilots deferred, Phase 21 incomplete and Phase 24/15 unchanged. No merge,
ready-state change, release, outreach or Phase 23.

'''
    text = text.replace('## Current v48', '## Historical v48', 1)
    first, rest = text.split('\n', 1)
    path.write_text(first+'\n\n'+status+rest)
write('owning-docs.json', {'sha256': {n: sha(ROOT/n) for n in docs}})
print('Reconciled253requirements and16owning docs; no technical acceptance or diagnostic execution.')
