from __future__ import annotations
def call(self, symbol: Symbol, node: ast.Call, env: dict[str, Value]) -> Value:
    if node in self.http_context.sdk_skipped_calls:
        return UNKNOWN_VALUE
    if node is self.launch_call:
        self.launch_states.append(
            {
                **self.globals,
                **{
                    (path, name): value
                    for key, value in env.items()
                    if key.startswith("#global-value:")
                    for path, name in [
                        key.removeprefix("#global-value:").rsplit(":", 1)
                    ]
                },
            }
        )
        return UNKNOWN_VALUE
    name = qualified_name(node.func) or "dynamic call"
    resolved = resolve_name(name, self.aliases[symbol.file.relative_path])
    root = name.split(".")[0]
    declarations = self.program.bindings[symbol.file.relative_path].get(root, [])
    if root in env or (
        declarations
        and not (
            len(declarations) == 1
            and isinstance(declarations[0], (ast.Import, ast.ImportFrom))
        )
    ):
        resolved = ""
    receiver = self.call_receiver(symbol, node, env)
    args = []
    unknown_args = False
    for arg in node.args:
        value = self.expression(
            symbol, arg.value if isinstance(arg, ast.Starred) else arg, env
        )
        if isinstance(arg, ast.Starred):
            expanded = self.argument_tuples.get(value.key)
            if expanded is None:
                unknown_args = True
                args.append(value)
            else:
                args.extend(expanded)
        else:
            args.append(value)
    keywords: dict[str | None, Value] = {}
    for keyword in node.keywords:
        value = self.expression(symbol, keyword.value, env)
        if keyword.arg is not None:
            if keyword.arg in keywords:
                keywords[None] = value
            keywords[keyword.arg] = replace(value, maybe_missing=False)
        elif (
            value.key in self.mapping_keys
            and "#member:unknown:" + value.key not in env
        ):
            for label, marker in self.members.get(value.key, {}).items():
                if marker not in env:
                    continue
                if (
                    not isinstance(label, str)
                    or label in keywords
                    or env[marker].maybe_missing
                ):
                    keywords[None] = value
                else:
                    keywords[label] = env[marker]
        else:
            keywords[None] = value
    if (
        resolved == "contextvars.ContextVar"
        and self.program.external(symbol, node.func) == resolved
        and len(args) == 1
        and not unknown_args
        and keywords.keys() <= {"default"}
        and isinstance(member_label(args[0]), str)
    ):
        value = Value(
            key=_key(
                "context-variable",
                symbol.file.relative_path,
                str(node.lineno),
                str(node.col_offset),
                *self.call_sites,
            )
        )
        self.context_variables[value.key] = keywords.get("default")
        self.record_keys.add(value.key)
        self.member_defaults["#context:" + value.key] = Value(
            key="#context-unset", maybe_missing=True
        )
        return value
    if receiver.key in self.context_variables and isinstance(
        node.func, ast.Attribute
    ):
        marker = "#context:" + receiver.key
        method = node.func.attr
        method_marker = self.members.get(receiver.key, {}).get(method)
        current = env.get(marker, self.member_defaults[marker])
        if (
            not keywords
            and not unknown_args
            and "#member:unknown:" + receiver.key not in env
            and (method_marker is None or method_marker not in env)
        ):
            if method == "get" and len(args) <= 1:
                context_default = (
                    args[0] if args else self.context_variables[receiver.key]
                )
                if not current.maybe_missing:
                    return current
                if context_default is not None:
                    return (
                        context_default
                        if current.key == "#context-unset"
                        else combine(
                            [replace(current, maybe_missing=False), context_default]
                        )
                    )
            elif method == "set" and len(args) == 1:
                token = Value(
                    key=_key(
                        "context-token",
                        symbol.file.relative_path,
                        str(node.lineno),
                        str(node.col_offset),
                        *self.call_sites,
                    )
                )
                self.context_tokens[token.key] = receiver.key
                self.record_keys.add(token.key)
                env["#context:token:" + token.key] = current
                env["#context:valid:" + token.key] = Value(key="True")
                env[marker] = replace(args[0], maybe_missing=False)
                return token
            elif method == "reset" and len(args) == 1:
                token_marker = "#context:token:" + args[0].key
                previous = env.get(token_marker)
                if (
                    self.context_tokens.get(args[0].key) == receiver.key
                    and "#member:unknown:" + args[0].key not in env
                    and previous is not None
                    and env.get("#context:valid:" + args[0].key, UNKNOWN_VALUE).key
                    == "True"
                ):
                    env[marker] = previous
                    env["#context:valid:" + args[0].key] = Value(key="False")
                    return Value(key="None")
        self.unresolved(symbol, node, "unresolved ContextVar operation")
        env[marker] = UNKNOWN_VALUE
        return UNKNOWN_VALUE
    if (
        resolved
        in {
            "httpx.Client",
            "httpx.AsyncClient",
            "requests.Session",
            "aiohttp.ClientSession",
            "atlassian.Jira",
            "atlassian.Confluence",
        }
        and self.program.external(symbol, node.func) == resolved
    ):
        value = Value(
            key=_key(
                "http-client",
                symbol.file.relative_path,
                str(node.lineno),
                str(node.col_offset),
                *self.call_sites,
            )
        )
        self.http_clients[value.key] = resolved
        self.record_keys.add(value.key)
        if resolved in {"atlassian.Jira", "atlassian.Confluence"}:
            if (
                unknown_args
                or None in keywords
                or len(args) > 1
                or (args and "url" in keywords)
                or not (args or "url" in keywords)
            ):
                self.unresolved(
                    symbol, node, "unresolved service constructor arguments"
                )
                return UNKNOWN_VALUE
            base_url = keywords.get("url", args[0] if args else UNKNOWN_VALUE)
            env[self.member_key(value, "url")] = replace(
                base_url,
                locations=base_url.locations
                | {(symbol.file.relative_path, node.lineno)},
            )
            session = keywords.get("session", Value(key="None"))
            if session.key == "None":
                session = Value(key=_key(value.key, "default-session"))
                self.http_clients[session.key] = "requests.Session"
                self.record_keys.add(session.key)
            env[self.member_key(value, "_session")] = session
        else:
            if resolved == "requests.Session" and (args or keywords):
                self.unresolved(
                    symbol, node, "unsupported Session constructor arguments"
                )
                return UNKNOWN_VALUE
            auth_field = (
                "_default_auth" if resolved == "aiohttp.ClientSession" else "auth"
            )
            env[self.member_key(value, auth_field)] = keywords.get(
                "auth", Value(key="None")
            )
            if resolved == "aiohttp.ClientSession":
                env[self.member_key(value, "_base_url")] = keywords.get(
                    "base_url", args[0] if args else Value(key="None")
                )
            for field in ("headers", "params"):
                if field == "params" and resolved == "aiohttp.ClientSession":
                    continue
                mapping = Value(key=_key(value.key, field))
                self.mapping_keys.add(mapping.key)
                if field == "headers":
                    self.header_mappings.add(mapping.key)
                    # Library-provided ordinary headers are not an empty mapping.
                    env["#member:unknown:" + mapping.key] = UNKNOWN_VALUE
                if field in keywords:
                    self.update_mapping(mapping, keywords[field], env)
                env[self.member_key(value, field)] = mapping
        return value
    if (
        resolved == "dataclasses.replace"
        and self.program.external(symbol, node.func) == resolved
        and len(args) == 1
        and not unknown_args
        and args[0].instance is not None
        and not args[0].maybe_missing
    ):
        original = args[0]
        assert original.instance is not None
        owner_path, owner_name = original.instance
        owner_file = next(
            file for file in self.program.files if file.relative_path == owner_path
        )
        record_class = self.program.resolve(owner_file, owner_name)
        fields = self.registrations.fields(record_class) if record_class else None
        if fields is not None and keywords.keys() <= set(fields):
            field_values = {
                field: keywords.get(field, self.member(original, field, env))
                for field in fields
            }
            if not any(value.maybe_missing for value in field_values.values()):
                copied = replace(
                    combine(
                        list(field_values.values()),
                        _key(
                            "dataclass-replacement",
                            symbol.file.relative_path,
                            str(node.lineno),
                            str(node.col_offset),
                            *self.call_sites,
                        ),
                    ),
                    instance=original.instance,
                    maybe_none=False,
                    maybe_missing=False,
                )
                self.record_keys.add(copied.key)
                for field, value in field_values.items():
                    marker = self.member_key(copied, field)
                    env[marker] = value
                    self.member_defaults[marker] = Value(
                        key="#missing", maybe_missing=True
                    )
                    self.required_members.add(marker)
                return copied
    super_owner = None
    if (
        isinstance(node.func, ast.Attribute)
        and isinstance(node.func.value, ast.Call)
        and isinstance(node.func.value.func, ast.Name)
        and node.func.value.func.id == "super"
        and not node.func.value.args
        and not node.func.value.keywords
        and "super" not in env
        and "super" not in self.program.bindings[symbol.file.relative_path]
        and isinstance(symbol.node, Function)
    ):
        enclosing_class = self.program.parents.get(symbol.node)
        method_parameters = (*symbol.node.args.posonlyargs, *symbol.node.args.args)
        if isinstance(enclosing_class, ast.ClassDef) and method_parameters:
            super_owner = Symbol(symbol.file, enclosing_class.name, enclosing_class)
            receiver = env.get(method_parameters[0].arg, UNKNOWN_VALUE)
    http_value = self.http_context.call(
        symbol, node, resolved, receiver, args, keywords, env, super_owner
    )
    if http_value is not None:
        return http_value
    if (
        isinstance(node.func, ast.Attribute)
        and node.func.attr == "append"
        and receiver.key in self.sequence_keys
    ):
        if not self.sequence_keys[receiver.key]:
            self.unresolved(symbol, node, "tuple has no builtin append method")
            return UNKNOWN_VALUE
        elements = self.sequence_elements(receiver, env)
        if (
            elements is not None
            and len(elements) < 32
            and len(args) == 1
            and not keywords
        ):
            env[self.member_key(receiver, len(elements))] = args[0]
            env[self.member_key(receiver, "#length")] = Value(
                key=repr(len(elements) + 1)
            )
            return Value(key="None")
    if (
        resolved == "fastmcp.server.dependencies.get_http_request"
        and not any(
            module in self.program.modules
            for module in (
                "fastmcp",
                "fastmcp.server",
                "fastmcp.server.dependencies",
            )
        )
        and not args
        and not keywords
    ):
        if env.get("#http:no-request", UNKNOWN_VALUE).key == "True":
            env["#http:stop"] = Value(key="True")
            return UNKNOWN_VALUE
        if "#http:request" in env:
            return env["#http:request"]
        request = Value(
            sources=frozenset({"http:request"}),
            key=_key(
                "http-request",
                symbol.file.relative_path,
                str(node.lineno),
                *self.call_sites,
            ),
            locations=frozenset({(symbol.file.relative_path, node.lineno)}),
        )
        env["#http:request"] = request
        env[self.member_key(request, "state")] = replace(
            request, key=_key(request.key, "state")
        )
        return request
    values = [*args, *keywords.values()]
    method = name.rsplit(".", 1)[-1]
    result = combine(values + ([receiver] if receiver.sources else []))
    result = replace(
        result,
        locations=result.locations | {(symbol.file.relative_path, node.lineno)},
    )
    if (
        resolved in {"os.getenv", "os.environ.get"}
        and self.program.external(symbol, node.func) == resolved
        and len(args) == 2
        and member_label(args[1]) is not UNKNOWN_MEMBER
        and args[1].key != "None"
    ):
        self.non_none.add(result.key)
        return result
    if (
        resolved in {"hasattr", "builtins.hasattr"}
        and root not in env
        and not declarations
        and len(args) == 2
        and not keywords
        and args[0].key in self.http_context.state_owners
        and isinstance(member_label(args[1]), str)
    ):
        member = self.member(args[0], member_label(args[1]), env)
        if member.key == "#missing" or not member.maybe_missing:
            return Value(key=repr(member.key != "#missing"))
        return UNKNOWN_VALUE
    if (
        (resolved in {"id", "builtins.id"} and len(args) == 1 and not keywords)
        or (
            resolved in {"hasattr", "builtins.hasattr"}
            and len(args) == 2
            and not keywords
            and args[0].key in self.record_keys
            and args[0].instance is not None
            and isinstance(member_label(args[1]), str)
            and self.member_key(args[0], member_label(args[1])) in env
            and self.instance_member(args[0], str(member_label(args[1]))) is None
        )
        or (
            resolved in {"len", "builtins.len"}
            and len(args) == 1
            and args[0].key in self.mapping_keys
            and not keywords
        )
        or (
            resolved in {"isinstance", "builtins.isinstance"}
            and len(args) == 2
            and args[0].key in self.mapping_keys
            and qualified_name(node.args[1]) == "dict"
            and "dict" not in env
            and "dict" not in self.program.bindings[symbol.file.relative_path]
            and not keywords
        )
    ):
        return UNKNOWN_VALUE
    if (
        resolved in {"isinstance", "builtins.isinstance"}
        and len(args) == 2
        and not keywords
        and args[0].key in self.record_keys
        and args[0].instance is not None
    ):
        class_info = self.callables.get(args[1].key)
        if class_info and self.registrations.fields(class_info) is not None:
            # Source-established dataclasses have no custom instance check or
            # attribute hooks. The builtin inspection does not mutate them.
            instance_path, instance_name = args[0].instance
            instance_file = next(
                file
                for file in self.program.files
                if file.relative_path == instance_path
            )
            actual_class = self.program.resolve(instance_file, instance_name)
            order = (
                self.program.method_order(actual_class) if actual_class else None
            )
            if order is not None:
                matches_type = any(
                    isinstance(parent, Symbol) and parent.node is class_info.node
                    for parent in order
                )
                if not matches_type or not (
                    args[0].maybe_none or args[0].maybe_missing
                ):
                    return Value(key=repr(matches_type))
            return UNKNOWN_VALUE
    if (
        method in {"keys", "items", "values"}
        and receiver.key in self.mapping_keys
        and not args
        and not keywords
    ):
        if method == "keys":
            return replace(
                env.get("#member:unknown:" + receiver.key, UNKNOWN_VALUE),
                key=_key("mapping-keys", receiver.key),
                instance=None,
            )
        return replace(self.aggregate(receiver, env), instance=None)
    if (
        resolved in {"dict", "builtins.dict"}
        and root not in env
        and not any(
            not isinstance(declaration, (ast.Import, ast.ImportFrom))
            for declaration in declarations
        )
    ) or (
        method == "copy"
        and receiver.key in self.mapping_keys
        and not args
        and not keywords
    ):
        mapping = Value(
            key=_key(
                "mapping-call",
                symbol.file.relative_path,
                str(node.lineno),
                str(node.col_offset),
                *self.call_sites,
            )
        )
        self.mapping_keys.add(mapping.key)
        if method == "copy":
            self.update_mapping(mapping, receiver, env)
        elif args:
            self.update_mapping(mapping, args[0], env)
        for label, value in keywords.items():
            if label is None:
                self.update_mapping(mapping, value, env)
            else:
                env[self.member_key(mapping, label)] = replace(
                    value, maybe_missing=False
                )
        return self.aggregate(mapping, env)
    if method == "update" and receiver.key in self.mapping_keys:
        if receiver.key in self.optional_mappings:
            # A write may target the empty fallback or the populated alias.
            self.update_mapping(
                self.optional_mappings[receiver.key],
                combine(
                    [receiver, *args, *keywords.values()],
                    _key("ambiguous-update", receiver.key),
                ),
                env,
            )
            return UNKNOWN_VALUE
        for argument in args:
            self.update_mapping(receiver, argument, env)
        for label, value in keywords.items():
            if label is None:
                self.update_mapping(receiver, value, env)
            else:
                env[self.member_key(receiver, label)] = replace(
                    value, maybe_missing=False
                )
        return UNKNOWN_VALUE
    if (method == "resolve" and receiver.path_object) or (
        resolved == "os.path.realpath"
        and self.program.external(symbol, node.func) == resolved
    ):
        return replace(
            result if args else receiver, resolved=True, locations=result.locations
        )
    if (
        resolved == "os.path.commonpath"
        and len(args) == 1
        and not keywords
        and self.program.external(symbol, node.func) == resolved
    ):
        path_values = self.path_arrays.get(node.args[0])
        if path_values:
            result = replace(
                result, key=_key("commonpath", *(v.key for v in path_values))
            )
            self.common_paths[result.key] = path_values
        return result
    if resolved == "pathlib.Path" and name.split(".")[0] not in env:
        return replace(
            result, path_object=True, maybe_missing=False, maybe_none=False
        )
    if resolved in {"str", "os.fspath"} and name.split(".")[0] not in env:
        return replace(result, path_object=False)
    if method in {"expanduser", "absolute"} and receiver.path_object:
        return replace(
            receiver,
            key=_key("expanduser", receiver.key)
            if method == "expanduser"
            else receiver.key,
            contained=False,
            checked_path_parent=False,
        )
    if method == "relative_to" and isinstance(node.func, ast.Attribute):
        self.protect(symbol, node, env)
        return result
    if method in {
        "is_relative_to",
        "is_absolute",
        "startswith",
        "exists",
        "is_file",
        "is_dir",
    }:
        return UNKNOWN_VALUE
    sink: Value | None = None
    workbook = (
        resolved
        in {
            "openpyxl.Workbook",
            "openpyxl.workbook.Workbook",
            "openpyxl.workbook.workbook.Workbook",
            "openpyxl.load_workbook",
            "openpyxl.reader.excel.load_workbook",
        }
        and self.program.external(symbol, node.func) == resolved
    )
    if workbook and resolved.endswith("Workbook"):
        value = Value(
            key=_key(
                "workbook",
                symbol.file.relative_path,
                str(node.lineno),
                str(node.col_offset),
                *self.call_sites,
            )
        )
        self.workbooks.add(value.key)
        return value
    if resolved in {
        "open",
        "builtins.open",
        "io.open",
        "os.open",
        "git.Repo",
        "os.remove",
        "os.unlink",
        "os.rmdir",
        "os.mkdir",
        "os.makedirs",
        "shutil.rmtree",
    }:
        sink = args[0] if args else keywords.get("file", keywords.get("path"))
    elif workbook or (receiver.key in self.workbooks and method == "save"):
        sink = args[0] if args else keywords.get("filename")
    elif (
        method
        in {
            "read_text",
            "read_bytes",
            "write_text",
            "write_bytes",
            "open",
            "unlink",
            "rmdir",
            "mkdir",
            "iterdir",
        }
        and receiver.sources
        and receiver.path_object
    ):
        sink = receiver
    elif name.endswith(".index.add") and receiver.repository_object:
        sink = args[0] if args else keywords.get("items")
    if sink is not None:
        if self.rule_id == "SENT-012" and sink.sources and not sink.contained:
            match = match_from_node("SENT-012", symbol.file, node, "path-flow")
            self.state.matches.append(
                replace(
                    match,
                    captures={
                        "sink_name": name,
                        **(
                            {"containment_gap": "checked-parent"}
                            if sink.checked_path_parent
                            else {}
                        ),
                        "flow_locations": json.dumps(
                            sorted(
                                sink.locations
                                | {(symbol.file.relative_path, node.lineno)}
                            )
                        ),
                    },
                )
            )
        if workbook:
            value = Value(
                key=_key(
                    "workbook",
                    symbol.file.relative_path,
                    str(node.lineno),
                    str(node.col_offset),
                    *self.call_sites,
                )
            )
            self.workbooks.add(value.key)
            return value
        return (
            replace(result, repository_object=True)
            if resolved == "git.Repo"
            else result
        )
    if receiver.key in self.workbooks and method in {
        "create_sheet",
        "close",
        "remove",
    }:
        return UNKNOWN_VALUE
    if method == "get" and (
        receiver.key in self.mapping_keys
        or (receiver.sources and receiver.instance is None)
    ):
        label = member_label(args[0]) if args else UNKNOWN_MEMBER
        if label is not UNKNOWN_MEMBER:
            member = self.member(receiver, label, env)
            get_default = args[1] if len(args) > 1 else Value(key="None")
            member = self.with_default(
                member,
                get_default,
                node.args[1] if len(node.args) > 1 else ast.Constant(None),
                env,
            )
            return replace(member, maybe_missing=False)
        return replace(
            receiver,
            key=receiver.key
            + "["
            + (ast.dump(node.args[0]) if node.args else "?")
            + "]",
            contained=False,
            checked_path_parent=False,
        )
    if (
        resolved in {"setattr", "builtins.setattr"}
        and root not in env
        and len(args) == 3
        and not unknown_args
        and not keywords
        and args[0].key in self.http_context.state_owners
        and isinstance(member_label(args[1]), str)
        and not str(member_label(args[1])).startswith("__")
        and not any(
            not isinstance(declaration, (ast.Import, ast.ImportFrom))
            for declaration in declarations
        )
    ):
        env["#setattr-target"] = args[0]
        self.assign(
            ast.Attribute(
                value=ast.Name(id="#setattr-target", ctx=ast.Load()),
                attr=str(member_label(args[1])),
                ctx=ast.Store(),
            ),
            args[2],
            env,
        )
        return Value(key="None")
    if (
        resolved in {"getattr", "builtins.getattr"}
        and root not in env
        and len(node.args) in {2, 3}
        and member_label(args[1]) is not UNKNOWN_MEMBER
        and not str(member_label(args[1])).startswith("__")
        and not any(
            not isinstance(declaration, (ast.Import, ast.ImportFrom))
            for declaration in declarations
        )
    ):
        member = self.member(args[0], member_label(args[1]), env)
        return (
            self.with_default(member, args[2], node.args[2], env)
            if member.maybe_missing and len(args) == 3
            else member
        )
    helper_name = name
    if name.startswith(("self.", "cls.")) and "." in symbol.name:
        helper_name = symbol.name.rsplit(".", 1)[0] + "." + name.split(".", 1)[1]
    helper = self.program.resolve_in(symbol, helper_name)
    callable_value = self.expression(symbol, node.func, env)
    bound_callable = self.callables.get(callable_value.key)
    if bound_callable:
        helper = bound_callable
    elif receiver.key in self.source_modules:
        helper = None
    elif isinstance(node.func, ast.Name):
        module = self.module_values[symbol.file.relative_path]
        if module.key in self.source_modules and (
            self.member_key(module, node.func.id) in env
            or "#member:unknown:" + module.key in env
        ):
            helper = None
    if receiver.instance and not bound_callable:
        owner_path, owner_name = receiver.instance
        owner_file = next(
            file for file in self.program.files if file.relative_path == owner_path
        )
        owner_symbol = self.program.resolve(owner_file, owner_name)
        helper = (
            self.program.instance_method(owner_symbol, method, after=super_owner)
            if owner_symbol
            else None
        )
    constructing: Value | None = None
    if (
        helper
        and isinstance(helper.node, ast.ClassDef)
        and (root not in env or bound_callable)
    ):
        fields = self.registrations.fields(helper)
        if fields is not None and len(args) <= len(fields) and None not in keywords:
            bindings = dict(zip(fields, args, strict=False))
            if not (bindings.keys() & keywords.keys()) and keywords.keys() <= set(
                fields
            ):
                bindings.update(
                    (key, value)
                    for key, value in keywords.items()
                    if key is not None
                )
                for field, default in self.registrations.defaults(helper).items():
                    if field not in bindings:
                        bindings[field] = self.expression(default, default.node, {})
                if set(bindings) == set(fields):
                    record = combine(
                        list(bindings.values()),
                        _key(
                            "record",
                            symbol.file.relative_path,
                            str(node.lineno),
                            str(node.col_offset),
                            *self.call_sites,
                        ),
                    )
                    self.record_keys.add(record.key)
                    for field, value in bindings.items():
                        marker = self.member_key(record, field)
                        env[marker] = replace(value, maybe_missing=False)
                        # A branch without this allocation does not make a
                        # declared field optional on the constructed record.
                        self.member_defaults[marker] = Value(
                            key="#missing", maybe_missing=True
                        )
                        self.required_members.add(marker)
                    return replace(
                        record,
                        instance=(helper.file.relative_path, helper.name),
                        maybe_missing=False,
                        maybe_none=False,
                    )
        instance = replace(
            result,
            key=_key(
                "instance",
                symbol.file.relative_path,
                str(node.lineno),
                str(node.col_offset),
                *self.call_sites,
            ),
            instance=(helper.file.relative_path, helper.name),
            maybe_missing=False,
            maybe_none=False,
        )
        if self.program.plain_instance(helper):
            return instance
        initializer = self.instance_member(instance, "__init__")
        if not (
            self.program.plain_instance(helper, inspect_init=True)
            and initializer is not None
            and isinstance(initializer.node, Function)
            and not initializer.node.decorator_list
            and not any(
                isinstance(part, ast.Attribute)
                and part.attr in {"__dict__", "__class__"}
                for part in ast.walk(initializer.node)
            )
        ):
            self.unresolved(symbol, node, "custom construction or instance state")
            return replace(result, instance=None)
        constructing = instance
        receiver = instance
        self.record_keys.add(instance.key)
        helper = initializer
    if (
        helper
        and isinstance(helper.node, Function)
        and any(
            not (
                isinstance(decorator, ast.Name)
                and decorator.id in {"staticmethod", "classmethod"}
                and not self.program.bindings[helper.file.relative_path].get(
                    decorator.id
                )
            )
            and not (
                isinstance(decorator, ast.Call)
                and len(decorator.args) == 1
                and not decorator.keywords
                and self.program.external(helper, decorator.func)
                == "functools.wraps"
            )
            for decorator in helper.node.decorator_list
        )
    ):
        self.unresolved(symbol, node, "decorated helper may replace behavior")
        helper = None
    if (
        helper
        and isinstance(helper.node, Function)
        and (
            name.split(".")[0] not in env
            or receiver.instance is not None
            or bound_callable is not None
        )
    ):
        parameters = helper.node.args
        positional = [p.arg for p in (*parameters.posonlyargs, *parameters.args)]
        descriptors = {
            decorator.id
            for decorator in helper.node.decorator_list
            if isinstance(decorator, ast.Name)
        }
        bound_parameter = (
            positional[0]
            if positional
            and "staticmethod" not in descriptors
            and (
                constructing is not None
                or "classmethod" in descriptors
                or super_owner is not None
                or callable_value.key in self.bound_receivers
                or ("." in helper.name and positional[0] in {"self", "cls"})
            )
            else None
        )
        if bound_parameter is not None:
            positional = positional[1:]
        bindings = dict(zip(positional, args, strict=False))
        valid = (
            not unknown_args
            and (len(args) <= len(positional) or parameters.vararg is not None)
            and not (set(bindings) & keywords.keys())
        )
        bindings.update(
            (key, value) for key, value in keywords.items() if key is not None
        )
        defaults = (
            dict(
                zip(
                    positional[-len(parameters.defaults) :],
                    parameters.defaults,
                    strict=False,
                )
            )
            if parameters.defaults
            else {}
        )
        defaults.update(
            (parameter.arg, default)
            for parameter, default in zip(
                parameters.kwonlyargs, parameters.kw_defaults, strict=True
            )
            if default is not None
        )
        all_parameters = [
            *positional,
            *(parameter.arg for parameter in parameters.kwonlyargs),
        ]
        if parameters.vararg is not None:
            tuple_key = _key(
                "arguments",
                symbol.file.relative_path,
                str(node.lineno),
                *self.call_sites,
            )
            extra_args = tuple(args[len(positional) :])
            self.argument_tuples[tuple_key] = extra_args
            bindings[parameters.vararg.arg] = combine(list(extra_args), tuple_key)
            all_parameters.append(parameters.vararg.arg)
        if parameters.kwarg is not None:
            extra = {
                key: value
                for key, value in bindings.items()
                if key not in all_parameters
            }
            for key in extra:
                del bindings[key]
            mapping = Value(
                key=_key(
                    "keywords",
                    symbol.file.relative_path,
                    str(node.lineno),
                    *self.call_sites,
                )
            )
            self.mapping_keys.add(mapping.key)
            for key, value in extra.items():
                env[self.member_key(mapping, key)] = value
            bindings[parameters.kwarg.arg] = mapping
            all_parameters.append(parameters.kwarg.arg)
        for parameter in all_parameters:
            if parameter not in bindings and parameter in defaults:
                bindings[parameter] = self.expression(
                    helper, defaults[parameter], {}
                )
        if (
            valid
            and set(bindings) == set(all_parameters)
            and not (
                {parameter.arg for parameter in parameters.posonlyargs}
                & keywords.keys()
            )
            and None not in keywords
        ):
            for name, value in self.closures.get(callable_value.key, {}).items():
                bindings.setdefault(name, value)
            if bound_parameter is not None:
                bindings[bound_parameter] = self.bound_receivers.get(
                    callable_value.key, receiver
                )
            bindings.update(
                (key, value)
                for key, value in env.items()
                if key.startswith(self.helper_state_prefixes)
                and not key.startswith("#member:")
            )
            # Carry reachable object state, not every temporary object from
            # the caller. Globals, closures and bound methods remain roots.
            pending = (
                [(value, False) for value in self.globals.values()]
                + [(value, True) for value in bindings.values()]
                + [
                    (self.module_values[file.relative_path], False)
                    for file in self.source_modules.values()
                ]
            )
            reached: set[str] = set()
            while pending:
                check_deadline(self.deadline)
                current, from_argument = pending.pop()
                if current.key in reached:
                    continue
                reached.add(current.key)
                # Scalars cannot expose additional helper state. Most cached
                # globals and member values are leaves; do not build empty
                # traversal generators and unknown-member tuples for them.
                if (
                    current.key not in self.members
                    and current.key not in self.instance_alternatives
                    and current.key not in self.argument_tuples
                    and current.key not in self.closures
                    and current.key not in self.bound_receivers
                    and "#member:unknown:" + current.key not in env
                ):
                    continue
                pending.extend(
                    (original, from_argument)
                    for original in self.instance_alternatives.get(current.key, ())
                )
                pending.extend(
                    (value, from_argument)
                    for value in self.argument_tuples.get(current.key, ())
                )
                pending.extend(
                    (value, from_argument)
                    for value in self.closures.get(current.key, {}).values()
                )
                if current.key in self.bound_receivers:
                    pending.append(
                        (self.bound_receivers[current.key], from_argument)
                    )
                for marker in (
                    *self.members.get(current.key, {}).values(),
                    "#member:unknown:" + current.key,
                ):
                    if marker in env:
                        value = env[marker]
                        # Unchanged globals load on use; carry caller mutations.
                        if from_argument or value is not self.global_members.get(
                            marker
                        ):
                            bindings[marker] = value
                        pending.append((value, from_argument))
            initial_instances = {
                value.key
                for value in bindings.values()
                if value.instance is not None
            }
            self.call_sites.append(
                f"{symbol.file.relative_path}:{node.lineno}:{node.col_offset}"
            )
            try:
                bindings["#callable-origin"] = callable_value
                returned = self.function(helper, bindings)
            finally:
                self.call_sites.pop()
            env.update(
                (key, value)
                for key, value in bindings.items()
                if key.startswith(self.helper_state_prefixes)
            )
            invalidated = {
                value.key
                for value in bindings.values()
                if value.key in initial_instances and value.instance is None
            }
            for key, value in env.items():
                if value.key in invalidated:
                    env[key] = replace(value, instance=None)
            if constructing is not None and bound_parameter is not None:
                initialized = bindings[bound_parameter]
                if initialized.instance is None:
                    self.unresolved(
                        symbol,
                        node,
                        "custom construction replaced methods "
                        "or exposed instance state",
                    )
                else:
                    for marker in self.members.get(initialized.key, {}).values():
                        if marker in env and not env[marker].maybe_missing:
                            self.member_defaults[marker] = Value(
                                key="#missing", maybe_missing=True
                            )
                            self.required_members.add(marker)
                return self.aggregate(initialized, env)
            # Propagate facts about actual values, not internal control markers.
            # Markers can share an empty key with unrelated unknown values.
            count_helper_facts(bindings)
            bound_values = [
                value
                for name, value in bindings.items()
                if value.key
                and not value.maybe_missing
                and not value.maybe_none
                and (
                    not name.startswith("#")
                    or name.startswith(("#member:", "#global-value:"))
                )
            ]
            protected = {value.key for value in bound_values if value.contained}
            option_checked = {
                value.key for value in bound_values if value.option_safe
            }
            url_checked: dict[str, Value] = {}
            for value in bound_values:
                if value.url_checks:
                    previous = url_checked.get(value.key)
                    url_checked[value.key] = (
                        replace(
                            value,
                            url_checks=value.url_checks | previous.url_checks,
                            locations=value.locations | previous.locations,
                        )
                        if previous is not None
                        else value
                    )
            if protected or option_checked or url_checked:
                for key, current in env.items():
                    checked = url_checked.get(current.key)
                    if (
                        checked
                        or current.key in protected
                        or current.key in option_checked
                    ):
                        env[key] = replace(
                            current,
                            contained=current.contained or current.key in protected,
                            option_safe=current.option_safe
                            or current.key in option_checked,
                            url_checks=current.url_checks | checked.url_checks
                            if checked
                            else current.url_checks,
                            locations=current.locations | checked.locations
                            if checked
                            else current.locations,
                        )
            return replace(
                returned, locations=returned.locations | result.locations
            )
    self.http_context.unknown_call(node, (*values, receiver), env)
    self.workbooks.difference_update(value.key for value in (*values, receiver))
    escaped = {
        value.key
        for value in (*values, receiver)
        if value.instance is not None
        or value.key in self.mapping_keys
        or value.key in self.record_keys
    }
    escaped.update(
        original.key
        for key in tuple(escaped)
        for original in self.instance_alternatives.get(key, ())
    )
    escaped.update(
        alias_owner.key
        for key in tuple(escaped)
        if (
            alias_owner := self.optional_mappings.get(key)
            or self.http_context.state_owners.get(key)
        )
        is not None
    )
    if escaped:
        changed = replace(
            combine(values),
            contained=False,
            checked_path_parent=False,
            option_safe=False,
            url_checks=frozenset(),
            credential_present=False,
            instance=None,
            operator_opt_in=frozenset(),
        )
        for owner in escaped:
            for marker in self.members.get(owner, {}).values():
                if marker in env:
                    env[marker] = replace(
                        combine([env[marker], changed]),
                        contained=False,
                        checked_path_parent=False,
                        option_safe=False,
                        url_checks=frozenset(),
                        credential_present=False,
                        instance=None,
                        operator_opt_in=frozenset(),
                        maybe_missing=True,
                    )
            env["#member:unknown:" + owner] = changed
        for key, value in env.items():
            if value.key in escaped:
                env[key] = replace(value, instance=None)
    if result.sources:
        self.unresolved(symbol, node, f"unresolved call to {name}")
    return replace(
        result,
        key=_key(
            symbol.file.relative_path,
            str(node.lineno),
            str(node.col_offset),
            name,
            result.key,
        ),
        contained=False,
        checked_path_parent=False,
        path_object=False,
        repository_object=False,
        instance=None,
        option_safe=False,
        url_checks=frozenset(),
        credential_present=False,
        operator_opt_in=frozenset(),
    )
