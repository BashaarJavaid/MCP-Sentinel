"""Count helper-return fact extraction; execute the original scanner logic."""
import ast,collections,hashlib,inspect,json,sys,textwrap,threading
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');sys.path[:0]=[str(root/'src'),str(root)]
from sentinel.static import workers,path_flow
out=Path(__file__).resolve().parent;rule=sys.argv[-1];counts=collections.Counter();stop=threading.Event()

def count_helper_facts(bindings):
 total=empty=eligible=eligible_empty=contained=option=url=0
 for name,value in bindings.items():
  total+=1
  no_facts=not (value.contained or value.option_safe or value.url_checks)
  empty+=no_facts
  if value.key and not value.maybe_missing and not value.maybe_none and (not name.startswith('#') or name.startswith(('#member:','#global-value:'))):
   eligible+=1;eligible_empty+=no_facts;contained+=bool(value.contained);option+=bool(value.option_safe);url+=bool(value.url_checks)
 counts.update(calls=1,bindings=total,empty_facts=empty,eligible=eligible,eligible_empty=eligible_empty,contained=contained,option_safe=option,url_checks=url)

original=textwrap.dedent(inspect.getsource(path_flow.PathFlow.call));needle='                bound_values = [';assert original.count(needle)==0
needle='            bound_values = [';assert original.count(needle)==1
instrumented=original.replace(needle,'            count_helper_facts(bindings)\n'+needle,1)
before=ast.parse(original);after=ast.parse(instrumented);removed=0
for node in ast.walk(after):
 if hasattr(node,'body') and isinstance(node.body,list):
  kept=[]
  for statement in node.body:
   if isinstance(statement,ast.Expr) and isinstance(statement.value,ast.Call) and isinstance(statement.value.func,ast.Name) and statement.value.func.id=='count_helper_facts':removed+=1
   else:kept.append(statement)
  node.body=kept
assert removed==1 and ast.dump(before)==ast.dump(after)
source='from __future__ import annotations\n'+instrumented
file=out/(rule+'-instrumented-call.py');file.write_text(source)
namespace=dict(path_flow.__dict__,count_helper_facts=count_helper_facts);exec(compile(source,str(file),'exec'),namespace);path_flow.PathFlow.call=namespace['call']
identity={'rule':rule,'original_call_sha256':hashlib.sha256(original.encode()).hexdigest(),'instrumented_call_sha256':hashlib.sha256(source.encode()).hexdigest(),'original_ast_preserved_except_counter_call':True,'source_values_recorded':False}
def snapshot(final=False):
 data={**identity,'counts':dict(counts),'final_worker_snapshot':final};path=out/(rule+'-helper-fact-counts.json');tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def snapshots():
 while not stop.wait(15):snapshot()
thread=threading.Thread(target=snapshots,daemon=True);thread.start()
try:workers._worker()
finally:stop.set();thread.join();snapshot(True)
