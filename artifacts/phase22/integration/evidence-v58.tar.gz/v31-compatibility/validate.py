"""Validate retained attempts and compare source-bound reports without new scans."""
import hashlib
import importlib.util
import json
from pathlib import Path
from sentinel.report.validate_json import validate_report_data
from sentinel.report.validate_sarif import validate_sarif_data

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;RAW=OUT/'raw';ASSETS=OUT.parent/'v30-compatibility-proposal'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
spec=importlib.util.spec_from_file_location('compat',ASSETS/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
proposal=m.approved();packet=read(RAW/'packet.json');launch=read(OUT/'launch-completed.json')
assert packet['budget_closed'] and packet['scanner']==proposal['scanner']
assert packet['proposal_sha256']==sha(ASSETS/'evaluation-proposal.json') and packet['approval_sha256']==sha(ASSETS/'evaluation-authorization.json')
assert packet['model_calls']==0 and not packet['target_execution']
assert packet['unstarted']==proposal['order'][len(packet['attempts']):]
for name,digest in packet['files_sha256'].items():assert sha(RAW/name)==digest,name
assert launch['log_sha256']==sha(OUT/'sequence.log')
rows=[];previous={}
def differences(a,b,pointer=''):
 if isinstance(a,dict) and isinstance(b,dict):return [v for key in sorted(a.keys()|b.keys()) for v in differences(a.get(key),b.get(key),pointer+'/'+key)]
 return [] if a==b else [{'pointer':pointer,'before':a,'after':b}]
for attempt,expected in zip(packet['attempts'],proposal['order']):
 assert all(attempt[k]==v for k,v in expected.items())
 row=dict(attempt);g=proposal['groups'][attempt['group']];item=g['inputs'][attempt['input_id']];folder=RAW/attempt['directory'];path=folder/attempt['input_id']/'report.json'
 if attempt['state']=='completed':
  m.prior.completed(attempt['timing']);assert attempt['timing']['elapsed_including_cleanup_seconds']-attempt['timing']['elapsed_seconds']<=15
  result=read(folder/'results.json');report=read(path)
  assert result['scanner']==proposal['scanner'] and result['manifest_sha256']==g['manifest_sha256']
  assert result['model_calls']==0 and not result['requests']
  assert len(result['outcomes'])==1 and result['outcomes'][0]['state']=='completed'
  assert sha(path)==result['outcomes'][0]['report_sha256']
  assert sha(path.parent/'configuration.json')==item['configuration_sha256']
  validate_report_data(report);validate_sarif_data(read(path.with_suffix('.sarif')))
  assert report['analysisComplete'] and report['executionSuccessful']
  reference=read(ROOT/item['reference_report']);excluded=set(proposal['volatile_exclusions'])
  condition=m.condition(report,reference,item['assessment'],item['input']['label'],excluded)
  assert condition==attempt['condition']
  canonical=m.supervisor.clean(report,excluded);old=m.supervisor.clean(reference,excluded)
  if attempt['batch']=='repeat':assert previous[attempt['input_id']]==canonical and attempt['ordered_repeat_equal']
  else:previous[attempt['input_id']]=canonical
  row.update(report_sha256=sha(path),reference_sha256=sha(ROOT/item['reference_report']),reference_deltas=differences(old,canonical),finding_count=len(report['findings']),warning_count=len(report['warnings']),coverage=report['static_analysis']['coverage'])
 rows.append(row)
if packet['passed']:
 assert launch['exit_code']==0 and len(rows)==54 and not packet['unstarted']
 assert all(r['state']=='completed' and r['condition']['condition_passed'] for r in rows)
else:assert launch['exit_code']!=0 and packet['stop_reason']
result={'scanner':proposal['scanner'],'passed':packet['passed'],'stop_reason':packet.get('stop_reason'),'budget_closed':True,'remaining':0,'unstarted_closed':packet['unstarted'],'attempts':rows,'raw_packet_sha256':sha(RAW/'packet.json'),'launch_sha256':sha(OUT/'launch-completed.json'),'validator_sha256':sha(Path(__file__)),'source_assessment_pending':True,'paid_calls':0}
p=OUT/'validation.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print('Validated',len(rows),'attempts;gate',packet['passed'],';closed',len(packet['unstarted']),'unstarted.')
