"""Source-assess changed diagnostics; reuse unchanged findings at exact identities."""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path
from scripts.phase22_corpus import frozen,input_files
from scripts.phase20_corpus import validate

ROOT=Path.cwd();OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v30-compatibility-proposal'
read=lambda p:json.loads(p.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
validation=read(OUT/'validation.json');proposal=read(ASSETS/'evaluation-proposal.json')
source_cache={};rows=[];summaries=[]
reviews={
'__tests__/real-life/test-gzip-fix.ts':{'console':'The standalone upstream gzip test logs progress and errors. This is unexecuted test output, not a caller destination check.','err':'The catch path logs a failed fetch and continues to the next constant test URL. No test request was executed.','err.message':'The error message is passed to the test failure logger after a failed fetch. It does not reject the MCP caller URL.'},
'__tests__/run-all.ts':{'console':'The upstream suite runner prints results and fatal errors; these are test harness output operations.','error':'Caught suite errors and stored error strings are reported by the test runner, outside the named MCP URL condition.','Math':'Math.round computes a test success percentage after test results are collected; it is not URL validation.','category':'The destructured unit/integration category is printed in a per-suite summary, not used as a URL guard.','process':'The suite runner sets the exit code after tests or a fatal error. This upstream runner was only read, never executed.'},
'__tests__/unit/url-reader.test.ts':{'process':'A module-entry check and final exit status govern the standalone unit test. Neither was executed.','process.argv':'import.meta.url is compared with process.argv[1] to decide whether to start upstream tests; this is not caller-URL validation.','console':'The unit test logs its title and catches startup rejection; no source test was run.','console.error':'The standalone runner sends an unhandled rejection to console.error; no protection or successful runtime is inferred.','error':'Tests catch expected URL/network/HTTP errors and inspect messages/types. Assertions in upstream tests do not establish runtime protection of the tool.','error.message':'Expected error-message assertions occur in the test body after attempted test fetches; they are not the named production destination guard.','error.name':'Tests check the error class name when accepting expected failures. No target tests executed or coverage inferred.','Buffer':'Buffer.from prepares an HTML payload for a gzip unit test response; it does not constrain a caller destination.'},
'__tests__/helpers/test-utils.ts':{'console':'The test wrapper prints progress, counts and stored failures; these operations do not guard the MCP URL.','Promise':'The wrapper checks whether a test callback returns a Promise and awaits it. This is test sequencing, not destination enforcement.','error':'The wrapper catches a failed test and records its message, outside the named production URL guard.','error.message':'The wrapper formats a failed test message for storage and logging; it is not a destination rejection.','Math':'Math.round computes the displayed test success rate, not a URL classification.'},
}
reviews['__tests__/unit/url-reader.test.ts'].update({'process.env':'The unit test saves and restores its explicit private-URL opt-in environment setting. This source was not executed; production default-loopback qualification retains its separate source-bound judgment.','process.env.MCP_HTTP_ALLOW_PRIVATE_URLS':'The unit test temporarily sets the private-URL override, then restores its original value. This test setting does not establish the production default or change the frozen named condition.'})
flow_reviews={
 ('src/cache.ts','unsupported class inheritance, decorators or members'):'The SimpleCache class stores entries in a Map, starts a cleanup interval and expires entries by timestamp. SENT-012 retains conservative class/member uncertainty. Added repeated occurrences arise through additional module entry analysis; neither cache semantics nor destination safety is proved.',
 ('src/error-handler.ts','unsupported class inheritance, decorators or members'):'MCPSearXNGError extends the builtin Error and sets its name after super(message). Conservative inheritance uncertainty remains visible; this class is not a caller destination guard.',
 ('src/proxy.ts','unsupported control flow'):'The continue skips empty NO_PROXY patterns before hostname matching. This is proxy routing policy, not proof that the initial caller destination is public.',
 ('src/tls-config.ts','unsupported control flow'):'The catch/continue tries the next CA file when one is unreadable. This is certificate configuration fallback, separate from the named initial IPv4 loopback restriction.',
 ('__tests__/unit/url-reader.test.ts','member deletion invalidates receiver'):'The upstream unit test deletes its temporary MCP_HTTP_ALLOW_PRIVATE_URLS setting when the original value was undefined, otherwise restores it. Conservative receiver invalidation remains appropriate. No upstream test or environment mutation was executed.',
}
config_meanings={'DEFAULT_SEARCH_ENGINE':'default search provider','ALLOWED_SEARCH_ENGINES':'provider allowlist','SEARCH_MODE':'request/browser search mode','PROXY_URL':'operator proxy destination','USE_PROXY':'operator proxy opt-in','FETCH_WEB_INSECURE_TLS':'explicit TLS verification override','PLAYWRIGHT_PACKAGE':'browser client package selection','PLAYWRIGHT_HEADLESS':'browser display mode','PLAYWRIGHT_NAVIGATION_TIMEOUT_MS':'browser navigation deadline','ENABLE_CORS':'HTTP CORS opt-in','CORS_ORIGIN':'HTTP allowed origin','MODE':'HTTP/stdio startup mode','OPEN_WEBSEARCH_QUIET_STARTUP':'startup log suppression'}
reviews['src/config.ts']={
 'process':'Configuration reads operator environment settings at module initialization; these values are distinct from caller tool arguments. Unknown binding remains visible and no target configuration was executed.',
 'process.env':'The module reads optional operator environment configuration. Unresolved binding is retained; no environment value is assumed to establish the named mapped-loopback rejection.',
 'console':'The module reports configuration defaults, invalid settings and selected operating modes at startup. Logging is not destination validation and target startup was not executed.',
 **{'process.env.'+name:'The source reads the '+meaning+' setting from operator environment during configuration initialization. This is separate from the named initial mapped-loopback condition; no runtime setting, safe destination or protection is inferred.' for name,meaning in config_meanings.items()},
}
reviews['src/test/test-github.ts']={
 'console':'The standalone GitHub README test suite logs progress, result summaries and caught failures. Source tests were not executed.',
 'Date':'Date.now measures elapsed time around upstream test fetches and the test suite. It is timing instrumentation in target source, not destination enforcement.',
 'error':'The upstream README tests catch and classify exceptions in result reporting. Test expectations do not establish production protection; no test fetch ran.',
 'process':'The standalone test main sets a failing exit status after an exception. Target main was only read, not executed.',
}
flow_reviews.update({
 ('src/cli/runCli.ts','indexed array alias unresolved'):'The CLI reads argv[index] or argv[index+1] while parsing search/fetch flags, including limit, engine(s), search-mode and max-chars. Adjacent source checks reject missing/flag-shaped values. The scanner retains unknown array aliasing; this is not proof of command injection or the named MCP mapped-loopback bypass.',
 ('src/test/test-mcp-adapter.ts','indexed array alias unresolved'):'The adapter test reads seenCalls[0] to assert that searchMode/readability/includeLinks reach a mocked call. This test assertion is not a production destination guard. No target tests ran; conservative indexed-alias uncertainty remains visible.',
})
reviews['src/utils.ts']={'console':'Mastra exports console.error as its log function to keep logging off MCP stdio stdout. This is diagnostic output, not the directory permission/enforcement condition. No target logging code was executed.'}

reviews['index.ts']={
 'console':'The filesystem server logs usage, allowed-directory validation errors, startup state and fatal errors to stderr. These logs are not the containment check, and startup was not executed.',
 'dir':'The startup loop validates operator-supplied allowed-directory arguments and reports invalid/inaccessible directories. Conservative loop binding uncertainty is retained; operator roots are distinct from caller file paths.',
 'dynamic tool description':'The filesystem ListTools response includes descriptions assembled from source strings. The scanner retains metadata-resolution uncertainty. This does not establish absent descriptions or complete inspection of every tool; the named containment findings remain exactly source-bound.',
}
flow_reviews.update({
 ('index.ts','indexed array alias unresolved'):'The byte-size formatter indexes a units array using a logarithm-derived display unit. This affects human-readable output formatting, not path containment. Conservative indexed-alias uncertainty remains visible.',
 ('index.ts','SDK instance escapes to an unresolved call'):'runServer passes the stdio transport to server.connect. Receiver escape is conservatively unresolved; no startup success, complete dispatch coverage or runtime protection is inferred.',
})
mobile_classes={
 ('src/android.ts',75):'AndroidRobot implements Robot and stores a constructor parameter property before forming adb argv. Conservative class/member uncertainty remains; neither complete device-flow coverage nor safe command execution is inferred.',
 ('src/image-utils.ts',9):'ImageTransformer stores a buffer parameter property plus mutable resize/format options. The unresolved class covers image transformation state, not proof of output-path containment.',
 ('src/image-utils.ts',117):'Image wraps a buffer parameter property and constructs ImageTransformer instances. This image-data wrapper does not establish destination-path rejection.',
 ('src/ios.ts',43):'IosRobot implements Robot with a deviceId parameter property and asynchronous socket/device helpers. The scanner retains class/member uncertainty; no device connection or runtime protection was tested.',
 ('src/iphone-simulator.ts',33):'Simctl implements Robot and stores a readonly simulator UUID parameter property, then uses simulator/WebDriver helpers. Conservative class uncertainty remains; no simulator started.',
 ('src/mobile-device.ts',62):'MobileDevice implements Robot, stores deviceId and constructs Mobilecli before forming device-command arguments. Unresolved class modeling is retained without claiming complete command/device coverage.',
 ('src/png.ts',6):'PNG stores a readonly buffer parameter property and checks a PNG signature before reading dimensions. That data-format check is separate from output-path containment.',
 ('src/robot.ts',6):'This source declaration is the ScreenSize interface extending Dimensions, not an executable runtime class. The generic unsupported-class diagnostic records static type/inheritance uncertainty and is not runtime proof.',
 ('src/robot.ts',39):'ActionableError extends builtin Error and forwards the message through super. Conservative inheritance uncertainty remains; this error wrapper does not enforce an output boundary.',
 ('src/webdriver-agent.ts',25):'WebDriverAgent stores host/port parameter properties and constructs status requests. The retained class uncertainty does not prove safe network destinations, successful device access or output-path containment.',
}
reviews['src/utils/kubernetes-manager.ts']={
 '../types.js:ResourceTracker':'The manager imports a ResourceTracker type through the compatibility barrel and uses it for tracked resource entries. src/types.ts re-exports the declared interface in models/resource-models.ts. Binding remains unresolved in this analysis path; no missing runtime export or command safety is inferred.',
 '../types.js:PortForwardTracker':'The manager imports the re-exported PortForwardTracker interface for its port-forward tracking array/method. This is tracking metadata, separate from the named kubectl_get command construction.',
 '../types.js:WatchTracker':'The manager imports the re-exported WatchTracker interface for tracked watches. Conservative barrel/type resolution uncertainty is retained, not treated as an absent declaration or runtime vulnerability.',
}
reviews['tests/service.test.ts']={'../src/types:CreateNamespaceResponseSchema':'The upstream test imports the Zod response schema through the compatibility barrel. Its definition is present in models/response-schemas.ts; this analysis path leaves the re-export unresolved. The import is test setup, not the named production command guard, and no test ran.'}
flow_reviews.update({
 ('src/models/helm-models.ts','unsupported class inheritance, decorators or members'):'These source declarations are HelmInstallOperation/HelmUpgradeOperation interfaces extending other interfaces. The generic unsupported-class warning denotes unresolved static type inheritance, not an executable class or proof of Helm-command protection. Helm was not rendered or executed.',
 ('vitest.config.ts','unsupported class inheritance, decorators or members'):'KubectlSequencer extends Vitest BaseSequencer, delegates sorting to super and moves kubectl.test.ts last. This is external test-framework configuration. Its class is unresolved and target tests/configuration were never executed.',
})
def files_for(group,input_id):
 if group not in source_cache:
  g=proposal['groups'][group];source_cache[group]=validate() if group=='historical' else frozen(approval_path=ROOT/g['source_freeze_approval'])
 m=source_cache[group];i=next(i for i in m.inputs if i.id==input_id);s=next(s for s in m.snapshots if s.revision==i.snapshot)
 files=input_files(i,s,ROOT);prefix='' if i.scan_root=='.' else i.scan_root+'/'
 return {name[len(prefix):]:data for name,data in files.items() if name.startswith(prefix)}
for attempt in validation['attempts']:
 if attempt['state']!='completed':continue
 group=attempt['group'];input_id=attempt['input_id'];expected=proposal['groups'][group]['inputs'][input_id]
 report=read(OUT/'raw'/attempt['directory']/input_id/'report.json');old=read(ROOT/expected['reference_report']);files=files_for(group,input_id)
 assert attempt['condition']['ordered_findings_equal'], 'Changed findings require separate source adjudication'
 before=len(rows)
 for pointer,left,right in [('warnings',old['warnings'],report['warnings']),('unresolved_flows',old['static_analysis']['coverage']['unresolved_flows'],report['static_analysis']['coverage']['unresolved_flows'])]:
  key=lambda x:json.dumps(x,sort_keys=True)
  a,b=Counter(map(key,left)),Counter(map(key,right))
  for direction,changes in [('added',b-a),('removed',a-b)]:
   for occurrence,text in enumerate(changes.elements()):
    diagnostic=json.loads(text);message=diagnostic['message']
    binding=re.fullmatch(r"(.*): cannot resolve TypeScript binding '(.*)'",message)
    if binding:
     path,name=binding.groups();assert group in {'searxng','openwebsearch'} or (group=='development' and input_id.startswith('mastra-') and path=='src/utils.ts') or (group=='historical' and input_id.startswith('filesystem-prefix-') and path=='index.ts') or (group=='historical' and input_id.startswith('kubernetes-shell-') and path in {'src/utils/kubernetes-manager.ts','tests/service.test.ts'});assessment=reviews[path][name];lines=files[path].decode().splitlines();locations=[n for n,line in enumerate(lines,1) if ('description:' if name=='dynamic tool description' else name.rsplit(':',1)[-1]) in line]
    else:
     flow=re.fullmatch(r'SENT-\d+ at (.*):(\d+): (.*); protection is not established',message);assert flow,message
     path,line,reason=flow.groups();locations=[int(line)];lines=files[path].decode().splitlines()
     if path=='__tests__/real-life/test-gzip-fix.ts':
      assert int(line) in {75,83} and reason=='unsupported control flow' and lines[int(line)-1].strip()=='continue;'
      assessment='The standalone gzip test continues after a failed request or empty response. Conservative unresolved flow is retained. This is outside the named MCP URL guard; no upstream test or network request executed.'
     elif path=='src/url-reader.ts':
      assert reason=='unsupported control flow'
      if 'for (let redirects' in lines[int(line)-1]:
       assessment='The bounded redirect loop builds each subsequent request and dispatcher. The named condition concerns the initial literal loopback request with opt-ins unset; unresolved redirect flow does not establish complete redirect, DNS or IPv6 protection.'
      else:
       assert 'for (let i =' in lines[int(line)-1]
       assessment='The counted loop locates the start or end of a Markdown heading section in already fetched response text. Conservative loop uncertainty is retained; it is separate from initial destination validation.'
     elif input_id.startswith('mobile-'):
      assert reason=='unsupported class inheritance, decorators or members'
      assessment=mobile_classes[(path,int(line))]
     else:assessment=flow_reviews[(path,reason)]
    assert locations
    related=[]
    if binding and input_id.startswith('kubernetes-shell-'):
     declarations={'ResourceTracker':('src/models/resource-models.ts',27),'PortForwardTracker':('src/models/resource-models.ts',34),'WatchTracker':('src/models/resource-models.ts',43),'CreateNamespaceResponseSchema':('src/models/response-schemas.ts',9)}
     if name.rsplit(':',1)[-1] in declarations:
      target,number=declarations[name.rsplit(':',1)[-1]]
      for source,ns in [('src/types.ts',range(1,len(files['src/types.ts'].decode().splitlines())+1)),(target,[number])]:
       content=files[source].decode().splitlines();related.append({'source_path':source,'sha256':sha(files[source]),'lines':[{'line':n,'text':content[n-1]} for n in ns]})
    rows.append({'group':group,'batch':attempt['batch'],'input_id':input_id,'kind':pointer,'direction':direction,'occurrence':occurrence,'diagnostic':diagnostic,'source_path':path,'source_scan_root':expected['input']['scan_root'],'source_sha256':sha(files[path]),'source_lines':[{'line':n,'text':lines[n-1]} for n in locations],'assessment':assessment,'runtime_proof':False,'related_sources':related})
 pointers={d['pointer'] for d in attempt['reference_deltas']}
 assert pointers <= {'/warnings','/static_analysis/coverage/unresolved_flows'},pointers
 summaries.append({'group':group,'batch':attempt['batch'],'input_id':input_id,'unchanged_findings':len(report['findings']),'prior_assessment':proposal['groups'][group]['assessment_path'],'reference_report_sha256':attempt['reference_sha256'],'new_report_sha256':attempt['report_sha256'],'source_assessed_delta_occurrences':len(rows)-before,'entire_report_equal_to_reference':not pointers,'unchanged_diagnostics_and_surfaces':'Retain their existing source assessments at the exact reference report; these are not new diagnostic occurrences or a broader coverage claim.'})
p=OUT/'source-assessment.json';assert not p.exists();p.write_text(json.dumps({'summaries':summaries,'rows':rows,'counts':dict(Counter((r['kind']+'_'+r['direction']) for r in rows)),'unassessed':0,'source_only':True,'paid_calls':0},indent=2)+'\n');print('Assessed',len(rows),'changed diagnostic occurrences across',len(summaries),'completed observations.')
