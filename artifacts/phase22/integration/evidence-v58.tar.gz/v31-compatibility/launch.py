"""Run the one approved serial sequence and retain its exact command and exit."""
import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4];OUT=Path(__file__).resolve().parent
SCANNER=Path('/private/tmp/mcp-phase22-frozen-f85a90f')
ASSETS=OUT.parent/'v30-compatibility-proposal'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
subprocess.run([sys.executable,str(OUT/'owned-work-preflight.py')],cwd=ROOT,check=True)
assert not subprocess.check_output(['git','status','--porcelain'],cwd=SCANNER)
assert not (ASSETS/'execution-consumed.json').exists()
command=[sys.executable,'-I',str(ASSETS/'evaluate.py'),'run',str(OUT/'raw')]
env={k:v for k,v in os.environ.items() if not k.startswith(('OPENAI_','SENTINEL_'))}
env['PATH']=str(Path(sys.executable).parent)+':'+env['PATH']
receipt={'command':command,'cwd':str(SCANNER),'recorded_at':datetime.now(timezone.utc).isoformat(),'runner_sha256':sha(ASSETS/'evaluate.py'),'approval_sha256':sha(ASSETS/'evaluation-authorization.json'),'proposal_sha256':sha(ASSETS/'evaluation-proposal.json'),'credentials_removed':True,'paid_calls_authorized':0,'target_execution':False}
p=OUT/'launch-started.json'
with p.open('x') as f:json.dump(receipt,f,indent=2)
started=time.monotonic()
with (OUT/'sequence.log').open('xb') as log:
 result=subprocess.run(command,cwd=SCANNER,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-started,log_sha256=sha(OUT/'sequence.log'))
(OUT/'launch-completed.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Approved sequence exited',result.returncode,'after',receipt['elapsed_seconds'],'seconds.',flush=True)
raise SystemExit(result.returncode)
