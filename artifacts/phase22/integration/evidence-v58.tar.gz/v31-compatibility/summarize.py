"""Close the actually consumed scope only after validation and source assessment."""
import hashlib
import json
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path

OUT=Path(__file__).resolve().parent;ASSETS=OUT.parent/'v30-compatibility-proposal'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
v=read(OUT/'validation.json');s=read(OUT/'source-assessment.json');p=read(ASSETS/'evaluation-proposal.json');launch=read(OUT/'launch-completed.json')
assert s['unassessed']==0 and v['budget_closed']
groups=defaultdict(list)
for row in v['attempts']:groups[(row['group'],row['batch'])].append(row)
rows=[]
for (group,batch),attempts in groups.items():
 completed=[a for a in attempts if a['state']=='completed'];positives=[a for a in completed if p['groups'][group]['inputs'][a['input_id']]['input']['label']=='vulnerable'];negatives=[a for a in completed if a not in positives]
 rows.append({'group':group,'batch':batch,'attempted':len(attempts),'completed':len(completed),'vulnerable_observed':len(positives),'vulnerable_condition_hits':sum(a.get('condition',{}).get('condition_passed') is True for a in positives),'negative_observed':len(negatives),'negative_condition_failures':sum(a.get('condition',{}).get('condition_passed') is not True for a in negatives),'all_conditions_passed':all(a.get('condition',{}).get('condition_passed') for a in completed),'entire_ordered_repeats_equal':all(a.get('ordered_repeat_equal') for a in completed) if batch=='repeat' else None,'maximum_whole_input_seconds':max((a['timing']['elapsed_seconds'] for a in completed),default=None),'maximum_native_seconds':max((a['native_seconds'] for a in completed),default=None)})
completed=[a for a in v['attempts'] if a['state']=='completed']
result={'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':v['scanner'],'compatibility_gate_passed':v['passed'],'stop_reason':v['stop_reason'],'budget':{'sequences_consumed':1,'native_attempted':len(v['attempts']),'native_completed':len(completed),'native_unstarted_closed':len(v['unstarted_closed']),'remaining':0,'closed':True,'retries':0,'profiles':0,'comparators':0,'paid_calls':0,'target_execution':False},'groups':rows,'timing_classes':dict(Counter(a['timing_class'] for a in completed)),'sequence_elapsed_seconds':launch['elapsed_seconds'],'source_assessment_counts':s['counts'],'source_assessment_complete':True,'same_finding_lists_required':True,'prior_whole_batch_timing':'Approved whole25 development reuse and45+45 historical passes remain measured at1f3f72f under120target/300maximum. These54 local TypeScript observations never constitute a new whole-batch Linux timing pass. Python15development+31historical results retain the source-only compatibility proof.','fresh_result':'Original fresh1f3f72f has15completed observations,0/2hits per native batch and comparator. Lighthouse subsequently passes10 exposed observations atf85a90f. No fresh generalization, runtime proof or independent human review follows.','new_paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False,'references_sha256':{n:sha(OUT/n) for n in ['validation.json','source-assessment.json','launch-started.json','launch-completed.json','binding.json']}}
path=OUT/'assessment.json';assert not path.exists();path.write_text(json.dumps(result,indent=2)+'\n');print('Compatibility gate',v['passed'],';',len(completed),'completed;',len(v['unstarted_closed']),'closed unstarted.')
