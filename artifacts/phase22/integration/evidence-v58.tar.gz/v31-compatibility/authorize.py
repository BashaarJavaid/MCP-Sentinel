"""Record the exact approved local sequence and verify immutable inputs."""
import hashlib
import importlib.util
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path(__file__).resolve().parents[4]
OUT=Path(__file__).resolve().parent
ASSETS=OUT.parent/'v30-compatibility-proposal'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head=='735e24eb070f203a1a3af337537586109e186d43'
p=ASSETS/'evaluation-proposal.json';proposal=json.loads(p.read_text())
assert p.read_bytes()==subprocess.check_output(['git','show',head+':'+p.relative_to(ROOT).as_posix()],cwd=ROOT)
receipt={'recorded_at':datetime.now(timezone.utc).isoformat(),'approved':True,'user_decision':'approved.','approval_context':'Direct approval of the exact54-observation local serial compatibility proposal delivered at735e24e. No additional paid calls, target execution, retries or final technical acceptance.','delivery_at_approval':head,'proposal_path':p.relative_to(ROOT).as_posix(),'proposal_sha256':sha(p),'scanner':proposal['scanner'],'bounds':proposal['bounds'],'order':proposal['order'],'stop':proposal['stop'],'exposure':proposal['exposure'],'technical_acceptance':False,'paid_calls_authorized':0}
a=ASSETS/'evaluation-authorization.json';assert not a.exists();a.write_text(json.dumps(receipt,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('compat',ASSETS/'evaluate.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
assert m.approved()==proposal
m.selfcheck()
# These checks validate source archives and scanner identity without any analysis run.
for group in proposal['groups']:
 checked,manifest,selected=m.identity(group)
 print('Verified source-only',group,len(selected),flush=True)
assert not (ASSETS/'execution-consumed.json').exists()
files={**proposal['files_sha256'],p.relative_to(ROOT).as_posix():sha(p),a.relative_to(ROOT).as_posix():sha(a)}
(OUT/'binding.json').write_text(json.dumps({'recorded_at':datetime.now(timezone.utc).isoformat(),'scanner':proposal['scanner'],'files':files,'source_only':True,'corpus_observations':0,'paid_calls':0,'python':__import__('sys').version,'platform':__import__('platform').platform()},indent=2)+'\n')
print('Approved54-observation sequence bound;zero observations before execution.')
