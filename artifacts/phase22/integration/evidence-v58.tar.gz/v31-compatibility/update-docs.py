"""Prepare the final technical acceptance packet from completed evidence."""
import hashlib
import json
from pathlib import Path

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(OUT/'assessment.json');audit=read(OUT/'audit.json')
assert a['compatibility_gate_passed'] and audit['acceptance_packet_ready']
common='''All current Phase 22 technical gates are ready for **explicit human acceptance**.
**Phase 22 remains incomplete** until that decision and subsequent closeout delivery.

At frozen scanner **`f85a90f`**, the approved local compatibility sequence passes
**54/54 observations**: each of SearXNG, fetch-mcp and open-webSearch completes two
whole five-input batches with two correlated vulnerable hits and zero matching
condition alerts on three negatives per batch. All **15 entire ordered repeats**
agree after only the established 11 volatile exclusions. The ten development and
14 historical TypeScript inputs each complete once with unchanged ordered findings
and named-condition outcomes: **4/4** and **6/6** vulnerable hits, respectively,
and zero matching alerts on six and eight negatives. These are partial compatibility
checks, never a pooled whole-batch execution claim.

All 54 observations meet the **120-second target**, with a longest whole input of
**114.274 seconds**, within the uniform 300-second maximum. The single serial
sequence took **2,363.732 seconds**. JSON/SARIF and owned process cleanup validate.
All **3,216 changed diagnostic occurrences** are individually source-assessed:
1,080 warnings and 2,126 unresolved flows added; five warnings and five flows removed.
Unchanged findings retain their exact source-assessed references. Diagnostic removal
does not prove runtime safety; unresolved coverage and raw unmatched scorer keys remain
visible. **One sequence and all 54 observations consumed; zero budget remains.**

The separately approved Lighthouse regression passes **10/10** at the same scanner,
workflow `75142f0`, run
[34648036083](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34648036083).
Both whole batches detect two correlated vulnerable variants and preserve the narrow
IPv4 link-local qualifier on fixed/control sources; all five ordered repeats agree.
Its 10 findings, 974 warnings, 624 unresolved-flow occurrences and 20 unresolved
surfaces are source-assessed. Broader SSRF candidates remain visible.

The accepted whole **25 development + 45 historical + 45 historical** Linux gate
retains measured scanner **`1f3f72f`**. The 98-observation refresh completed all inputs:
72 within 120 seconds, 26 using extended time, maximum **176.032 seconds**.
Each whole historical batch has 20/20 vulnerable hits and zero matching alerts on
25 negatives. Whole development reuse retains ten vulnerable hits, two raw Meta
operator erratum alerts and zero matching alerts on 13 valid negatives. Source-only
AST/configuration proof establishes unchanged Python paths for 15 development and
31 historical inputs. Current TypeScript compatibility does not relabel old timing
or establish a new whole-batch Linux performance result.

Product, tests, packages and workflows still equal verified **`439c3fe`**: local
and all 12 hosted suites pass **2,242 tests / 36 skips**, local branch coverage
**89.76%**, all **29 normal jobs** and docs pass. Packaging, installed-wheel/Docker/
isolation, Ruff/format/strict mypy, lock/schema/notices/offline artifacts and six
production-request replays retain their exact source bindings. **Zero additional
paid calls.** Git runtime/image are unchanged; 13 campaigns remain incomplete at
**312/1,040** tested attempts.

The proposed acceptance explicitly retains the original fresh-source result at
`1f3f72f`: **15 completed observations, 0/2 vulnerable hits in each native batch and
comparator**. The later corrections and passes are exposed regressions, not fresh
generalization or independent human review. The original held-out result remains
ten completed, ten unsupported and five incomplete, with zero hits among four
completed vulnerable inputs out of ten vulnerable inputs total. All earlier failed
optimizations, stopped sequences and invalid v4 novelty are preserved with their
superseding evidence; no failed attempt is turned into a pass or reopened budget.

The audit contains **89 original rows: 84 passed, two user-deferred, two proposed
documented limitations and one pending human acceptance**. Its **83 added rows**
contain 78 passed and five proposed dispositions of superseded historical failures.
Those dispositions require the actual acceptance decision; no new limitation is
accepted in advance. Pilots/full paid benchmark remain deferred and nonblocking;
Phase 21 remains incomplete and Phase 24/15 gates are unchanged. No merge, ready-state,
release, outreach, participant source sharing or Phase 23 is authorized.
'''
names=['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','docs/phase22-timeout-policy.md','docs/phase22-corpus-review.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/requirements.md','artifacts/phase22/integration/progress.md']
for name in names:
 p=ROOT/name;s=p.read_text();level='###' if name=='ROADMAP.md' else '##';marker=level+' Current Lighthouse regression pass and compatibility checkpoint\n';assert s.count(marker)==1
 s=s.replace(marker,level+' Current technical acceptance checkpoint\n\n'+common+'\n'+level+' Historical v30 Lighthouse regression checkpoint\n',1)
 if name.endswith('integration/README.md'):
  s=s.replace('batches 1–57','batches 1–58',1);marker=level+' Current technical acceptance checkpoint\n\n';s=s.replace(marker,marker+'Review the [technical acceptance summary](v31-compatibility/summary.md), [89 + 83 row audit](v31-compatibility/audit.json), [exact acceptance proposal](v31-compatibility/acceptance-proposal.json) and [completed compatibility assessment](v31-compatibility/assessment.json). Restore seal 58 after seals 1–57; verify every archive/member hash using the existing numeric restoration procedure.\n\n',1)
 p.write_text(s)
p=ROOT/'ARCHITECTURE.md';s=p.read_text().replace('Earlier TypeScript compatibility\nnow has a separate, unapproved 54-observation local proposal; final acceptance remains open.', 'Earlier TypeScript compatibility\nnow passes the separately approved 54-observation local sequence at the same scanner.\nAll current technical gates are ready for explicit human acceptance; Phase 22 remains\nincomplete until that decision and closeout delivery.');p.write_text(s)
(OUT/'summary.md').write_text('# Phase 22 technical acceptance packet\n\n'+common+'\nThe exact acceptance proposal binds the measured results, audit and enumerated limitations. Evidence seals 1–58 preserve raw observations, approvals, source assessments and all earlier failures; final documentation/delivery bindings are supplemental.\n')
(OUT/'pr-body.md').write_text('Phase 22 delivers bounded source security analysis and ordered runtime campaigns. All current technical gates are ready for explicit human acceptance; final closeout remains pending.\n\n'+common+'\nReview `artifacts/phase22/integration/v31-compatibility/summary.md`, `audit.json` and `acceptance-proposal.json`. Evidence seals 1–58 retain all source-bound results and closed budgets.\n')
lim='proposed documented limitation awaiting decision'
refs=['v31-compatibility/audit.json','v31-compatibility/assessment.json','v31-compatibility/source-assessment.json','v31-compatibility/summary.md','v30-lighthouse-regression/assessment.json','v24-fresh-v5/assessment.json','v30-compatibility-proposal/evaluation-authorization.json','v30-compatibility-proposal/source-proof.json','v29-quality/packet.json','v29-quality-audit/packet.json','v29-full-suite.json','v29-loopback-fix/local-source-binding.json','v29-production-capture-revalidation/packet.json','v22-refresh-disposition-corrected.json']
proposal={'status':'prepared_for_explicit_human_technical_acceptance','accepted':False,'scanner':a['scanner'],'lock_sha256':read(BASE/'v30-compatibility-proposal/evaluation-proposal.json')['lock_sha256'],'tested_workflow':'439c3fe658d30ebbc6cf6e21296261a38a6a3e92','lighthouse_evaluation_workflow':'75142f053ab5017ebd0a7f0953994ee9f7c14dd8','compatibility_runner_revision':'735e24eb070f203a1a3af337537586109e186d43','historical_whole_batch_scanner':'1f3f72f0f25c597b53c9f833e2e4bec99728d328','technical_gates_passed':True,'current_source_observations':{'lighthouse':10,'earlier_exposed_families':30,'development_typescript':10,'historical_typescript':14},'proposed_requirement_dispositions':[{'id':r['id'],'requirement':r['requirement'],'assessment':r['assessment']} for r in audit['requirements']+audit['additional_scope_requirements'] if r['disposition']==lim],'retained_limitations':['Original independent-source frozen misses remain0/2per native batch/comparator;later exposed fixes do not establish fresh generalization or independent human validation.','Original heldout completion/support/detection limits and unresolved static coverage remain visible;no whole-repository precision or safety claim.','Git runtime campaigns remain312/1040tested,incomplete;no complete Git runtime coverage.','Historical whole-batch timing retains measured1f3f72f and approved120target/300maximum;current partial compatibility is not a new whole-batch Linux timing run.','All superseded failed optimizations,sequences,preparations and corrective evaluations retain actual outcomes and closed budgets.'],'retained_user_deferrals':['Full396-request paid benchmark','External pilots'],'unchanged_later_phase_gates':['Phase21 remains incomplete','Phase24 adoption/retention gates unchanged','Phase15 launch gates unchanged'],'new_paid_calls':0,'acceptance_effect':'Record the exact human decision;mark Phase22 technically complete only under these enumerated scope/limitations;then validate,seal,commit,push and verify the accepted closeout on the existing draft PR37. Acceptance does not turn misses or superseded failures into passes.','not_authorized':['Any paid call','New experiments or target executions','Merge or mark draft ready','Release/publication/outreach/participant source sharing','Phase23'],'files_sha256':{n:sha(BASE/n) for n in refs},'evidence_seal':'evidence-v58.json (final archive hash bound in supplemental documentation/delivery record)','final_human_acceptance_received':False,'phase22_complete':False}
p=OUT/'acceptance-proposal.json';assert not p.exists();p.write_text(json.dumps(proposal,indent=2)+'\n');print('Prepared final technical acceptance packet and owning docs;human decision remains pending.')
