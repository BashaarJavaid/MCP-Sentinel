"""Prepare the complete acceptance audit after all approved technical work passes."""
import copy
import hashlib
import json
from collections import Counter
from datetime import datetime,timezone
from pathlib import Path

ROOT=Path.cwd();BASE=ROOT/'artifacts/phase22/integration';OUT=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
a=read(OUT/'assessment.json');assert a['compatibility_gate_passed'] and a['budget']['native_completed']==54 and a['source_assessment_complete']
old=read(BASE/'v30-lighthouse-regression/audit.json');p=copy.deepcopy(old)
refs=['v31-compatibility/assessment.json','v31-compatibility/source-assessment.json','v31-compatibility/validation.json','v30-compatibility-proposal/evaluation-authorization.json','v30-compatibility-proposal/source-proof.json','v30-lighthouse-regression/assessment.json']
common='Frozenf85a90f passes10 Lighthouse observations plus the separately approved54-observation local compatibility sequence. All3 earlier exposed families pass two whole5-input batches and ordered repeats;all24 affected historical/development TypeScript inputs retain ordered findings and named conditions. Every diagnostic delta is source-assessed. Original whole25+45+45 timing stays measured at1f3f72f;Python execution paths retain the source-only compatibility proof. Original fresh misses remain visible. Current technical work is ready for explicit human acceptance;Phase22 remains incomplete until that decision and subsequent closeout delivery.'
limitation='proposed documented limitation awaiting decision'
for r in p['requirements']:
 r['historical_assessment']={'audit':'v30-lighthouse-regression/audit.json','text':r['assessment']}
 r['interpretation']=common;r['evidence'].extend('artifacts/phase22/integration/'+n for n in refs)
 if r['id'] in {'R87','R89'}:r.update(disposition='passed',assessment='Atf85a90f each of fetch-mcp,open-webSearch and SearXNG completes two whole5-input local batches with2/2 correlated vulnerable hits and0 matching fixed/control alerts per batch;all15 entire ordered repeats agree. Ordered finding lists equal their source-assessed2ac39aa references. All changed diagnostics are separately source-assessed. This is current-source exposed compatibility,not fresh generalization.')
 elif r['id'] in {'R66','R88'}:r.update(disposition=limitation,assessment='Independent-repository replacement-v5 was frozen after1f3f72f stabilization and evaluated under exact approval:15completed observations,0/2 vulnerable hits in each native batch and comparator. The implementation agent curated/reviewed it;no independent human or unseen-source review. Subsequentf85a90f correction passes10 exposed observations. Proposed acceptance retains the fresh misses as a documented detection/generalization limitation;it does not turn them into hits or claim a fresh result atf85a90f. A new fresh evaluation is not executed or silently substituted.')
 elif r['id'] in {'R62','R63','R64','R65','R67','R69','R80','R83'}:r['assessment']=common
 elif r['id']=='R84':r['assessment']='Technical acceptance packet is ready after all current technical gates pass. Explicit human decision and post-acceptance documentation/evidence delivery remain required. Pilots/full paid benchmark are already user-deferred and nonblocking;no acceptance is inferred from measurement approval.'
superseded={
'V14-RETENTION':'The candidate violated its per-observation retention rule and was reverted. No5% gain is claimed. The user later approved120-second target/300-second maximum,under which the whole historical/development timing gate passes at1f3f72f. Accept closure while retaining the failed optimization as a historical failure.',
'V21-SEQUENCE':'The old115-observation sequence stopped at62 due to stale assessment identity;53unstarted closed. The later exact98-observation refresh passes both whole45-input historical batches and explicitly reuses the passed whole25development batch. Accept the superseding approved completion evidence without relabeling the earlier stop.',
'V21-FRESH-PROPOSAL':'The v4auth-fetch source was reused and fails novelty. Source-only recovery was approved;independent-repository v5 replaces it and its original misses remain recorded. Accept the failedv4preparation as historical,not an independent evaluation.',
'V25-EXPOSED-REGRESSION':'The6db3858 run stopped after one vulnerable miss;nine unstarted closed. The laterf85a90f approved Lighthouse gate passes all10 observations. Accept closure of this superseded failed attempt without reopening its budget.',
'V27-REGRESSION':'The4a2359d run stopped after two vulnerable hits and a fixed qualification failure;seven unstarted closed. Thef85a90f correction subsequently passes all10Lighthouse observations. Accept the earlier stop as a preserved historical failure.',
}
for r in p['additional_scope_requirements']:
 if r['id']=='V25-PRIOR-COMPATIBILITY':r.update(disposition='passed',assessment=common,evidence=['artifacts/phase22/integration/'+n for n in refs])
 if r['id'] in superseded:r.update(disposition=limitation,assessment=superseded[r['id']],historical_gate_failed=True,current_implementation_gate=False,explicit_acceptance_pending=True)
for ident,requirement in [('V31-AUTH','Record exact54-observation approval and execute one serial sequence within its bounds'),('V31-DISPOSITION','Retain and source-assess all54 observations,condition outcomes,ordered repeats,timing,cleanup and closed budget')]:
 p['additional_scope_requirements'].append({'id':ident,'requirement':requirement,'disposition':'passed','evidence':['artifacts/phase22/integration/'+n for n in refs]})
p.update(recorded_at=datetime.now(timezone.utc).isoformat(),source='735e24eb070f203a1a3af337537586109e186d43',scanner_identity=a['scanner'],latest_measured_scanner=a['scanner'],current_source_corpus_runs=64,current_compatibility_observations_this_continuation=54,current_compatibility_passed=True,status=common,prior_audit={'path':'v30-lighthouse-regression/audit.json','sha256':sha(BASE/'v30-lighthouse-regression/audit.json')},new_paid_calls=0,technical_acceptance_requested=False,acceptance_packet_ready=True,technical_acceptance_received=False,phase22_complete=False,owning_document_binding='Final v31 documentation/delivery binding follows final owning-doc edits.')
p['references_sha256'].update({n:sha(BASE/n) for n in refs})
p['dispositions']=dict(Counter(r['disposition'] for r in p['requirements']));p['additional_scope_dispositions']=dict(Counter(r['disposition'] for r in p['additional_scope_requirements']))
assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==83
assert p['dispositions']=={'passed':84,'explicitly user-deferred':2,limitation:2,'unresolved':1}
assert p['additional_scope_dispositions']=={'passed':78,limitation:5}
p['current_source_and_test_files']={n:sha(ROOT/n) for n in old['current_source_and_test_files']}
path=OUT/'audit.json';assert not path.exists();path.write_text(json.dumps(p,indent=2)+'\n');print(p['dispositions'],p['additional_scope_dispositions'])
