"""Commit the corrected instance boundary, preserving the failed predecessor."""
import hashlib,json,subprocess
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True).strip()
intake=read(OUT/'intake.json');old=read(BASE/'v82-python-module-dispatch/candidate-commit.json')
assert run('git','rev-parse','HEAD')==intake['baseline_candidate'] and not run('git','diff','--cached')
files=['src/sentinel/static/discovery.py','src/sentinel/static/path_flow.py','tests/test_module_dispatch.py']
assert set(run('git','diff','--name-only').splitlines())==set(files)
assert set(run('git','ls-files','--others','--exclude-standard').splitlines())==set(intake['protected_user_files_sha256'])
for name,d in intake['protected_user_files_sha256'].items():assert sha(ROOT/name)==d,name
labels=['v83-final-focused','v83-final-lint','v83-final-format','v83-final-types']
for label in labels:assert read(BASE/(label+'.json'))['exit_code']==0,label
current={name:sha(ROOT/name) for name in old['candidate_engineering_files_sha256']}
assert {name for name,d in current.items() if d!=old['candidate_engineering_files_sha256'][name]}==set(files)
baseline=read(BASE/'v72-prototype-property-correction/local-checks.json')['candidate_engineering_files_sha256']
changes={name:{'before':baseline.get(name),'after':d} for name,d in current.items() if baseline.get(name)!=d}
with (OUT/'candidate.patch').open('x') as f:f.write(run('git','diff','HEAD')+'\n')
run('git','add','--',*files);assert set(run('git','diff','--cached','--name-only').splitlines())==set(files)
run('git','diff','--cached','--check')
print(run('git','commit','-m','Reject mutated or escaped global instance guard receivers'))
head=run('git','rev-parse','HEAD')
for name,d in current.items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)).hexdigest()==d,name
with (OUT/'candidate-commit.json').open('x') as f:json.dump({'source':head,'parent':intake['baseline_candidate'],'recorded_at':datetime.now(timezone.utc).isoformat(),'files_sha256':{name:sha(ROOT/name) for name in files},'candidate_engineering_files_sha256':current,'changes_from_prior_engineering':changes,'failed_predecessor_controls_sha256':sha(BASE/'v82-python-module-dispatch/receiver-mutation-controls.json'),'focused_checks':{label:sha(BASE/(label+'.json')) for label in labels},'focused_passed':466,'full_engineering':'pending','corpus_observations':0,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False},f,indent=2);f.write('\n')
print(head)
