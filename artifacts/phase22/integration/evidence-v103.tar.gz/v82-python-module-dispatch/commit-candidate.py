"""Commit the bounded ordinary correction for exact-source engineering."""
import ast,hashlib,json,subprocess,tarfile
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True).strip()
intake=read(OUT/'intake-and-authorization.json')
assert run('git','rev-parse','HEAD')==intake['baseline_delivery'] and run('git','branch','--show-current')=='phase22/integration'
assert not run('git','diff','--cached') and not run('git','ls-files','--deleted')
files=['CHANGELOG.md','src/sentinel/static/coverage.py','src/sentinel/static/discovery.py','src/sentinel/static/path_flow.py','src/sentinel/static/module_dispatch.py','tests/test_module_dispatch.py']
assert set(run('git','diff','--name-only').splitlines())==set(files[:4])
assert set(run('git','ls-files','--others','--exclude-standard').splitlines())==set(intake['protected_user_files_sha256'])|set(files[4:])
for name,d in intake['protected_user_files_sha256'].items():assert sha(ROOT/name)==d,name
labels=['v82-candidate-focused','v82-final-lint-corrected','v82-final-format-corrected','v82-final-types']
for label in labels:assert read(BASE/(label+'.json'))['exit_code']==0,label
with tarfile.open(BASE/'v82-candidate-focused.untracked.tar.gz') as archive:
 assert ast.dump(ast.parse(archive.extractfile('tests/test_module_dispatch.py').read()))==ast.dump(ast.parse((ROOT/'tests/test_module_dispatch.py').read_text()))
 assert archive.extractfile('src/sentinel/static/module_dispatch.py').read()==(ROOT/'src/sentinel/static/module_dispatch.py').read_bytes()
before=intake['baseline_engineering_files_sha256']; current={name:sha(ROOT/name) for name in before}
current.update({name:sha(ROOT/name) for name in files[4:]})
changed={name:{'before':before.get(name),'after':digest} for name,digest in current.items() if before.get(name)!=digest}
assert set(changed)==set(files)
with (OUT/'candidate.patch').open('x') as f:f.write(run('git','diff','HEAD')+'\n')
run('git','add','--',*files);assert set(run('git','diff','--cached','--name-only').splitlines())==set(files)
run('git','diff','--cached','--check')
print(run('git','commit','-m','Recover bounded Python module dispatch and global instance receivers'))
head=run('git','rev-parse','HEAD')
for name,d in current.items():assert hashlib.sha256(subprocess.check_output(['git','show',head+':'+name],cwd=ROOT)).hexdigest()==d,name
receipt={'source':head,'parent':intake['baseline_delivery'],'recorded_at':datetime.now(timezone.utc).isoformat(),'files_sha256':{name:sha(ROOT/name) for name in files},'candidate_engineering_files_sha256':current,'changes_from_prior_engineering':changed,'focused_checks':{label:sha(BASE/(label+'.json')) for label in labels},'focused_passed':444,'test_format_change':'Only adjacent string literal splitting after focused run; complete test AST equality verified against captured source. Full suite will use final bytes.','full_engineering':'pending','corpus_observations':0,'paid_calls':0,'technical_acceptance_received':False,'phase22_complete':False}
with (OUT/'candidate-commit.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(head)
