"""Deliver the authorized correction to the existing draft for normal CI."""
import hashlib,json,subprocess,time
from datetime import datetime,timezone
from pathlib import Path
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;ROOT=OUT.parents[3]
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
run=lambda *args:subprocess.check_output(args,cwd=ROOT,text=True,stderr=subprocess.STDOUT,timeout=180)
def save(name,value):
 with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def pr():return json.loads(run('gh','pr','view','37','--json','number,state,isDraft,headRefName,headRefOid,baseRefName,title,body'))
def guard(p):assert p['number']==37 and p['state']=='OPEN' and p['isDraft'] and p['headRefName']=='phase22/integration' and p['baseRefName']=='phase22/description-poisoning'
c=read(OUT/'candidate-commit.json');intake=read(OUT/'intake.json');head=c['source']
assert run('git','rev-parse','HEAD').strip()==head and not run('git','diff','HEAD')
for name,d in c['candidate_engineering_files_sha256'].items():assert sha(ROOT/name)==d,name
for name,d in intake['protected_user_files_sha256'].items():assert sha(ROOT/name)==d,name
old=read(BASE/'v83-global-instance-boundary/candidate-delivery.json');current=pr();guard(current)
assert current['headRefOid']==old['head'] and current['title']==old['pr']['title'] and current['body']==(BASE/'v83-global-instance-boundary/candidate-pr-body.md').read_text()
assert run('gh','api','repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration','--jq','.commit.sha').strip()==old['head']
save('candidate-pre-pr37.json',current)
body=f'''Candidate `{head}` retains bounded Python module-table discovery and preserves global instance receivers only across source-established mutation/escape boundaries. The first candidate `8f0639f` failed direct/aliased receiver replacement and escape controls; its local suite stopped after 45 passes and CI 34910063570 was cancelled. The second candidate `1ee96cb` completed its full local suite with 2,549 passes/36 skips, then failed a concrete class-call mutation control; CI 34910945759 was cancelled. The current correction rejects unproved constructor-class attribute access, including direct class-method calls that can replace guards. All failures and actual partial/full results remain preserved. All 470 focused discovery, containment, state, recovery and worker checks pass, including actual serial/parallel result equality on owned synthetic sources. Whole-scope lint, format and strict typing pass. Full local/hosted engineering and production request replay are in progress, not yet passed.

The original unseen results at `cec0322` remain unchanged: 12 complete observations/six equal ordered pairs; Taskwarrior passes its narrow shell condition, Proxmox misses both vulnerable reads and has four unsupported negative paths. The user chose a bounded correctness correction before acceptance. No current-candidate corpus result exists; all earlier budgets remain closed. A new exact exposed regression proposal will require separate approval. No additional unseen repositories, profiles, performance attempts, target execution or paid calls.

The complete 448-row V81 audit and all 26 unaccepted limitations remain preserved. New correction and engineering rows will be reconciled with actual evidence. Prior V73/V75 results are 205 exposed observations/95 pairs at their original source; candidate compatibility is pending. The V81 acceptance proposal is not accepted and cannot establish current technical completion.

Normal FAF completion within 1,800 seconds remains unestablished; V68 stays unopened/unimplemented. Git 312/1,040 incomplete, 728 deferred; paid benchmark/pilots deferred; Phase 21 incomplete and Phase 24/15 unchanged. Historical paid spend $0.071799; zero new paid calls.

Phase 22 remains incomplete pending current-source regression, updated review, explicit human technical acceptance and verified accepted closeout. This PR stays OPEN DRAFT on the existing base. No merge, ready-state change, release, outreach or Phase 23 is authorized.
'''
title='Phase 22: class-call boundary corrected; engineering in progress'
with (OUT/'candidate-pr-body.md').open('x') as f:f.write(body)
save('candidate-metadata-update.json',{'title':title,'body':body})
print(run('git','push','https://github.com/BashaarJavaid/MCP-Sentinel.git','HEAD:refs/heads/phase22/integration'),flush=True)
response=json.loads(run('gh','api','--method','PATCH','repos/BashaarJavaid/MCP-Sentinel/pulls/37','--input',str(OUT/'candidate-metadata-update.json'),'--jq','{number,state,draft,title,head:.head.sha,base:.base.ref}'));save('candidate-patch-response.json',response)
history=[]
for attempt in range(12):
 current=pr();guard(current);branch=run('gh','api','repos/BashaarJavaid/MCP-Sentinel/branches/phase22/integration','--jq','.commit.sha').strip();history.append({'pr':current,'branch':branch})
 if current['headRefOid']==branch==head and current['title']==title and current['body']==body:break
 time.sleep(5)
else:
 save('candidate-readback-history.json',history);raise AssertionError('Retain writes and verify by reads only; never rerun mutation.')
save('candidate-readback-history.json',history)
save('candidate-delivery.json',{'passed':True,'head':head,'recorded_at':datetime.now(timezone.utc).isoformat(),'pr':current,'body_sha256':sha(OUT/'candidate-pr-body.md'),'paid_calls':0,'engineering':'pending','technical_acceptance_received':False})
print('Exact candidate draft delivery verified.',head,flush=True)
