# Credential merge correction and canonical bypass: engineering in progress

Approved candidate `dc7371513a065457af566f4b589b9ed147130d64` makes equal immutable credential markers join consistently regardless of cache interning, then bypasses cache dispatch only for the canonical `UNKNOWN_VALUE` singleton without a key override. This deliberately revises the named marker-join behavior; it is not claimed to preserve every original `a36f696` internal state.

The correction passes 4,050 structural cases with 552 explicitly retained marker deltas and 552 derived cache-input deltas; credential guard results agree. All 480 correction-stage credential/flow regressions pass. The bypass passes 2,430 complete Python/TypeScript state comparisons against the correction-only reference and two saturated-cache eviction cases. Affected tests, Ruff/format and strict mypy passed; full local and hosted engineering are in progress. The initial synthetic fixture recursion failure and test-format failures remain retained with their corrections.

Both older singleton failures reproduce against their original sources. All three native timeouts, partial/invalid profiles, original four fresh failures, prior TS/Python and whole-batch evidence, six historical closure proposals and original held-out limitations remain unchanged. No new corpus observation, profile or paid call is authorized or executed. No speedup or 300-second completion is established.

Phase 22 remains incomplete. Exact regression approval, actual results, explicit human technical acceptance and accepted closeout remain pending. Git stays312/1,040 incomplete; pilots/paid benchmark deferred, Phase21 incomplete and Phase24/15 unchanged. PR remains OPEN DRAFT; no merge, ready-state, release, outreach or Phase23. Main worktree and all eight protected user documents are preserved.

The complete preceding evidence and limitations remain in [v56](https://github.com/BashaarJavaid/MCP-Sentinel/blob/9b2585d3a6cc7e1a3584eff1d9dcbf16a41cffbc/artifacts/phase22/integration/v56-canonical-unknown/summary.md). Final engineering evidence and the complete updated audit will follow after verification.
