import collections,datetime,hashlib,json
from pathlib import Path
root=Path('/private/tmp/mcp-phase22-options');b=root/'artifacts/phase22/integration';read=lambda n:json.loads((b/n).read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=read('v18-scaling-assessment.json');v=read('v18-source-verification.json');seal=read('evidence-v47.json');p=read('v17-closeout-audit/packet.json')
assert a['scope_stopped'] and a['remaining_dispatches']==0 and a['decision']=='premise_not_supported_E3_below_2.7'
p.update(source=a['workflow_source'],scanner_identity=v['current_scanner_identity'],workflow_delivery=v['executed_hosted_source'],recorded_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),latest_diagnostic=a,prior_audit={'path':'artifacts/phase22/integration/v17-closeout-audit/packet.json','sha256':sha(b/'v17-closeout-audit/packet.json')},current_verification={'path':'artifacts/phase22/integration/v18-source-verification.json','sha256':sha(b/'v18-source-verification.json'),'actual_executed_hosted_source':v['executed_hosted_source'],'compatible_local_execution_source':v['compatible_local_engineering_source'],'new_hosted_run':True,'new_local_full_suite':False},stage0_approved=True,stage0_consumed=True,stage1_approved=False,partitioning_approved=False,current_source_fresh_evaluation_approved=False,new_paid_calls=0,phase22_complete=False,technical_acceptance_requested=False,technical_acceptance_received=False,status='Stage0 complete; prospective throughput premise fails. No scanner optimization or partitioning. Linux scanner timing, fresh evaluation and human acceptance remain unmet.')
p['latest_timing_disposition']={'source':'v18-scaling-assessment.json','decision':a['decision'],'scanner_timing_gate_unchanged':True,'previous_source_review':'v17-timing-disposition.json','no_new_optimization_proposed':True}
p['current_source_and_test_files']=v['source_and_test_files_sha256'];p['owning_document_binding']='Final document hashes are in v18-final-documentation-binding.json. Fresh hosted workflow verification and synthetic probe at0b71a29; local checks/replay compatibility at592a9cd; exposed native measurements at2ac39aa. Scanner bytes unchanged.'
p['current_check_failure']={'failures':v['failures_preserved'],'all_corrected_before_closeout':True}
for row in p['requirements']:
 row['evidence']=list(dict.fromkeys(row['evidence']+['artifacts/phase22/integration/v18-source-verification.json','artifacts/phase22/integration/v18-hosted-audit/packet.json']))
 row['current_verification']='Fresh normal CI at0b71a29 verifies the optional-workflow change; all12 suites pass2183/36. Scanner/test/package bytes equal592a9cd, retaining prior local/capture/runtime evidence at its actual source. No new scanner timing or fresh evaluation.'
 if row['id'] in ['R63','R64','R65','R69','R85','R86']:
  row['evidence']+=['artifacts/phase22/integration/v18-scaling-assessment.json'];row['latest_diagnostic']='Approved Stage0 synthetic Linux throughput probe completes12/12; E3=2.029,E4=2.136,E6=2.125. E3 fails2.7 premise; no partitioning proposed or approved. Four reported vCPUs are2cores with2threads/core on this runner. Scanner timing gate unchanged; zero paid model calls.'
 if row['id']=='R79':row['evidence']+=['artifacts/phase22/integration/evidence-v47.json']
 if row['id']=='R82':row['evidence']+=['artifacts/phase22/integration/v18-delivery-verification.json']
for i,title,evidence in [('AUTH','Exact Stage0 approval and immutable implementation bindings',['v18-scaling-authorization.json','v18-linux-scaling-probe-v1/packet.json']),('CHECK','Readiness, checksum, timeout, cleanup and decision implementation controls',['v18-probe-selfcheck.json','v18-probe-lint.json']),('DISPATCH','One bounded synthetic Linux dispatch with retained observations',['v18-scaling-dispatch.json','v18-scaling-assessment.json']),('STOP','Apply the failed throughput premise without inferring scanner improvement',['v18-scaling-assessment.json']),('VERIFY','Verify changed workflow with fresh hosted CI and unchanged scanner compatibility',['v18-hosted-audit/packet.json','v18-source-verification.json']),('DELIVERY','Seal and deliver all completed scope while retaining unmet Phase22 gates',['evidence-v47.json','v18-delivery-verification.json'])]:
 p['additional_scope_requirements'].append({'id':'V18-'+i,'requirement':title,'disposition':'passed','evidence':evidence})
p['additional_scope_dispositions']=dict(collections.Counter(r['disposition'] for r in p['additional_scope_requirements']));assert len(p['requirements'])==89 and len(p['additional_scope_requirements'])==28 and p['additional_scope_dispositions']=={'passed':27,'unresolved':1}
p['references_sha256'].update({'artifacts/phase22/integration/'+n:sha(b/n) for n in ['v18-scaling-authorization.json','v18-scaling-assessment.json','v18-source-verification.json','v18-hosted-audit/packet.json','evidence-v47.json']})
out=b/'v18-closeout-audit';out.mkdir(exist_ok=False);(out/'packet.json').write_text(json.dumps(p,indent=2)+'\n')
summary='''The approved Stage 0 synthetic throughput probe is complete at `0b71a29`.
Run **34536965288** completed **12/12 observations** in an 88-second job;
all checksums match, all children were ready before the shared monotonic start,
and every child was reaped. No scanner or corpus input executed in the probe.

Median throughput relative to one process is **2.029× at three processes,
2.136× at four, and 2.125× at six**. Four processes add only **5.25%** over
three; six add **4.71%**. The runner reports four vCPUs, two cores and two
threads per core, with Python 3.12.14. The prospective **E3 ≥ 2.7 premise
fails**. This result does not support proceeding to the proposed partitioning
experiment; it is not proof that all scanner parallelism is ineffective.
See `v18-scaling-assessment.json` and its retained raw observations.

**One dispatch consumed; zero scanner runs, optimization attempts or paid model
calls.** Stage 1 and partitioning remain unapproved. The normal CI jobs are
structurally unchanged, but the optional workflow changed, ending workflow
equality to `592a9cd`. Fresh CI **34536886816** verifies all 29 normal jobs;
all 12 suites pass **2,183 tests / 36 skipped**. Docs **34536886750** pass.
Scanner/test/package bytes remain identical to `592a9cd`; prior local checks,
production replay and Git compatibility retain their executed sources, and the
three exposed SSRF gates retain measured `2ac39aa`. Initial probe lint issues
and an immediate post-push PR-readback assertion are preserved with corrections.

**Phase 22 remains incomplete.** The retained Linux scanner result is still
15/25 development complete, ten Meta timeouts and both historical batches
skipped. No current-source full timing pass, fresh evaluation, scope waiver or
final human acceptance is inferred. Further source-design work may investigate
reducing repeated analysis, but no safe reuse design or new experiment is
established here. Pilots/full paid benchmark remain deferred, Phase 21 incomplete,
and Phase 24/15 unchanged. No merge, release, outreach or next phase.
'''
for name in ['AGENTS.md','ROADMAP.md','docs/phase22-technical.md','docs/phase22-implementation-status.md','docs/phase22-ssrf-follow-up.md','artifacts/phase22/integration/README.md','artifacts/phase22/integration/progress.md']:
 f=root/name;s=f.read_text()
 if name=='AGENTS.md':needle='## Current phase\n\n';assert s.count(needle)==1;s=s.replace(needle,needle+summary+'\n### Historical v17 diagnostic at `127763c`\n\n',1)
 else:
  level='###' if name=='ROADMAP.md' else '##';needle=level+' Current v17 diagnostic at `127763c`';assert s.count(needle)==1;s=s.replace(needle,level+' Current v18 throughput probe at `0b71a29`\n\n'+summary+'\n'+level+' Historical v17 diagnostic at `127763c`',1)
 f.write_text(s.rstrip()+'\n')
f=b/'requirements.md';s=f.read_text();title,rest=s.split('\n',1);rest=rest.replace('## Current v17 source-bound audit','## Historical v17 source-bound audit',1)
text='''\n## Current v18 source-bound audit\n\nAll 89 original rows are mapped in `v18-closeout-audit/packet.json`:
**70 passed, 2 explicitly user-deferred, 17 unresolved**. Six v18 execution
requirements pass, including applying the failed throughput premise correctly.
The throughput premise itself failed. All 28 added rows retain **27 passed and
1 unresolved** (the historical v14 retention requirement). Fresh normal hosted
CI verifies `0b71a29`; compatible local checks remain at `592a9cd`.
No scanner timing pass, fresh result, scope waiver or human acceptance is inferred.

| ID | Requirement | Disposition |
| --- | --- | --- |
'''
for row in p['additional_scope_requirements']:
 if row['id'].startswith('V18-'):text+='| '+row['id']+' | '+row['requirement']+' | **passed** |\n'
f.write_text(title+'\n'+text+rest)
index=f'''Batch 47 is sealed: **{len(seal['files'])} files**, SHA-256
`{seal['sha256']}`. Every member and all 46 prior archive hashes are verified.
Restore after batches 1–46 in separate staging using `evidence-v47.json`; existing
destinations must match identical bytes or a recorded previous hash. Stop on
unexpected conflicts. This batch retains Stage0 approval/implementation, all raw
observations and logs, fresh CI/docs artifacts, the failed premise, verification,
preparation failures/corrections and helper sources. Final audit/docs/delivery
bindings are tracked directly after the seal.\n\n'''
f=b/'README.md';s=f.read_text().replace('batches 1–46 and closeout audit','batches 1–47 and closeout audit',1).replace('## Evidence archives\n','## Evidence archives\n\n'+index,1);f.write_text(s)
f=b/'progress.md';f.write_text((f.read_text().rstrip()+'\n\n### Evidence batch 47\n\n'+index).rstrip()+'\n')
body=(b/'v17-closeout-draft-body.md').read_text().split('\n\n',1)[0]+'\n\n'+summary+'\n[Current audit](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v18-closeout-audit/packet.json), [throughput assessment](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/v18-scaling-assessment.json), [approved probe](https://github.com/BashaarJavaid/MCP-Sentinel/tree/phase22/integration/artifacts/phase22/integration/v18-linux-scaling-probe-v1), and [evidence batches 1–47](https://github.com/BashaarJavaid/MCP-Sentinel/blob/phase22/integration/artifacts/phase22/integration/README.md).\n\nThe final docs/evidence-only delivery uses authorized CI skip after proving inputs equal the newly verified `0b71a29` workflow candidate. Final docs are checked locally; the later delivery is not another hosted pass.\n'
f=b/'v18-closeout-draft-body.md';assert not f.exists();f.write_text(body)
print(p['dispositions'],p['additional_scope_dispositions'])
