"""Publish completed engineering and the exact next approval checkpoint."""
import json
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / "artifacts/phase22/integration"
OUT = BASE / "v27-constructor-fix"
quality = json.loads((BASE / "v27-quality-audit/packet.json").read_text())
assert len(quality["quality"]) == 12 and all(q["passed"] == 2236 and q["skipped"] == 36 for q in quality["quality"])
assert json.loads((BASE / "v27-full-suite.json").read_text())["exit_code"] == 0
coverage = json.loads((BASE / "v27-full-suite-coverage.json").read_text())["totals"]["percent_covered"]
hosted = [q["branch_coverage_percent"] for q in quality["quality"]]
common = (OUT / "preparation-summary.md").read_text().split("\n\n", 1)[1]
start = common.index("The remaining class-recognition gap")
end = common.index("The new exact **unapproved** proposal")
common = common[:start] + f'''The constructor-scope correction is verified at scanner **`4a2359d`**.
Constructor eligibility now excludes returns owned by nested callbacks/functions/
classes; a constructor's own returned object remains unsupported. Five synthetic
counterexamples fail at `6db3858`; all 81 class/SDK tests and 315 affected tests
pass with the correction. No current-source corpus observation has occurred.

Full local and all 12 Linux/macOS/Windows × Python 3.10–3.13 suites pass
**2,236 tests / 36 skips**. Local branch coverage is **{coverage:.2f}%**; hosted
coverage is **{min(hosted):.2f}–{max(hosted):.2f}%**. All **29 normal jobs** and documentation
pass at workflow **`2998b79`**
([CI](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34622991759),
[docs](https://github.com/BashaarJavaid/MCP-Sentinel/actions/runs/34622991696)).
Wheel/sdist sources match actual Git blobs. Ruff/format/strict mypy, lock, schemas,
notices and offline artifacts pass. Six actual production requests regenerate
and checked-replay with unchanged fingerprints/request hashes and **zero paid calls**.
The owned Docker demo completes 20/20 attempts with 14 findings and cleanup.
Git's unchanged runtime/image retains 13 incomplete campaigns, 312/1,040 attempts.
The earlier 2,230-test pass remains bound to `6db3858`.

''' + common[end:]
common = common.replace("Both the original fresh", "The **89-row audit remains 82 passed, two user-deferred and five unresolved**.\nThe 72 added rows are 66 passed and six unresolved, including four closed historical\nfailure rows. No failed measurement is relabeled as accepted or reopened.\nThe original held-out baseline remains10 completed,10 unsupported and5 incomplete,\nwith0 hits among4 completed vulnerable inputs out of10 vulnerable inputs total.\n\nBoth the original fresh", 1)
names = ["AGENTS.md", "ROADMAP.md", "docs/phase22-technical.md", "docs/phase22-implementation-status.md", "docs/phase22-ssrf-follow-up.md", "docs/phase22-timeout-policy.md", "docs/phase22-corpus-review.md", "artifacts/phase22/integration/README.md", "artifacts/phase22/integration/requirements.md", "artifacts/phase22/integration/progress.md"]
for name in names:
    path = ROOT / name
    text = path.read_text()
    level = "###" if name == "ROADMAP.md" else "##"
    start = text.index(level + " Current constructor-scope correction under verification\n")
    end = text.index(level + " Historical v25 Lighthouse correction checkpoint\n", start)
    text = text[:start] + level + " Current constructor-scope correction and regression checkpoint\n\n" + common + "\n" + text[end:]
    if name == "artifacts/phase22/integration/README.md":
        text = text.replace("batches 1–54", "batches 1–55", 1)
        marker = level + " Current constructor-scope correction and regression checkpoint\n\n"
        text = text.replace(marker, marker + "Review the [current summary](v27-constructor-fix/summary.md), [89 + 72 row audit](v27-constructor-fix/audit.json), [stopped regression](v26-lighthouse-regression/assessment.json) and [exact unapproved proposal](v27-constructor-fix/evaluation-proposal.json).\nRestore seal 55 after seals 1–54 using the existing numeric-order procedure and verify every archive/member hash.\n\n", 1)
    path.write_text(text)
path = ROOT / "ARCHITECTURE.md"
text = path.read_text().replace("This correction follows the first exposed `6db3858` miss; full verification is pending.", "This correction follows the first exposed `6db3858` miss; engineering verification\npasses at `2998b79`. The next exposed regression is unapproved; no corrected-source\ncorpus detection or generalization result is claimed.", 1)
text = text.replace("No corrected-source corpus result or generalization is claimed.", "No successful Lighthouse regression or generalization result is claimed.", 1)
path.write_text(text)
(OUT / "summary.md").write_text("# Phase 22 constructor-scope correction checkpoint\n\n" + common + "\nThe stopped run, all 27 diagnostic occurrences, synthetic failures, source correction, completed engineering and all prior immutable evidence are retained in seals 1–55. Final documentation/delivery bindings are supplemental. Phase 22 requires the remaining current-source gates and explicit human technical acceptance.\n")
(OUT / "pr-body.md").write_text("Phase 22 integrates bounded security source analysis and ordered runtime campaigns. Technical acceptance remains open.\n\n" + common + "\nReview `artifacts/phase22/integration/v27-constructor-fix/summary.md`, its complete audit, and the exact unapproved proposal. Evidence seals 1–55 preserve the original held-out misses, failed novelty check, failed experiments and stopped Lighthouse regression without changing their sources or budgets.\n")
print("Final owning docs and draft body prepared from completed verification.")
