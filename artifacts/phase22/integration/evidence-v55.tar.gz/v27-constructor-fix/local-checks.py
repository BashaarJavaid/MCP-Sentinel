"""Summarize completed local checks at their actual recorded source."""
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path

BASE = Path("artifacts/phase22/integration")
OUT = BASE / "v27-constructor-fix"
labels = ["full-suite", "ruff", "format", "mypy", "lock", "schema", "notices", "artifacts", "production-capture-corrected"]
checks = []
for label in labels:
    path = BASE / ("v27-" + label + ".json")
    metadata = json.loads(path.read_text())
    assert metadata["exit_code"] == 0
    checks.append({"label": "v27-" + label, "command": metadata["command"], "source": metadata["source_commit"], "exit_code": metadata["exit_code"], "evidence_sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
counts = Counter("skipped" if c.find("skipped") is not None else "failed" if c.find("failure") is not None or c.find("error") is not None else "passed" for c in ET.parse(BASE / "v27-full-suite-junit.xml").iter("testcase"))
assert counts == {"passed": 2236, "skipped": 36}
coverage = json.loads((BASE / "v27-full-suite-coverage.json").read_text())["totals"]["percent_covered"]
path = OUT / "local-checks.json"
assert not path.exists()
path.write_text(json.dumps({"scanner": "4a2359d5b67719b1129c7a63eafc17e6d85cedf3", "checks": checks, "full_suite": dict(counts, branch_coverage_percent=coverage), "source_binding": "local-source-binding.json", "new_paid_calls": 0}, indent=2) + "\n")
print(dict(counts), coverage)
