"""Reconcile all requirements without relabeling the failed regression."""
import copy
import hashlib
import json
import xml.etree.ElementTree as ET
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path.cwd()
BASE = ROOT / "artifacts/phase22/integration"
OUT = BASE / "v27-constructor-fix"
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
old = json.loads((BASE / "v25-lighthouse-fix/audit.json").read_text())
packet = copy.deepcopy(old)
quality = json.loads((BASE / "v27-quality-audit/packet.json").read_text())
assert len(quality["quality"]) == 12 and all(q["passed"] == 2236 and q["skipped"] == 36 for q in quality["quality"])
assert json.loads((BASE / "v27-full-suite.json").read_text())["exit_code"] == 0
assert json.loads((OUT / "local-source-binding.json").read_text())["current_product_tests_packages_equal_corrected_commit"]
proposal = json.loads((OUT / "evaluation-proposal.json").read_text())
assert not proposal["approval_received"] and not (OUT / "evaluation-authorization.json").exists()
counts = defaultdict(Counter)
for case in ET.parse(BASE / "v27-full-suite-junit.xml").iter("testcase"):
    state = "skipped" if case.find("skipped") is not None else "failed" if case.find("failure") is not None or case.find("error") is not None else "passed"
    counts[case.attrib["classname"].replace(".", "/") + ".py"][state] += 1
assert sum(c["passed"] for c in counts.values()) == 2236 and sum(c["skipped"] for c in counts.values()) == 36 and not any(c["failed"] for c in counts.values())
assert counts["tests/test_typescript_sdk_wrappers.py"]["passed"] == 37 and counts["tests/test_typescript_classes.py"]["passed"] == 44
refs = ["v27-quality/packet.json", "v27-quality-audit/packet.json", "v27-full-suite.json", "v27-full-suite-junit.xml", "v27-full-suite-coverage.json", "v27-production-capture-revalidation/packet.json", "v27-constructor-fix/compatibility.json", "v27-constructor-fix/local-source-binding.json", "v27-constructor-fix/local-checks.json", "v27-constructor-fix/correction.json", "v27-constructor-fix/check-failure-assessment.json", "v27-constructor-fix/evaluation-proposal.json", "v27-constructor-fix/source-compatibility-scope.json", "v26-lighthouse-regression/assessment.json", "v26-lighthouse-regression/diagnostic-source-assessment.json", "v26-lighthouse-regression/retained-source-delta.json", "v25-lighthouse-fix/evaluation-authorization-final.json"]
for row in packet["requirements"]:
    prior = next(r for r in old["requirements"] if r["id"] == row["id"])
    row["prior_requirement_record_sha256"] = hashlib.sha256(json.dumps(prior, sort_keys=True).encode()).hexdigest()
    row["historical_assessment"] = {"audit": "v25-lighthouse-fix/audit.json", "text": row["assessment"]}
    row["evidence"].extend("artifacts/phase22/integration/" + n for n in refs)
    row["interpretation"] = "Original measurements keep actual source identities and budgets.6db3858 failed its first exposed Lighthouse condition and closed9 unstarted observations. Current4a2359d passes engineering atworkflow2998b79 but has no corpus observation. No limitation or final technical acceptance is inferred."
    if row["id"] in {"R66", "R88"}:
        row["assessment"] = "Original fresh1f3f72f result remains15 completed with0/2 vulnerable hits per native batch and comparator. The approved6db3858 exposed regression completed one vulnerable input with zero findings and closed nine unstarted inputs on condition failure. All27 diagnostics are source-assessed. A constructor-scope correction passes engineering at4a2359d; its new ten-observation proposal is unapproved. Fresh-result disposition remains unresolved; no fresh generalization or accepted limitation claim."
    elif row["id"] in {"R71", "R72", "R73", "R74"}:
        row["assessment"] = "Current4a2359d local and all12 hosted suites pass2236 tests/36 skips, branch coverage above80%, all29 ordinary jobs and docs atworkflow2998b79. Exact package Git blobs, lock/schema/notices/offline artifacts, Ruff/format/strict mypy, installed-wheel consumers, Docker/isolation/hooks and six zero-call production replays pass. This is engineering evidence, not a corrected corpus pass."
    elif row["id"] in {"R62", "R83"}:
        row["assessment"] = "Owning docs and current audit prominently retain the original fresh miss, stopped6db3858 regression and closed nine-input remainder, current verified constructor correction, exact unapproved new proposal, historical source-specific gates and remaining human acceptance. Phase22 incomplete and later-phase/paid/pilot dispositions unchanged."
    elif row["id"] in {"R44", "R70", "R75", "R76"}:
        row["assessment"] += " At4a2359d all six actual production requests again replay with identical prior fingerprints/request hashes and zero paid calls. Runtime/image bindings remain unchanged; Git campaigns remain incomplete312/1040."
for row in packet["additional_scope_requirements"]:
    if row["id"] == "V25-EXPOSED-REGRESSION":
        row["assessment"] = "Actual approval received in evaluation-authorization-final.json. Run34621524649 failed its first vulnerable condition at6db3858: one completed miss, nine unstarted closed, zero remaining. This closed historical failed gate is not an available retry budget."
        row["evidence"].append("artifacts/phase22/integration/v26-lighthouse-regression/assessment.json")
additions = [
    ("V26-AUTH", "Record the exact continue approval and consume only its single bounded dispatch", "passed"),
    ("V26-DISPOSITION", "Preserve the completed miss, close all nine unstarted observations and source-assess every diagnostic", "passed"),
    ("V27-CORRECTION", "Keep nested callback/function/class returns outside constructor eligibility while rejecting actual returned replacements", "passed"),
    ("V27-ENGINEERING", "Verify the constructor correction locally and across hosted packaging/runtime/replay checks", "passed"),
    ("V27-PROPOSAL", "Prepare the exact new ten-observation exposed regression without executing it", "passed"),
    ("V27-REGRESSION", "Obtain exact new approval and demonstrate the corrected Lighthouse condition/repeat gate", "unresolved"),
]
packet["additional_scope_requirements"].extend({"id": i, "requirement": text, "disposition": disposition, "evidence": ["artifacts/phase22/integration/" + n for n in refs]} for i, text, disposition in additions)
packet.update(recorded_at=datetime.now(timezone.utc).isoformat(), source="2998b79d0ff41b40a1fbbf6fc161f727dc2ad776", scanner_identity=proposal["scanner"], workflow_tested_source="2998b79d0ff41b40a1fbbf6fc161f727dc2ad776", current_tests_by_file=dict(counts), current_source_corpus_runs=0, latest_measured_scanner=json.loads((BASE / "v26-lighthouse-regression/assessment.json").read_text())["scanner"], prior_scanner_regression_observations_this_continuation=1, new_paid_calls=0, technical_acceptance_requested=False, technical_acceptance_received=False, phase22_complete=False, current_exposed_evaluation_approved=False, current_exposed_evaluation_executed=False, status="Stopped exposed regression preserved; scoped constructor correction passes engineering, new regression proposal and current-source prior-gate compatibility/fresh/human disposition unresolved.", prior_audit={"path": "v25-lighthouse-fix/audit.json", "sha256": sha(BASE / "v25-lighthouse-fix/audit.json")}, owning_document_binding="Final v27 documentation/delivery bindings are supplemental to this pre-seal audit.", per_file_test_counts_basis="Actual completed v27 JUnit, source snapshot byte-bound to committed4a2359d.")
packet["historical_source_and_test_file_bindings"] = {"source": old["source"], "files": old["current_source_and_test_files"], "earlier": old["historical_source_and_test_file_bindings"]}
packet["current_source_and_test_files"] = {name: sha(ROOT / name) for name in old["current_source_and_test_files"]}
packet["references_sha256"].update({name: sha(BASE / name) for name in refs})
packet["dispositions"] = dict(Counter(r["disposition"] for r in packet["requirements"]))
packet["additional_scope_dispositions"] = dict(Counter(r["disposition"] for r in packet["additional_scope_requirements"]))
assert len(packet["requirements"]) == 89 and len(packet["additional_scope_requirements"]) == 72
assert packet["dispositions"] == {"passed": 82, "explicitly user-deferred": 2, "unresolved": 5}
assert packet["additional_scope_dispositions"] == {"passed": 66, "unresolved": 6}
path = OUT / "audit.json"
assert not path.exists()
path.write_text(json.dumps(packet, indent=2) + "\n")
print(packet["dispositions"], packet["additional_scope_dispositions"])
