import argparse,dataclasses,hashlib,json,sys
from datetime import datetime,timezone
from pathlib import Path
from tempfile import TemporaryDirectory
from uuid import uuid4
sys.path[:0]=['/private/tmp/mcp-phase22-runtime-80bd278/src','/private/tmp/mcp-phase22-runtime-80bd278']
import sentinel
assert Path(sentinel.__file__).is_relative_to('/private/tmp/mcp-phase22-runtime-80bd278/src')
from scripts.phase20_corpus import validate,materialize
from scripts.phase20_measurements import scanner_identity
from sentinel.config import load_configuration
from sentinel.dynamic.sandbox import DockerSandbox,SCAN_LABEL,_dependency_inputs
from sentinel.dynamic.prober import run_dynamic_scan
from sentinel.report.model import DynamicAnalysisSummary
parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--input',default='git-staging-vulnerable');args=parser.parse_args();args.output.mkdir(parents=True,exist_ok=False)
authorization=json.loads(Path('artifacts/phase22/authorization.json').read_text())['git_environment'];raw=Path(authorization['packet']).read_bytes();assert authorization['adoption_approved'] and hashlib.sha256(raw).hexdigest()==authorization['sha256']
packet=json.loads(raw);approved=next(i for i in packet['inputs'] if i['input_id']==args.input);manifest=validate();item=next(i for i in manifest.inputs if i.id==args.input);snapshot=next(s for s in manifest.snapshots if s.revision==item.snapshot);assert item.runtime_applicability=='eligible' and item.tree_sha256==approved['tree_sha256']
record={'input_id':item.id,'source_tree_sha256':item.tree_sha256,'scanner':scanner_identity(),'environment_packet_sha256':authorization['sha256'],'model_calls':0,'status':'incomplete'}
def save(): (args.output/'runtime.json').write_text(json.dumps(record,indent=2)+'\n')
save()
try:
 with TemporaryDirectory(prefix='phase22-git-campaign-') as tmp:
  root=materialize(item,snapshot,Path(tmp).resolve()/'source',manifest.packet)
  (root/'.phase22').mkdir();(root/'.phase22/requirements.txt').write_text(approved['requirements'])
  config=load_configuration(root,environ={});assert config.target
  config=config.model_copy(update={'target':config.target.model_copy(update={'install_cmd':('pip','install','-r','.phase22/requirements.txt')})})
  assert config.target.model_dump(mode='json')==approved['target']
  cache_key,_,_=_dependency_inputs(config);assert 'mcp-sentinel-deps:'+cache_key==approved['image']
  scan_id=uuid4();sandbox=DockerSandbox(config,scan_id);sandbox.preflight()
  image=json.loads(sandbox.docker(('image','inspect',approved['image'])).stdout);assert image[0]['Id']==authorization['image_id'];record['image_inspect']=image;record['target']=config.target.model_dump(mode='json');record['sandbox']=config.scanner.sandbox.model_dump(mode='json');save()
  try:
   measured=run_dynamic_scan(sandbox,(),scan_id=scan_id,timestamp=datetime.now(timezone.utc));summary=measured.summary;DynamicAnalysisSummary.model_validate_json(summary.model_dump_json())
   record.update(status='completed' if measured.complete else 'incomplete',complete=measured.complete,execution_successful=measured.execution_successful,summary=summary.model_dump(mode='json'),findings=[f.model_dump(mode='json',round_trip=True) for f in measured.findings],warnings=[w.model_dump(mode='json') for w in measured.warnings],image=dataclasses.asdict(measured.image))
  finally:
   record['cleanup_remaining']=sandbox.docker(('ps','-aq','--filter',f'label={SCAN_LABEL}={scan_id}')).stdout.strip();save()
  assert not record['cleanup_remaining']
except Exception as e:
 record['error']=str(e);save();raise
print(json.dumps({'input':item.id,'status':record['status'],'campaign':record['summary']['coverage']['campaign'],'findings':len(record['findings'])}))
sys.exit(0 if record['complete'] else 3)
