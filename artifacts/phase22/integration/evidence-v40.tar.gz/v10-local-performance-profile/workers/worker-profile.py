import collections,json,sys,threading,time
from pathlib import Path
sys.path.insert(0,'/private/tmp/mcp-phase22-options/src')
from sentinel.static import workers,path_flow
out=Path('/private/tmp/mcp-phase22-options/artifacts/phase22/integration/v10-local-performance-profile/workers');rule=sys.argv[-1];original=path_flow.combine;counts=collections.Counter();stop=threading.Event()
def counted(values,key=''):
 counts[(len(values),len({id(value) for value in values}),bool(key))]+=1
 return original(values,key)
path_flow.combine=counted
def snapshot():
 (out/(rule+'-counts.json')).write_text(json.dumps({str(k):v for k,v in counts.copy().items()},indent=2))
def snapshots():
 while not stop.wait(20):snapshot()
thread=threading.Thread(target=snapshots,daemon=True);thread.start();start=time.monotonic();cpu=time.process_time()
try:workers._worker()
finally:
 stop.set();thread.join();snapshot()
 (out/(rule+'-timing.json')).write_text(json.dumps({'wall':time.monotonic()-start,'cpu':time.process_time()-cpu}))
