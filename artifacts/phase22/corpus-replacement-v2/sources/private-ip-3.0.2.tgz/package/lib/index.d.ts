declare const _default: (ip: string) => boolean | undefined;
export default _default;
